package com.jarvis.ai.agent

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Base64
import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Jarvis'in telefonu KENDİSİ kullanması: "Google'dan X sitesini aç",
 * "YouTube'u aç ve şunu ara", bir oyunda/uygulamada belirli bir yere dokun
 * gibi HER türlü görev için genel bir gözlem → karar → eylem döngüsü.
 *
 * Her adımda: (1) erişilebilirlik servisinden ekrandaki öğeler okunur, öğe
 * listesi yetersizse (oyun, canvas, korumasız olmayan her ekran) ayrıca ekran
 * görüntüsü alınır; (2) Mistral (görsel destekli model) TEK bir sonraki eylemi
 * JSON olarak seçer; (3) eylem JarvisAccessibilityService ile uygulanır.
 * Çalıştığı sürece ekranın etrafında turuncu çerçeve görünür.
 *
 * SINIRLAR (dürüst olmak için): her adım bir model çağrısı olduğu için adım
 * başına ~2-5 sn sürer -- refleks isteyen gerçek zamanlı oyun işleri için
 * yavaştır; FLAG_SECURE'lu ekranlarda (bazı bankacılık/DRM uygulamaları)
 * Android ekran görüntüsünü ve öğeleri vermez.
 */
object PhoneAgent {
    private const val TAG = "PhoneAgent"
    private const val CHAT_URL = "https://api.mistral.ai/v1/chat/completions"
    private val MODELS = listOf("mistral-large-latest", "mistral-medium-latest", "mistral-small-latest")
    private const val MAX_STEPS = 24
    private const val HISTORY_SENT = 8

    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .callTimeout(70, TimeUnit.SECONDS)
        .build()

    @Volatile private var cancelled = false
    @Volatile var running = false
        private set

    /** DURDUR'a basılınca ya da kullanıcı "dur" deyince çağrılır. */
    fun cancel() { cancelled = true }

    class Outcome(val ok: Boolean, val message: String)

    private val SYSTEM_PROMPT = """
Sen, kullanıcının Android telefonunu onun adına kullanan bir ajansın. Her adımda ekranın durumunu (öğe listesi ve bazen ekran görüntüsü) görürsün ve YALNIZCA TEK bir sonraki eylemi JSON olarak verirsin. JSON dışında hiçbir şey yazma.

Biçim: {"thought":"çok kısa düşünce","action":"...", ...parametreler}

Eylemler:
- {"action":"home"}  ana ekrana dön
- {"action":"back"}  geri
- {"action":"open_app","name":"Google"}  yüklü uygulamayı adıyla aç
- {"action":"click","id":N}  ÖĞELER listesindeki [N] numaralı öğeye dokun (tercih edilen yol)
- {"action":"click_text","text":"..."}  ekranda bu yazıyı taşıyan öğeye dokun
- {"action":"tap","x":0-1000,"y":0-1000}  koordinata dokun (0,0 sol üst; 1000,1000 sağ alt). Öğe listesi boşsa/yetersizse (oyun, çizim alanı) ekran görüntüsüne bakarak kullan
- {"action":"long_press","x":..,"y":..}
- {"action":"type","text":"...","submit":true}  odaktaki yazı alanına yaz; submit=true ise klavyedeki ara/git tuşuna basar
- {"action":"swipe","x1":..,"y1":..,"x2":..,"y2":..}  kaydır/sürükle
- {"action":"scroll","direction":"down"}  sayfayı aşağı (içeriği yukarı) kaydır; "up" tersi
- {"action":"wait","ms":1500}  yükleme için bekle
- {"action":"done","summary":"kullanıcıya söylenecek tek cümle"}  hedef TAMAMLANDI
- {"action":"fail","reason":"neden yapılamadı"}

Kurallar:
1. Bir site/sayfa açma görevi: ana ekrandan Google uygulamasını aç (open_app "Google"; yoksa Chrome), arama kutusuna tıkla, aranan siteyi/konuyu yaz (submit:true), sonuçlardan doğru olanı seçip tıkla. Sayfa gerçekten açılınca done de.
2. open_app başarısız olursa ana ekranda uygulama simgesini bul ve ona dokun (gerekirse ana ekranda yukarı kaydırarak uygulama listesini aç).
3. Önce click id kullan. Öğe listesi yetersizse ekran görüntüsünden tap kullan.
4. Çerez/reklam/bildirim izni pencerelerini kapat veya reddet.
5. ASLA parola, kart/ödeme bilgisi yazma. Kullanıcının hedefinde AÇIKÇA yoksa satın alma, ödeme, para/mesaj gönderme, silme, bağış, abonelik gibi geri alınamaz işlemleri YAPMA; bunun yerine done ile kullanıcıdan onay iste.
6. Aynı eylemi üst üste tekrar etme; olmuyorsa farklı yol dene. Gerçekten ilerleyemiyorsan fail ver.
7. Oyunlarda ekran görüntüsünü incele, hedef nesneye tap ile dokun. Çok hızlı refleks isteyen bir iş senin hızına uygun değilse bunu fail ile dürüstçe söyle.
8. Ekran Jarvis uygulamasının kendisiyse ve hedef başka bir yerdeyse önce home ver.
""".trimIndent()

    fun runGoal(
        context: Context,
        apiKey: String,
        goal: String,
        fallbackShot: (() -> ByteArray?)? = null
    ): Outcome {
        val svc = JarvisAccessibilityService.instance
            ?: return Outcome(false, "NEEDS_ACCESSIBILITY")
        if (running) return Outcome(false, "Zaten çalışan bir telefon görevi var.")
        running = true
        cancelled = false
        svc.showGlow("başlıyor")
        try {
            return loop(context, svc, apiKey, goal, fallbackShot)
        } catch (e: Exception) {
            Log.w(TAG, "Ajan hatası", e)
            return Outcome(false, "Telefon görevi yarıda kesildi: ${e.message}")
        } finally {
            running = false
            svc.hideGlow()
        }
    }

    private fun loop(
        context: Context,
        svc: JarvisAccessibilityService,
        apiKey: String,
        goal: String,
        fallbackShot: (() -> ByteArray?)?
    ): Outcome {
        val history = ArrayList<String>()
        val recentSigs = ArrayList<String>()
        var failStreak = 0

        // Kullanıcının istediği akış: önce ana ekrana gel.
        svc.setGlowStatus("ana ekran")
        svc.home()
        sleep(900)

        for (step in 1..MAX_STEPS) {
            if (cancelled) return Outcome(false, "Görev durduruldu.")

            val snap = svc.snapshot()
            val sparse = snap.nodes.size < 6
            val wantShot = sparse || failStreak >= 2
            var shot: ByteArray? = null
            if (wantShot) {
                shot = svc.screenshotJpeg() ?: try { fallbackShot?.invoke() } catch (e: Exception) { null }
            }

            val decision = askModel(apiKey, goal, history, snap, shot) ?: run {
                failStreak++
                if (failStreak >= 4) return Outcome(false, "Yapay zekadan geçerli yanıt alınamadı.")
                sleep(600)
                null
            } ?: continue

            val action = decision.optString("action").trim()
            val thought = decision.optString("thought").take(80)
            if (cancelled) return Outcome(false, "Görev durduruldu.")

            if (action == "done") {
                return Outcome(true, decision.optString("summary").ifBlank { "Tamamlandı." })
            }
            if (action == "fail") {
                return Outcome(false, decision.optString("reason").ifBlank { "Yapamadım." })
            }

            // Döngü koruması.
            val sig = decision.toString()
            recentSigs.add(sig)
            if (recentSigs.size > 6) recentSigs.removeAt(0)
            val repeats = recentSigs.count { it == sig }
            if (repeats >= 5) return Outcome(false, "Aynı adımda takılıp kaldım, ilerleyemedim.")
            if (repeats >= 3) history.add("UYARI: bu eylemi $repeats kez tekrarladın, FARKLI bir yol dene.")

            svc.setGlowStatus(statusFor(action, decision, thought))
            val (ok, note) = execute(context, svc, decision)
            failStreak = if (ok) 0 else failStreak + 1
            history.add("adım $step: ${compact(decision)} → ${if (ok) "tamam" else "BAŞARISIZ"}${if (note.isBlank()) "" else " ($note)"}")

            sleep(if (action == "open_app" || action == "home") 1800L else 1000L)
        }
        return Outcome(false, "Adım sınırına ulaştım ama hedef tamamlanmadı.")
    }

    private fun statusFor(action: String, d: JSONObject, thought: String): String = when (action) {
        "home" -> "ana ekran"
        "back" -> "geri"
        "open_app" -> "${d.optString("name")} açılıyor"
        "type" -> "yazıyor"
        "scroll", "swipe" -> "kaydırıyor"
        "wait" -> "bekliyor"
        "click", "click_text", "tap", "long_press" -> if (thought.isNotBlank()) thought.take(32) else "dokunuyor"
        else -> action
    }

    private fun compact(d: JSONObject): String {
        val copy = JSONObject(d.toString())
        copy.remove("thought")
        return copy.toString()
    }

    private fun sleep(ms: Long) {
        try { Thread.sleep(ms) } catch (e: InterruptedException) { /* yoksay */ }
    }

    // ─── Eylem uygulama ─────────────────────────────────────────────────

    private fun execute(context: Context, svc: JarvisAccessibilityService, d: JSONObject): Pair<Boolean, String> {
        return try {
            when (d.optString("action")) {
                "home" -> svc.home() to ""
                "back" -> svc.back() to ""
                "open_app" -> openApp(context, svc, d.optString("name"))
                "click" -> {
                    if (!d.has("id")) false to "id yok"
                    else {
                        val ok = svc.clickById(d.optInt("id", -1))
                        ok to if (ok) "" else "öğe bulunamadı"
                    }
                }
                "click_text" -> {
                    val ok = svc.clickByText(d.optString("text"))
                    ok to if (ok) "" else "yazı ekranda bulunamadı"
                }
                "tap" -> svc.tapNormalized(d.optInt("x", 500), d.optInt("y", 500)) to ""
                "long_press" -> svc.tapNormalized(d.optInt("x", 500), d.optInt("y", 500), 800) to ""
                "type" -> {
                    val ok = svc.typeText(d.optString("text"), d.optBoolean("submit", false))
                    ok to if (ok) "" else "yazı alanı bulunamadı"
                }
                "swipe" -> svc.swipeNormalized(
                    d.optInt("x1", 500), d.optInt("y1", 700),
                    d.optInt("x2", 500), d.optInt("y2", 300)
                ) to ""
                "scroll" -> svc.scroll(d.optString("direction", "down") != "up") to ""
                "wait" -> {
                    sleep(d.optLong("ms", 1200).coerceIn(300, 5000)); true to ""
                }
                else -> false to "bilinmeyen eylem"
            }
        } catch (e: Exception) {
            Log.w(TAG, "Eylem hatası", e)
            false to (e.message ?: "hata")
        }
    }

    private fun openApp(context: Context, svc: JarvisAccessibilityService, name: String): Pair<Boolean, String> {
        val clean = name.trim()
        if (clean.isBlank()) return false to "ad boş"
        val pm = context.packageManager
        // Google için doğrudan bilinen paket.
        if (clean.equals("google", ignoreCase = true)) {
            if (svc.launchPackage("com.google.android.googlequicksearchbox")) return true to ""
        }
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = try { pm.queryIntentActivities(launcher, PackageManager.MATCH_ALL) } catch (e: Exception) { emptyList() }
        val q = clean.lowercase()
        fun label(i: android.content.pm.ResolveInfo) =
            try { i.loadLabel(pm).toString().lowercase() } catch (e: Exception) { "" }
        // Tam eşleşme > öneki eşleşen > içeren (ör. "Google" ararken "Google Play Store" seçilmesin).
        val match = apps.firstOrNull { label(it) == q }
            ?: apps.firstOrNull { label(it).startsWith(q) }
            ?: apps.firstOrNull { label(it).contains(q) }
        if (match != null && svc.launchPackage(match.activityInfo.packageName)) return true to ""
        if (q == "google") {
            // Google uygulaması yoksa tarayıcı.
            val chrome = apps.firstOrNull { label(it) == "chrome" }
            if (chrome != null && svc.launchPackage(chrome.activityInfo.packageName)) return true to "Google yok, Chrome açıldı"
        }
        return false to "uygulama bulunamadı, ana ekranda simgesini ara"
    }

    // ─── Model çağrısı ──────────────────────────────────────────────────

    private fun askModel(
        apiKey: String,
        goal: String,
        history: List<String>,
        snap: JarvisAccessibilityService.Snapshot,
        shot: ByteArray?
    ): JSONObject? {
        val text = buildString {
            append("HEDEF: ").append(goal).append("\n\n")
            if (history.isNotEmpty()) {
                append("SON ADIMLAR:\n")
                history.takeLast(HISTORY_SENT).forEach { append("- ").append(it).append('\n') }
                append('\n')
            }
            append("ŞU ANKİ EKRAN (paket: ").append(snap.packageName.ifBlank { "bilinmiyor" }).append(")\n")
            if (snap.nodes.isEmpty()) {
                append("Öğe listesi BOŞ (oyun/korumalı ekran olabilir).")
                append(if (shot != null) " Ekran görüntüsüne bak.\n" else " Ekran görüntüsü de alınamadı.\n")
            } else {
                append("ÖĞELER ([id] tür \"yazı\" @x,y):\n")
                snap.nodes.forEach {
                    append('[').append(it.id).append("] ").append(it.kind).append(" \"")
                        .append(it.label.replace("\"", "'")).append("\" @").append(it.cx).append(',').append(it.cy).append('\n')
                }
                if (shot != null) append("(Ekran görüntüsü de ekte.)\n")
            }
            append("\nSıradaki TEK eylemi JSON olarak ver.")
        }

        val userContent: Any = if (shot != null) {
            JSONArray().apply {
                put(JSONObject().put("type", "text").put("text", text))
                put(
                    JSONObject().put("type", "image_url")
                        .put("image_url", "data:image/jpeg;base64," + Base64.encodeToString(shot, Base64.NO_WRAP))
                )
            }
        } else text

        for (model in MODELS) {
            if (cancelled) return null
            try {
                val body = JSONObject().apply {
                    put("model", model)
                    put("temperature", 0.2)
                    put("max_tokens", 300)
                    put("response_format", JSONObject().put("type", "json_object"))
                    put("messages", JSONArray().apply {
                        put(JSONObject().put("role", "system").put("content", SYSTEM_PROMPT))
                        put(JSONObject().put("role", "user").put("content", userContent))
                    })
                }
                val req = Request.Builder()
                    .url(CHAT_URL)
                    .header("Authorization", "Bearer $apiKey")
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()
                http.newCall(req).execute().use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        Log.w(TAG, "$model → HTTP ${resp.code}: ${raw.take(200)}")
                        if (resp.code == 429) sleep(2500)
                        return@use
                    }
                    val msg = JSONObject(raw).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
                    val content = when (val c = msg?.opt("content")) {
                        is String -> c
                        is JSONArray -> buildString {
                            for (i in 0 until c.length()) append(c.optJSONObject(i)?.optString("text").orEmpty())
                        }
                        else -> ""
                    }
                    parseJson(content)?.let { return it }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Model isteği başarısız: $model", e)
            }
        }
        return null
    }

    private fun parseJson(content: String): JSONObject? {
        val a = content.indexOf('{')
        val b = content.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return try {
            val o = JSONObject(content.substring(a, b + 1))
            if (o.optString("action").isBlank()) null else o
        } catch (e: Exception) {
            null
        }
    }
}
