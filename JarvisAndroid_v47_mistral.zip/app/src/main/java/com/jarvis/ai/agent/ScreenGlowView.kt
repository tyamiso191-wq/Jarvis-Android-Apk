package com.jarvis.ai.agent

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import android.view.animation.LinearInterpolator

/**
 * Jarvis telefonu kullanırken ekranın dört kenarında nabız gibi atan turuncu
 * çerçeve + üstte küçük bir durum etiketi. Dokunmaları ENGELLEMEZ (pencere
 * FLAG_NOT_TOUCHABLE ile eklenir), sadece "şu an Jarvis kontrol ediyor"
 * uyarısıdır.
 */
class ScreenGlowView(context: Context) : View(context) {

    private val orange = 0xFFFF8A00.toInt()
    private val density = resources.displayMetrics.density

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val chipPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC000000.toInt() }
    private val chipBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = orange
        strokeWidth = density * 1.2f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = orange
        textSize = density * 12f
        typeface = Typeface.MONOSPACE
        textAlign = Paint.Align.CENTER
    }

    @Volatile var status: String = ""
        set(value) {
            field = value
            postInvalidate()
        }

    private var phase = 0f
    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1300
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // Dıştan içe doğru sönen katmanlar = yumuşak ışıma (blur'suz, donanım
        // hızlandırmasıyla uyumlu).
        val layers = 16
        val step = density * 1.6f
        val corner = density * 28f
        val rect = RectF()
        for (i in 0 until layers) {
            val fade = 1f - i / layers.toFloat()
            val alpha = (fade * fade * (120f + 110f * phase)).toInt().coerceIn(0, 255)
            strokePaint.color = (orange and 0x00FFFFFF) or (alpha shl 24)
            strokePaint.strokeWidth = step
            val inset = step * i + step / 2f
            rect.set(inset, inset, w - inset, h - inset)
            val r = (corner - inset).coerceAtLeast(0f)
            canvas.drawRoundRect(rect, r, r, strokePaint)
        }
        // Keskin dış çizgi.
        strokePaint.color = orange
        strokePaint.strokeWidth = density * 3f
        rect.set(density * 1.5f, density * 1.5f, w - density * 1.5f, h - density * 1.5f)
        canvas.drawRoundRect(rect, corner, corner, strokePaint)

        val label = status
        if (label.isNotBlank()) {
            val text = "JARVIS • $label"
            val tw = textPaint.measureText(text)
            val padX = density * 14f
            val chipH = density * 26f
            val top = density * 44f
            val chip = RectF(w / 2f - tw / 2f - padX, top, w / 2f + tw / 2f + padX, top + chipH)
            canvas.drawRoundRect(chip, chipH / 2f, chipH / 2f, chipPaint)
            canvas.drawRoundRect(chip, chipH / 2f, chipH / 2f, chipBorder)
            val baseline = top + chipH / 2f - (textPaint.descent() + textPaint.ascent()) / 2f
            canvas.drawText(text, w / 2f, baseline, textPaint)
        }
    }
}
