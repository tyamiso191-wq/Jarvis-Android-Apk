package com.jarvis.ai.agent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Jarvis'in telefonu GERÇEKTEN kullanabilmesini sağlayan erişilebilirlik
 * servisi: ana ekrana dönme, geri, öğelere dokunma, yazı yazma, kaydırma,
 * herhangi bir (oyun dahil) ekrana koordinatla dokunma ve ekran görüntüsü.
 * Bu servis Android'de KULLANICI tarafından elle açılmak zorundadır
 * (Ayarlar > Erişilebilirlik > J.A.R.V.I.S) -- uygulama bunu kendi kendine
 * açamaz, bu bir Android güvenlik kuralıdır.
 *
 * Çalışırken ekranın etrafında turuncu çerçeve gösterir (bkz. ScreenGlowView),
 * TYPE_ACCESSIBILITY_OVERLAY penceresiyle -- "üstte çiz" izni gerekmez.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "JarvisA11y"

        @Volatile var instance: JarvisAccessibilityService? = null
            private set

        fun isEnabled(): Boolean = instance != null

        fun openSettings(context: Context) {
            try {
                context.startActivity(
                    Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
                Log.w(TAG, "Erişilebilirlik ayarları açılamadı", e)
            }
        }
    }

    /** Ekrandaki bir öğenin ajan için sadeleştirilmiş hali. */
    class UiNode(
        val id: Int,
        val node: AccessibilityNodeInfo,
        val label: String,
        val kind: String,
        val clickable: Boolean,
        val editable: Boolean,
        val bounds: Rect,
        val cx: Int, // 0..1000 normalize
        val cy: Int
    )

    class Snapshot(val packageName: String, val nodes: List<UiNode>)

    private val main = Handler(Looper.getMainLooper())
    private val shotExecutor = Executors.newSingleThreadExecutor()
    private var glow: ScreenGlowView? = null
    @Volatile private var lastNodes: List<UiNode> = emptyList()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "Erişilebilirlik servisi bağlandı")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* sadece komut üzerine çalışıyoruz */ }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        hideGlow()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        hideGlow()
        super.onDestroy()
    }

    // ─── Turuncu çerçeve ───────────────────────────────────────────────

    fun showGlow(status: String) {
        main.post {
            try {
                val existing = glow
                if (existing != null) {
                    existing.status = status
                    return@post
                }
                val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val view = ScreenGlowView(this).apply { this.status = status }
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    lp.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                }
                wm.addView(view, lp)
                glow = view
            } catch (e: Exception) {
                Log.w(TAG, "Çerçeve gösterilemedi", e)
            }
        }
    }

    fun setGlowStatus(status: String) {
        main.post { glow?.status = status }
    }

    fun hideGlow() {
        main.post {
            try {
                val g = glow ?: return@post
                glow = null
                (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(g)
            } catch (e: Exception) {
                Log.w(TAG, "Çerçeve kaldırılamadı", e)
            }
        }
    }

    private fun setGlowVisible(visible: Boolean) {
        main.post { glow?.visibility = if (visible) View.VISIBLE else View.INVISIBLE }
    }

    // ─── Genel eylemler ─────────────────────────────────────────────────

    fun home(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun recents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)

    /** Uygulamayı paket adıyla açar (servis bağlamından -- arka plan kısıtına takılmaz). */
    fun launchPackage(pkg: String): Boolean {
        return try {
            val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            startActivity(intent)
            true
        } catch (e: Exception) {
            Log.w(TAG, "Uygulama açılamadı: $pkg", e)
            false
        }
    }

    fun openUrl(url: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            true
        } catch (e: Exception) {
            Log.w(TAG, "URL açılamadı: $url", e)
            false
        }
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    fun foregroundPackage(): String =
        try { rootInActiveWindow?.packageName?.toString().orEmpty() } catch (e: Exception) { "" }

    // ─── Dokunma / kaydırma (herhangi bir ekranda, oyunlar dahil) ─────

    /** x,y: 0..1000 normalize koordinat. */
    fun tapNormalized(x: Int, y: Int, holdMs: Long = 60): Boolean {
        val (w, h) = screenSize()
        return tapPx(x.coerceIn(0, 1000) / 1000f * w, y.coerceIn(0, 1000) / 1000f * h, holdMs)
    }

    fun tapPx(x: Float, y: Float, holdMs: Long = 60): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return dispatch(p, holdMs)
    }

    fun swipeNormalized(x1: Int, y1: Int, x2: Int, y2: Int, durationMs: Long = 350): Boolean {
        val (w, h) = screenSize()
        val p = Path().apply {
            moveTo(x1.coerceIn(0, 1000) / 1000f * w, y1.coerceIn(0, 1000) / 1000f * h)
            lineTo(x2.coerceIn(0, 1000) / 1000f * w, y2.coerceIn(0, 1000) / 1000f * h)
        }
        return dispatch(p, durationMs)
    }

    private fun dispatch(path: Path, durationMs: Long): Boolean {
        return try {
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(1)))
                .build()
            val latch = CountDownLatch(1)
            var ok = false
            val accepted = dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { ok = true; latch.countDown() }
                override fun onCancelled(g: GestureDescription?) { latch.countDown() }
            }, main)
            if (!accepted) return false
            latch.await(durationMs + 2500, TimeUnit.MILLISECONDS)
            ok
        } catch (e: Exception) {
            Log.w(TAG, "Hareket gönderilemedi", e)
            false
        }
    }

    // ─── Ekran içeriği ──────────────────────────────────────────────────

    fun snapshot(maxNodes: Int = 70): Snapshot {
        val root = try { rootInActiveWindow } catch (e: Exception) { null }
        val pkg = root?.packageName?.toString().orEmpty()
        val out = ArrayList<UiNode>()
        if (root != null) {
            val (sw, sh) = screenSize()
            var visited = 0
            fun walk(n: AccessibilityNodeInfo?, depth: Int) {
                if (n == null || depth > 28 || visited > 900 || out.size >= maxNodes) return
                visited++
                if (n.isVisibleToUser) {
                    val text = n.text?.toString()?.trim().orEmpty()
                    val desc = n.contentDescription?.toString()?.trim().orEmpty()
                    val hint = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        n.hintText?.toString()?.trim().orEmpty()
                    } else ""
                    val idName = n.viewIdResourceName?.substringAfterLast('/').orEmpty()
                    val label = listOf(text, desc, hint).firstOrNull { it.isNotBlank() } ?: idName
                    val interesting = label.isNotBlank() || n.isClickable || n.isEditable
                    if (interesting) {
                        val r = Rect()
                        n.getBoundsInScreen(r)
                        if (r.width() > 0 && r.height() > 0 && r.right > 0 && r.bottom > 0 && r.left < sw && r.top < sh) {
                            val kind = when {
                                n.isEditable -> "alan"
                                n.isCheckable -> "anahtar"
                                n.isClickable -> "buton"
                                else -> "metin"
                            }
                            out.add(
                                UiNode(
                                    id = out.size,
                                    node = n,
                                    label = label.take(60),
                                    kind = kind,
                                    clickable = n.isClickable,
                                    editable = n.isEditable,
                                    bounds = r,
                                    cx = (r.centerX() * 1000f / sw).toInt().coerceIn(0, 1000),
                                    cy = (r.centerY() * 1000f / sh).toInt().coerceIn(0, 1000)
                                )
                            )
                        }
                    }
                }
                for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
            }
            walk(root, 0)
        }
        lastNodes = out
        return Snapshot(pkg, out)
    }

    private fun clickNode(n: UiNode): Boolean {
        var cur: AccessibilityNodeInfo? = n.node
        var depth = 0
        while (cur != null && depth < 7) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
            depth++
        }
        // Tıklanabilir ata yoksa/işlemediyse: merkezine gerçek dokunuş.
        return tapPx(n.bounds.exactCenterX(), n.bounds.exactCenterY())
    }

    fun clickById(id: Int): Boolean {
        val n = lastNodes.firstOrNull { it.id == id } ?: return false
        return clickNode(n)
    }

    fun clickByText(text: String): Boolean {
        val q = text.trim().lowercase()
        if (q.isBlank()) return false
        val nodes = lastNodes.ifEmpty { snapshot().nodes }
        val hit = nodes.firstOrNull { it.label.lowercase() == q }
            ?: nodes.firstOrNull { it.label.lowercase().contains(q) }
        if (hit != null) return clickNode(hit)
        val root = try { rootInActiveWindow } catch (e: Exception) { null } ?: return false
        val found = root.findAccessibilityNodeInfosByText(text)
        val target = found?.firstOrNull { it.isVisibleToUser } ?: return false
        var cur: AccessibilityNodeInfo? = target
        var depth = 0
        while (cur != null && depth < 7) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
            depth++
        }
        val r = Rect()
        target.getBoundsInScreen(r)
        return tapPx(r.exactCenterX(), r.exactCenterY())
    }

    /** Odaktaki (yoksa ilk) yazı alanına metin yazar; submit ise klavyedeki "ara/git" tuşuna basar. */
    fun typeText(text: String, submit: Boolean): Boolean {
        val root = try { rootInActiveWindow } catch (e: Exception) { null } ?: return false
        val focused: AccessibilityNodeInfo? = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        val target: AccessibilityNodeInfo
        if (focused != null && focused.isEditable) {
            target = focused
        } else {
            val nodes = lastNodes.ifEmpty { snapshot().nodes }
            val ed = nodes.firstOrNull { it.editable } ?: return false
            clickNode(ed)
            Thread.sleep(500)
            ed.node.refresh()
            target = ed.node
        }
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val ok = target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok && submit) {
            Thread.sleep(350)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                target.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
            }
        }
        return ok
    }

    fun scroll(down: Boolean): Boolean =
        if (down) swipeNormalized(500, 720, 500, 280, 400) else swipeNormalized(500, 280, 500, 720, 400)

    // ─── Ekran görüntüsü (Android 11+) ──────────────────────────────────

    /** Arka plan thread'inden çağrılmalı. Başarısızsa (FLAG_SECURE, Android<11) null. */
    fun screenshotJpeg(maxEdge: Int = 1024): ByteArray? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        var result: ByteArray? = null
        val latch = CountDownLatch(1)
        setGlowVisible(false)
        try {
            Thread.sleep(120)
            takeScreenshot(Display.DEFAULT_DISPLAY, shotExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(shot: AccessibilityService.ScreenshotResult) {
                    try {
                        val hw = shot.hardwareBuffer
                        val bmp = Bitmap.wrapHardwareBuffer(hw, shot.colorSpace)
                        val soft = bmp?.copy(Bitmap.Config.ARGB_8888, false)
                        hw.close()
                        if (soft != null) {
                            val scale = maxEdge.toFloat() / maxOf(soft.width, soft.height)
                            val scaled = if (scale < 1f) {
                                Bitmap.createScaledBitmap(
                                    soft, (soft.width * scale).toInt(), (soft.height * scale).toInt(), true
                                )
                            } else soft
                            val bos = ByteArrayOutputStream()
                            scaled.compress(Bitmap.CompressFormat.JPEG, 72, bos)
                            result = bos.toByteArray()
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Ekran görüntüsü işlenemedi", e)
                    } finally {
                        latch.countDown()
                    }
                }

                override fun onFailure(errorCode: Int) {
                    Log.w(TAG, "Ekran görüntüsü alınamadı: $errorCode")
                    latch.countDown()
                }
            })
            latch.await(5, TimeUnit.SECONDS)
        } catch (e: Exception) {
            Log.w(TAG, "takeScreenshot hatası", e)
        } finally {
            setGlowVisible(true)
        }
        return result
    }
}
