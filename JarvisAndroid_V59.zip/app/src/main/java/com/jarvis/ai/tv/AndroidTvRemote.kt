package com.jarvis.ai.tv

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Log
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.math.BigInteger
import java.net.InetSocketAddress
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.util.Date
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import javax.security.auth.x500.X500Principal

/**
 * TCL (ve diğer) Google TV / Android TV'yi Wi-Fi üzerinden kumanda eder.
 * "Android TV Remote protocol v2" -- Google TV telefon uygulamasının kullandığı
 * protokol. ADB ya da geliştirici modu GEREKMEZ; TV ile telefon AYNI Wi-Fi'de olmalı.
 *
 * İlk kullanımda bir kez EŞLEŞTİRME gerekir: TV ekranında 6 haneli kod çıkar,
 * kullanıcı kodu Jarvis'e söyler/yazar. Sonra komutlar doğrudan çalışır.
 *
 * Protokol (6467 eşleştirme, 6466 kumanda; ikisi de TLS + istemci sertifikası,
 * mesajlar "uzunluk (varint) + protobuf") kütüphanesiz, elle kodlandı.
 * Cihazda/TV'de DENENMEDİ -- uyuşmazlık olursa hata mesajı adımı söyler.
 */
object AndroidTvRemote {
    private const val TAG = "AndroidTvRemote"
    private const val PREFS = "tv_remote"
    private const val KEY_IP = "ip"
    private const val KEY_PAIRED = "paired"
    private const val ALIAS = "jarvis_tv_client"
    private const val PORT_PAIR = 6467
    private const val PORT_REMOTE = 6466

    data class TvResult(val ok: Boolean, val code: String, val message: String)

    // ─── Tuş adları -> Android KeyEvent kodları ───────────────────────────
    private val KEYS = mapOf(
        "power" to 26, "home" to 3, "back" to 4,
        "up" to 19, "down" to 20, "left" to 21, "right" to 22, "ok" to 23,
        "volume_up" to 24, "volume_down" to 25, "mute" to 164,
        "play_pause" to 85, "play" to 126, "pause" to 127,
        "channel_up" to 166, "channel_down" to 167,
        "menu" to 82, "input" to 178, "settings" to 176,
        "wakeup" to 224, "sleep" to 223
    )
    val keyNames: List<String> get() = KEYS.keys.toList()

    private val APP_LINKS = mapOf(
        "youtube" to "https://www.youtube.com",
        "netflix" to "https://www.netflix.com",
        "spotify" to "https://open.spotify.com",
        "prime" to "https://app.primevideo.com",
        "disney" to "https://www.disneyplus.com",
        "twitch" to "https://www.twitch.tv"
    )
    val appNames: List<String> get() = APP_LINKS.keys.toList()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun isPaired(ctx: Context) = prefs(ctx).getBoolean(KEY_PAIRED, false)
    fun savedIp(ctx: Context): String? = prefs(ctx).getString(KEY_IP, null)?.takeIf { it.isNotBlank() }

    // ─── Minik protobuf yardımcıları ──────────────────────────────────────
    private fun writeVarint(os: OutputStream, value: Long) {
        var v = value
        while (true) {
            if ((v and 0x7FL.inv()) == 0L) { os.write(v.toInt()); return }
            os.write(((v and 0x7F) or 0x80).toInt())
            v = v ushr 7
        }
    }

    private fun vi(field: Int, v: Long): ByteArray = ByteArrayOutputStream().also {
        writeVarint(it, ((field shl 3) or 0).toLong()); writeVarint(it, v)
    }.toByteArray()

    private fun ld(field: Int, b: ByteArray): ByteArray = ByteArrayOutputStream().also {
        writeVarint(it, ((field shl 3) or 2).toLong()); writeVarint(it, b.size.toLong()); it.write(b)
    }.toByteArray()

    private fun cat(vararg parts: ByteArray): ByteArray = ByteArrayOutputStream().also { o -> parts.forEach { o.write(it) } }.toByteArray()

    private class Field(val num: Int, val varint: Long, val bytes: ByteArray?)

    private fun parse(b: ByteArray): List<Field> {
        val out = ArrayList<Field>()
        var i = 0
        fun readVar(): Long {
            var shift = 0; var r = 0L
            while (i < b.size) {
                val x = b[i++].toInt() and 0xFF
                r = r or ((x and 0x7F).toLong() shl shift)
                if (x and 0x80 == 0) return r
                shift += 7
            }
            return r
        }
        while (i < b.size) {
            val key = readVar()
            val num = (key ushr 3).toInt()
            when ((key and 7).toInt()) {
                0 -> out.add(Field(num, readVar(), null))
                2 -> {
                    val len = readVar().toInt()
                    if (len < 0 || i + len > b.size) return out
                    out.add(Field(num, 0, b.copyOfRange(i, i + len))); i += len
                }
                1 -> i += 8
                5 -> i += 4
                else -> return out
            }
        }
        return out
    }

    private fun writeFrame(os: OutputStream, payload: ByteArray) {
        val o = ByteArrayOutputStream()
        writeVarint(o, payload.size.toLong()); o.write(payload)
        os.write(o.toByteArray()); os.flush()
    }

    private fun readFrame(ins: InputStream): ByteArray? {
        var len = 0; var shift = 0
        while (true) {
            val x = ins.read()
            if (x < 0) return null
            len = len or ((x and 0x7F) shl shift)
            if (x and 0x80 == 0) break
            shift += 7
            if (shift > 28) return null
        }
        if (len < 0 || len > 1_000_000) return null
        val buf = ByteArray(len)
        var read = 0
        while (read < len) {
            val n = ins.read(buf, read, len - read)
            if (n < 0) return null
            read += n
        }
        return buf
    }

    // ─── TLS: istemci sertifikası Android KeyStore'da kalıcı ──────────────
    private fun keyStore(): KeyStore {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!ks.containsAlias(ALIAS)) {
            val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore")
            kpg.initialize(
                KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
                    .setKeySize(2048)
                    .setDigests(
                        KeyProperties.DIGEST_NONE, KeyProperties.DIGEST_SHA1, KeyProperties.DIGEST_SHA256,
                        KeyProperties.DIGEST_SHA384, KeyProperties.DIGEST_SHA512
                    )
                    .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1, KeyProperties.SIGNATURE_PADDING_RSA_PSS)
                    .setCertificateSubject(X500Principal("CN=jarvis-android"))
                    .setCertificateSerialNumber(BigInteger.valueOf(System.currentTimeMillis()))
                    .setCertificateNotBefore(Date(System.currentTimeMillis() - 86_400_000L))
                    .setCertificateNotAfter(Date(System.currentTimeMillis() + 20L * 365 * 86_400_000L))
                    .build()
            )
            kpg.generateKeyPair()
        }
        return ks
    }

    private fun connect(ip: String, port: Int): SSLSocket {
        val ks = keyStore()
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm()).apply { init(ks, null) }
        val trustAll = arrayOf<TrustManager>(object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        })
        val ctx = SSLContext.getInstance("TLSv1.2").apply { init(kmf.keyManagers, trustAll, null) }
        val raw = java.net.Socket()
        raw.connect(InetSocketAddress(ip, port), 5000)
        val s = ctx.socketFactory.createSocket(raw, ip, port, true) as SSLSocket
        s.soTimeout = 8000
        s.startHandshake()
        return s
    }

    private fun clientPublicKey(): RSAPublicKey =
        (keyStore().getCertificate(ALIAS) as X509Certificate).publicKey as RSAPublicKey

    private fun unsigned(n: BigInteger): ByteArray {
        var b = n.toByteArray()
        if (b.size > 1 && b[0] == 0.toByte()) b = b.copyOfRange(1, b.size)
        return b
    }

    // ─── TV'yi ağda bulma (mDNS) ──────────────────────────────────────────
    fun discover(ctx: Context, timeoutMs: Long = 6000): String? {
        val wifi = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val lock = try { wifi?.createMulticastLock("jarvis_nsd")?.apply { setReferenceCounted(false); acquire() } } catch (_: Exception) { null }
        val nsd = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
        val latch = CountDownLatch(1)
        val found = java.util.concurrent.atomic.AtomicReference<String?>(null)
        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onServiceFound(info: NsdServiceInfo) {
                try {
                    @Suppress("DEPRECATION")
                    nsd.resolveService(info, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(i: NsdServiceInfo, errorCode: Int) {}
                        override fun onServiceResolved(i: NsdServiceInfo) {
                            val h = i.host?.hostAddress
                            if (h != null && found.compareAndSet(null, h)) latch.countDown()
                        }
                    })
                } catch (_: Exception) { }
            }
            override fun onServiceLost(info: NsdServiceInfo) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) { latch.countDown() }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
        }
        return try {
            nsd.discoverServices("_androidtvremote2._tcp", NsdManager.PROTOCOL_DNS_SD, listener)
            latch.await(timeoutMs, TimeUnit.MILLISECONDS)
            found.get()
        } catch (e: Exception) {
            Log.w(TAG, "Keşif başarısız", e); null
        } finally {
            try { nsd.stopServiceDiscovery(listener) } catch (_: Exception) { }
            try { lock?.release() } catch (_: Exception) { }
        }
    }

    // ─── Eşleştirme ───────────────────────────────────────────────────────
    private class PairSession(val socket: SSLSocket, val ip: String)
    @Volatile private var pending: PairSession? = null

    private fun pairingMsg(vararg payload: ByteArray) = cat(vi(1, 2), vi(2, 200), *payload)

    private fun expectPairing(ins: InputStream, field: Int, step: String): Boolean {
        val frame = readFrame(ins) ?: return false
        val f = parse(frame)
        val status = f.firstOrNull { it.num == 2 }?.varint ?: 200
        return status == 200L && f.any { it.num == field }.also { if (!it) Log.w(TAG, "$step: beklenmeyen yanıt") }
    }

    /** TV'de 6 haneli kodu gösterir. [ipOverride] verilmezse kayıtlı/bulunan IP kullanılır. */
    fun startPairing(ctx: Context, ipOverride: String?): TvResult {
        val ip = ipOverride?.trim()?.takeIf { it.isNotBlank() } ?: savedIp(ctx) ?: discover(ctx)
            ?: return TvResult(false, "not_found", "TV ağda bulunamadı. Telefon ve TV aynı Wi-Fi'de mi? TV'nin IP adresini (Ayarlar > Ağ) söylersen onunla denerim.")
        pending?.let { try { it.socket.close() } catch (_: Exception) { } }
        pending = null
        return try {
            val s = connect(ip, PORT_PAIR)
            val os = s.outputStream; val ins = s.inputStream
            writeFrame(os, pairingMsg(ld(10, cat(ld(1, "androidtv-remote".toByteArray()), ld(2, "Jarvis".toByteArray())))))
            if (!expectPairing(ins, 11, "request")) return fail(s, "Eşleştirme isteği reddedildi")
            val enc = cat(vi(1, 3), vi(2, 6)) // HEX, 6 karakter
            writeFrame(os, pairingMsg(ld(20, cat(ld(1, enc), vi(3, 1)))))
            if (!expectPairing(ins, 20, "option")) return fail(s, "Seçenek aşaması başarısız")
            writeFrame(os, pairingMsg(ld(30, cat(ld(1, enc), vi(2, 1)))))
            if (!expectPairing(ins, 31, "config")) return fail(s, "Yapılandırma aşaması başarısız")
            prefs(ctx).edit().putString(KEY_IP, ip).apply()
            pending = PairSession(s, ip)
            TvResult(true, "code_shown", "TV ekranında 6 haneli kod görünmeli. Kodu söyle/yaz.")
        } catch (e: Exception) {
            Log.w(TAG, "Eşleştirme başlatılamadı", e)
            TvResult(false, "connect", "TV'ye bağlanılamadı (${e.javaClass.simpleName}: ${e.message}). TV açık ve aynı Wi-Fi'de mi?")
        }
    }

    private fun fail(s: SSLSocket, msg: String): TvResult {
        try { s.close() } catch (_: Exception) { }
        return TvResult(false, "pair_step", msg)
    }

    fun finishPairing(ctx: Context, codeRaw: String): TvResult {
        val session = pending ?: return TvResult(false, "no_session", "Önce eşleştirmeyi başlat (tv_pair_start).")
        val code = codeRaw.trim().replace(" ", "").uppercase()
        if (!Regex("[0-9A-F]{6}").matches(code)) return TvResult(false, "bad_code", "Kod 6 karakter (0-9, A-F) olmalı.")
        return try {
            val codeBytes = ByteArray(3) { code.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
            val serverKey = session.socket.session.peerCertificates[0].let { (it as X509Certificate).publicKey as RSAPublicKey }
            val client = clientPublicKey()
            val md = MessageDigest.getInstance("SHA-256")
            md.update(unsigned(client.modulus)); md.update(unsigned(client.publicExponent))
            md.update(unsigned(serverKey.modulus)); md.update(unsigned(serverKey.publicExponent))
            md.update(codeBytes, 1, 2)
            val hash = md.digest()
            if (hash[0] != codeBytes[0]) return TvResult(false, "wrong_code", "Kod yanlış görünüyor, TV'deki kodu tekrar kontrol et.")
            writeFrame(session.socket.outputStream, pairingMsg(ld(40, ld(1, hash))))
            val ok = expectPairing(session.socket.inputStream, 41, "secret")
            try { session.socket.close() } catch (_: Exception) { }
            pending = null
            if (ok) {
                prefs(ctx).edit().putBoolean(KEY_PAIRED, true).putString(KEY_IP, session.ip).apply()
                TvResult(true, "paired", "Eşleşti.")
            } else TvResult(false, "secret_rejected", "TV kodu kabul etmedi.")
        } catch (e: Exception) {
            Log.w(TAG, "Eşleştirme tamamlanamadı", e)
            TvResult(false, "pair_error", "Eşleştirme tamamlanamadı: ${e.message}")
        }
    }

    // ─── Kumanda ──────────────────────────────────────────────────────────
    private fun configureReply() = ld(1, cat(
        vi(1, 622),
        ld(2, cat(
            ld(1, "Jarvis".toByteArray()), ld(2, "Jarvis".toByteArray()), vi(3, 1),
            ld(4, "1".toByteArray()), ld(5, "androidtv-remote".toByteArray()), ld(6, "1.0.0".toByteArray())
        ))
    ))

    private fun withRemote(ctx: Context, block: (send: (ByteArray) -> Unit) -> Unit): TvResult {
        if (!isPaired(ctx)) return TvResult(false, "NEEDS_PAIRING", "TV henüz eşleşmedi.")
        var ip = savedIp(ctx)
        var socket: SSLSocket? = null
        var lastErr: Exception? = null
        for (attempt in 0..1) {
            if (ip == null) ip = discover(ctx)
            if (ip == null) break
            try { socket = connect(ip, PORT_REMOTE); break } catch (e: Exception) {
                lastErr = e
                // IP değişmiş olabilir: bir kez yeniden keşfet.
                ip = if (attempt == 0) discover(ctx, 4000) else null
                if (ip != null) prefs(ctx).edit().putString(KEY_IP, ip).apply()
            }
        }
        val s = socket ?: return TvResult(false, "unreachable",
            "TV'ye ulaşılamadı${lastErr?.let { " (${it.javaClass.simpleName})" } ?: ""}. TV tamamen kapalıysa ağdan komut alamaz; açıkken tekrar dene.")
        val lock = Any()
        val active = java.util.concurrent.atomic.AtomicBoolean(false)
        val send: (ByteArray) -> Unit = { payload -> synchronized(lock) { writeFrame(s.outputStream, payload) } }
        val reader = Thread {
            try {
                while (!s.isClosed) {
                    val frame = readFrame(s.inputStream) ?: break
                    for (f in parse(frame)) {
                        when (f.num) {
                            1 -> send(configureReply())
                            2 -> { send(ld(2, vi(1, 622))); active.set(true) }
                            8 -> {
                                val v = f.bytes?.let { b -> parse(b).firstOrNull { it.num == 1 }?.varint } ?: 0L
                                send(ld(9, vi(1, v)))
                            }
                        }
                    }
                }
            } catch (_: Exception) { }
        }.apply { isDaemon = true; start() }
        return try {
            val end = System.currentTimeMillis() + 6000
            while (!active.get() && System.currentTimeMillis() < end) Thread.sleep(80)
            if (!active.get()) return TvResult(false, "handshake", "TV el sıkışmasını tamamlamadı (eşleşme silinmiş olabilir, yeniden eşleştir).")
            block(send)
            Thread.sleep(350)
            TvResult(true, "ok", "Tamam")
        } catch (e: Exception) {
            Log.w(TAG, "Kumanda hatası", e)
            TvResult(false, "send_error", "Komut gönderilemedi: ${e.message}")
        } finally {
            try { s.close() } catch (_: Exception) { }
            reader.interrupt()
        }
    }

    fun press(ctx: Context, keyName: String, times: Int = 1): TvResult {
        val code = KEYS[keyName.trim().lowercase()]
            ?: return TvResult(false, "bad_key", "Bilinmeyen tuş: $keyName. Geçerli: ${KEYS.keys.joinToString()}")
        val n = times.coerceIn(1, 30)
        return withRemote(ctx) { send ->
            repeat(n) {
                send(ld(10, cat(vi(1, code.toLong()), vi(2, 3)))) // 3 = kısa basış
                Thread.sleep(140)
            }
        }
    }

    fun openApp(ctx: Context, app: String): TvResult {
        val key = app.trim().lowercase()
        val link = APP_LINKS[key] ?: app.trim().takeIf { it.startsWith("http") }
            ?: return TvResult(false, "bad_app", "Bilinmeyen uygulama: $app. Geçerli: ${APP_LINKS.keys.joinToString()} ya da bir https bağlantısı.")
        return withRemote(ctx) { send -> send(ld(90, ld(1, link.toByteArray()))) }
    }
}
