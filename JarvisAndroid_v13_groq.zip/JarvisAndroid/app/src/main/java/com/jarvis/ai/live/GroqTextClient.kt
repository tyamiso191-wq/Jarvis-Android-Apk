package com.jarvis.ai.live

import android.content.Context
import android.util.Log
import com.jarvis.ai.files.FileTool
import com.jarvis.ai.music.MusicController
import com.jarvis.ai.weather.WeatherClient
import com.jarvis.ai.web.WebSearchClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Groq'un OpenAI-uyumlu Chat Completions API'si (https://api.groq.com/openai/v1)
 * ile konuşur. GeminiTextClient'ın yerini alır — aynı public arayüzü
 * (verifyKey / sendMessage) sağladığı için JarvisViewModel'de sadece bu
 * sınıfın kullanılması yeterli.
 *
 * NEDEN GEMINI DEĞİL DE GROQ: Gemini'nin ücretsiz tier kotası çok düşüktü ve
 * bu key'de sürekli 429 (kota aşıldı) hatası alınıyordu — hem "yanlış model
 * seçildi" (nano-banana, customtools gibi sohbete uygun olmayan modellerin
 * sızması) hem de gerçek hesap/proje bazlı kota tükenmesi şeklinde. Groq'un
 * ücretsiz tier'ı (Llama modelleri için günde binlerce istek) çok daha
 * cömert ve model isimleri Gemini'nin aksine sık değişmiyor, bu yüzden
 * Gemini'deki gibi ağır bir "dinamik model keşfi" mekanizmasına gerek yok —
 * sabit, dokümante edilmiş birkaç model arasında basit bir fallback yeterli.
 *
 * WEB ARAMASI: Groq'un "compound" modelleri yerleşik arama yapıyor ama
 * kullanıcı tanımlı fonksiyonları desteklemiyor. Bu yüzden arama, kendi
 * fonksiyonlarımız olarak (web_search / read_webpage / get_weather) uygulamada
 * çalışıyor: model önce bu fonksiyonları çağırıp araştırıyor, sonuçları görüp
 * öyle cevap veriyor. Böylece hem dosya/müzik fonksiyonları hem canlı
 * araştırma bir arada çalışıyor.
 */
class GroqTextClient(
    private val apiKey: String,
    private val persona: String,
    private val appContext: Context
) {
    companion object {
        private const val TAG = "GroqTextClient"
        private const val CHAT_URL = "https://api.groq.com/openai/v1/chat/completions"
        private const val MODELS_URL = "https://api.groq.com/openai/v1/models"

        // Groq'un model isimleri Gemini'nin aksine sık değişmiyor ve
        // dokümante edilmiş durumda, o yüzden dinamik keşif yerine sabit,
        // bilinen bir sıra kullanıyoruz. Sıra: en iyi genel amaçlı/tool-use
        // model önce, sonra hızlı/hafif yedek, en sonda ek bir yedek.
        private val DEFAULT_CANDIDATES = listOf(
            "openai/gpt-oss-120b",
            "llama-3.3-70b-versatile",
            "openai/gpt-oss-20b",
            "qwen/qwen3.6-27b"
        )

        // HTTP 429 alan bir model bu süre boyunca tekrar denenmez.
        private const val COOLDOWN_MS = 60_000L

        // Bir sendMessage() çağrısında en fazla bu kadar farklı model denenir.
        private const val MAX_ATTEMPTS_PER_MESSAGE = 3

        // Art arda bu kadar model 429 döndürürse hesabın genel limiti
        // dolmuş demektir, daha fazla denemek yerine erken kes.
        private const val MAX_CONSECUTIVE_429 = 3

        // Başarısız denemeler arasında küçük bir bekleme (rate-limit
        // burst'ünü tetiklememek için).
        private const val ATTEMPT_DELAY_MS = 400L

        // Araştırma (arama + sayfa okuma + cevap) birkaç tur sürebilir.
        private const val MAX_TOOL_TURNS = 7

        private const val PREFS_NAME = "groq_text_client_cache"
        private const val PREF_WORKING_MODEL = "working_model"
    }

    /** Araç çalışırken arayüzün durum yazısını güncellemesi için (örn. "ARAŞTIRIYOR"). */
    @Volatile var onToolUse: ((String) -> Unit)? = null

    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .callTimeout(50, TimeUnit.SECONDS)
        .build()

    // Süreç boyunca (ve SharedPreferences sayesinde uygulama yeniden
    // başlasa bile) hatırlanan, en son başarılı olan model.
    @Volatile private var workingModel: String? = prefs.getString(PREF_WORKING_MODEL, null)

    // HTTP 429 alınan modeller burada, tekrar denenebilecekleri zaman
    // damgasıyla tutulur.
    private val modelCooldownUntil = ConcurrentHashMap<String, Long>()

    private fun isOnCooldown(model: String): Boolean {
        val until = modelCooldownUntil[model] ?: return false
        return System.currentTimeMillis() < until
    }

    private fun markCooldown(model: String) {
        modelCooldownUntil[model] = System.currentTimeMillis() + COOLDOWN_MS
    }

    private fun persistWorkingModel(model: String) {
        prefs.edit().putString(PREF_WORKING_MODEL, model).apply()
    }

    /** Basit bir GET ile key'in geçerli olup olmadığını hızlıca doğrular. */
    suspend fun verifyKey(): String? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url(MODELS_URL)
                .header("Authorization", "Bearer $apiKey")
                .build()
            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    null
                } else {
                    val body = try { resp.body?.string()?.take(300) } catch (e: Exception) { null }
                    "API anahtarı kontrolü başarısız: HTTP ${resp.code}${if (!body.isNullOrBlank()) " — $body" else ""}"
                }
            }
        } catch (e: Exception) {
            "Ağa ulaşılamıyor (${e.javaClass.simpleName}: ${e.message}). İnternet bağlantını kontrol et."
        }
    }

    /**
     * conversation: sırayla ("user", metin) / ("model", metin) geçmişi
     * (ViewModel Gemini konvansiyonunu koruyor, burada "model" -> "assistant"
     * olarak çevriliyor).
     */
    suspend fun sendMessage(
        conversation: List<Pair<String, String>>,
        deviceContext: String = ""
    ): Result<String> =
        withContext(Dispatchers.IO) {
            val fullInstruction = if (deviceContext.isBlank()) persona else "$persona\n\n$deviceContext"

            val baseOrder = workingModel?.let { pref ->
                listOf(pref) + DEFAULT_CANDIDATES.filterNot { it == pref }
            } ?: DEFAULT_CANDIDATES

            val order = baseOrder
                .sortedBy { if (isOnCooldown(it)) 1 else 0 }
                .take(MAX_ATTEMPTS_PER_MESSAGE)

            var lastError: String? = null
            var consecutive429 = 0
            for (model in order) {
                val result = callModel(model, conversation, fullInstruction)
                if (result.isSuccess) {
                    workingModel = model
                    persistWorkingModel(model)
                    return@withContext result
                }
                lastError = result.exceptionOrNull()?.message
                if (lastError?.contains("HTTP 429") == true) {
                    markCooldown(model)
                    consecutive429++
                    if (consecutive429 >= MAX_CONSECUTIVE_429) {
                        Log.w(TAG, "Art arda $consecutive429 model 429 döndürdü — deneme durduruldu.")
                        break
                    }
                } else {
                    consecutive429 = 0
                }
                if (result.isFailure) delay(ATTEMPT_DELAY_MS)
                Log.w(TAG, "Model başarısız, sıradaki deneniyor: $model → $lastError")
            }

            val finalMessage = if (consecutive429 >= MAX_CONSECUTIVE_429) {
                "Birden fazla model art arda 429 (kota aşıldı) döndürdü — API anahtarının genel istek/kota limiti doldu. console.groq.com/settings/limits üzerinden kontrol et. Son hata: $lastError"
            } else {
                lastError ?: "Bilinmeyen hata"
            }
            Result.failure(IOException(finalMessage))
        }

    private fun callModel(
        model: String,
        conversation: List<Pair<String, String>>,
        systemInstruction: String
    ): Result<String> {
      return try {
        // OpenAI-uyumlu "messages" dizisi: sistem mesajı + geçmiş.
        val messages = JSONArray().apply {
            put(JSONObject().apply {
                put("role", "system")
                put("content", systemInstruction)
            })
            conversation.forEach { (role, text) ->
                put(JSONObject().apply {
                    put("role", if (role == "model") "assistant" else "user")
                    put("content", text)
                })
            }
        }

        var lastText = ""
        for (turn in 0 until MAX_TOOL_TURNS) {
            // Son turda tool_choice=none: model artık elindekiyle cevap vermek zorunda.
            val lastTurn = turn == MAX_TOOL_TURNS - 1
            val body = JSONObject().apply {
                put("model", model)
                put("messages", messages)
                put("temperature", 0.7)
                // gpt-oss gibi muhakeme yapan modellerde düşünme token'ları da
                // bu sınıra dahil; 400 çok azdı ve cevap boş kalabiliyordu.
                put("max_tokens", 1500)
                if (model.startsWith("openai/gpt-oss")) put("reasoning_effort", "low")
                put("tools", buildTools())
                put("tool_choice", if (lastTurn) "none" else "auto")
            }

            val req = Request.Builder()
                .url(CHAT_URL)
                .header("Authorization", "Bearer $apiKey")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val message = client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return Result.failure(IOException("$model → HTTP ${resp.code}: ${raw.take(200)}"))
                }
                JSONObject(raw).optJSONArray("choices")
                    ?.optJSONObject(0)
                    ?.optJSONObject("message")
            } ?: return Result.failure(IOException("$model → boş yanıt döndü"))

            val toolCalls = message.optJSONArray("tool_calls")
            val text = message.optString("content", "")

            if (toolCalls == null || toolCalls.length() == 0) {
                if (text.isBlank()) {
                    return Result.failure(IOException("$model → boş yanıt döndü"))
                }
                return Result.success(text)
            }

            // Modelin fonksiyon çağırma turunu sohbet geçmişine ekle
            // (OpenAI formatı: assistant mesajı tool_calls alanıyla birlikte).
            messages.put(JSONObject().apply {
                put("role", "assistant")
                put("content", if (text.isBlank()) JSONObject.NULL else text)
                put("tool_calls", toolCalls)
            })

            // Her fonksiyon çağrısını GERÇEKTEN çalıştır, sonucu "tool"
            // rolüyle geri besle.
            for (i in 0 until toolCalls.length()) {
                val call = toolCalls.optJSONObject(i) ?: continue
                val fn = call.optJSONObject("function") ?: continue
                val name = fn.optString("name")
                val argsRaw = fn.optString("arguments", "{}")
                val args = try { JSONObject(argsRaw) } catch (e: Exception) { JSONObject() }
                try { onToolUse?.invoke(name) } catch (e: Exception) { Log.w(TAG, "onToolUse", e) }
                val outcome = executeFunction(name, args)
                messages.put(JSONObject().apply {
                    put("role", "tool")
                    put("tool_call_id", call.optString("id"))
                    put("content", outcome.toString())
                })
            }

            lastText = text
        }

        if (lastText.isNotBlank()) Result.success(lastText)
        else Result.failure(IOException("$model → fonksiyon döngüsü tamamlanamadı"))
      } catch (e: Exception) {
        Result.failure(e)
      }
    }

    private fun buildTools(): JSONArray = JSONArray()
        .put(functionTool(
            name = "web_search",
            description = "İnternette (Google/DuckDuckGo/Bing benzeri) arama yapar ve sonuç başlıkları + özetleri döndürür. Güncel bilgi, haber, fiyat, skor, okul/sınav/tatil tarihleri, kişiler, ürünler, 'nedir/kimdir/ne zaman' gibi eğitim verinde olmayabilecek ya da emin olmadığın HER konuda ÖNCE bunu çağır, sonra sonuçlara dayanarak cevap ver. Kısa ve net Türkçe sorgu yaz (örn. 'MEB 2026 yaz tatili ne zaman'). Haber/gündem sorusu ise news=true yap.",
            properties = JSONObject().apply {
                put("query", JSONObject().apply {
                    put("type", "string")
                    put("description", "Arama sorgusu")
                })
                put("news", JSONObject().apply {
                    put("type", "boolean")
                    put("description", "Güncel haber araması ise true")
                })
            },
            required = listOf("query")
        ))
        .put(functionTool(
            name = "read_webpage",
            description = "web_search sonucundaki bir sayfanın (url) metnini okur. Arama özetleri cevap için yetersizse en alakalı 1 sonucun sayfasını bununla oku.",
            properties = JSONObject().apply {
                put("url", JSONObject().apply {
                    put("type", "string")
                    put("description", "web_search sonucundan alınan tam adres")
                })
            },
            required = listOf("url")
        ))
        .put(functionTool(
            name = "get_weather",
            description = "Herhangi bir şehir için anlık hava durumu ve günlük tahmin verir (yarın, hafta sonu, yağmur olur mu vb.). Şehir söylenmemişse city'yi boş bırak (kullanıcının bulunduğu yer kullanılır).",
            properties = JSONObject().apply {
                put("city", JSONObject().apply {
                    put("type", "string")
                    put("description", "Şehir adı, örn. Ankara")
                })
                put("days", JSONObject().apply {
                    put("type", "integer")
                    put("description", "Kaç günlük tahmin (1-7), varsayılan 3")
                })
            },
            required = emptyList()
        ))
        .put(functionTool(
            name = "create_file",
            description = "Kullanıcı için düz metin bir dosya (örn. .txt, .md, .json, .csv) oluşturup İndirilenler klasörüne kaydeder. Kullanıcı açıkça bir not/liste/metin kaydetmeni istediğinde çağır.",
            properties = JSONObject().apply {
                put("filename", JSONObject().apply {
                    put("type", "string")
                    put("description", "Uzantılı dosya adı, örn. notlar.txt")
                })
                put("content", JSONObject().apply {
                    put("type", "string")
                    put("description", "Dosyanın tam içeriği")
                })
            },
            required = listOf("filename", "content")
        ))
        .put(functionTool(
            name = "create_zip",
            description = "Birden fazla metin dosyasını tek bir zip arşivinde birleştirip İndirilenler klasörüne kaydeder.",
            properties = JSONObject().apply {
                put("zip_filename", JSONObject().apply {
                    put("type", "string")
                    put("description", "Arşiv adı, .zip uzantılı ya da uzantısız")
                })
                put("files", JSONObject().apply {
                    put("type", "array")
                    put("items", JSONObject().apply {
                        put("type", "object")
                        put("properties", JSONObject().apply {
                            put("filename", JSONObject().put("type", "string"))
                            put("content", JSONObject().put("type", "string"))
                        })
                        put("required", JSONArray().put("filename").put("content"))
                    })
                })
            },
            required = listOf("zip_filename", "files")
        ))
        .put(functionTool(
            name = "play_song",
            description = "Kullanıcının istediği şarkıyı çalmaya başlar: önce telefonun yerel müzik kütüphanesinde arar, yoksa YouTube'da arayıp bulduğu ses akışını YİNE arka planda, ekran değiştirmeden çalar. status=playing_local ya da status=playing_stream dönerse şarkı fiilen çalmaya başlamıştır. Sadece status=opened_youtube_search dönerse (nadir, ses akışı çözülemediği durumlar) kullanıcıya YouTube'da açtığını söyle.",
            properties = JSONObject().apply {
                put("query", JSONObject().apply {
                    put("type", "string")
                    put("description", "Şarkı adı ve varsa sanatçı, örn. 'Tarkan Kuzu Kuzu'")
                })
            },
            required = listOf("query")
        ))
        .put(functionTool(
            name = "stop_song",
            description = "Şu anda arka planda çalmakta olan şarkıyı/müziği durdurur. Kullanıcı 'durdur', 'kapat', 'yeter', 'müziği kes' gibi bir şey söylediğinde ve bir şarkı çalıyorsa çağır.",
            properties = JSONObject(),
            required = emptyList()
        ))

    private fun functionTool(
        name: String,
        description: String,
        properties: JSONObject,
        required: List<String>
    ): JSONObject = JSONObject().apply {
        put("type", "function")
        put("function", JSONObject().apply {
            put("name", name)
            put("description", description)
            put("parameters", JSONObject().apply {
                put("type", "object")
                put("properties", properties)
                put("required", JSONArray(required))
            })
        })
    }

    private fun executeFunction(name: String, args: JSONObject): JSONObject = try {
        when (name) {
            "create_file" -> {
                val filename = args.optString("filename").ifBlank { "not.txt" }
                val content = args.optString("content")
                val saved = FileTool.createTextFile(appContext, filename, content)
                JSONObject().put("status", "ok").put("path", saved.displayPath)
            }
            "create_zip" -> {
                val zipName = args.optString("zip_filename").ifBlank { "arsiv.zip" }
                val filesArr = args.optJSONArray("files") ?: JSONArray()
                val entries = mutableListOf<Pair<String, String>>()
                for (i in 0 until filesArr.length()) {
                    val f = filesArr.optJSONObject(i) ?: continue
                    entries += f.optString("filename", "dosya_$i.txt") to f.optString("content")
                }
                val saved = FileTool.createZipFile(appContext, zipName, entries)
                JSONObject().put("status", "ok").put("path", saved.displayPath)
            }
            "play_song" -> {
                val query = args.optString("query")
                when (val result = MusicController.play(appContext, query)) {
                    is MusicController.PlayResult.PlayingLocal ->
                        JSONObject().put("status", "playing_local")
                            .put("title", result.title).put("artist", result.artist)
                    is MusicController.PlayResult.PlayingStream ->
                        JSONObject().put("status", "playing_stream")
                            .put("title", result.title).put("artist", result.artist)
                    is MusicController.PlayResult.OpenedYoutubeSearch ->
                        JSONObject().put("status", "opened_youtube_search").put("query", result.query)
                    is MusicController.PlayResult.PermissionMissing ->
                        JSONObject().put("status", "error").put("message", result.message)
                    is MusicController.PlayResult.Error ->
                        JSONObject().put("status", "error").put("message", result.message)
                }
            }
            "web_search" -> WebSearchClient.search(
                args.optString("query"),
                args.optBoolean("news", false)
            )
            "read_webpage" -> WebSearchClient.readPage(args.optString("url"))
            "get_weather" -> WeatherClient.forecastFor(
                args.optString("city").takeIf { it.isNotBlank() && it != "null" },
                if (args.has("days")) args.optInt("days", 3) else 3
            )
            "stop_song" -> {
                MusicController.stop(appContext)
                JSONObject().put("status", "ok")
            }
            else -> JSONObject().put("status", "error").put("message", "Bilinmeyen fonksiyon: $name")
        }
    } catch (e: Exception) {
        JSONObject().put("status", "error").put("message", e.message ?: "bilinmeyen hata")
    }
}
