package com.jarvis.ai.agents

import kotlinx.coroutines.test.runTest
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.IOException

class FallbackAndLedgerTest {

    private fun body() = JSONObject().put(
        "messages", JSONArray().put(JSONObject().put("role", "user").put("content", "selam"))
    )

    private class Rig(handler: suspend (JSONObject) -> RawResponse) {
        val transport = FakeTransport(handler)
        val ledger = UsageLedger()
        val events = EventLog()
        val health = HealthTracker()
        val runner = FallbackRunner(health, events, delayFn = {})
        val caller = LlmCaller(transport, ledger)
        suspend fun ask(models: List<ModelInfo>, body: JSONObject): LlmReply =
            runner.run("t1", "test", models) { m -> caller.complete(CallContext("t1", "AG#1", "test"), m, JSONObject(body.toString())) }
    }

    // 1) Tek modelle normal sohbet: tek çağrı, yedek yok
    @Test fun singleModelChatMakesExactlyOneCall() = runTest {
        val rig = Rig { okResp("merhaba") }
        val r = rig.ask(listOf(mkModel("a/one"), mkModel("b/two")), body())
        assertEquals("a/one", r.modelId)
        assertEquals(1, rig.transport.calls.get())
        assertTrue(rig.events.events.value.none { it.kind == EventKind.FALLBACK })
    }

    // 5) 429 → yedek modele geçiş + cooldown + olay kaydı
    @Test fun rateLimitFallsBackToNextModel() = runTest {
        val rig = Rig { b -> if (b.optString("model") == "a/one") errResp(429, "Rate limit exceeded", 30_000) else okResp("tamam") }
        val r = rig.ask(listOf(mkModel("a/one"), mkModel("b/two")), body())
        assertEquals("b/two", r.modelId)
        assertEquals(2, rig.transport.calls.get())
        assertFalse(rig.health.isUsable(mkModel("a/one")))
        assertTrue(rig.events.events.value.any { it.kind == EventKind.FALLBACK })
        // Başarısız çağrı da defterde (başarısız olarak) kayıtlı
        assertEquals(1, rig.ledger.summarize().failedCalls)
    }

    // 6) Bir sağlayıcı/model bağlantısı kesilirse: aynı modelde tek kısa deneme, sonra yedek
    @Test fun connectionDropFallsBack() = runTest {
        val rig = Rig { b -> if (b.optString("model") == "a/one") throw IOException("bağlantı koptu") else okResp("tamam") }
        val r = rig.ask(listOf(mkModel("a/one"), mkModel("b/two")), body())
        assertEquals("b/two", r.modelId)
        assertEquals(3, rig.transport.calls.get()) // a (1) + a (yeniden deneme) + b
    }

    // 6b) Tamamen bağlantı yoksa sonsuz döngü YOK; açık mesaj
    @Test fun totalNetworkFailureStopsWithClearMessage() = runTest {
        val rig = Rig { throw IOException("yok") }
        try {
            rig.ask(listOf(mkModel("a/1"), mkModel("b/2"), mkModel("c/3"), mkModel("d/4")), body())
            fail("istisna bekleniyordu")
        } catch (e: AiUnavailableException) {
            assertTrue(e.userMessage.contains("ulaşılamıyor"))
            assertTrue(rig.transport.calls.get() <= 6)
        }
    }

    // 8) Kredi bitti: sonsuz deneme yok, kredi mesajı, çağrı sayısı sınırlı
    @Test fun creditsExhaustedStopsAndSaysSo() = runTest {
        val rig = Rig { errResp(402, "Insufficient credits") }
        try {
            rig.ask(listOf(mkModel("a/1"), mkModel("b/2"), mkModel("f/free:free", free = true)), body())
            fail("istisna bekleniyordu")
        } catch (e: AiUnavailableException) {
            assertTrue(e.userMessage.contains("kredi"))
            assertTrue(ErrorKind.CREDITS in e.kinds)
            assertTrue(rig.transport.calls.get() <= 3)
        }
    }

    // Kredi bitti ama ücretsiz model çalışıyorsa ona geçilir (aynı modele değil, farklı sınıfa)
    @Test fun creditsExhaustedFallsBackToFreeModel() = runTest {
        val rig = Rig { b -> if (b.optString("model").endsWith(":free")) okResp("ücretsiz cevap") else errResp(402, "Insufficient credits") }
        val r = rig.ask(listOf(mkModel("a/paid"), mkModel("b/paid2"), mkModel("f/free:free", free = true)), body())
        assertEquals("f/free:free", r.modelId)
        assertEquals(2, rig.transport.calls.get()) // ikinci ücretli model atlandı
    }

    // Bağlam aşımı: yalnızca daha geniş bağlamlı modele geçilir
    @Test fun contextOverflowOnlyTriesLargerContextModels() = runTest {
        val rig = Rig { b ->
            if (b.optString("model") == "a/small") errResp(400, "maximum context length is 8192 tokens") else okResp("ok")
        }
        val r = rig.ask(listOf(mkModel("a/small", ctx = 8_000), mkModel("b/same", ctx = 8_000), mkModel("c/big", ctx = 200_000)), body())
        assertEquals("c/big", r.modelId)
        assertEquals(2, rig.transport.calls.get())
    }

    @Test fun authErrorStopsImmediately() = runTest {
        val rig = Rig { errResp(401, "No auth credentials found") }
        try {
            rig.ask(listOf(mkModel("a/1"), mkModel("b/2")), body())
            fail()
        } catch (e: AiUnavailableException) {
            assertTrue(e.userMessage.contains("anahtar"))
            assertEquals(1, rig.transport.calls.get())
        }
    }

    // 10) API anahtarı yoksa çökmeden doğru mesaj (gerçek OpenRouterClient, ağ yok)
    @Test fun missingApiKeyGivesCleanMessageWithoutCrash() = runTest {
        val client = OpenRouterClient({ null })
        val ledger = UsageLedger()
        val caller = LlmCaller(client, ledger)
        val runner = FallbackRunner(HealthTracker(), EventLog(), delayFn = {})
        try {
            runner.run("t", "x", listOf(mkModel("a/1"))) { m -> caller.complete(CallContext("t", "a", "x"), m, body()) }
            fail()
        } catch (e: AiUnavailableException) {
            assertTrue(e.userMessage.contains("anahtar"))
        }
    }

    // 11) Token ve maliyet kayıtları: gerçek veri, tahmin gerçekmiş gibi gösterilmez
    @Test fun ledgerSeparatesReportedComputedAndUnknownUsage() = runTest {
        val model = mkModel("a/one", price = 0.000002)
        val responses = ArrayDeque(listOf(
            okResp("1", prompt = 100, completion = 50, cost = 0.002),   // bildirilen maliyet
            okResp("2", prompt = 100, completion = 50, cost = null),    // token var, maliyet yok -> hesaplanır
            okResp("3", prompt = null, completion = null, cost = null)  // kullanım yok -> bilinmiyor
        ))
        val rig = Rig { responses.removeFirst() }
        repeat(3) { rig.ask(listOf(model), body()) }
        val s = rig.ledger.summarize()
        assertEquals(3, s.calls)
        assertEquals(200L, s.promptTokens)
        assertEquals(100L, s.completionTokens)
        assertEquals(0.002, s.reportedCostUsd, 1e-9)
        assertEquals(150 * 0.000002, s.computedCostUsd, 1e-9)
        assertEquals(1, s.unknownUsageCalls)
        assertEquals(0.002 + 150 * 0.000002, s.costUsd, 1e-9)
    }

    // Model 401 dönse bile anahtar hâlâ geçerliyse (model/sağlayıcıya özgü red) sıradaki modele geçilir
    @Test fun authFromOneModelButValidKeyFallsBack() = runTest {
        val transport = FakeTransport { b -> if (b.optString("model") == "a/one") errResp(401, "User not found") else okResp("tamam") }
        val health = HealthTracker()
        val runner = FallbackRunner(health, EventLog(), delayFn = {}, keyStillValid = { true })
        val caller = LlmCaller(transport, UsageLedger())
        val r = runner.run("t", "x", listOf(mkModel("a/one"), mkModel("b/two"))) { m ->
            caller.complete(CallContext("t", "a", "x"), m, body())
        }
        assertEquals("b/two", r.modelId)
        assertFalse(health.authBroken)
    }

    // Anahtar gerçekten geçersizse durur ve açık mesaj verir
    @Test fun authWithInvalidKeyStopsWithMessage() = runTest {
        val transport = FakeTransport { errResp(401, "No auth credentials found") }
        val runner = FallbackRunner(HealthTracker(), EventLog(), delayFn = {}, keyStillValid = { false })
        val caller = LlmCaller(transport, UsageLedger())
        try {
            runner.run("t", "x", listOf(mkModel("a/one"), mkModel("b/two"))) { m ->
                caller.complete(CallContext("t", "a", "x"), m, body())
            }
            fail()
        } catch (e: AiUnavailableException) {
            assertTrue(e.userMessage.contains("anahtar"))
            assertEquals(1, transport.calls.get())
        }
    }
}
