package com.jarvis.ai.agents

import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OrchestratorTest {

    private val sixRoles = arrayOf("CODING", "ANALYSIS", "WRITING", "OPTIMIZATION", "SECURITY", "TESTING")
    private fun settings(conc: Int) = AgentSettings(maxConcurrent = conc, taskTokenBudget = 2_000_000, taskCostBudgetUsd = 50.0)

    // 3) En az 5 ajan GERÇEKTEN eşzamanlı çalışır
    @Test fun runsAtLeastFiveAgentsInParallel() = runTest {
        val probe = ConcurrencyProbe(sixRoles)
        val h = Harness(FOUR_MODELS, settings(6)) { probe.handle(it) }
        val r = h.orchestrator.runMultiAgent("büyük bir proje", HIGH_PROFILE)
        assertTrue(r.isSuccess)
        assertTrue("eşzamanlı ajan sayısı: ${probe.maxActive.get()}", probe.maxActive.get() >= 5)
        val t = h.orchestrator.tasks.value.last()
        assertEquals(TaskPhase.DONE, t.phase)
        assertEquals(6, t.agents.count { it.status == AgentStatus.DONE })
    }

    // 4) Eşzamanlı ajan sınırı uygulanır
    @Test fun respectsMaxConcurrentLimit() = runTest {
        val probe = ConcurrencyProbe(sixRoles)
        val h = Harness(FOUR_MODELS, settings(2)) { probe.handle(it) }
        val r = h.orchestrator.runMultiAgent("büyük bir proje", HIGH_PROFILE)
        assertTrue(r.isSuccess)
        assertTrue("sınır aşıldı: ${probe.maxActive.get()}", probe.maxActive.get() <= 2)
        assertTrue(probe.maxActive.get() >= 1)
    }

    // 7) Bir ajan başarısız olunca diğerlerinin sonuçları korunur; nihai yanıt yine tek parça
    @Test fun failedAgentDoesNotLoseOthersResults() = runTest {
        val h = Harness(FOUR_MODELS, settings(5)) { body ->
            val sys = systemOf(body)
            when {
                sys.contains("görev planlayıcısısın") -> okResp(planJson("CODING", "ANALYSIS", "SECURITY"))
                sys.contains("Security Agent") -> errResp(400, "geçersiz istek")
                sys.contains("çoklu ajan sisteminde") -> okResp("başarılı ajan çıktısı, yeterince uzun bir metin.")
                else -> okResp("Nihai birleşik yanıt.")
            }
        }
        val r = h.orchestrator.runMultiAgent("büyük bir proje", HIGH_PROFILE)
        assertTrue(r.isSuccess)
        assertEquals("Nihai birleşik yanıt.", r.getOrNull())
        val t = h.orchestrator.tasks.value.last()
        assertEquals(AgentStatus.FAILED, t.agents.first { it.role == AgentRole.SECURITY }.status)
        assertEquals(2, t.agents.count { it.status == AgentStatus.DONE })
    }

    // Tüm ajanlar başarısızsa dürüst hata (uydurma sonuç yok)
    @Test fun allAgentsFailingReturnsFailure() = runTest {
        val h = Harness(FOUR_MODELS, settings(5)) { body ->
            if (systemOf(body).contains("görev planlayıcısısın")) okResp(planJson("CODING", "ANALYSIS")) else errResp(400, "kötü istek")
        }
        val r = h.orchestrator.runMultiAgent("büyük bir proje", HIGH_PROFILE)
        assertTrue(r.isFailure)
        assertEquals(TaskPhase.FAILED, h.orchestrator.tasks.value.last().phase)
    }

    // Planner bozuk JSON döndürürse yerel şablona düşer ve görev yine de tamamlanır
    @Test fun invalidPlannerOutputFallsBackToTemplate() = runTest {
        val h = Harness(FOUR_MODELS, settings(5)) { body ->
            val sys = systemOf(body)
            when {
                sys.contains("görev planlayıcısısın") -> okResp("bu bir JSON değil")
                sys.contains("çoklu ajan sisteminde") -> okResp("ajan çıktısı, yeterince uzun bir metin burada.")
                else -> okResp("Nihai yanıt.")
            }
        }
        val r = h.orchestrator.runMultiAgent("büyük bir proje", HIGH_PROFILE)
        assertTrue(r.isSuccess)
        assertTrue(h.orchestrator.tasks.value.last().agents.size >= 3)
    }

    // 9) Kullanıcı iptal edince tüm işlemler sonlanır, yeni API çağrısı yapılmaz
    @Test fun cancellationStopsAllWorkAndFurtherCalls() = runTest {
        val h = Harness(FOUR_MODELS, settings(6)) { body ->
            val sys = systemOf(body)
            when {
                sys.contains("görev planlayıcısısın") -> okResp(planJson(*sixRoles))
                else -> { delay(10_000); okResp("geç kalan cevap") }
            }
        }
        val job = async { h.orchestrator.runMultiAgent("büyük bir proje", HIGH_PROFILE) }
        advanceTimeBy(500)
        val task = h.orchestrator.tasks.value.last()
        h.orchestrator.cancel(task.id)
        val result = job.await()
        assertTrue(result.exceptionOrNull() is TaskCancelledException)
        val callsAtCancel = h.transport.calls.get()
        advanceUntilIdle()
        advanceTimeBy(60_000)
        assertEquals(callsAtCancel, h.transport.calls.get())
        assertEquals(TaskPhase.CANCELLED, h.orchestrator.tasks.value.last().phase)
        assertFalse(h.orchestrator.tasks.value.last().agents.any { it.status == AgentStatus.RUNNING })
    }

    // Bütçe: çok düşük token bütçesinde ajanlar sadeleştirilir/atlanır, sonsuz harcama olmaz
    @Test fun tokenBudgetSimplifiesOrSkipsAgents() = runTest {
        val probe = ConcurrencyProbe(sixRoles)
        val tiny = AgentSettings(maxConcurrent = 6, taskTokenBudget = 2_000, taskCostBudgetUsd = 50.0)
        val h = Harness(FOUR_MODELS, tiny) { probe.handle(it) }
        h.orchestrator.runMultiAgent("büyük bir proje", HIGH_PROFILE)
        val ran = h.orchestrator.tasks.value.last().agents.count { it.status == AgentStatus.DONE }
        assertTrue("bütçe yine de 6 ajanı çalıştırdı", ran < 6)
        assertTrue(h.events.events.value.any { it.kind == EventKind.BUDGET })
    }
}
