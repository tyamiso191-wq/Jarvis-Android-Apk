package com.jarvis.ai.agents

import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicInteger

/** MOCK taşıyıcı: gerçek ağ YOK. Bu testler canlı OpenRouter çağrısı yapmaz. */
class FakeTransport(private val handler: suspend (JSONObject) -> RawResponse) : ChatTransport {
    val calls = AtomicInteger(0)
    override suspend fun post(body: JSONObject): RawResponse {
        calls.incrementAndGet()
        return handler(body)
    }
}

fun okResp(text: String, prompt: Int? = 10, completion: Int? = 20, cost: Double? = 0.001): RawResponse {
    val msg = JSONObject().put("role", "assistant").put("content", text)
    val root = JSONObject().put(
        "choices", JSONArray().put(JSONObject().put("message", msg).put("finish_reason", "stop"))
    )
    if (prompt != null || completion != null || cost != null) {
        val u = JSONObject()
        if (prompt != null) u.put("prompt_tokens", prompt)
        if (completion != null) u.put("completion_tokens", completion)
        if (cost != null) u.put("cost", cost)
        root.put("usage", u)
    }
    return RawResponse(200, root.toString(), null)
}

fun errResp(code: Int, msg: String, retryAfterMs: Long? = null): RawResponse =
    RawResponse(code, JSONObject().put("error", JSONObject().put("code", code).put("message", msg)).toString(), retryAfterMs)

fun mkModel(
    id: String,
    price: Double = 0.000003,
    ctx: Int = 100_000,
    tools: Boolean = true,
    reasoning: Boolean = false,
    images: Boolean = false,
    free: Boolean = false
) = ModelInfo(
    id = id, name = id, contextLength = ctx, maxCompletion = null,
    promptPrice = if (free) 0.0 else price, completionPrice = if (free) 0.0 else price,
    supportsTools = tools, supportsReasoning = reasoning, supportsImages = images,
    created = System.currentTimeMillis() / 1000 - 86_400L * 30
)

fun systemOf(body: JSONObject): String =
    body.optJSONArray("messages")?.optJSONObject(0)?.optString("content").orEmpty()

fun planJson(vararg roles: String): String {
    val arr = JSONArray()
    roles.forEachIndexed { i, r ->
        arr.put(JSONObject().put("id", "a${i + 1}").put("role", r).put("goal", "hedef numarası ${i + 1} için $r işi").put("depends_on", JSONArray()))
    }
    return JSONObject().put("tasks", arr).toString()
}

/** Orkestratör testleri için tam kurulum. */
class Harness(
    val models: List<ModelInfo>,
    val settings: AgentSettings,
    handler: suspend (JSONObject) -> RawResponse
) {
    val transport = FakeTransport(handler)
    val ledger = UsageLedger()
    val events = EventLog()
    val health = HealthTracker()
    val runner = FallbackRunner(health, events)
    val caller = LlmCaller(transport, ledger)
    val router = ModelRouter()
    val orchestrator = Orchestrator(
        caller = caller, catalog = { models }, router = router, health = health, runner = runner,
        events = events, ledger = ledger, settings = { settings }
    )
}

val HIGH_PROFILE = TaskProfile(TaskType.PROJECT, Complexity.HIGH)

val FOUR_MODELS = listOf(
    mkModel("aa/model-one"), mkModel("bb/model-two"), mkModel("cc/model-three"), mkModel("dd/model-four")
)

/** Planner'a plan döndüren; ajan çağrılarında eşzamanlılığı ölçen ortak işleyici. */
class ConcurrencyProbe(private val roles: Array<String>, private val agentDelayMs: Long = 200) {
    val active = AtomicInteger(0)
    val maxActive = AtomicInteger(0)

    suspend fun handle(body: JSONObject): RawResponse {
        val sys = systemOf(body)
        return when {
            sys.contains("görev planlayıcısısın") -> okResp(planJson(*roles))
            sys.contains("çoklu ajan sisteminde") -> {
                val cur = active.incrementAndGet()
                maxActive.updateAndGet { maxOf(it, cur) }
                try { delay(agentDelayMs) } finally { active.decrementAndGet() }
                okResp("ajan çıktısı: yeterince uzun bir sonuç metni burada yer alıyor.")
            }
            else -> okResp("Birleştirilmiş nihai yanıt.")
        }
    }
}
