package com.jarvis.ai.agents

import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NanoNoticeTest {
    @Test
    fun unavailableMentionsOpenRouter() {
        val m = NanoNotice.messageFor(NanoState.UNAVAILABLE)
        assertNotNull(m)
        assertTrue(m!!.contains("desteklemiyor") && m.contains("OpenRouter"))
    }

    @Test
    fun noNoticeWhenAvailableOrUnknown() {
        assertNull(NanoNotice.messageFor(NanoState.AVAILABLE))
        assertNull(NanoNotice.messageFor(NanoState.UNKNOWN))
    }

    @Test
    fun downloadStatesExplainFallback() {
        assertTrue(NanoNotice.messageFor(NanoState.DOWNLOADABLE)!!.contains("OpenRouter"))
        assertTrue(NanoNotice.messageFor(NanoState.DOWNLOADING)!!.contains("OpenRouter"))
    }
}
