package com.jarvis.ai.attach

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.util.zip.GZIPInputStream
import java.util.zip.ZipException
import java.util.zip.ZipFile
import kotlin.math.max
import kotlin.math.min

/**
 * Sohbete eklenen tek bir fotoğraf / dosya.
 *
 * - Fotoğraf ve PDF: sayfalar küçültülmüş JPEG olarak [imageDataUrls] içinde
 *   ("data:image/jpeg;base64,...") tutulur, vision modeline görsel olarak gider.
 * - Metin/kod dosyası: içeriği [text] içinde tutulur, mesajın içine yazılır.
 */
data class Attachment(
    val name: String,
    val icon: String,
    val text: String? = null,
    val truncated: Boolean = false,
    val imageDataUrls: List<String> = emptyList(),
    /** Modele söylenecek ek not (örn. "PDF'nin sadece ilk 2 sayfası eklendi"). */
    val hint: String? = null,
    /** Orijinal dosyanın adresi: gönderilince sohbette indirilebilir kart olarak gösterilir. */
    val sourceUri: Uri? = null
)

sealed class AttachmentResult {
    data class Ok(val attachment: Attachment) : AttachmentResult()
    data class Failed(val message: String) : AttachmentResult()
}

object AttachmentLoader {

    /** Tek mesajda modele gidebilecek en fazla görsel sayısı (Mistral görsel giriş limiti). */
    const val MAX_IMAGES = 3

    private const val MAX_TEXT_CHARS = 8000
    private const val MAX_IMAGE_SIDE = 1280
    private const val MAX_PDF_PAGES = 2
    private const val PDF_RENDER_SIDE = 1100
    private const val JPEG_QUALITY = 82

    private val IMAGE_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif")

    private val TEXT_EXTENSIONS = setOf(
        "txt", "md", "json", "csv", "tsv", "xml", "html", "htm", "css", "js", "ts", "kt", "kts",
        "java", "py", "c", "cpp", "h", "hpp", "cs", "go", "rs", "swift", "rb", "php", "sh", "bat",
        "sql", "yml", "yaml", "toml", "ini", "cfg", "conf", "properties", "gradle", "log", "srt",
        "vtt", "tex", "rtf"
    )

    private val TEXT_MIMES = setOf(
        "application/json", "application/xml", "application/javascript", "application/x-sh",
        "application/x-yaml", "application/sql", "application/x-httpd-php"
    )

    suspend fun load(ctx: Context, uri: Uri): AttachmentResult = withContext(Dispatchers.IO) {
        val name = displayName(ctx, uri)
        val mime = ctx.contentResolver.getType(uri).orEmpty().lowercase()
        val ext = name.substringAfterLast('.', "").lowercase()
        try {
            val lname = name.lowercase()
            when {
                mime.startsWith("image/") || ext in IMAGE_EXTENSIONS -> loadImage(ctx, uri, name)
                mime == "application/pdf" || ext == "pdf" -> loadPdf(ctx, uri, name)
                ext in OFFICE_EXTENSIONS -> loadOffice(ctx, uri, name, ext)
                lname.endsWith(".tar.gz") || ext == "tgz" -> loadTar(ctx, uri, name, gz = true)
                ext == "tar" -> loadTar(ctx, uri, name, gz = false)
                ext == "gz" -> loadGzip(ctx, uri, name)
                ext in ARCHIVE_EXTENSIONS || mime in ZIP_MIMES -> loadZip(ctx, uri, name)
                ext == "rar" || ext == "7z" -> AttachmentResult.Failed(
                    "$name okunamadı: RAR/7z desteklenmiyor. ZIP olarak sıkıştırıp tekrar ekleyebilirsin."
                )
                mime.startsWith("text/") || mime in TEXT_MIMES || ext in TEXT_EXTENSIONS ->
                    loadText(ctx, uri, name)
                else -> AttachmentResult.Failed(
                    "$name okunamadı: bu dosya türü desteklenmiyor. Fotoğraf, PDF, ZIP/TAR/GZ arşivleri, Word/Excel/PowerPoint, metin ve kod dosyaları okunabiliyor."
                )
            }
        } catch (e: OutOfMemoryError) {
            AttachmentResult.Failed("$name çok büyük, okunamadı.")
        } catch (e: SecurityException) {
            AttachmentResult.Failed("$name okunamadı (erişim izni yok ya da dosya korumalı).")
        } catch (e: Exception) {
            AttachmentResult.Failed("$name okunamadı: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun displayName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) c.getString(idx)?.takeIf { it.isNotBlank() }?.let { return it }
                }
            }
        } catch (e: Exception) {
            // ad okunamazsa aşağıdaki varsayılana düş
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "dosya"
    }

    // ---------------------------------------------------------------- METİN

    private fun loadText(ctx: Context, uri: Uri, name: String): AttachmentResult {
        val limitBytes = MAX_TEXT_CHARS * 4
        val input = ctx.contentResolver.openInputStream(uri)
            ?: return AttachmentResult.Failed("$name açılamadı.")
        val buf = ByteArray(limitBytes + 1)
        var total = 0
        input.use {
            while (total < buf.size) {
                val n = it.read(buf, total, buf.size - total)
                if (n <= 0) break
                total += n
            }
        }
        val str = String(buf, 0, min(total, limitBytes), Charsets.UTF_8)
        if (str.isBlank()) return AttachmentResult.Failed("$name boş görünüyor.")
        if (str.any { it == '\u0000' }) {
            return AttachmentResult.Failed("$name metin dosyası değil, okunamadı.")
        }
        val truncated = total > limitBytes || str.length > MAX_TEXT_CHARS
        return AttachmentResult.Ok(
            Attachment(name = name, icon = "📄", text = str.take(MAX_TEXT_CHARS), truncated = truncated)
        )
    }

    // -------------------------------------------------------------- FOTOĞRAF

    private fun loadImage(ctx: Context, uri: Uri, name: String): AttachmentResult {
        val url = decodeImageToDataUrl(ctx, uri)
            ?: return AttachmentResult.Failed("$name açılamadı ya da desteklenmeyen bir görsel biçimi.")
        return AttachmentResult.Ok(Attachment(name = name, icon = "🖼", imageDataUrls = listOf(url)))
    }

    private fun decodeImageToDataUrl(ctx: Context, uri: Uri): String? {
        val resolver = ctx.contentResolver

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        // Belleği şişirmemek için önce 2'nin kuvvetleriyle kaba küçült.
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_IMAGE_SIDE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return null

        val orientation = try {
            resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }

        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
        }
        val scale = MAX_IMAGE_SIDE.toFloat() / max(decoded.width, decoded.height)
        if (scale < 1f) matrix.postScale(scale, scale)

        val finalBmp = if (matrix.isIdentity) decoded else
            Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        return encodeJpeg(finalBmp)
    }

    /** Şeffaf PNG'ler JPEG'de siyah olmasın diye beyaz zemine oturtup sıkıştırır. */
    private fun encodeJpeg(bmp: Bitmap): String {
        val flat = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        Canvas(flat).apply {
            drawColor(Color.WHITE)
            drawBitmap(bmp, 0f, 0f, null)
        }
        val out = ByteArrayOutputStream()
        flat.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
        return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    // ------------------------------------------------------------------- PDF

    private fun loadPdf(ctx: Context, uri: Uri, name: String): AttachmentResult {
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r")
            ?: return AttachmentResult.Failed("$name açılamadı.")
        return pfd.use { fd ->
            PdfRenderer(fd).use { renderer ->
                val total = renderer.pageCount
                if (total == 0) {
                    AttachmentResult.Failed("$name boş bir PDF.")
                } else {
                    val count = min(total, MAX_PDF_PAGES)
                    val images = (0 until count).map { i ->
                        renderer.openPage(i).use { page ->
                            val scale = PDF_RENDER_SIDE.toFloat() / max(page.width, page.height)
                            val w = max(1, (page.width * scale).toInt())
                            val h = max(1, (page.height * scale).toInt())
                            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(Color.WHITE) // PDF şeffaf render ediliyor, zemin şart
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            encodeJpeg(bmp)
                        }
                    }
                    val hint = if (total > count) {
                        "PDF toplam $total sayfa; yalnızca ilk $count sayfası görsel olarak eklendi."
                    } else null
                    AttachmentResult.Ok(
                        Attachment(name = name, icon = "📄", imageDataUrls = images, hint = hint)
                    )
                }
            }
        }
    }

    // ======================================================= ARŞİV / OFİS
    //
    // ZIP/JAR/APK, TAR/TGZ/GZ ve docx/xlsx/pptx/odt/epub dosyaları ARTIK okunuyor:
    // arşivler diske AÇILMAZ, sadece dosya listesi + metin/kod dosyalarının
    // içeriği (kısaltılarak) metne çevrilip modele verilir. Ofis dosyalarından
    // yalnızca düz metin çıkarılır.

    private val ARCHIVE_EXTENSIONS = setOf("zip", "jar", "apk", "aar", "war", "xapk", "apks")
    private val ZIP_MIMES = setOf(
        "application/zip", "application/x-zip-compressed", "application/x-zip",
        "application/java-archive", "application/vnd.android.package-archive"
    )
    private val OFFICE_EXTENSIONS = setOf("docx", "pptx", "xlsx", "odt", "odp", "ods", "epub")
    private val EXTRA_TEXT_NAMES = setOf(
        "readme", "license", "dockerfile", "makefile", "gradlew", "gradlew.bat",
        ".gitignore", ".gitattributes", ".editorconfig", "proguard-rules.pro"
    )
    private val EXTRA_TEXT_EXTS = setOf("svg", "pro", "gitignore", "env", "lock", "gradle", "kts")
    private val SKIP_DIRS = listOf("/build/", "node_modules/", ".git/", "/.gradle/", "__macosx/", "/.idea/")

    private const val MAX_ARCHIVE_FILE_BYTES = 200L * 1024 * 1024 // 200 MB'tan büyük arşiv alınmaz
    private const val MAX_ARCHIVE_SCAN = 2000        // en fazla bu kadar dosya taranır
    private const val MAX_ARCHIVE_LISTED = 300       // listede en fazla bu kadar dosya yazılır
    private const val MAX_ARCHIVE_CHARS = 45000      // içerik olarak toplam en fazla bu kadar karakter
    private const val PER_FILE_CHARS = 5000          // tek dosyadan en fazla bu kadar karakter
    private const val MAX_ENTRY_BYTES = 512L * 1024  // bundan büyük tek dosyanın içeriği okunmaz
    private const val MAX_DOC_CHARS = 40000          // ofis belgesinden çıkarılan metin sınırı
    private const val MAX_XML_BYTES = 8 * 1024 * 1024
    private const val MAX_TAR_SCAN_BYTES = 300L * 1024 * 1024

    private fun isTextName(path: String): Boolean {
        val base = path.substringAfterLast('/').lowercase()
        val ext = base.substringAfterLast('.', "")
        return ext in TEXT_EXTENSIONS || ext in EXTRA_TEXT_EXTS || base in EXTRA_TEXT_NAMES
    }

    private fun isSkippedPath(path: String): Boolean {
        val p = "/" + path.lowercase()
        return SKIP_DIRS.any { p.contains(it) }
    }

    private fun humanSize(n: Long): String = when {
        n < 1024 -> "$n B"
        n < 1024 * 1024 -> "${n / 1024} KB"
        else -> String.format(java.util.Locale.US, "%.1f MB", n / 1048576.0)
    }

    /** Arşiv içeriğini (liste + metin dosyaları) bütçe dahilinde biriktirir. */
    private class Collector {
        val listing = StringBuilder()
        val contents = StringBuilder()
        var fileCount = 0
        var readCount = 0
        var hidden = 0
        var unreadable = 0
        var listingCut = false
        var contentCut = false

        fun note(path: String, size: Long) {
            if (isSkippedPath(path)) { hidden++; return }
            fileCount++
            if (fileCount <= MAX_ARCHIVE_LISTED) {
                listing.append("- ").append(path)
                if (size >= 0) listing.append(" (").append(humanSize(size)).append(")")
                listing.append('\n')
            } else listingCut = true
        }

        fun canRead(path: String, size: Long): Boolean {
            if (!isTextName(path) || isSkippedPath(path)) return false
            if (size > MAX_ENTRY_BYTES) return false
            if (contents.length >= MAX_ARCHIVE_CHARS) { contentCut = true; return false }
            return true
        }

        fun addContent(path: String, bytes: ByteArray) {
            val s = String(bytes, Charsets.UTF_8)
            if (s.indexOf('\u0000') >= 0) return
            contents.append("\n=== ").append(path).append(" ===\n").append(s.take(PER_FILE_CHARS))
            if (s.length > PER_FILE_CHARS) contents.append("\n[... bu dosya kısaltıldı ...]")
            contents.append('\n')
            readCount++
        }
    }

    private fun buildArchive(name: String, kind: String, c: Collector): AttachmentResult {
        if (c.fileCount == 0) return AttachmentResult.Failed("$name boş görünüyor.")
        val text = buildString {
            append("$kind arşivi: ${c.fileCount} dosya")
            if (c.hidden > 0) append(" (+${c.hidden} derleme/gizli dosya listelenmedi)")
            append("\nDosya listesi:\n").append(c.listing)
            if (c.listingCut) append("[... liste kısaltıldı ...]\n")
            if (c.contents.isNotEmpty()) {
                append("\nOkunan metin/kod dosyaları (${c.readCount} adet):").append(c.contents)
            } else {
                append("\n(İçinde okunabilir metin/kod dosyası yok.)\n")
            }
        }
        val hint = buildString {
            if (c.contentCut) append("Arşivdeki bazı metin dosyaları boyut sınırı yüzünden okunmadı. ")
            if (c.unreadable > 0) append("${c.unreadable} dosya şifreli/bozuk olduğu için okunamadı. ")
        }.trim().ifEmpty { null }
        return AttachmentResult.Ok(
            Attachment(name = name, icon = "🗜", text = text, truncated = false, hint = hint)
        )
    }

    /** Uri'yi önbelleğe kopyalar (ZipFile rastgele erişim ister). Çok büyükse null. */
    private fun copyToCache(ctx: Context, uri: Uri): File? {
        val f = File.createTempFile("att_", ".tmp", ctx.cacheDir)
        var total = 0L
        var tooBig = false
        val ok = ctx.contentResolver.openInputStream(uri)?.use { ins ->
            f.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n <= 0) break
                    total += n
                    if (total > MAX_ARCHIVE_FILE_BYTES) { tooBig = true; break }
                    out.write(buf, 0, n)
                }
            }
            true
        } ?: false
        if (!ok || tooBig) { f.delete(); return null }
        return f
    }

    private fun readUpTo(ins: InputStream, limit: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var left = limit
        while (left > 0) {
            val n = ins.read(buf, 0, min(buf.size, left))
            if (n <= 0) break
            out.write(buf, 0, n)
            left -= n
        }
        return out.toByteArray()
    }

    private fun openZip(f: File): ZipFile =
        try { ZipFile(f) } catch (e: IllegalArgumentException) { ZipFile(f, Charsets.ISO_8859_1) }

    // ------------------------------------------------------------------ ZIP

    private fun loadZip(ctx: Context, uri: Uri, name: String): AttachmentResult {
        val tmp = copyToCache(ctx, uri)
            ?: return AttachmentResult.Failed("$name açılamadı ya da çok büyük (en fazla 200 MB).")
        return try {
            openZip(tmp).use { z ->
                val c = Collector()
                var seen = 0
                val en = z.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    if (e.isDirectory) continue
                    if (++seen > MAX_ARCHIVE_SCAN) { c.listingCut = true; break }
                    c.note(e.name, e.size)
                    if (c.canRead(e.name, e.size)) {
                        try {
                            val bytes = z.getInputStream(e).use { readUpTo(it, PER_FILE_CHARS * 4) }
                            c.addContent(e.name, bytes)
                        } catch (ex: Exception) {
                            c.unreadable++
                        }
                    }
                }
                buildArchive(name, "ZIP", c)
            }
        } catch (e: ZipException) {
            AttachmentResult.Failed("$name geçerli bir ZIP değil ya da bozuk: ${e.message}")
        } finally {
            tmp.delete()
        }
    }

    // ------------------------------------------------------------------ TAR

    private fun readFully(ins: InputStream, buf: ByteArray): Boolean {
        var off = 0
        while (off < buf.size) {
            val n = ins.read(buf, off, buf.size - off)
            if (n <= 0) return false
            off += n
        }
        return true
    }

    private fun skipFully(ins: InputStream, count: Long): Boolean {
        var left = count
        val sink = ByteArray(8192)
        while (left > 0) {
            val s = ins.skip(left)
            if (s > 0) left -= s else {
                val r = ins.read(sink, 0, min(sink.size.toLong(), left).toInt())
                if (r < 0) return false
                left -= r
            }
        }
        return true
    }

    private fun cString(b: ByteArray, off: Int, len: Int): String {
        var end = off
        while (end < off + len && b[end].toInt() != 0) end++
        return String(b, off, end - off, Charsets.UTF_8)
    }

    private fun parseOctal(b: ByteArray, off: Int, len: Int): Long {
        val s = cString(b, off, len).trim()
        return s.toLongOrNull(8) ?: 0L
    }

    private fun loadTar(ctx: Context, uri: Uri, name: String, gz: Boolean): AttachmentResult {
        val raw = ctx.contentResolver.openInputStream(uri)
            ?: return AttachmentResult.Failed("$name açılamadı.")
        val c = Collector()
        try {
            val stream: InputStream =
                if (gz) GZIPInputStream(BufferedInputStream(raw)) else BufferedInputStream(raw)
            stream.use { ins ->
                val header = ByteArray(512)
                var seen = 0
                var consumed = 0L
                while (seen < MAX_ARCHIVE_SCAN) {
                    if (!readFully(ins, header)) break
                    if (header.all { it.toInt() == 0 }) break
                    val rawName = cString(header, 0, 100)
                    val prefix = cString(header, 345, 155)
                    val path = if (prefix.isNotEmpty()) "$prefix/$rawName" else rawName
                    val size = parseOctal(header, 124, 12)
                    val type = header[156].toInt().toChar()
                    val padded = (size + 511) / 512 * 512
                    var toSkip = padded
                    if (type == '0' || type == '\u0000') {
                        seen++
                        c.note(path, size)
                        if (c.canRead(path, size)) {
                            val want = min(size, (PER_FILE_CHARS * 4).toLong()).toInt()
                            val buf = ByteArray(want)
                            if (!readFully(ins, buf)) break
                            c.addContent(path, buf)
                            toSkip = padded - want
                        }
                    }
                    if (!skipFully(ins, toSkip)) break
                    consumed += padded
                    if (consumed > MAX_TAR_SCAN_BYTES) { c.listingCut = true; break }
                }
            }
        } catch (e: java.io.IOException) {
            if (c.fileCount == 0) {
                return AttachmentResult.Failed("$name geçerli bir TAR/GZ arşivi değil ya da bozuk.")
            }
        }
        return buildArchive(name, "TAR", c)
    }

    /** Tek dosyalık .gz: açıp içindeki metni okur. */
    private fun loadGzip(ctx: Context, uri: Uri, name: String): AttachmentResult {
        val raw = ctx.contentResolver.openInputStream(uri)
            ?: return AttachmentResult.Failed("$name açılamadı.")
        val limit = MAX_TEXT_CHARS * 4
        val bytes = try {
            GZIPInputStream(BufferedInputStream(raw)).use { readUpTo(it, limit + 1) }
        } catch (e: java.io.IOException) {
            return AttachmentResult.Failed("$name geçerli bir GZ dosyası değil ya da bozuk.")
        }
        val str = String(bytes, 0, min(bytes.size, limit), Charsets.UTF_8)
        if (str.isBlank()) return AttachmentResult.Failed("$name boş görünüyor.")
        if (str.indexOf('\u0000') >= 0) {
            return AttachmentResult.Failed("$name sıkıştırılmış bir metin dosyası değil, okunamadı.")
        }
        return AttachmentResult.Ok(
            Attachment(
                name = name, icon = "🗜", text = str.take(MAX_TEXT_CHARS),
                truncated = bytes.size > limit || str.length > MAX_TEXT_CHARS
            )
        )
    }

    // ------------------------------------------------------ OFİS BELGELERİ

    private fun unescapeXml(s: String): String {
        if (s.indexOf('&') < 0) return s
        return Regex("&(#x?[0-9a-fA-F]+|amp|lt|gt|quot|apos|nbsp);").replace(s) { m ->
            when (val g = m.groupValues[1]) {
                "amp" -> "&"
                "lt" -> "<"
                "gt" -> ">"
                "quot" -> "\""
                "apos" -> "'"
                "nbsp" -> " "
                else -> try {
                    val code = if (g[1] == 'x' || g[1] == 'X') g.substring(2).toInt(16) else g.substring(1).toInt()
                    String(Character.toChars(code))
                } catch (e: Exception) { "" }
            }
        }
    }

    private val TAG_RE = Regex("<[^>]+>")

    private fun stripTags(xml: String): String = unescapeXml(TAG_RE.replace(xml, ""))

    private fun tidy(s: String): String =
        s.lines().joinToString("\n") { it.trimEnd() }.replace(Regex("\n{3,}"), "\n\n").trim()

    private fun readEntryText(z: ZipFile, entryName: String): String? {
        val e = z.getEntry(entryName) ?: return null
        return z.getInputStream(e).use { String(readUpTo(it, MAX_XML_BYTES), Charsets.UTF_8) }
    }

    private fun numberOf(path: String): Int =
        Regex("\\d+").find(path.substringAfterLast('/'))?.value?.toIntOrNull() ?: 0

    private fun entryNames(z: ZipFile): List<String> = z.entries().toList().map { it.name }

    private fun docxText(z: ZipFile): String {
        val xml = readEntryText(z, "word/document.xml") ?: return ""
        val s = xml
            .replace(Regex("</w:p>"), "\n")
            .replace(Regex("<w:tab\\s*/>"), "\t")
            .replace(Regex("<w:br\\s*/>"), "\n")
            .replace(Regex("</w:tc>"), "\t")
        return tidy(stripTags(s))
    }

    private fun pptxText(z: ZipFile): String {
        val slides = entryNames(z)
            .filter { Regex("ppt/slides/slide\\d+\\.xml").matches(it) }
            .sortedBy { numberOf(it) }
        val sb = StringBuilder()
        for (slide in slides) {
            val xml = readEntryText(z, slide) ?: continue
            sb.append("--- Slayt ${numberOf(slide)} ---\n")
            sb.append(tidy(stripTags(xml.replace(Regex("</a:p>"), "\n")))).append("\n\n")
            if (sb.length > MAX_DOC_CHARS) break
        }
        return sb.toString().trim()
    }

    private fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) {
            if (ch in 'A'..'Z') n = n * 26 + (ch - 'A' + 1) else break
        }
        return (n - 1).coerceAtLeast(0)
    }

    private fun xlsxText(z: ZipFile): String {
        val dot = RegexOption.DOT_MATCHES_ALL
        val shared = readEntryText(z, "xl/sharedStrings.xml")?.let { xml ->
            Regex("<si>(.*?)</si>", dot).findAll(xml).map { si ->
                Regex("<t[^>]*>(.*?)</t>", dot).findAll(si.groupValues[1])
                    .joinToString("") { unescapeXml(it.groupValues[1]) }
            }.toList()
        } ?: emptyList()
        val sheetNames = readEntryText(z, "xl/workbook.xml")?.let { xml ->
            Regex("<sheet\\s[^>]*?name=\"([^\"]*)\"").findAll(xml).map { unescapeXml(it.groupValues[1]) }.toList()
        } ?: emptyList()
        val sheets = entryNames(z)
            .filter { Regex("xl/worksheets/sheet\\d+\\.xml").matches(it) }
            .sortedBy { numberOf(it) }
        val sb = StringBuilder()
        for ((idx, path) in sheets.withIndex()) {
            val xml = readEntryText(z, path) ?: continue
            sb.append("## Sayfa: ").append(sheetNames.getOrNull(idx) ?: "Sheet${idx + 1}").append('\n')
            var rows = 0
            for (row in Regex("<row[^>]*>(.*?)</row>", dot).findAll(xml)) {
                if (rows++ >= 300 || sb.length > MAX_DOC_CHARS) break
                val cells = mutableListOf<String>()
                for (cell in Regex("<c\\s([^>]*?)(?:/>|>(.*?)</c>)", dot).findAll(row.groupValues[1])) {
                    val attrs = cell.groupValues[1]
                    val body = cell.groupValues[2]
                    val ref = Regex("(?:^|\\s)r=\"([A-Z]+)\\d*\"").find(attrs)?.groupValues?.get(1) ?: "A"
                    val type = Regex("(?:^|\\s)t=\"(\\w+)\"").find(attrs)?.groupValues?.get(1)
                    val v = Regex("<v>(.*?)</v>", dot).find(body)?.groupValues?.get(1)
                    val value = when (type) {
                        "s" -> v?.toIntOrNull()?.let { shared.getOrNull(it) } ?: ""
                        "inlineStr" -> stripTags(body)
                        "b" -> if (v == "1") "TRUE" else "FALSE"
                        else -> v?.let { unescapeXml(it) } ?: ""
                    }
                    val col = colIndex(ref)
                    while (cells.size < col) cells.add("")
                    cells.add(value.replace('\t', ' ').replace('\n', ' '))
                }
                if (cells.any { it.isNotEmpty() }) sb.append(cells.joinToString("\t")).append('\n')
            }
            sb.append('\n')
            if (sb.length > MAX_DOC_CHARS) break
        }
        return sb.toString().trim()
    }

    private fun odfText(z: ZipFile): String {
        val xml = readEntryText(z, "content.xml") ?: return ""
        val s = xml
            .replace(Regex("</text:p>|</text:h>|</table:table-row>"), "\n")
            .replace(Regex("</table:table-cell>"), "\t")
            .replace(Regex("<text:tab\\s*/>"), "\t")
            .replace(Regex("<text:line-break\\s*/>"), "\n")
            .replace(Regex("<text:s\\s*/>"), " ")
            .replace(Regex("</draw:page>"), "\n--- yeni sayfa/slayt ---\n")
        return tidy(stripTags(s).replace(Regex("\t{3,}"), "\t\t"))
    }

    private fun epubText(z: ZipFile): String {
        val pages = entryNames(z).filter {
            val l = it.lowercase()
            l.endsWith(".xhtml") || l.endsWith(".html") || l.endsWith(".htm")
        }
        val sb = StringBuilder()
        for (p in pages) {
            val html = readEntryText(z, p) ?: continue
            val cleaned = html
                .replace(Regex("<(script|style)[^>]*>.*?</\\1>", RegexOption.DOT_MATCHES_ALL), "")
                .replace(Regex("</p>|</div>|<br\\s*/?>|</h[1-6]>|</li>"), "\n")
            sb.append(tidy(stripTags(cleaned))).append("\n\n")
            if (sb.length > MAX_DOC_CHARS) break
        }
        return sb.toString().trim()
    }

    private fun loadOffice(ctx: Context, uri: Uri, name: String, ext: String): AttachmentResult {
        val tmp = copyToCache(ctx, uri)
            ?: return AttachmentResult.Failed("$name açılamadı ya da çok büyük (en fazla 200 MB).")
        try {
            val text = openZip(tmp).use { z ->
                when (ext) {
                    "docx" -> docxText(z)
                    "pptx" -> pptxText(z)
                    "xlsx" -> xlsxText(z)
                    "odt", "odp", "ods" -> odfText(z)
                    else -> epubText(z)
                }
            }
            if (text.isBlank()) {
                return AttachmentResult.Failed("$name içinde okunabilir metin bulunamadı (resimli ya da şifreli olabilir).")
            }
            val icon = when (ext) { "xlsx", "ods" -> "📊"; "pptx", "odp" -> "📽"; "epub" -> "📚"; else -> "📝" }
            return AttachmentResult.Ok(
                Attachment(name = name, icon = icon, text = text.take(MAX_DOC_CHARS), truncated = text.length > MAX_DOC_CHARS)
            )
        } catch (e: ZipException) {
            return AttachmentResult.Failed("$name açılamadı: dosya bozuk, şifreli ya da eski biçimde (.doc/.xls/.ppt desteklenmiyor).")
        } finally {
            tmp.delete()
        }
    }
}
