package com.jarvis.ai.ui

import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.jarvis.ai.theme.Text

/**
 * Emoji yerine kullanılan ince çizgili (stroke) vektör simgeler -- ek bağımlılık gerektirmez.
 * Her simge 24x24 görünüm alanında SVG yol komutlarıyla tanımlı.
 */
enum class JI(val paths: List<String>) {
    Menu(listOf("M4 9h16", "M4 15h10")),
    Close(listOf("M18 6L6 18", "M6 6l12 12")),
    Camera(listOf(
        "M4 8h3l2-3h6l2 3h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z",
        "M16 13a4 4 0 1 1-8 0 4 4 0 0 1 8 0z"
    )),
    Send(listOf("M12 19V5", "M5 12l7-7 7 7")),
    Sparkles(listOf(
        "M12 3l1.8 4.7 4.7 1.8-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8z",
        "M19 15l.7 1.8 1.8.7-1.8.7L19 20l-.7-1.8-1.8-.7 1.8-.7z"
    )),
    Terminal(listOf("M5 8l4 4-4 4", "M12 17h7")),
    Mic(listOf(
        "M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3z",
        "M18 11a6 6 0 0 1-12 0", "M12 17v4"
    )),
    Moon(listOf("M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z")),
    Rotate(listOf("M20 12a8 8 0 1 1-2.5-5.8", "M20 4v4.5h-4.5")),
    Key(listOf(
        "M12 15a4 4 0 1 1-8 0 4 4 0 0 1 8 0z", "M10.8 12.2L20 3", "M17 6l3 3", "M14.5 8.5l2 2"
    )),
    Speed(listOf("M6 17l5-5-5-5", "M13 17l5-5-5-5")),
    Volume(listOf(
        "M11 5L6.5 9H3v6h3.5L11 19z", "M15.5 9a4.5 4.5 0 0 1 0 6", "M18.5 6a8.5 8.5 0 0 1 0 12"
    )),
    File(listOf(
        "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z", "M14 2v6h6"
    )),
    Image(listOf(
        "M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",
        "M21 15l-5-5L5 21", "M9 9h.01"
    )),
    Download(listOf("M12 4v11", "M7 11l5 5 5-5", "M5 20h14")),
    Plus(listOf("M12 5v14", "M5 12h14")),
    Agents(listOf("M12 3.5a2 2 0 1 0 0 4 2 2 0 0 0 0-4z", "M5 16.5a2 2 0 1 0 0 4 2 2 0 0 0 0-4z", "M19 16.5a2 2 0 1 0 0 4 2 2 0 0 0 0-4z", "M12 7.5v4", "M12 11.5l-6 5", "M12 11.5l6 5")),
    Copy(listOf("M9 9h11v11H9z", "M5 15V4h11")),
    History(listOf("M3 12a9 9 0 1 0 3-6.7", "M3 4v5h5", "M12 7v5l3 2")),
    VolumeOff(listOf("M11 5L6.5 9H3v6h3.5L11 19z", "M22 9l-6 6", "M16 9l6 6")),
    Trash(listOf("M4 7h16", "M10 11v6", "M14 11v6", "M6 7l1 13h10l1-13", "M9 7V4h6v3")),
    Check(listOf("M5 12.5l4.5 4.5L19 7.5"));

    fun vector(): ImageVector {
        val b = ImageVector.Builder(
            name = name, defaultWidth = 24.dp, defaultHeight = 24.dp,
            viewportWidth = 24f, viewportHeight = 24f
        )
        for (d in paths) {
            b.addPath(
                pathData = PathParser().parsePathString(d).toNodes(),
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.8f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            )
        }
        return b.build()
    }
}

@Composable
fun JIcon(icon: JI, modifier: Modifier = Modifier, tint: Color = Text, size: Dp = 22.dp) {
    val vec = remember(icon) { icon.vector() }
    Icon(imageVector = vec, contentDescription = null, tint = tint, modifier = modifier.size(size))
}
