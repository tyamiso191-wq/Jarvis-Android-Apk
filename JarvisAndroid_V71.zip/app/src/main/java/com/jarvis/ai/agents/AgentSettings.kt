package com.jarvis.ai.agents

import org.json.JSONArray
import org.json.JSONObject

enum class CostMode(val label: String) {
    ECONOMY("Ekonomik"), BALANCED("Dengeli"), QUALITY("Kalite")
}

/**
 * Kullanıcı ayarları. Model adı girmek ZORUNLU değil: [pinned] boşsa modeller OpenRouter
 * kataloğundan otomatik seçilir. Doluysa liste sırasıyla (ilki öncelikli, sonrakiler yedek) denenir.
 */
data class AgentSettings(
    val multiAgentEnabled: Boolean = true,
    /** Aynı anda çalışabilecek en fazla ajan (1..10). */
    val maxConcurrent: Int = 5,
    val advancedMode: Boolean = false,
    val costMode: CostMode = CostMode.BALANCED,
    /** Çoklu ajan görevi başına GERÇEK token üst sınırı (giriş+çıkış). */
    val taskTokenBudget: Int = 60_000,
    /** Çoklu ajan görevi başına gerçekleşen maliyet üst sınırı (USD). */
    val taskCostBudgetUsd: Double = 0.50,
    val agentTimeoutSec: Int = 120,
    val pinned: Map<TaskType, List<String>> = emptyMap()
) {
    fun normalized(): AgentSettings = copy(
        maxConcurrent = maxConcurrent.coerceIn(1, 10),
        taskTokenBudget = taskTokenBudget.coerceIn(2_000, 2_000_000),
        taskCostBudgetUsd = taskCostBudgetUsd.coerceIn(0.01, 50.0),
        agentTimeoutSec = agentTimeoutSec.coerceIn(20, 600)
    )

    fun toJson(): String {
        val pins = JSONObject()
        pinned.forEach { (t, ids) -> pins.put(t.name, JSONArray(ids)) }
        return JSONObject()
            .put("multi", multiAgentEnabled).put("conc", maxConcurrent).put("adv", advancedMode)
            .put("cost", costMode.name).put("tokBudget", taskTokenBudget).put("usdBudget", taskCostBudgetUsd)
            .put("timeout", agentTimeoutSec).put("pinned", pins).toString()
    }

    companion object {
        fun fromJson(json: String?): AgentSettings {
            if (json.isNullOrBlank()) return AgentSettings()
            return try {
                val o = JSONObject(json)
                val pins = mutableMapOf<TaskType, List<String>>()
                o.optJSONObject("pinned")?.let { p ->
                    p.keys().forEach { k ->
                        val type = runCatching { TaskType.valueOf(k) }.getOrNull() ?: return@forEach
                        val arr = p.optJSONArray(k) ?: return@forEach
                        pins[type] = (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
                    }
                }
                AgentSettings(
                    multiAgentEnabled = o.optBoolean("multi", true),
                    maxConcurrent = o.optInt("conc", 5),
                    advancedMode = o.optBoolean("adv", false),
                    costMode = runCatching { CostMode.valueOf(o.optString("cost")) }.getOrDefault(CostMode.BALANCED),
                    taskTokenBudget = o.optInt("tokBudget", 60_000),
                    taskCostBudgetUsd = o.optDouble("usdBudget", 0.50),
                    agentTimeoutSec = o.optInt("timeout", 120),
                    pinned = pins
                ).normalized()
            } catch (e: Exception) {
                AgentSettings()
            }
        }
    }
}
