package com.jarvis.ai.agents

import java.util.concurrent.ConcurrentHashMap

/**
 * Model ve hesap sağlığı: bekleme süreleri (cooldown) ve geçici devre kesici.
 * - Model/sağlayıcı hız sınırı: sadece O MODEL bekler.
 * - Ücretsiz katman limiti (hesap düzeyi): TÜM ücretsiz modeller bekler.
 * - Kredi bitti: ücretli modeller bekler; ücretsiz modeller denenebilir.
 * - Art arda geçici hata: model için devre kesici açılır (süre katlanarak artar).
 */
class HealthTracker(private val now: () -> Long = System::currentTimeMillis) {

    private val cooldownUntil = ConcurrentHashMap<String, Long>()
    private val deadUntil = ConcurrentHashMap<String, Long>()
    private val breakerUntil = ConcurrentHashMap<String, Long>()
    private val consecutiveFails = ConcurrentHashMap<String, Int>()
    private val breakerTrips = ConcurrentHashMap<String, Int>()

    @Volatile private var freeBlockedUntil = 0L
    @Volatile private var paidBlockedUntil = 0L
    @Volatile private var authBrokenUntil = 0L

    /** 401 sonrası kısa süre (2 dk) anahtar geçersiz sayılır; sonra yeniden denenir. Kalıcı kilit YOK. */
    val authBroken: Boolean get() = authBrokenUntil > now()

    companion object {
        const val DEFAULT_RATE_LIMIT_MS = 60_000L
        const val DAILY_BLOCK_MS = 30 * 60_000L
        const val CREDITS_BLOCK_MS = 5 * 60_000L
        const val AUTH_BLOCK_MS = 2 * 60_000L
        const val UNAVAILABLE_MS = 30 * 60_000L
        const val BREAKER_THRESHOLD = 3
        const val BREAKER_BASE_MS = 2 * 60_000L
        const val BREAKER_MAX_MS = 10 * 60_000L
    }

    fun resetAuth() { authBrokenUntil = 0L }

    fun creditsBlocked(): Boolean = paidBlockedUntil > now()

    fun isUsable(m: ModelInfo): Boolean = blockedForMs(m) == 0L

    /** Modelin ne kadar süre daha kullanılamayacağı (0 = kullanılabilir; Long.MAX = süresiz). */
    fun blockedForMs(m: ModelInfo): Long {
        if (authBroken) return Long.MAX_VALUE
        val t = now()
        var until = maxOf(
            cooldownUntil[m.id] ?: 0L, deadUntil[m.id] ?: 0L, breakerUntil[m.id] ?: 0L,
            if (m.isFree) freeBlockedUntil else paidBlockedUntil
        )
        if (until < t) until = 0L
        return if (until == 0L) 0L else until - t
    }

    /** Verilen modeller arasında en erken kullanılabilir olanın bekleme süresi; hiçbiri yoksa null. */
    fun soonestAvailableMs(models: List<ModelInfo>): Long? =
        models.map { blockedForMs(it) }.filter { it != Long.MAX_VALUE }.minOrNull()

    fun onSuccess(m: ModelInfo) {
        consecutiveFails.remove(m.id)
        breakerTrips.remove(m.id)
        breakerUntil.remove(m.id)
    }

    fun onFailure(m: ModelInfo, e: LlmException) {
        val t = now()
        when (e.kind) {
            ErrorKind.AUTH -> authBrokenUntil = t + AUTH_BLOCK_MS
            ErrorKind.CREDITS -> paidBlockedUntil = t + CREDITS_BLOCK_MS
            ErrorKind.INFLIGHT_BUDGET -> {
                val wait = e.retryAfterMs ?: 10_000L
                paidBlockedUntil = maxOf(paidBlockedUntil, t + wait)
            }
            ErrorKind.RATE_LIMIT_MODEL ->
                cooldownUntil[m.id] = t + (e.retryAfterMs ?: if (e.daily) DAILY_BLOCK_MS else DEFAULT_RATE_LIMIT_MS)
            ErrorKind.RATE_LIMIT_ACCOUNT -> {
                val wait = e.retryAfterMs ?: if (e.daily) DAILY_BLOCK_MS else DEFAULT_RATE_LIMIT_MS
                freeBlockedUntil = maxOf(freeBlockedUntil, t + wait)
            }
            ErrorKind.MODEL_UNAVAILABLE, ErrorKind.MODEL_INCOMPATIBLE -> deadUntil[m.id] = t + UNAVAILABLE_MS
            ErrorKind.TRANSIENT_SERVER, ErrorKind.NETWORK, ErrorKind.TIMEOUT, ErrorKind.EMPTY_RESPONSE -> {
                val n = (consecutiveFails[m.id] ?: 0) + 1
                consecutiveFails[m.id] = n
                if (n >= BREAKER_THRESHOLD) {
                    val trips = (breakerTrips[m.id] ?: 0) + 1
                    breakerTrips[m.id] = trips
                    val dur = (BREAKER_BASE_MS shl (trips - 1).coerceAtMost(4)).coerceAtMost(BREAKER_MAX_MS)
                    breakerUntil[m.id] = t + dur
                    consecutiveFails[m.id] = 0
                }
            }
            else -> Unit
        }
    }
}
