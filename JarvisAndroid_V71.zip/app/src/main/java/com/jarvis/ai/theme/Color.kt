package com.jarvis.ai.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

// Yumuşatılmış palet: neon yerine mat, hafif pastel tonlar; koyu lacivert-petrol zemin.
val Bg = Color(0xFF080F16)
val BgTop = Color(0xFF10202B)
val Panel = Color(0xFF111D27)
val Teal = Color(0xFF6FD3C8)
val TealDim = Color(0xFF2F5E63)
val TealMid = Color(0xFF16313A)
val Text = Color(0xFFDDEFED)
val Dim = Color(0xFF86A3A5)
val Green = Color(0xFF7BE0AD)
val Red = Color(0xFFFF7D8B)
val Gold = Color(0xFFF2CC7A)
val Blue = Color(0xFF8BB2FF)
val Orange = Color(0xFFFF9D5C)
val Muted = Color(0xFFD96C8F)

/** Arayüz yazı tipi: eski "terminal" görünümü yerine yumuşak, düz bir yazı tipi. */
val UiFont: FontFamily = FontFamily.SansSerif
