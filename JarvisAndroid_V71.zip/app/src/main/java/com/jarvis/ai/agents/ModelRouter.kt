package com.jarvis.ai.agents

import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * AI Model Router. Model adları KODDA YOK: adaylar OpenRouter kataloğundaki ölçülebilir
 * alanlardan (araç/akıl yürütme/görsel desteği, bağlam penceresi, fiyat, yenilik) ve görev türüne
 * göre ağırlıklandırılmış ad ipuçlarından (ör. "coder", "reason") puanlanır.
 *
 * DÜRÜST NOT: Katalog kalite/benchmark bilgisi vermez. Fiyat ve yenilik, kaliteye dolaylı
 * göstergelerdir; bu yüzden sonuç bir sezgisel (heuristic) sıralamadır. Kullanıcı Gelişmiş modda
 * görev türü başına kendi modellerini sabitleyebilir.
 */
class ModelRouter(private val now: () -> Long = System::currentTimeMillis) {

    companion object {
        val HINTS: Map<TaskType, List<String>> = mapOf(
            TaskType.CODING to listOf("code", "coder", "codestral", "devstral", "program"),
            TaskType.REASONING to listOf("reason", "think", "thinking", "r1", "reasoner"),
            TaskType.CHAT to listOf("flash", "mini", "lite", "haiku", "fast", "instant", "chat"),
            TaskType.RESEARCH to listOf("online", "search"),
            TaskType.REVIEW to listOf("code", "reason", "think"),
            TaskType.PROJECT to listOf("reason", "think", "coder")
        )
        const val DEFAULT_LIMIT = 8
    }

    private data class Weights(
        val quality: Double, val fresh: Double, val ctx: Double, val tools: Double,
        val reasoning: Double, val hint: Double, val costMul: Double
    )

    private fun weights(type: TaskType): Weights = when (type) {
        TaskType.CHAT -> Weights(1.0, 0.5, 0.0, 0.2, 0.0, 0.2, 1.5)
        TaskType.CODING -> Weights(1.0, 0.8, 0.3, 0.3, 0.2, 1.3, 1.0)
        TaskType.REASONING -> Weights(1.2, 0.6, 0.2, 0.0, 1.1, 0.8, 0.8)
        TaskType.RESEARCH -> Weights(0.9, 0.7, 0.4, 0.9, 0.0, 0.4, 1.0)
        TaskType.WRITING -> Weights(1.1, 0.6, 0.2, 0.0, 0.0, 0.0, 1.0)
        TaskType.REVIEW -> Weights(1.1, 0.7, 0.3, 0.0, 0.6, 0.6, 0.9)
        TaskType.VISION -> Weights(1.0, 0.7, 0.1, 0.0, 0.0, 0.0, 1.0)
        TaskType.PROJECT -> Weights(1.1, 0.7, 0.4, 0.0, 0.8, 0.6, 0.9)
    }

    private fun tokens(m: ModelInfo): List<String> =
        (m.id + " " + m.name).lowercase().split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }

    private fun hintScore(m: ModelInfo, type: TaskType): Double {
        val hints = HINTS[type] ?: return 0.0
        val toks = tokens(m)
        val hit = hints.count { h -> toks.any { it == h || (h.length >= 4 && it.startsWith(h)) } }
        return min(hit, 2).toDouble() / 2.0
    }

    /** Ad/kimlikteki parametre sayısı ipucu (örn. "8b", "70b", "235b-a22b" → 235). Yoksa null. */
    private val sizeRegex = Regex("(?<![a-z0-9])(\\d+(?:\\.\\d+)?)b(?![a-z])")

    private fun sizeBillions(m: ModelInfo): Double? =
        sizeRegex.findAll((m.id + " " + m.name).lowercase())
            .mapNotNull { it.groupValues[1].toDoubleOrNull() }.maxOrNull()

    private fun meetsCapabilities(m: ModelInfo, p: TaskProfile): Boolean {
        if (m.expired) return false
        if (p.needsTools && !m.supportsTools) return false
        if (p.needsImages && !m.supportsImages) return false
        val needed = p.estimatedInputTokens + p.expectedOutputTokens + 512
        return m.contextLength >= needed
    }

    fun score(m: ModelInfo, p: TaskProfile, mode: CostMode): Double {
        val w = weights(p.type)
        val perM = m.completionPrice * 1_000_000.0
        val tier = ln(1.0 + perM)
        val cap = when (mode) { CostMode.ECONOMY -> 1.2; CostMode.BALANCED -> 2.6; CostMode.QUALITY -> 4.0 }
        val quality = min(tier, cap)
        val ageDays = max(0.0, (now() / 1000.0 - m.created) / 86_400.0)
        val fresh = max(0.0, 1.0 - ageDays / 540.0)
        val ctx = min(3.0, max(0.0, ln(m.contextLength / 8000.0))) / 3.0
        val costPenalty = when (mode) { CostMode.ECONOMY -> 0.5; CostMode.BALANCED -> 0.08; CostMode.QUALITY -> 0.0 } * w.costMul
        var s = quality * w.quality + fresh * w.fresh + ctx * w.ctx - costPenalty * tier
        if (m.supportsTools) s += w.tools
        if (m.supportsReasoning) s += w.reasoning
        s += hintScore(m, p.type) * w.hint
        // Ücretsiz modeller çoğunlukla küçük/kuantize ve hız sınırlıdır: Dengeli/Kalite modunda geri plana itilir.
        if (m.isFree) s += when (mode) { CostMode.ECONOMY -> 1.0; CostMode.BALANCED -> -0.6; CostMode.QUALITY -> -1.0 }
        // Küçük modeller (≤30B) Türkçe talimat takibinde zayıf kalır: boyuta göre ceza (ekonomik modda hafif).
        if (mode != CostMode.ECONOMY) {
            sizeBillions(m)?.let { b -> if (b < 30.0) s -= (1.0 - b / 30.0) * 1.2 }
            if (tokens(m).any { it == "nano" || it == "tiny" || it == "micro" }) s -= 0.8
        }
        return s
    }

    /**
     * Öncelikli + yedek model listesi. Sıra: (1) kullanıcının sabitledikleri (yetenekleri uygunsa),
     * (2) puana göre en iyiler; yedekler farklı sağlayıcı ailelerine yayılır; kredi bitme ihtimaline
     * karşı listede en az bir ücretsiz model bulunur. [avoid] içindekiler (ör. denetçinin, kodu yazan
     * modelden bağımsız olması için) listenin sonuna itilir.
     */
    fun rank(
        profile: TaskProfile,
        catalog: List<ModelInfo>,
        health: HealthTracker,
        settings: AgentSettings,
        avoid: Set<String> = emptySet(),
        limit: Int = DEFAULT_LIMIT
    ): List<ModelInfo> {
        val capable = catalog.filter { meetsCapabilities(it, profile) }
        if (capable.isEmpty()) return emptyList()
        val usable = capable.filter { health.isUsable(it) }
        // Hepsi geçici beklemedeyse (hız sınırı vb.) boş liste DÖNME: en erken açılacak modelleri ver ki
        // FallbackRunner "geçici beklemede" mantığıyla kısa süre bekleyip yeniden denesin.
        if (usable.isEmpty()) {
            return capable.filter { health.blockedForMs(it) != Long.MAX_VALUE }
                .sortedBy { health.blockedForMs(it) }.take(3)
        }
        val eligible = usable

        val pinnedIds = settings.pinned[profile.type].orEmpty()
        val pinned = pinnedIds.mapNotNull { id -> eligible.firstOrNull { it.id == id } }

        var pool = eligible.filter { it !in pinned }
        // Maliyet moduna göre kaba fiyat üst sınırı (çok pahalı modeller); havuz boşalırsa gevşetilir.
        val capPerM = when (settings.costMode) { CostMode.ECONOMY -> 5.0; CostMode.BALANCED -> 25.0; CostMode.QUALITY -> Double.MAX_VALUE }
        val capped = pool.filter { it.completionPrice * 1_000_000.0 <= capPerM }
        if (capped.isNotEmpty()) pool = capped

        val sorted = pool.sortedByDescending { score(it, profile, settings.costMode) }
        val spread = spreadFamilies(sorted)

        val result = mutableListOf<ModelInfo>()
        result += pinned
        for (m in spread) if (result.size < limit && m !in result) result += m

        // Kredi bitişine karşı kaçış yolu: listede ücretsiz model yoksa en iyi ücretsizi sona ekle.
        if (result.none { it.isFree }) {
            eligible.filter { it.isFree && it !in result }
                .maxByOrNull { score(it, profile, settings.costMode) }?.let { result += it }
        }

        if (avoid.isEmpty()) return result
        val (keep, push) = result.partition { it.id !in avoid }
        return keep + push
    }

    /** İlk modelden sonra gelen yedeklerin ilkini farklı bir sağlayıcı ailesinden seçer (ilişkili arızaları azaltır). */
    private fun spreadFamilies(sorted: List<ModelInfo>): List<ModelInfo> {
        if (sorted.size < 3) return sorted
        val first = sorted[0]
        val altIdx = sorted.drop(1).take(5).indexOfFirst { it.family != first.family }
        if (altIdx <= 0) return sorted
        val alt = sorted[altIdx + 1]
        return listOf(first, alt) + sorted.filter { it != first && it != alt }
    }
}
