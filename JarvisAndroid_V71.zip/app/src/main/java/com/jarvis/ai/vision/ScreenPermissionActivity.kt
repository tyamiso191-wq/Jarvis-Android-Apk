package com.jarvis.ai.vision

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/**
 * Arka Plan Modu'nda ekranı görmek için gereken ekran yakalama iznini (Android 14+'ta her
 * seferinde tek kullanımlık) almak için açılan şeffaf, görünmez aktivite. Servis bildirimine
 * dokunulunca açılır, sistem iznini sorar, sonucu ScreenVisionController'a bırakıp kapanır.
 */
class ScreenPermissionActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) return
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(ScreenVisionController.buildPermissionRequestIntent(this), 7001)
        } catch (e: Exception) {
            ScreenVisionController.completeBackgroundPermission(false)
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        val ok = requestCode == 7001 && resultCode == RESULT_OK && data != null
        if (ok) ScreenVisionController.onPermissionResult(resultCode, data)
        ScreenVisionController.completeBackgroundPermission(ok)
        finish()
    }
}
