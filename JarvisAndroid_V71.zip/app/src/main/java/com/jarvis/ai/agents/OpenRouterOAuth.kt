package com.jarvis.ai.agents

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URLDecoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

/** PKCE (RFC 7636) yardımcıları. */
object Pkce {
    private val b64 = Base64.getUrlEncoder().withoutPadding()

    /** 48 rastgele bayt -> 64 karakterlik doğrulayıcı (izin verilen aralık: 43–128). */
    fun newVerifier(random: SecureRandom = SecureRandom()): String {
        val bytes = ByteArray(48)
        random.nextBytes(bytes)
        return b64.encodeToString(bytes)
    }

    fun challengeS256(verifier: String): String =
        b64.encodeToString(
            MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII))
        )
}

sealed class OAuthResult {
    data class Success(val key: String) : OAuthResult()
    data class Failure(val message: String) : OAuthResult()
}

/** Yerel callback sunucusuna gelen ilk istek satırının (GET /callback?code=...) çözümü. */
internal object OAuthCallbackParser {
    sealed class Parsed {
        data class Code(val code: String) : Parsed()
        data class Denied(val reason: String) : Parsed()
        object Ignore : Parsed()
    }

    fun parse(requestLine: String?): Parsed {
        val parts = requestLine?.trim()?.split(" ") ?: return Parsed.Ignore
        if (parts.size < 2 || parts[0] != "GET") return Parsed.Ignore
        val target = parts[1]
        if (target.substringBefore('?') != "/callback") return Parsed.Ignore
        val params = target.substringAfter('?', "")
            .split('&')
            .filter { it.isNotEmpty() }
            .associate { it.substringBefore('=').dec() to it.substringAfter('=', "").dec() }
        params["code"]?.takeIf { it.isNotBlank() }?.let { return Parsed.Code(it) }
        params["error"]?.let { return Parsed.Denied(it) }
        return Parsed.Ignore
    }

    private fun String.dec(): String =
        try { URLDecoder.decode(this, "UTF-8") } catch (e: Exception) { this }
}

/**
 * OpenRouter'a tek tuşla bağlanma (OAuth PKCE).
 *
 * Akış:
 *  1. Telefonda yalnızca 127.0.0.1 üzerinde geçici bir port açılır (dışarıdan erişilemez).
 *  2. Kullanıcı tarayıcıda openrouter.ai/auth sayfasına gönderilir; callback_url
 *     http://localhost:<port>/callback olur (OpenRouter localhost callback'lerini her portta destekler).
 *  3. Onaydan sonra tarayıcı bu yerel porta ?code=... ile döner.
 *  4. Kod, PKCE doğrulayıcısıyla POST /api/v1/auth/keys'e verilip kullanıcıya ait API anahtarına çevrilir.
 *
 * Anahtar burada saklanmaz ve loglanmaz; çağıran taraf (JarvisViewModel.saveApiKey) doğrular
 * ve Android Keystore ile şifreli kaydeder.
 */
class OpenRouterOAuth(
    private val appPackage: String,
    private val http: OkHttpClient = OpenRouterClient.defaultHttp(),
    private val timeoutMs: Long = 5 * 60_000L,
    private val mainDispatcher: CoroutineDispatcher = Dispatchers.Main
) {
    companion object {
        const val AUTH_URL = "https://openrouter.ai/auth"
        const val KEYS_URL = "https://openrouter.ai/api/v1/auth/keys"
    }

    fun buildAuthUrl(callbackUrl: String, challenge: String): String =
        AUTH_URL +
            "?callback_url=" + java.net.URLEncoder.encode(callbackUrl, "UTF-8") +
            "&code_challenge=" + challenge +
            "&code_challenge_method=S256"

    /**
     * @param openBrowser verilen adresi tarayıcıda açar (ana iş parçacığında çağrılır).
     * İptal edilirse (coroutine cancel) sunucu kapanır.
     */
    suspend fun authorize(openBrowser: (String) -> Unit): OAuthResult = withContext(Dispatchers.IO) {
        val verifier = Pkce.newVerifier()
        val challenge = Pkce.challengeS256(verifier)

        val server = try {
            ServerSocket(0, 4, InetAddress.getByName("127.0.0.1"))
        } catch (e: IOException) {
            return@withContext OAuthResult.Failure("Yerel bağlantı noktası açılamadı. Anahtarı elle girebilirsin.")
        }

        try {
            server.soTimeout = 1000
            val callbackUrl = "http://localhost:${server.localPort}/callback"
            val url = buildAuthUrl(callbackUrl, challenge)
            withContext(mainDispatcher) { openBrowser(url) }

            val deadline = System.currentTimeMillis() + timeoutMs
            while (System.currentTimeMillis() < deadline) {
                currentCoroutineContext().ensureActive()
                val socket = try {
                    server.accept()
                } catch (e: SocketTimeoutException) {
                    continue
                }
                val outcome = socket.use { handle(it, verifier) }
                if (outcome != null) return@withContext outcome
            }
            OAuthResult.Failure("Onay zaman aşımına uğradı. Tekrar dene.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            OAuthResult.Failure(
                "Tarayıcı açılamadı ya da bağlantı kurulamadı: " +
                    Redactor.redact(e.message ?: e.javaClass.simpleName)
            )
        } finally {
            try { server.close() } catch (_: Exception) {}
        }
    }

    /** Tek bir tarayıcı isteğini işler. Sonuç belli olduysa döner, alakasız istekse null. */
    private fun handle(socket: Socket, verifier: String): OAuthResult? {
        socket.soTimeout = 3000
        val line = try {
            BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.US_ASCII)).readLine()
        } catch (e: IOException) {
            null
        }
        return when (val parsed = OAuthCallbackParser.parse(line)) {
            is OAuthCallbackParser.Parsed.Code -> {
                val result = exchange(parsed.code, verifier)
                respond(
                    socket,
                    200,
                    if (result is OAuthResult.Success) page("Bağlandı ✓", "OpenRouter bağlantısı tamamlandı. Uygulamaya dönebilirsin.", true)
                    else page("Bağlanamadı", (result as OAuthResult.Failure).message, false)
                )
                result
            }
            is OAuthCallbackParser.Parsed.Denied -> {
                respond(socket, 200, page("İptal edildi", "Bağlantı onaylanmadı. Uygulamaya dönüp tekrar deneyebilirsin.", false))
                OAuthResult.Failure("OpenRouter bağlantısı onaylanmadı.")
            }
            OAuthCallbackParser.Parsed.Ignore -> {
                respond(socket, 404, "Not found")
                null
            }
        }
    }

    private fun exchange(code: String, verifier: String): OAuthResult {
        val body = JSONObject()
            .put("code", code)
            .put("code_verifier", verifier)
            .put("code_challenge_method", "S256")
            .toString()
        val req = Request.Builder()
            .url(KEYS_URL)
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()
        return try {
            http.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    OAuthResult.Failure(
                        when (resp.code) {
                            400, 403 -> "OpenRouter kodu kabul etmedi (süresi dolmuş olabilir). Tekrar dene."
                            else -> "OpenRouter beklenmeyen yanıt verdi (HTTP ${resp.code})."
                        }
                    )
                } else {
                    val key = JSONObject(text).optString("key")
                    if (key.isBlank()) OAuthResult.Failure("OpenRouter anahtar döndürmedi.")
                    else OAuthResult.Success(key)
                }
            }
        } catch (e: IOException) {
            OAuthResult.Failure("OpenRouter'a ulaşılamadı: " + Redactor.redact(e.message ?: "bağlantı hatası"))
        } catch (e: Exception) {
            OAuthResult.Failure("Anahtar alınamadı: " + Redactor.redact(e.message ?: e.javaClass.simpleName))
        }
    }

    private fun respond(socket: Socket, status: Int, body: String) {
        try {
            val bytes = body.toByteArray(Charsets.UTF_8)
            val reason = if (status == 200) "OK" else "Not Found"
            val head = "HTTP/1.1 $status $reason\r\n" +
                "Content-Type: text/html; charset=utf-8\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Cache-Control: no-store\r\n" +
                "Connection: close\r\n\r\n"
            socket.getOutputStream().apply {
                write(head.toByteArray(Charsets.US_ASCII))
                write(bytes)
                flush()
            }
        } catch (_: IOException) {
        }
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun page(title: String, message: String, ok: Boolean): String {
        val back = "intent:#Intent;action=android.intent.action.MAIN;" +
            "category=android.intent.category.LAUNCHER;package=$appPackage;end"
        val color = if (ok) "#6FD3C8" else "#FF7D8B"
        return """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Jarvis</title>
<style>body{background:#080F16;color:#DDEFED;font-family:sans-serif;display:flex;flex-direction:column;
align-items:center;justify-content:center;min-height:100vh;margin:0;padding:24px;text-align:center}
h1{color:$color}a{background:#6FD3C8;color:#080F16;padding:14px 24px;border-radius:14px;
text-decoration:none;font-weight:bold;margin-top:20px}</style></head><body>
<h1>${esc(title)}</h1><p>${esc(message)}</p>
<a href="$back">Uygulamaya dön</a>
</body></html>"""
    }
}
