package com.jarvis.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.jarvis.ai.agents.*
import com.jarvis.ai.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun usd(v: Double): String = "$" + String.format(Locale.US, "%.4f", v)
private fun tok(v: Long): String = if (v >= 10_000) String.format(Locale.US, "%.1fk", v / 1000.0) else v.toString()

@Composable
private fun Card(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .background(Panel, RoundedCornerShape(20.dp))
            .padding(14.dp)
    ) {
        Text(title, color = Teal, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, fontFamily = UiFont)
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
private fun Line(label: String, value: String, valueColor: Color = Text) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Dim, fontSize = 12.sp, fontFamily = UiFont, modifier = Modifier.weight(1f))
        Text(value, color = valueColor, fontSize = 12.sp, fontFamily = UiFont, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(if (selected) Teal else TealMid, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Text(text, color = if (selected) Bg else Text, fontSize = 12.sp, fontFamily = UiFont, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun SmallButton(text: String, enabled: Boolean = true, danger: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(
                if (!enabled) TealMid else if (danger) Red.copy(alpha = 0.18f) else Teal.copy(alpha = 0.16f),
                RoundedCornerShape(12.dp)
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Text(text, color = if (!enabled) Dim else if (danger) Red else Teal, fontSize = 12.sp, fontFamily = UiFont)
    }
}

@Composable
fun AgentsScreen(
    settings: AgentSettings,
    keyInfo: KeyStatus.Valid?,
    keyBusy: Boolean,
    models: List<ModelInfo>,
    tasks: List<TaskState>,
    usage: List<UsageRecord>,
    events: List<EventRecord>,
    runtime: AiRuntime,
    onUpdate: ((AgentSettings) -> AgentSettings) -> Unit,
    onCancelTask: (String) -> Unit,
    onRefreshKey: () -> Unit,
    onRefreshModels: () -> Unit,
    onChangeKey: () -> Unit,
    onClearHistory: () -> Unit,
    onClose: () -> Unit
) {
    var pickerFor by remember { mutableStateOf<TaskType?>(null) }
    val timeFmt = remember { SimpleDateFormat("HH:mm:ss", Locale("tr", "TR")) }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().background(Panel).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("AI AJANLARI / MODEL YÖNETİMİ", color = Teal, fontSize = 14.sp, fontFamily = UiFont,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("KAPAT", color = Dim, fontSize = 12.sp, fontFamily = UiFont, modifier = Modifier.clickable(onClick = onClose).padding(6.dp))
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(vertical = 8.dp)) {

            // ---- Bağlantı ----
            Card("OPENROUTER BAĞLANTISI") {
                if (keyInfo != null) {
                    Line("Durum", "Anahtar doğrulandı", Green)
                    keyInfo.label?.let { Line("Anahtar etiketi", it) }
                    keyInfo.usageUsd?.let { Line("Bu anahtarla toplam harcama", usd(it)) }
                    Line("Anahtar limiti", keyInfo.limitUsd?.let { usd(it) } ?: "limit yok / bilinmiyor")
                    keyInfo.limitRemainingUsd?.let { Line("Kalan limit", usd(it)) }
                    if (keyInfo.isFreeTier == true) Line("Hesap", "Ücretsiz katman", Gold)
                } else {
                    Line("Durum", "Henüz doğrulanmadı", Gold)
                }
                Line("Keşfedilen model", "${models.size}")
                if (runtime.health.creditsBlocked()) Line("Kredi durumu", "Kredi yetersiz uyarısı alındı", Red)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallButton(if (keyBusy) "Kontrol…" else "Anahtarı sına", enabled = !keyBusy, onClick = onRefreshKey)
                    SmallButton("Modelleri yenile", onClick = onRefreshModels)
                    SmallButton("Anahtarı değiştir", danger = true, onClick = onChangeKey)
                }
            }

            // ---- Mod + çoklu ajan ----
            Card("MOD VE ÇOKLU AJAN") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Basit", !settings.advancedMode) { onUpdate { it.copy(advancedMode = false) } }
                    Chip("Gelişmiş", settings.advancedMode) { onUpdate { it.copy(advancedMode = true) } }
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Çoklu ajan sistemi", color = Text, fontSize = 13.sp, fontFamily = UiFont)
                        Text("Yalnızca büyük/karmaşık görevlerde devreye girer; sohbet tek modelle cevaplanır.",
                            color = Dim, fontSize = 11.sp, fontFamily = UiFont)
                    }
                    Switch(checked = settings.multiAgentEnabled, onCheckedChange = { v -> onUpdate { it.copy(multiAgentEnabled = v) } })
                }
                Spacer(Modifier.height(8.dp))
                Text("Eşzamanlı ajan sınırı: ${settings.maxConcurrent} (en fazla 10)", color = Text, fontSize = 12.sp, fontFamily = UiFont)
                Slider(
                    value = settings.maxConcurrent.toFloat(), valueRange = 1f..10f, steps = 8,
                    onValueChange = { v -> onUpdate { it.copy(maxConcurrent = v.toInt()) } },
                    enabled = settings.multiAgentEnabled
                )
                Text("Maliyet modu", color = Text, fontSize = 12.sp, fontFamily = UiFont)
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CostMode.values().forEach { m -> Chip(m.label, settings.costMode == m) { onUpdate { it.copy(costMode = m) } } }
                }
                if (settings.costMode == CostMode.ECONOMY) {
                    Spacer(Modifier.height(4.dp))
                    Text("Ekonomik mod ücretsiz modelleri öne alır; bunlar hız/günlük limitlere takılabilir ve hesap durumuna bağlıdır.",
                        color = Dim, fontSize = 11.sp, fontFamily = UiFont)
                }
                if (settings.advancedMode) {
                    Spacer(Modifier.height(10.dp))
                    Text("Görev başına token bütçesi: ${settings.taskTokenBudget}", color = Text, fontSize = 12.sp, fontFamily = UiFont)
                    Slider(
                        value = settings.taskTokenBudget.toFloat(), valueRange = 10_000f..500_000f,
                        onValueChange = { v -> onUpdate { it.copy(taskTokenBudget = (v / 5000).toInt() * 5000) } }
                    )
                    Text("Görev başına maliyet bütçesi: ${usd(settings.taskCostBudgetUsd)}", color = Text, fontSize = 12.sp, fontFamily = UiFont)
                    Slider(
                        value = settings.taskCostBudgetUsd.toFloat(), valueRange = 0.05f..5f,
                        onValueChange = { v -> onUpdate { it.copy(taskCostBudgetUsd = (v * 20).toInt() / 20.0) } }
                    )
                    Text("Ajan zaman aşımı: ${settings.agentTimeoutSec} sn", color = Text, fontSize = 12.sp, fontFamily = UiFont)
                    Slider(
                        value = settings.agentTimeoutSec.toFloat(), valueRange = 30f..300f,
                        onValueChange = { v -> onUpdate { it.copy(agentTimeoutSec = (v / 10).toInt() * 10) } }
                    )
                }
            }

            // ---- Aktif / son görevler ----
            Card("ÇOKLU AJAN GÖREVLERİ") {
                if (tasks.isEmpty()) {
                    Text("Henüz çoklu ajan görevi çalışmadı.", color = Dim, fontSize = 12.sp, fontFamily = UiFont)
                }
                tasks.reversed().forEach { t ->
                    val active = t.phase == TaskPhase.PLANNING || t.phase == TaskPhase.RUNNING ||
                        t.phase == TaskPhase.REVIEWING || t.phase == TaskPhase.MERGING
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${t.id}  ${t.title}", color = Text, fontSize = 12.sp, fontFamily = UiFont,
                                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            Text(t.phase.name, color = if (active) Gold else if (t.phase == TaskPhase.DONE) Green else Red,
                                fontSize = 11.sp, fontFamily = UiFont)
                        }
                        Line("Gerçekleşen maliyet", usd(t.actualCostUsd))
                        Line("Gerçek token", tok(t.actualTokens))
                        t.estimatedCostUsd?.let { Line("Çalışma öncesi TAHMİN", "~" + usd(it), Dim) }
                        if (t.unknownUsageCalls > 0) {
                            Text("${t.unknownUsageCalls} çağrıda sağlayıcı kullanım bilgisi vermedi (tahminle doldurulmadı).",
                                color = Gold, fontSize = 11.sp, fontFamily = UiFont)
                        }
                        t.note?.let { Text(it, color = Dim, fontSize = 11.sp, fontFamily = UiFont) }
                        t.agents.forEach { a ->
                            Row(Modifier.fillMaxWidth().padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("${a.role.label} (${a.id})", color = Text, fontSize = 11.sp, fontFamily = UiFont, modifier = Modifier.weight(1f))
                                Text(a.status.name, color = when (a.status) {
                                    AgentStatus.DONE -> Green; AgentStatus.FAILED -> Red; AgentStatus.RUNNING -> Gold; else -> Dim
                                }, fontSize = 11.sp, fontFamily = UiFont)
                            }
                            val detail = listOfNotNull(
                                a.modelId?.let { "model: $it" },
                                if (a.promptTokens + a.completionTokens > 0) "${tok(a.promptTokens)}→${tok(a.completionTokens)} token, ${usd(a.costUsd)}" else null,
                                a.error
                            ).joinToString(" · ")
                            if (detail.isNotBlank()) Text(detail, color = Dim, fontSize = 10.sp, fontFamily = UiFont, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        if (active) {
                            Spacer(Modifier.height(6.dp))
                            SmallButton("Görevi iptal et", danger = true) { onCancelTask(t.id) }
                        }
                    }
                }
            }

            // ---- Model yönlendirme önizlemesi ----
            Card("MODEL SEÇİMİ (GÖREV TÜRÜNE GÖRE)") {
                Text(
                    "Modeller OpenRouter kataloğundan otomatik seçilir (fiyat, bağlam, araç/akıl yürütme/görsel desteği, yenilik). " +
                        "Bu sıralama bir sezgiseldir; kalite ölçümü değildir.",
                    color = Dim, fontSize = 11.sp, fontFamily = UiFont
                )
                Spacer(Modifier.height(6.dp))
                TaskType.values().forEach { type ->
                    val profile = TaskProfile(
                        type, Complexity.MEDIUM, needsTools = type == TaskType.CHAT || type == TaskType.RESEARCH,
                        needsImages = type == TaskType.VISION
                    )
                    val chain = remember(models, settings) {
                        runtime.router.rank(profile, models, runtime.health, settings, limit = 4)
                    }
                    val pinned = settings.pinned[type].orEmpty()
                    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(type.label + if (pinned.isNotEmpty()) " (sabit)" else "", color = Text, fontSize = 12.sp,
                                fontFamily = UiFont, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                            if (settings.advancedMode) {
                                SmallButton("Düzenle") { pickerFor = type }
                            }
                        }
                        if (chain.isEmpty()) {
                            Text("Uygun model yok (katalog boş ya da özellik desteklenmiyor).", color = Red, fontSize = 11.sp, fontFamily = UiFont)
                        } else {
                            chain.forEachIndexed { i, m ->
                                Text(
                                    (if (i == 0) "▸ öncelikli: " else "   yedek ${i}: ") + m.id +
                                        (if (m.isFree) "  [ücretsiz]" else ""),
                                    color = if (i == 0) Green else Dim, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            // ---- Kullanım ----
            Card("KULLANIM VE MALİYET (GERÇEK VERİ)") {
                val ledger = runtime.ledger
                val total = remember(usage) { ledger.summarize() }
                Line("Toplam çağrı", "${total.calls} (başarısız: ${total.failedCalls})")
                Line("Başarısızlık oranı", String.format(Locale.US, "%.1f%%", ledger.failureRate() * 100))
                Line("Ort. gecikme (başarılı)", "${ledger.avgLatencyMs()} ms")
                Line("Giriş tokenı", tok(total.promptTokens))
                Line("Çıkış tokenı", tok(total.completionTokens))
                Line("Gerçekleşen maliyet", usd(total.costUsd), Green)
                Line("  OpenRouter'ın bildirdiği", usd(total.reportedCostUsd))
                Line("  Gerçek token × katalog fiyatı", usd(total.computedCostUsd))
                if (total.unknownUsageCalls > 0) {
                    Text("${total.unknownUsageCalls} başarılı çağrıda kullanım bilgisi gelmedi; bunlar toplamlara DAHİL DEĞİL.",
                        color = Gold, fontSize = 11.sp, fontFamily = UiFont)
                }
                val byModel = remember(usage) { ledger.byModel().take(5) }
                if (byModel.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Model bazında", color = Dim, fontSize = 11.sp, fontFamily = UiFont)
                    byModel.forEach { (m, s) ->
                        Text("$m — ${s.calls} çağrı, ${tok(s.totalTokens)} token, ${usd(s.costUsd)}", color = Text, fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
                val byAgent = remember(usage) { ledger.byAgent().take(8) }
                if (byAgent.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Ajan bazında", color = Dim, fontSize = 11.sp, fontFamily = UiFont)
                    byAgent.forEach { (a, s) ->
                        Text("$a — ${s.calls} çağrı, ${tok(s.totalTokens)} token, ${usd(s.costUsd)}", color = Text, fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace)
                    }
                }
            }

            // ---- Kayıtlar ----
            Card("HATA VE YEDEK MODEL KAYITLARI") {
                if (events.isEmpty()) {
                    Text("Kayıt yok.", color = Dim, fontSize = 12.sp, fontFamily = UiFont)
                }
                events.takeLast(40).reversed().forEach { e ->
                    Text(
                        "${timeFmt.format(Date(e.ts))} [${e.kind.name}] ${e.message}",
                        color = when (e.kind) { EventKind.ERROR -> Red; EventKind.FALLBACK -> Gold; EventKind.BUDGET -> Gold; else -> Dim },
                        fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(vertical = 1.dp)
                    )
                }
                Spacer(Modifier.height(8.dp))
                SmallButton("Kullanım ve kayıtları temizle", danger = true, onClick = onClearHistory)
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    pickerFor?.let { type ->
        ModelPickerDialog(
            type = type,
            models = models,
            selected = settings.pinned[type].orEmpty(),
            onDismiss = { pickerFor = null },
            onSave = { ids ->
                onUpdate { s -> s.copy(pinned = if (ids.isEmpty()) s.pinned - type else s.pinned + (type to ids)) }
                pickerFor = null
            }
        )
    }
}

@Composable
private fun ModelPickerDialog(
    type: TaskType,
    models: List<ModelInfo>,
    selected: List<String>,
    onDismiss: () -> Unit,
    onSave: (List<String>) -> Unit
) {
    val chosen = remember { mutableStateListOf<String>().also { it.addAll(selected) } }
    var query by remember { mutableStateOf("") }
    val filtered = remember(models, query) {
        models.filter { query.isBlank() || it.id.contains(query, ignoreCase = true) || it.name.contains(query, ignoreCase = true) }
            .sortedBy { it.id }.take(80)
    }
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(14.dp)) {
            Text("${type.label}: öncelikli + yedek modeller", color = Teal, fontSize = 13.sp, fontFamily = UiFont, fontWeight = FontWeight.Bold)
            Text("Dokunma sırası = deneme sırası. Boş bırakırsan otomatik seçilir.", color = Dim, fontSize = 11.sp, fontFamily = UiFont)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("Model ara", color = Dim, fontFamily = UiFont) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Teal, unfocusedBorderColor = TealDim,
                    focusedTextColor = Text, unfocusedTextColor = Text, cursorColor = Teal
                ),
                modifier = Modifier.fillMaxWidth()
            )
            LazyColumn(Modifier.heightIn(max = 340.dp).padding(vertical = 6.dp)) {
                items(filtered, key = { it.id }) { m ->
                    val idx = chosen.indexOf(m.id)
                    Row(
                        Modifier.fillMaxWidth().clickable { if (idx >= 0) chosen.remove(m.id) else chosen.add(m.id) }.padding(vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (idx >= 0) "${idx + 1}." else "  ", color = Green, fontSize = 12.sp, fontFamily = UiFont, modifier = Modifier.width(24.dp))
                        Column(Modifier.weight(1f)) {
                            Text(m.id, color = Text, fontSize = 11.sp, fontFamily = FontFamily.Monospace, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                (if (m.isFree) "ücretsiz" else "\$" + String.format(Locale.US, "%.2f", m.completionPrice * 1_000_000) + "/M çıkış") +
                                    " · ${m.contextLength / 1000}k bağlam" + (if (!m.supportsTools) " · araç YOK" else "") + (if (m.supportsImages) " · görsel" else ""),
                                color = Dim, fontSize = 10.sp, fontFamily = UiFont
                            )
                        }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallButton("Kaydet") { onSave(chosen.toList()) }
                SmallButton("Otomatik") { onSave(emptyList()) }
                SmallButton("İptal", onClick = onDismiss)
            }
        }
    }
}
