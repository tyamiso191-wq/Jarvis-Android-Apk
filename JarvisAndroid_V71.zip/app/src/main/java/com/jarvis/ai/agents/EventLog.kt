package com.jarvis.ai.agents

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean

enum class EventKind { INFO, ERROR, FALLBACK, BUDGET, TASK }

data class EventRecord(
    val ts: Long,
    val kind: EventKind,
    val message: String,
    val taskId: String? = null,
    val modelId: String? = null
)

/** Basit anahtar-değer yazıcı (Android'de dosya, testte null). */
interface TextStore {
    fun load(): String?
    fun save(text: String)
}

/** Hata, yedek model geçişi ve bütçe olayları. Kullanıcıya gösterilecekler [userNotifier] ile iletilir. */
class EventLog(
    private val cap: Int = 200,
    private val store: TextStore? = null,
    private val scope: CoroutineScope? = null,
    private val now: () -> Long = System::currentTimeMillis
) {
    private val _events = MutableStateFlow(store?.load()?.let { parse(it) } ?: emptyList())
    val events: StateFlow<List<EventRecord>> = _events.asStateFlow()

    /** FALLBACK / BUDGET / önemli ERROR olayları sohbete kısa bir bilgi olarak düşsün diye. */
    @Volatile var userNotifier: ((String) -> Unit)? = null

    private val savePending = AtomicBoolean(false)

    fun add(kind: EventKind, message: String, taskId: String? = null, modelId: String? = null, notifyUser: Boolean = false) {
        val clean = Redactor.redact(message).take(400)
        _events.update { (it + EventRecord(now(), kind, clean, taskId, modelId)).takeLast(cap) }
        scheduleSave()
        if (notifyUser) {
            try { userNotifier?.invoke(clean) } catch (e: Exception) { /* arayüz hatası akışı bozmasın */ }
        }
    }

    fun clear() {
        _events.value = emptyList()
        scheduleSave()
    }

    private fun scheduleSave() {
        val st = store ?: return
        val sc = scope ?: return
        if (savePending.compareAndSet(false, true)) {
            sc.launch {
                delay(1500)
                savePending.set(false)
                try { st.save(toJson(_events.value)) } catch (e: Exception) { /* kayıt başarısızsa bellekte kalır */ }
            }
        }
    }

    private fun toJson(list: List<EventRecord>): String {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("ts", it.ts).put("k", it.kind.name).put("m", it.message)
                    .put("t", it.taskId ?: JSONObject.NULL).put("md", it.modelId ?: JSONObject.NULL)
            )
        }
        return arr.toString()
    }

    private fun parse(json: String): List<EventRecord> = try {
        val arr = JSONArray(json)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            EventRecord(
                o.optLong("ts"), runCatching { EventKind.valueOf(o.optString("k")) }.getOrDefault(EventKind.INFO),
                o.optString("m"), if (o.isNull("t")) null else o.optString("t"),
                if (o.isNull("md")) null else o.optString("md")
            )
        }
    } catch (e: Exception) {
        emptyList()
    }
}
