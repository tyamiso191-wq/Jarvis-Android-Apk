package com.jarvis.ai.automation

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Jarvis'in "senin yerine dokunan/yazan" eli. Kullanıcı Ayarlar > Erişilebilirlik
 * bölümünden AÇIKÇA etkinleştirmedikçe çalışmaz ve sadece Jarvis bir komut
 * (örn. "Ahmet'e Instagram'dan mesaj at") işlerken kullanılır.
 *
 * Güvenlik: işlem sürerken ekranda "DURDUR" düğmeli bir şerit gösterilir;
 * düğme [cancelRequested] bayrağını kaldırır ve akış hemen kesilir.
 */
class JarvisAccessibilityService : AccessibilityService() {

    private var overlayView: LinearLayout? = null
    private var overlayText: TextView? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* olaylar polling ile okunuyor */ }

    override fun onInterrupt() {}

    override fun onDestroy() {
        hideOverlay()
        if (instance === this) instance = null
        super.onDestroy()
    }

    // ─── Ekran okuma ──────────────────────────────────────────────────────
    /** Belirli bir paketin penceresinin kökü (pencere aktif/odakta olmasa bile). */
    fun rootFor(pkg: String): AccessibilityNodeInfo? {
        try {
            for (w in windows) {
                val r = w.root ?: continue
                if (r.packageName?.toString() == pkg) return r
            }
        } catch (_: Exception) { }
        val active = rootInActiveWindow
        return if (active?.packageName?.toString() == pkg) active else null
    }

    fun windowBounds(pkg: String): Rect? {
        val r = rootFor(pkg) ?: return null
        val b = Rect()
        r.getBoundsInScreen(b)
        return b
    }

    /** Tüm pencerelerin kökleri (split-screen seçici/recents için). */
    fun allRoots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) w.root?.let { out.add(it) }
        } catch (_: Exception) { }
        rootInActiveWindow?.let { if (out.isEmpty()) out.add(it) }
        return out
    }

    // ─── Düğüm arama ──────────────────────────────────────────────────────
    fun findAll(root: AccessibilityNodeInfo, predicate: (AccessibilityNodeInfo) -> Boolean): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40) return
            if (predicate(n)) out.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return out
    }

    fun labelOf(n: AccessibilityNodeInfo): String =
        listOfNotNull(n.text?.toString(), n.contentDescription?.toString())
            .joinToString(" ").trim()

    /**
     * Yazı VEYA açıklama, verilen etiketlerden birine TAM eşit mi? (labelOf ikisini
     * birleştirdiği için "Mesaj Mesaj" gibi çift yazılan düğmeler eşleşmiyordu.)
     */
    fun matches(n: AccessibilityNodeInfo, labels: List<String>): Boolean =
        listOfNotNull(n.text?.toString(), n.contentDescription?.toString())
            .any { it.trim().lowercase() in labels }

    /** Düğüm tıklanabilir değilse tıklanabilir ilk atasını tıklar. */
    fun click(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var hops = 0
        while (n != null && hops < 8) {
            if (n.isClickable && n.isEnabled) {
                if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
            n = n.parent
            hops++
        }
        return false
    }

    fun setText(node: AccessibilityNodeInfo, text: String): Boolean {
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun toggleSplitScreen() = performGlobalAction(GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)

    // ─── "Jarvis çalışıyor" şeridi + DURDUR ───────────────────────────────
    private val main = Handler(Looper.getMainLooper())

    fun showOverlay(message: String) { main.post { showOverlayOnMain(message) } }

    fun hideOverlay() { main.removeCallbacks(hideRunnable); main.post { hideOverlayOnMain() } }

    private val hideRunnable = Runnable { hideOverlayOnMain() }

    /** Şerit, son işlemden [ms] sonra kendiliğinden kaybolur (art arda adımlarda açık kalır). */
    fun hideOverlayDelayed(ms: Long) {
        main.removeCallbacks(hideRunnable)
        main.postDelayed(hideRunnable, ms)
    }

    private fun showOverlayOnMain(message: String) {
        main.removeCallbacks(hideRunnable)
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val existing = overlayText
        if (existing != null) {
            existing.text = message
            return
        }
        val bg = GradientDrawable().apply {
            setColor(Color.parseColor("#E6010A0A"))
            setStroke(2, Color.parseColor("#00D4C0"))
            cornerRadius = 40f
        }
        val label = TextView(this).apply {
            text = message
            setTextColor(Color.parseColor("#00D4C0"))
            textSize = 13f
            setPadding(24, 12, 24, 12)
        }
        val stop = TextView(this).apply {
            text = "DURDUR"
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(28, 12, 28, 12)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#CC2222")); cornerRadius = 30f
            }
            setOnClickListener {
                cancelRequested = true
                (overlayText)?.text = "Durduruluyor…"
            }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = bg
            setPadding(16, 8, 12, 8)
            addView(label)
            addView(stop)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 160
        }
        try {
            wm.addView(row, lp)
            overlayView = row
            overlayText = label
        } catch (_: Exception) { }
    }

    private fun hideOverlayOnMain() {
        val v = overlayView ?: return
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (_: Exception) { }
        overlayView = null
        overlayText = null
    }

    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
        @Volatile var cancelRequested: Boolean = false

        fun isEnabled(): Boolean = instance != null
    }
}
