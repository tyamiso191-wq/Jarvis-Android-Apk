package com.jarvis.ai.agents

import org.json.JSONObject

data class PlanNode(
    val id: String,
    val role: AgentRole,
    val goal: String,
    val dependsOn: List<String> = emptyList()
)

/** Planner çıktısını doğrular; bozuksa yerel şablona düşer. Döngü ve tekrar görevleri engellenir. */
object AgentPlan {

    fun parse(text: String, maxNodes: Int): List<PlanNode>? {
        val json = extractJson(text) ?: return null
        val arr = try { JSONObject(json).optJSONArray("tasks") } catch (e: Exception) { null } ?: return null
        val nodes = mutableListOf<PlanNode>()
        val seenGoals = HashSet<String>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("id").trim().ifBlank { "a${i + 1}" }
            val role = runCatching { AgentRole.valueOf(o.optString("role").trim().uppercase()) }.getOrNull() ?: continue
            if (role == AgentRole.PLANNER) continue
            val goal = o.optString("goal").trim()
            if (goal.isBlank() || nodes.any { it.id == id }) continue
            // Aynı rol + aynı hedef ikinci kez çalışmasın.
            if (!seenGoals.add(role.name + "|" + goal.lowercase().take(80))) continue
            val deps = o.optJSONArray("depends_on")?.let { d -> (0 until d.length()).map { d.optString(it).trim() } }.orEmpty()
            nodes += PlanNode(id, role, goal.take(600), deps)
            if (nodes.size >= maxNodes) break
        }
        if (nodes.isEmpty()) return null
        return sanitize(nodes)
    }

    /** Var olmayan bağımlılıkları atar; döngü varsa tüm bağımlılıkları kaldırır. */
    fun sanitize(nodes: List<PlanNode>): List<PlanNode> {
        val ids = nodes.map { it.id }.toSet()
        val cleaned = nodes.map { n -> n.copy(dependsOn = n.dependsOn.filter { it in ids && it != n.id }.distinct()) }
        return topoOrder(cleaned) ?: cleaned.map { it.copy(dependsOn = emptyList()) }
    }

    /** Bağımlılık sırasına göre dizer; döngü varsa null. */
    fun topoOrder(nodes: List<PlanNode>): List<PlanNode>? {
        val remaining = nodes.toMutableList()
        val done = HashSet<String>()
        val out = mutableListOf<PlanNode>()
        while (remaining.isNotEmpty()) {
            val ready = remaining.filter { n -> n.dependsOn.all { it in done } }
            if (ready.isEmpty()) return null
            ready.forEach { out += it; done += it.id }
            remaining.removeAll(ready.toSet())
        }
        return out
    }

    /** Planner yanıt vermezse kullanılan, görev türüne göre deterministik şablon. */
    fun template(type: TaskType, goal: String, maxNodes: Int): List<PlanNode> {
        val g = goal.take(300)
        val nodes: List<PlanNode> = when (type) {
            TaskType.RESEARCH -> listOf(
                PlanNode("r1", AgentRole.RESEARCH, "Konunun güncel durumunu ve ana kaynaklarını araştır: $g"),
                PlanNode("r2", AgentRole.RESEARCH, "Karşıt görüşleri, riskleri ve eksik kalan noktaları araştır: $g"),
                PlanNode("a1", AgentRole.ANALYSIS, "Bulguları karşılaştır ve sonuç çıkar.", listOf("r1", "r2")),
                PlanNode("w1", AgentRole.WRITING, "Bulguları düzenli bir özet olarak yaz.", listOf("a1"))
            )
            TaskType.REASONING -> listOf(
                PlanNode("a1", AgentRole.ANALYSIS, "Problemi çöz, birinci yaklaşım: $g"),
                PlanNode("a2", AgentRole.ANALYSIS, "Problemi bağımsız olarak farklı bir yaklaşımla çöz: $g"),
                PlanNode("v1", AgentRole.REVIEW, "İki çözümü karşılaştır, hataları ve çelişkileri bul.", listOf("a1", "a2"))
            )
            else -> listOf(
                PlanNode("p1", AgentRole.ANALYSIS, "Mimariyi ve dosya yapısını tasarla: $g"),
                PlanNode("r1", AgentRole.RESEARCH, "Gereken kütüphane/API dokümantasyonunu araştır: $g"),
                PlanNode("c1", AgentRole.CODING, "Mimariye göre kodu üret: $g", listOf("p1", "r1")),
                PlanNode("v1", AgentRole.REVIEW, "Üretilen kodu bağımsız olarak denetle.", listOf("c1")),
                PlanNode("t1", AgentRole.TESTING, "Üretilen kod için test senaryoları tasarla.", listOf("c1")),
                PlanNode("s1", AgentRole.SECURITY, "Üretilen kodun güvenlik risklerini değerlendir.", listOf("c1")),
                PlanNode("w1", AgentRole.WRITING, "Kullanım/kurulum dokümantasyonunu hazırla.", listOf("c1"))
            )
        }
        return fit(nodes, maxNodes)
    }

    /** En fazla [max] düğüme sığdırır: önce öncelikli (atılabilir) rolleri çıkarır, bağımlılıkları temizler. */
    fun fit(nodes: List<PlanNode>, max: Int): List<PlanNode> {
        var cur = nodes
        while (cur.size > max.coerceAtLeast(1)) {
            val victim = cur.filter { it.role.dropPriority > 0 }.minByOrNull { it.role.dropPriority } ?: cur.last()
            cur = cur.filter { it.id != victim.id }
        }
        return sanitize(cur)
    }

    private fun extractJson(text: String): String? {
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        return if (start in 0 until end) text.substring(start, end + 1) else null
    }
}
