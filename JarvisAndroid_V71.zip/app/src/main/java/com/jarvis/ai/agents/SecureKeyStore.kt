package com.jarvis.ai.agents

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * OpenRouter API anahtarı güvenli depolama: AES-256-GCM anahtarı Android Keystore içinde
 * (çıkarılamaz) durur; SharedPreferences'ta yalnızca ŞİFRELİ veri bulunur. Düz metin anahtar
 * diske yazılmaz, loglanmaz. Keystore kullanılamazsa anahtar yalnızca bellekte tutulur
 * (uygulama yeniden başlayınca tekrar sorulur) — asla düz metin kaydedilmez.
 */
class SecureKeyStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("jarvis_secure", Context.MODE_PRIVATE)
    @Volatile private var memoryOnly: String? = null

    companion object {
        private const val ALIAS = "jarvis_openrouter_key"
        private const val PREF = "or_key_enc"
        private const val PROVIDER = "AndroidKeyStore"
        private const val TRANSFORM = "AES/GCM/NoPadding"
    }

    fun get(): String? {
        memoryOnly?.let { return it }
        val blob = prefs.getString(PREF, null) ?: return null
        return try { decrypt(blob) } catch (e: Exception) { null }
    }

    fun has(): Boolean = !get().isNullOrBlank()

    /** @return true: şifreli olarak kalıcı kaydedildi; false: yalnızca bellekte tutuldu. */
    fun save(key: String): Boolean {
        val k = key.trim()
        return try {
            prefs.edit().putString(PREF, encrypt(k)).apply()
            memoryOnly = null
            true
        } catch (e: Exception) {
            memoryOnly = k
            prefs.edit().remove(PREF).apply()
            false
        }
    }

    fun clear() {
        memoryOnly = null
        prefs.edit().remove(PREF).apply()
    }

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance(PROVIDER).apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    private fun encrypt(plain: String): String {
        val cipher = Cipher.getInstance(TRANSFORM)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val ct = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(cipher.iv + ct, Base64.NO_WRAP)
    }

    private fun decrypt(blob: String): String {
        val bytes = Base64.decode(blob, Base64.NO_WRAP)
        val iv = bytes.copyOfRange(0, 12)
        val ct = bytes.copyOfRange(12, bytes.size)
        val cipher = Cipher.getInstance(TRANSFORM)
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(ct), Charsets.UTF_8)
    }
}
