package com.jarvis.ai.vision

import android.content.Context
import android.util.Base64
import com.jarvis.ai.agents.AiRuntime
import com.jarvis.ai.agents.AiUnavailableException
import com.jarvis.ai.agents.CallContext
import com.jarvis.ai.agents.Complexity
import com.jarvis.ai.agents.TaskProfile
import com.jarvis.ai.agents.TaskType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/**
 * analyze_screen / analyze_webcam fonksiyonları için: tek bir fotoğrafı, araç çağırma
 * OLMADAN, OpenRouter üzerinden GÖRSEL GİRDİYİ destekleyen bir modele gönderir. Model,
 * OpenRouter kataloğundan (image girişi destekleyenler arasından) otomatik seçilir;
 * kota/hata durumunda ortak yedekleme mekanizması devreye girer.
 */
object VisionAnalyzer {
    suspend fun analyze(context: Context, jpegBytes: ByteArray, question: String): Result<String> =
        withContext(Dispatchers.IO) {
            val runtime = AiRuntime.get(context)
            val b64 = Base64.encodeToString(jpegBytes, Base64.NO_WRAP)
            val prompt = question.ifBlank { "Bu görselde ne görüyorsun? Kısa ve net Türkçe anlat." }
            val profile = TaskProfile(
                TaskType.VISION, Complexity.LOW, needsImages = true,
                estimatedInputTokens = 1500, expectedOutputTokens = 700
            )
            try {
                val candidates = runtime.chatCandidates(profile)
                val text = runtime.runner.run("vision", "görsel analiz", candidates) { model ->
                    val messages = JSONArray().put(
                        JSONObject().put("role", "user").put(
                            "content", JSONArray()
                                .put(JSONObject().put("type", "text").put("text", prompt))
                                .put(
                                    JSONObject().put("type", "image_url").put(
                                        "image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64")
                                    )
                                )
                        )
                    )
                    val body = JSONObject().put("messages", messages).put("max_tokens", 1200)
                    val reply = runtime.caller.complete(CallContext("vision", "VISION#analyze", "görsel analiz"), model, body)
                    val c = reply.message.opt("content")
                    val t = if (c == null || c == JSONObject.NULL) "" else c.toString()
                    if (t.isBlank()) throw IOException("boş yanıt") else t.trim()
                }
                Result.success(text)
            } catch (e: CancellationException) {
                throw e
            } catch (e: AiUnavailableException) {
                Result.failure(IOException(e.userMessage))
            } catch (e: Exception) {
                Result.failure(IOException(e.message ?: "Görsel analiz edilemedi"))
            }
        }
}
