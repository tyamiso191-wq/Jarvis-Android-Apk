package com.jarvis.ai.memory

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Kalıcı, uzun-vadeli hafıza. Windows Jarvis V3'teki memory_manager.py'nin
 * (save_memory / delete_memory araçları) Android karşılığı.
 *
 * Konuşma geçmişinden FARKLI: konuşma geçmişi belli bir sayıda mesajla
 * sınırlıyken ("MAX_HISTORY_SENT"), buraya kaydedilen notlar kullanıcı
 * silene kadar HER sohbette (uygulama kapatılıp açılsa bile) hatırlanır --
 * örn. "kedimin adı Pamuk", "işe pazartesi-cuma 08:00'de gidiyorum" gibi.
 *
 * Basit bir SharedPreferences + JSON dizisi olarak saklanır, ekstra bir
 * kütüphane ya da izin gerekmez.
 */
object MemoryStore {
    private const val PREFS = "jarvis_memory_store"
    private const val KEY_ITEMS = "items"
    private const val MAX_ITEMS = 200

    data class MemoryItem(val id: String, val text: String, val savedAtMillis: Long)

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun list(context: Context): List<MemoryItem> {
        val raw = prefs(context).getString(KEY_ITEMS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                MemoryItem(
                    id = o.optString("id"),
                    text = o.optString("text"),
                    savedAtMillis = o.optLong("savedAtMillis")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    private fun save(context: Context, items: List<MemoryItem>) {
        val arr = JSONArray()
        items.takeLast(MAX_ITEMS).forEach { item ->
            arr.put(JSONObject().apply {
                put("id", item.id)
                put("text", item.text)
                put("savedAtMillis", item.savedAtMillis)
            })
        }
        prefs(context).edit().putString(KEY_ITEMS, arr.toString()).apply()
    }

    /** Yeni bir not ekler, kaydedilen notun id'sini döndürür. */
    fun add(context: Context, text: String): String {
        val trimmed = text.trim()
        val id = "m${System.currentTimeMillis()}"
        val items = list(context) + MemoryItem(id, trimmed, System.currentTimeMillis())
        save(context, items)
        return id
    }

    /**
     * id ile, ya da id bulunamazsa metne göre (içeren, büyük/küçük harf
     * duyarsız) en iyi eşleşen notu siler. Kaç kayıt silindiğini döndürür.
     */
    fun delete(context: Context, idOrQuery: String): Int {
        val current = list(context)
        val byId = current.filter { it.id == idOrQuery }
        val toRemove = if (byId.isNotEmpty()) {
            byId
        } else {
            val q = idOrQuery.trim().lowercase()
            if (q.isBlank()) emptyList() else current.filter { it.text.lowercase().contains(q) }
        }
        if (toRemove.isEmpty()) return 0
        save(context, current - toRemove.toSet())
        return toRemove.size
    }

    /** Modele her turda gönderilen cihaz bağlamına eklenecek özet blok. */
    fun contextBlock(context: Context): String {
        val items = list(context)
        if (items.isEmpty()) return ""
        val lines = items.joinToString("\n") { "- (${it.id}) ${it.text}" }
        return """

            [KALICI HAFIZA — kullanıcının daha önce save_memory ile saklamanı istediği notlar, hepsi doğru ve güncel kabul edilir]
            $lines
        """.trimIndent()
    }
}
