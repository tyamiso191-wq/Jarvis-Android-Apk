package com.jarvis.ai.vision

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Android 14 (API 34) itibarıyla MediaProjection (ekran yakalama) SADECE
 * "mediaProjection" türünde bir foreground servis çalışırken kullanılabiliyor.
 * Bu servis herhangi bir iş YAPMAZ -- tek görevi, ScreenVisionController
 * ekran görüntüsünü yakalarken sistemin gerektirdiği foreground servis
 * şartını karşılamak. Yakalama bitince ScreenVisionController bu servisi
 * hemen durdurur (stopService), yani kalıcı bir bildirim/servis olarak
 * ekranda takılı KALMAZ.
 */
class ScreenCaptureService : Service() {

    companion object {
        private const val CHANNEL_ID = "jarvis_screen_capture"
        private const val NOTIFICATION_ID = 4242
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Ekran analizi",
                NotificationManager.IMPORTANCE_MIN
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("J.A.R.V.I.S")
            .setContentText("Ekran analiz ediliyor…")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Bilinçli olarak boş: tüm yakalama işi ScreenVisionController'da,
        // bu servis sadece sistem şartını karşılamak için canlı tutuluyor.
        return START_NOT_STICKY
    }
}
