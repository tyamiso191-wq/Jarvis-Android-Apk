package com.jarvis.ai.reminders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * AlarmManager alarmları telefon yeniden başlatılınca silinir; bu receiver
 * açılışta bekleyen tüm hatırlatıcıları yeniden kurar ki kullanıcı hiçbirini
 * kaçırmasın.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            ReminderStore.rescheduleAll(context)
        }
    }
}
