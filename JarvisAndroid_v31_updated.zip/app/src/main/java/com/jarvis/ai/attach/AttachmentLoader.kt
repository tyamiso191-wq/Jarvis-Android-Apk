package com.jarvis.ai.attach

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.min

/**
 * Sohbete eklenen tek bir fotoğraf / dosya.
 *
 * - Fotoğraf ve PDF: sayfalar küçültülmüş JPEG olarak [imageDataUrls] içinde
 *   ("data:image/jpeg;base64,...") tutulur, vision modeline görsel olarak gider.
 * - Metin/kod dosyası: içeriği [text] içinde tutulur, mesajın içine yazılır.
 */
data class Attachment(
    val name: String,
    val icon: String,
    val text: String? = null,
    val truncated: Boolean = false,
    val imageDataUrls: List<String> = emptyList(),
    /** Modele söylenecek ek not (örn. "PDF'nin sadece ilk 2 sayfası eklendi"). */
    val hint: String? = null
)

sealed class AttachmentResult {
    data class Ok(val attachment: Attachment) : AttachmentResult()
    data class Failed(val message: String) : AttachmentResult()
}

object AttachmentLoader {

    /** Tek mesajda modele gidebilecek en fazla görsel sayısı (Gemini görsel giriş limiti). */
    const val MAX_IMAGES = 3

    private const val MAX_TEXT_CHARS = 8000
    private const val MAX_IMAGE_SIDE = 1280
    private const val MAX_PDF_PAGES = 2
    private const val PDF_RENDER_SIDE = 1100
    private const val JPEG_QUALITY = 82

    private val IMAGE_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif")

    private val TEXT_EXTENSIONS = setOf(
        "txt", "md", "json", "csv", "tsv", "xml", "html", "htm", "css", "js", "ts", "kt", "kts",
        "java", "py", "c", "cpp", "h", "hpp", "cs", "go", "rs", "swift", "rb", "php", "sh", "bat",
        "sql", "yml", "yaml", "toml", "ini", "cfg", "conf", "properties", "gradle", "log", "srt",
        "vtt", "tex", "rtf"
    )

    private val TEXT_MIMES = setOf(
        "application/json", "application/xml", "application/javascript", "application/x-sh",
        "application/x-yaml", "application/sql", "application/x-httpd-php"
    )

    suspend fun load(ctx: Context, uri: Uri): AttachmentResult = withContext(Dispatchers.IO) {
        val name = displayName(ctx, uri)
        val mime = ctx.contentResolver.getType(uri).orEmpty().lowercase()
        val ext = name.substringAfterLast('.', "").lowercase()
        try {
            when {
                mime.startsWith("image/") || ext in IMAGE_EXTENSIONS -> loadImage(ctx, uri, name)
                mime == "application/pdf" || ext == "pdf" -> loadPdf(ctx, uri, name)
                mime.startsWith("text/") || mime in TEXT_MIMES || ext in TEXT_EXTENSIONS ->
                    loadText(ctx, uri, name)
                else -> AttachmentResult.Failed(
                    "$name okunamadı: bu dosya türü desteklenmiyor. Şimdilik fotoğraf, PDF, metin ve kod dosyaları okunabiliyor."
                )
            }
        } catch (e: OutOfMemoryError) {
            AttachmentResult.Failed("$name çok büyük, okunamadı.")
        } catch (e: SecurityException) {
            AttachmentResult.Failed("$name okunamadı (erişim izni yok ya da dosya korumalı).")
        } catch (e: Exception) {
            AttachmentResult.Failed("$name okunamadı: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun displayName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) c.getString(idx)?.takeIf { it.isNotBlank() }?.let { return it }
                }
            }
        } catch (e: Exception) {
            // ad okunamazsa aşağıdaki varsayılana düş
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "dosya"
    }

    // ---------------------------------------------------------------- METİN

    private fun loadText(ctx: Context, uri: Uri, name: String): AttachmentResult {
        val limitBytes = MAX_TEXT_CHARS * 4
        val input = ctx.contentResolver.openInputStream(uri)
            ?: return AttachmentResult.Failed("$name açılamadı.")
        val buf = ByteArray(limitBytes + 1)
        var total = 0
        input.use {
            while (total < buf.size) {
                val n = it.read(buf, total, buf.size - total)
                if (n <= 0) break
                total += n
            }
        }
        val str = String(buf, 0, min(total, limitBytes), Charsets.UTF_8)
        if (str.isBlank()) return AttachmentResult.Failed("$name boş görünüyor.")
        if (str.any { it == '\u0000' }) {
            return AttachmentResult.Failed("$name metin dosyası değil, okunamadı.")
        }
        val truncated = total > limitBytes || str.length > MAX_TEXT_CHARS
        return AttachmentResult.Ok(
            Attachment(name = name, icon = "📄", text = str.take(MAX_TEXT_CHARS), truncated = truncated)
        )
    }

    // -------------------------------------------------------------- FOTOĞRAF

    private fun loadImage(ctx: Context, uri: Uri, name: String): AttachmentResult {
        val url = decodeImageToDataUrl(ctx, uri)
            ?: return AttachmentResult.Failed("$name açılamadı ya da desteklenmeyen bir görsel biçimi.")
        return AttachmentResult.Ok(Attachment(name = name, icon = "🖼", imageDataUrls = listOf(url)))
    }

    private fun decodeImageToDataUrl(ctx: Context, uri: Uri): String? {
        val resolver = ctx.contentResolver

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        // Belleği şişirmemek için önce 2'nin kuvvetleriyle kaba küçült.
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_IMAGE_SIDE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return null

        val orientation = try {
            resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                )
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }

        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
        }
        val scale = MAX_IMAGE_SIDE.toFloat() / max(decoded.width, decoded.height)
        if (scale < 1f) matrix.postScale(scale, scale)

        val finalBmp = if (matrix.isIdentity) decoded else
            Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        return encodeJpeg(finalBmp)
    }

    /** Şeffaf PNG'ler JPEG'de siyah olmasın diye beyaz zemine oturtup sıkıştırır. */
    private fun encodeJpeg(bmp: Bitmap): String {
        val flat = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        Canvas(flat).apply {
            drawColor(Color.WHITE)
            drawBitmap(bmp, 0f, 0f, null)
        }
        val out = ByteArrayOutputStream()
        flat.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
        return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    // ------------------------------------------------------------------- PDF

    private fun loadPdf(ctx: Context, uri: Uri, name: String): AttachmentResult {
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r")
            ?: return AttachmentResult.Failed("$name açılamadı.")
        return pfd.use { fd ->
            PdfRenderer(fd).use { renderer ->
                val total = renderer.pageCount
                if (total == 0) {
                    AttachmentResult.Failed("$name boş bir PDF.")
                } else {
                    val count = min(total, MAX_PDF_PAGES)
                    val images = (0 until count).map { i ->
                        renderer.openPage(i).use { page ->
                            val scale = PDF_RENDER_SIDE.toFloat() / max(page.width, page.height)
                            val w = max(1, (page.width * scale).toInt())
                            val h = max(1, (page.height * scale).toInt())
                            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(Color.WHITE) // PDF şeffaf render ediliyor, zemin şart
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            encodeJpeg(bmp)
                        }
                    }
                    val hint = if (total > count) {
                        "PDF toplam $total sayfa; yalnızca ilk $count sayfası görsel olarak eklendi."
                    } else null
                    AttachmentResult.Ok(
                        Attachment(name = name, icon = "📄", imageDataUrls = images, hint = hint)
                    )
                }
            }
        }
    }
}
