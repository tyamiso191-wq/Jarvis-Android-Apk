package com.jarvis.ai.vision

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * analyze_screen / analyze_webcam fonksiyonları için: tek bir fotoğrafı,
 * araç çağırma OLMADAN (sade tek-turlu bir istek), Gemini'nin OpenAI-uyumlu
 * katmanına gönderip kısa bir Türkçe açıklama/cevap alır. GeminiTextClient'ın
 * ana sohbet döngüsünden BAĞIMSIZ, hafif bir yardımcı -- ana konuşma
 * geçmişini şişirmemek için sonucu düz metin olarak geri döndürür, çağıran
 * (GeminiTextClient.executeFunction) bunu normal bir fonksiyon sonucu gibi
 * modele geri besler.
 */
object VisionAnalyzer {
    private const val TAG = "VisionAnalyzer"
    private const val CHAT_URL = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"
    private val MODEL_CANDIDATES = listOf("gemini-2.5-flash", "gemini-2.0-flash")

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(35, TimeUnit.SECONDS)
        .build()

    /**
     * @param apiKey kullanıcının Gemini anahtarı (JarvisViewModel'deki aynı anahtar).
     * @param jpegBytes analiz edilecek fotoğraf.
     * @param question kullanıcının ne sormak istediği, örn. "ekranda ne yazıyor" ya
     * da "üzerimde ne var" -- boşsa genel bir açıklama istenir.
     */
    suspend fun analyze(apiKey: String, jpegBytes: ByteArray, question: String): Result<String> =
        withContext(Dispatchers.IO) {
            val b64 = Base64.encodeToString(jpegBytes, Base64.NO_WRAP)
            val prompt = question.ifBlank { "Bu görselde ne görüyorsun? Kısa ve net Türkçe anlat." }

            val messages = JSONArray().put(
                JSONObject().apply {
                    put("role", "user")
                    put("content", JSONArray().apply {
                        put(JSONObject().put("type", "text").put("text", prompt))
                        put(
                            JSONObject()
                                .put("type", "image_url")
                                .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64"))
                        )
                    })
                }
            )

            var lastError: String? = null
            for (model in MODEL_CANDIDATES) {
                val body = JSONObject().apply {
                    put("model", model)
                    put("messages", messages)
                    put("temperature", 0.4)
                    put("max_tokens", 500)
                }
                try {
                    val req = Request.Builder()
                        .url(CHAT_URL)
                        .header("Authorization", "Bearer $apiKey")
                        .post(body.toString().toRequestBody("application/json".toMediaType()))
                        .build()
                    client.newCall(req).execute().use { resp ->
                        val raw = resp.body?.string().orEmpty()
                        if (!resp.isSuccessful) {
                            lastError = "$model → HTTP ${resp.code}: ${raw.take(300)}"
                            return@use
                        }
                        val text = JSONObject(raw).optJSONArray("choices")
                            ?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                        if (text.isNullOrBlank()) {
                            lastError = "$model → boş yanıt"
                        } else {
                            return@withContext Result.success(text.trim())
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Görsel analiz isteği başarısız: $model", e)
                    lastError = e.message
                }
            }
            Result.failure(IOException(lastError ?: "Görsel analiz edilemedi"))
        }
}
