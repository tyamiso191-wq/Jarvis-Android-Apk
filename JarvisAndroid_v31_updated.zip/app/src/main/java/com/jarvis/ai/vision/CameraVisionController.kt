package com.jarvis.ai.vision

import android.content.Context
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/**
 * Windows Jarvis V3'teki toggle_webcam/analyze araçlarının Android karşılığı:
 * ÖNİZLEME GÖSTERMEDEN, arka planda kameradan (varsayılan ön kamera --
 * "kendine bak" senaryosu için) TEK bir JPEG kare yakalar. Kalıcı bir kamera
 * oturumu açık bırakmıyoruz -- her çağrıda bağlanıp fotoğrafı alır almaz
 * hemen kapatıyoruz, bu yüzden ayrı bir "toggle" durumu yok, doğrudan
 * "analyze_webcam" fonksiyonu var (bkz. GeminiTextClient).
 *
 * Önizlemesiz çalışabilmek için kendi minik LifecycleOwner'ımızı
 * kullanıyoruz -- CameraX'in bağlanabilmesi için bir Lifecycle şart, ama
 * ekranda gösterilecek bir Compose/View hiyerarşisine ihtiyacımız yok.
 */
object CameraVisionController {
    private const val TAG = "CameraVisionController"

    private class SimpleLifecycleOwner : LifecycleOwner {
        val registry = LifecycleRegistry.createUnsafe(this)
        override val lifecycle: Lifecycle get() = registry
    }

    /**
     * @param useFrontCamera true ise ön kamera ("selfie", kullanıcıya bakan),
     * false ise arka kamera. Varsayılan true -- "bana bak", "beni gör" gibi
     * istekler için en doğal seçenek bu.
     * @return yakalanan fotoğrafın JPEG bayt dizisi, başarısız/izin yoksa null.
     */
    suspend fun captureJpeg(context: Context, useFrontCamera: Boolean = true): ByteArray? {
        val appContext = context.applicationContext
        val cameraProvider = try {
            getCameraProvider(appContext)
        } catch (e: Exception) {
            Log.w(TAG, "Kamera sağlayıcısı alınamadı", e)
            return null
        }

        val lifecycleOwner = SimpleLifecycleOwner()
        lifecycleOwner.registry.currentState = Lifecycle.State.STARTED

        val imageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .build()

        val selector = if (useFrontCamera) {
            CameraSelector.DEFAULT_FRONT_CAMERA
        } else {
            CameraSelector.DEFAULT_BACK_CAMERA
        }

        return try {
            withContext(Dispatchers.Main) {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(lifecycleOwner, selector, imageCapture)
            }

            val jpeg = suspendCoroutine<ByteArray?> { cont ->
                imageCapture.takePicture(
                    ContextCompat.getMainExecutor(appContext),
                    object : ImageCapture.OnImageCapturedCallback() {
                        override fun onCaptureSuccess(image: ImageProxy) {
                            val bytes = try {
                                imageProxyToJpeg(image)
                            } catch (e: Exception) {
                                Log.w(TAG, "Kare JPEG'e çevrilemedi", e)
                                null
                            } finally {
                                image.close()
                            }
                            cont.resume(bytes)
                        }

                        override fun onError(exception: ImageCaptureException) {
                            Log.w(TAG, "Fotoğraf çekilemedi", exception)
                            cont.resume(null)
                        }
                    }
                )
            }
            jpeg
        } catch (e: Exception) {
            Log.w(TAG, "Kameraya bağlanılamadı (izin verilmemiş olabilir)", e)
            null
        } finally {
            withContext(Dispatchers.Main) {
                cameraProvider.unbindAll()
            }
            lifecycleOwner.registry.currentState = Lifecycle.State.DESTROYED
        }
    }

    /** ImageProxy'nin YUV_420_888 formatındaki verisini JPEG bayt dizisine çevirir. */
    private fun imageProxyToJpeg(image: ImageProxy): ByteArray {
        // ImageCapture.OnImageCapturedCallback varsayılan olarak JPEG formatı
        // verir (setBufferFormat ayarlanmadıysa), bu durumda plane[0] zaten
        // sıkıştırılmış JPEG bayt akışıdır.
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        return bytes
    }

    @Volatile private var cachedProvider: ProcessCameraProvider? = null

    private suspend fun getCameraProvider(context: Context): ProcessCameraProvider {
        cachedProvider?.let { return it }
        return suspendCoroutine { cont ->
            val future = ProcessCameraProvider.getInstance(context)
            future.addListener({
                try {
                    val provider = future.get()
                    cachedProvider = provider
                    cont.resume(provider)
                } catch (e: Exception) {
                    cont.resumeWithException(e)
                }
            }, ContextCompat.getMainExecutor(context))
        }
    }
}
