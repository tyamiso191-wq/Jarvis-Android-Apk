package com.jarvis.ai.music

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.ContextCompat

/**
 * "Bohemian Rhapsody aç" gibi bir istek geldiğinde:
 *  1) Önce cihazın yerel müzik kütüphanesinde (MediaStore.Audio) başlık/
 *     sanatçı adına göre arar. Bulursa MusicService'i başlatıp gerçekten
 *     ARKA PLANDA çalmaya başlar — sohbet ekranından çıksa bile devam eder.
 *  2) Yerelde yoksa, YoutubeAudioResolver ile YouTube'da o şarkıyı arayıp
 *     doğrudan ses akışı adresini çözer ve YİNE MusicService üzerinden
 *     arka planda çalar — YouTube uygulamasına/tarayıcıya geçiş YOK, ekran
 *     değişmiyor.
 *  3) Ses akışı hiçbir şekilde çözülemezse (ör. YouTube'un sayfa yapısı
 *     değişmiş, extractor güncel değil) son çare olarak YouTube'da arama
 *     sonucunu açan bir intent'e düşülür — kullanıcı hiçbir ses duymadan
 *     sessizce başarısız olmasın diyedir.
 */
object MusicController {

    sealed class PlayResult {
        data class PlayingLocal(val title: String, val artist: String) : PlayResult()
        data class PlayingStream(val title: String, val artist: String) : PlayResult()
        data class OpenedYoutubeSearch(val query: String) : PlayResult()
        data class PermissionMissing(val message: String) : PlayResult()
        data class Error(val message: String) : PlayResult()
    }

    private const val PREFS_NAME = "music_controller_memory"
    private const val PREF_LAST_QUERY = "last_song_query"

    /**
     * En son başarıyla çalınmaya başlanan şarkının sorgusu. Kullanıcı isim
     * vermeden sadece "çal"/"tekrar çal" derse bu hatırlanıp yeniden
     * başlatılır -- kullanıcıya tekrar şarkı adı sorulmaz.
     */
    fun lastPlayedQuery(context: Context): String? =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(PREF_LAST_QUERY, null)
            ?.takeIf { it.isNotBlank() }

    private fun rememberQuery(context: Context, query: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(PREF_LAST_QUERY, query).apply()
    }

    private fun readAudioPermission(): String =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, readAudioPermission()) == PackageManager.PERMISSION_GRANTED

    fun play(context: Context, query: String): PlayResult {
        // Boş sorgu: kullanıcı şarkı adı vermeden "çal"/"tekrar çal" demiş --
        // en son çalınan şarkıyı hatırlayıp onu yeniden başlat.
        val q = query.trim().ifBlank { lastPlayedQuery(context).orEmpty() }
        if (q.isBlank()) return PlayResult.Error("Hangi şarkıyı çalacağım belirtilmedi ve hatırlanan önceki bir şarkı yok.")
        rememberQuery(context, q)

        if (hasPermission(context)) {
            val local = findLocalTrack(context, q)
            if (local != null) {
                val intent = Intent(context, MusicService::class.java).apply {
                    action = MusicService.ACTION_PLAY
                    putExtra(MusicService.EXTRA_URI, local.uri.toString())
                    putExtra(MusicService.EXTRA_TITLE, local.title)
                    putExtra(MusicService.EXTRA_ARTIST, local.artist)
                }
                ContextCompat.startForegroundService(context, intent)
                return PlayResult.PlayingLocal(local.title, local.artist)
            }
        }

        // Yerelde yok -- YouTube uygulamasına/tarayıcıya geçmeden, doğrudan
        // ses akışını çözüp arka planda MediaPlayer ile çalmayı dene.
        val resolved = YoutubeAudioResolver.resolve(q)
        if (resolved != null) {
            val intent = Intent(context, MusicService::class.java).apply {
                action = MusicService.ACTION_PLAY
                putExtra(MusicService.EXTRA_URI, resolved.streamUrl)
                putExtra(MusicService.EXTRA_TITLE, resolved.title)
                putExtra(MusicService.EXTRA_ARTIST, resolved.artist)
                if (resolved.headers.isNotEmpty()) {
                    putExtra(MusicService.EXTRA_HEADERS, HashMap(resolved.headers))
                }
            }
            ContextCompat.startForegroundService(context, intent)
            return PlayResult.PlayingStream(resolved.title, resolved.artist)
        }

        // Son çare: ses akışı çözülemediyse (kütüphane/YouTube tarafında bir
        // sorun varsa) tamamen sessiz kalmamak için eski YouTube yoluna düş.
        return try {
            val searchUrl = "https://www.youtube.com/results?search_query=" +
                Uri.encode(q)
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(searchUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            PlayResult.OpenedYoutubeSearch(q)
        } catch (e: Exception) {
            PlayResult.Error("Açılamadı: ${e.message}")
        }
    }

    fun stop(context: Context) {
        val intent = Intent(context, MusicService::class.java).apply {
            action = MusicService.ACTION_STOP
        }
        context.startService(intent)
    }

    private data class LocalTrack(val uri: Uri, val title: String, val artist: String)

    private fun findLocalTrack(context: Context, query: String): LocalTrack? {
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND (" +
            "${MediaStore.Audio.Media.TITLE} LIKE ? OR ${MediaStore.Audio.Media.ARTIST} LIKE ?)"
        val like = "%$query%"
        val args = arrayOf(like, like)

        context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            args,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID))
                val title = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE))
                val artist = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST))
                val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                return LocalTrack(uri, title ?: query, artist ?: "")
            }
        }
        return null
    }
}
