package com.jarvis.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.theme.*
import kotlinx.coroutines.launch

/**
 * Jarvis'in kendi terminali: uygulamanın sandbox'ında gerçek bir kabuk
 * (/system/bin/sh) çalıştırır. Hem kullanıcı elle komut yazabilir, hem de
 * Jarvis run_terminal_command fonksiyonuyla buraya komut "yazıp" çalıştırır
 * (aynı geçmiş listesinde görünür).
 */
data class TerminalLine(val command: String?, val output: String)

@Composable
fun TerminalScreen(
    history: List<TerminalLine>,
    onRunCommand: (String) -> Unit,
    onClose: () -> Unit
) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(history.size) {
        if (history.isNotEmpty()) {
            scope.launch { listState.animateScrollToItem(history.lastIndex) }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Panel)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "JARVIS TERMİNAL",
                color = Teal,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                "✕ KAPAT",
                color = Dim,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier
                    .clickable(onClick = onClose)
                    .background(Dim.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            Text(
                "Sandbox: /terminal_workspace  •  gerçek shell, root/derleyici yok",
                color = Dim,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .border(1.dp, TealDim.copy(alpha = 0.35f))
                    .padding(10.dp)
            ) {
                items(history) { line ->
                    Column(modifier = Modifier.padding(bottom = 8.dp)) {
                        if (line.command != null) {
                            Text(
                                "$ ${line.command}",
                                color = Teal,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            line.output,
                            color = Text.copy(alpha = 0.9f),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$", color = Teal, fontFamily = FontFamily.Monospace, fontSize = 14.sp)
                Spacer(Modifier.width(6.dp))
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    placeholder = {
                        Text("komut yaz…", color = Dim, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            if (input.isNotBlank()) { onRunCommand(input); input = "" }
                        }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Teal,
                        unfocusedBorderColor = TealDim,
                        focusedTextColor = Text,
                        unfocusedTextColor = Text,
                        cursorColor = Teal
                    ),
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, fontFamily = FontFamily.Monospace),
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(6.dp))
                IconButton(
                    onClick = { if (input.isNotBlank()) { onRunCommand(input); input = "" } },
                    modifier = Modifier
                        .size(42.dp)
                        .background(Teal, RoundedCornerShape(8.dp))
                ) {
                    Text("➤", color = Bg, fontSize = 16.sp)
                }
            }
        }
    }
}
