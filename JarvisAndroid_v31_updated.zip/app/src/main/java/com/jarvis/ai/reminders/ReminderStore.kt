package com.jarvis.ai.reminders

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.text.format.DateFormat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Date

/**
 * Anımsatıcılar. Windows Jarvis V3'teki actions/reminders.py'nin
 * (get_reminders / add_reminder) Android karşılığı: JSON olarak
 * SharedPreferences'ta kalıcı saklanır ve zamanı geldiğinde AlarmManager +
 * ReminderReceiver ile bildirim gösterilir.
 *
 * NOT: setExactAndAllowWhileIdle Android 12+'ta ayrı bir "tam zamanlı alarm"
 * izni (SCHEDULE_EXACT_ALARM) ister ve bu izin Play Store'da kısıtlıdır. Bir
 * hatırlatıcının birkaç dakika erken/geç gelmesi kritik olmadığından, ekstra
 * izin istemeden çalışsın diye bilerek YAKLAŞIK (setAndAllowWhileIdle)
 * zamanlama kullanılıyor.
 */
object ReminderStore {
    private const val PREFS = "jarvis_reminder_store"
    private const val KEY_ITEMS = "items"
    const val CHANNEL_ID = "jarvis_reminders"
    const val EXTRA_ID = "reminder_id"
    const val EXTRA_TEXT = "reminder_text"

    data class Reminder(
        val id: String,
        val text: String,
        val timeMillis: Long,
        val fired: Boolean = false
    )

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun list(context: Context): List<Reminder> {
        val raw = prefs(context).getString(KEY_ITEMS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                Reminder(
                    id = o.optString("id"),
                    text = o.optString("text"),
                    timeMillis = o.optLong("timeMillis"),
                    fired = o.optBoolean("fired", false)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    private fun saveAll(context: Context, items: List<Reminder>) {
        val arr = JSONArray()
        items.forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id)
                put("text", r.text)
                put("timeMillis", r.timeMillis)
                put("fired", r.fired)
            })
        }
        prefs(context).edit().putString(KEY_ITEMS, arr.toString()).apply()
    }

    /** Yeni bir hatırlatıcı ekler ve alarmı kurar. Reminder'ı döndürür. */
    fun add(context: Context, text: String, timeMillis: Long): Reminder {
        val id = "r${System.currentTimeMillis()}"
        val reminder = Reminder(id, text.trim(), timeMillis)
        saveAll(context, list(context) + reminder)
        schedule(context, reminder)
        return reminder
    }

    /** id ile ya da metne göre en iyi eşleşeni siler ve alarmını iptal eder. */
    fun delete(context: Context, idOrQuery: String): Int {
        val current = list(context)
        val byId = current.filter { it.id == idOrQuery }
        val toRemove = if (byId.isNotEmpty()) {
            byId
        } else {
            val q = idOrQuery.trim().lowercase()
            if (q.isBlank()) emptyList() else current.filter { it.text.lowercase().contains(q) }
        }
        if (toRemove.isEmpty()) return 0
        toRemove.forEach { cancelAlarm(context, it.id) }
        saveAll(context, current - toRemove.toSet())
        return toRemove.size
    }

    fun markFired(context: Context, id: String) {
        val current = list(context)
        saveAll(context, current.map { if (it.id == id) it.copy(fired = true) else it })
    }

    /** Sadece henüz gelmemiş, gelecekteki hatırlatıcılar (get_reminders için). */
    fun upcoming(context: Context): List<Reminder> {
        val now = System.currentTimeMillis()
        return list(context).filter { !it.fired && it.timeMillis >= now - 60_000L }
            .sortedBy { it.timeMillis }
    }

    private fun schedule(context: Context, reminder: Reminder) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(EXTRA_ID, reminder.id)
            putExtra(EXTRA_TEXT, reminder.text)
        }
        val pi = PendingIntent.getBroadcast(
            context, reminder.id.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.timeMillis, pi)
        } catch (e: Exception) {
            // İzin/kısıtlama olursa hatırlatıcı yine listede kalır, get_reminders
            // ile sesli olarak hatırlatılabilir, sadece push bildirimi gelmez.
        }
    }

    private fun cancelAlarm(context: Context, id: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, ReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context, id.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
    }

    /** Uygulama her açıldığında (MainActivity) çağrılır: bekleyen tüm hatırlatıcıların alarmını yeniden kurar. */
    fun rescheduleAll(context: Context) {
        upcoming(context).forEach { schedule(context, it) }
    }

    /** Modele her turda gönderilen cihaz bağlamına eklenecek özet blok. */
    fun contextBlock(context: Context): String {
        val items = upcoming(context)
        if (items.isEmpty()) return ""
        val fmt = { t: Long -> DateFormat.format("d MMMM HH:mm", Date(t)).toString() }
        val lines = items.joinToString("\n") { "- (${it.id}) ${it.text} → ${fmt(it.timeMillis)}" }
        return """

            [BEKLEYEN ANIMSATICILAR]
            $lines
        """.trimIndent()
    }
}
