package com.jarvis.ai.terminal

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

/**
 * Uygulama içi gerçek bir terminal: verilen kabuk komutunu uygulamanın kendi
 * sandbox'ı (Context.filesDir/terminal_workspace) içinde, cihazın Linux
 * kabuğuyla (/system/bin/sh) GERÇEKTEN çalıştırır -- simülasyon değil.
 *
 * ÖNEMLİ SINIRLAMA: Android uygulamaları root olmadan sistem genelinde komut
 * çalıştıramaz ve cihazda gradle/JDK gibi derleyiciler kurulu olmaz. Yani bu
 * terminalde "build" demek, tam bir Android/Gradle derlemesi anlamına gelmez;
 * ama sandbox içinde dosya/klasör işlemleri, metin işleme (ls, cat, echo,
 * mkdir, grep, find, zip vb. -- cihazda kurulu olan araçlar) ve basit
 * script'ler (sh script.sh) çalıştırılabilir, çıktısı gerçek zamanlı okunur.
 * Jarvis bunu; kullanıcı "terminalde şunu yap/derle/çalıştır" dediğinde
 * KENDİSİ çağırıp sonucu okuyup yorumlamak için kullanır.
 */
object TerminalRunner {
    data class Result(val output: String, val exitCode: Int, val timedOut: Boolean)

    fun workspaceDir(filesDir: File): File =
        File(filesDir, "terminal_workspace").apply { mkdirs() }

    suspend fun run(filesDir: File, command: String, timeoutMs: Long = 15_000L): Result =
        withContext(Dispatchers.IO) {
            val workDir = workspaceDir(filesDir)
            val cmd = command.trim()
            if (cmd.isBlank()) return@withContext Result("(boş komut)", -1, false)
            try {
                val process = ProcessBuilder("sh", "-c", cmd)
                    .directory(workDir)
                    .redirectErrorStream(true)
                    .start()

                val output = StringBuilder()
                val reader = BufferedReader(InputStreamReader(process.inputStream))
                val finished = withTimeoutOrNull(timeoutMs) {
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        output.appendLine(line)
                        if (output.length > 8000) break
                    }
                    process.waitFor()
                }
                if (finished == null) {
                    process.destroyForcibly()
                    Result(output.toString().take(8000).ifBlank { "(çıktı yok)" }, -1, true)
                } else {
                    Result(output.toString().take(8000).ifBlank { "(çıktı yok, komut bitti)" }, process.exitValue(), false)
                }
            } catch (e: Exception) {
                Result("Komut çalıştırılamadı: ${e.message}", -1, false)
            }
        }
}
