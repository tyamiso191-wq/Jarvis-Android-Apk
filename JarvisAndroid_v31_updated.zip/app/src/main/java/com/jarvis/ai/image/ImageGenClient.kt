package com.jarvis.ai.image

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * AI ile görsel/fotoğraf oluşturma.
 *
 * ESKİDEN: API anahtarı gerektirmeyen, ücretsiz Pollinations.ai servisi
 * kullanılıyordu. SORUN: Pollinations artık ANONİM (hesapsız) isteklerde
 * "nologo=true" parametresine rağmen sağ altta kendi filigranını/logosunu
 * basıyor -- bunu kaldırmak auth.pollinations.ai üzerinden ayrı bir hesap+
 * token gerektiriyor. Kullanıcı görselde HİÇBİR yabancı marka/yazı
 * istemediği için bu servisten tamamen vazgeçildi.
 *
 * ŞİMDİ: Zaten elde olan TEK Gemini API anahtarıyla, Gemini'nin kendi
 * görsel üretim modeli (gemini-2.5-flash-image) kullanılıyor. Bu modelin
 * çıktısında görünür bir logo/filigran YOK (sadece görüntüye gömülü,
 * görsel olarak fark edilmeyen bir SynthID damgası var -- ekranda hiçbir
 * yazı/logo çıkmaz).
 */
object ImageGenClient {
    private const val TAG = "ImageGenClient"
    private const val MODEL = "gemini-2.5-flash-image"
    private const val URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .callTimeout(65, TimeUnit.SECONDS)
        .build()

    /**
     * @param apiKey kullanıcının Gemini anahtarı.
     * @return üretilen görselin bayt dizisi (PNG), başarısız olursa null.
     */
    suspend fun generate(apiKey: String, prompt: String): ByteArray? =
        withContext(Dispatchers.IO) {
            try {
                val cleanPrompt = prompt.trim().ifBlank { "abstract colorful art" }
                val body = JSONObject().apply {
                    put("contents", JSONArray().put(
                        JSONObject().put("parts", JSONArray().put(
                            JSONObject().put("text", cleanPrompt)
                        ))
                    ))
                    put("generationConfig", JSONObject().apply {
                        put("responseModalities", JSONArray().put("TEXT").put("IMAGE"))
                    })
                }
                val req = Request.Builder()
                    .url(URL)
                    .header("x-goog-api-key", apiKey)
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()
                client.newCall(req).execute().use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        Log.w(TAG, "Görsel isteği başarısız: HTTP ${resp.code}: ${raw.take(300)}")
                        return@withContext null
                    }
                    val parts = JSONObject(raw)
                        .optJSONArray("candidates")?.optJSONObject(0)
                        ?.optJSONObject("content")?.optJSONArray("parts")
                        ?: run {
                            Log.w(TAG, "Yanıtta parts yok: ${raw.take(300)}")
                            return@withContext null
                        }
                    for (i in 0 until parts.length()) {
                        val inline = parts.optJSONObject(i)?.optJSONObject("inlineData")
                            ?: parts.optJSONObject(i)?.optJSONObject("inline_data")
                        val b64 = inline?.optString("data")
                        if (!b64.isNullOrBlank()) {
                            return@withContext Base64.decode(b64, Base64.DEFAULT)
                        }
                    }
                    Log.w(TAG, "Yanıtta görsel (inlineData) bulunamadı")
                    null
                }
            } catch (e: Exception) {
                Log.w(TAG, "Görsel oluşturulamadı", e)
                null
            }
        }
}
