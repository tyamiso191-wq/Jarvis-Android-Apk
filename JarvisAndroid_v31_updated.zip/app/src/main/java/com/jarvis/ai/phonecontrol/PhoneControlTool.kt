package com.jarvis.ai.phonecontrol

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import android.util.Log

/**
 * Windows Jarvis V3'te "her şeyi yapabilsin" isteği Windows'ta gerçek bir
 * masaüstü otomasyonuna (shell_run, sistem ayarları vb.) karşılık geliyordu.
 * Android'de GÜVENLİK MİMARİSİ GEREĞİ üçüncü parti bir uygulama (Google
 * Asistan dahil) telefonu bu kadar sınırsız kontrol EDEMEZ -- ama gerçekten
 * çalışan, sahte olmayan şu eylemler mümkün:
 *
 *  - GERÇEKTEN alarm kurmak (saat uygulamasına gidip onay istemeden).
 *  - Yüklü bir uygulamayı GERÇEKTEN açmak.
 *  - Yüklü OLMAYAN bir uygulama/oyun için Play Store'da doğrudan o
 *    uygulamanın sayfasını açmak (kullanıcı sadece "Yükle"ye basar --
 *    Android hiçbir üçüncü parti uygulamanın kullanıcı onayı OLMADAN
 *    sessizce apk kurmasına izin vermiyor, bu Google Asistan için de
 *    aynı şekilde çalışıyor, JARVIS'e özgü bir kısıtlama değil).
 *  - Medya sesini gerçekten ayarlamak.
 *  - El feneri gerçekten açmak/kapamak.
 *  - Wi-Fi/Bluetooth ayar panelini açmak (Android 10+ itibarıyla 3. parti
 *    uygulamalar bunları KULLANICI ONAYI olmadan sessizce açıp
 *    kapatamıyor -- bu da JARVIS'e özgü değil, işletim sistemi kısıtı).
 */
object PhoneControlTool {
    private const val TAG = "PhoneControlTool"

    // ─── Alarm ────────────────────────────────────────────────────────────
    fun setAlarm(context: Context, hour: Int, minute: Int, label: String): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                if (label.isNotBlank()) putExtra(AlarmClock.EXTRA_MESSAGE, label)
                // true: saat uygulaması UI'sini AÇMADAN, direkt kurar (çoğu
                // saat uygulaması -- Google Saat, Samsung Saat -- bunu
                // destekliyor). Desteklemeyen nadir bir saat uygulaması
                // varsa kullanıcıya onay ekranını gösterir, yine de alarm
                // kurulmuş olur, sadece bir dokunuş daha ister.
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (intent.resolveActivity(context.packageManager) == null) return false
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.w(TAG, "Alarm kurulamadı", e)
            false
        }
    }

    // ─── Uygulama açma / Play Store'a yönlendirme ──────────────────────────
    sealed class OpenAppResult {
        data class Opened(val appLabel: String) : OpenAppResult()
        data class OpenedStorePage(val query: String) : OpenAppResult()
        object Failed : OpenAppResult()
    }

    /**
     * Önce cihazda YÜKLÜ uygulamalar arasında isimle eşleşen bir tane arar,
     * bulursa GERÇEKTEN açar. Bulamazsa (yüklü değilse) Play Store'da o
     * uygulamanın/oyunun sayfasını/aramasını açar -- kullanıcı tek dokunuşla
     * yükleyebilsin diye. Android, üçüncü parti bir uygulamanın kullanıcı
     * onayı olmadan SESSİZCE apk kurmasına izin VERMEZ (bu JARVIS'in değil,
     * işletim sisteminin kısıtı -- Google Asistan da aynı şekilde çalışır).
     */
    fun openOrOfferInstall(context: Context, appName: String): OpenAppResult {
        val clean = appName.trim()
        if (clean.isBlank()) return OpenAppResult.Failed
        val pm = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val candidates = try {
            pm.queryIntentActivities(launcherIntent, PackageManager.MATCH_ALL)
        } catch (e: Exception) {
            emptyList()
        }
        val lowerQuery = clean.lowercase()
        val match = candidates.firstOrNull { info ->
            val label = try { info.loadLabel(pm).toString() } catch (e: Exception) { "" }
            label.lowercase().contains(lowerQuery) || lowerQuery.contains(label.lowercase())
        }
        if (match != null) {
            val pkg = match.activityInfo.packageName
            val label = try { match.loadLabel(pm).toString() } catch (e: Exception) { clean }
            val launch = pm.getLaunchIntentForPackage(pkg)
            return if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    context.startActivity(launch)
                    OpenAppResult.Opened(label)
                } catch (e: Exception) {
                    Log.w(TAG, "Uygulama açılamadı: $pkg", e)
                    OpenAppResult.Failed
                }
            } else {
                OpenAppResult.Failed
            }
        }

        // Yüklü değil -- Play Store'da ara/aç.
        return try {
            val marketIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("market://search?q=${Uri.encode(clean)}&c=apps")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (marketIntent.resolveActivity(pm) != null) {
                context.startActivity(marketIntent)
            } else {
                val webIntent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/search?q=${Uri.encode(clean)}&c=apps")
                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(webIntent)
            }
            OpenAppResult.OpenedStorePage(clean)
        } catch (e: Exception) {
            Log.w(TAG, "Play Store açılamadı", e)
            OpenAppResult.Failed
        }
    }

    // ─── Medya sesi ─────────────────────────────────────────────────────
    /** @param percent 0-100 arası. Medya (müzik/video) ses seviyesini ayarlar. */
    fun setMediaVolume(context: Context, percent: Int): Boolean {
        return try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val clamped = percent.coerceIn(0, 100)
            val target = (max * clamped / 100.0).toInt().coerceIn(0, max)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
            true
        } catch (e: Exception) {
            Log.w(TAG, "Ses ayarlanamadı", e)
            false
        }
    }

    // ─── El feneri ──────────────────────────────────────────────────────
    fun setFlashlight(context: Context, on: Boolean): Boolean {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val camId = cm.cameraIdList.firstOrNull { id ->
                cm.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            cm.setTorchMode(camId, on)
            true
        } catch (e: Exception) {
            Log.w(TAG, "El feneri değiştirilemedi (izin ya da donanım sorunu olabilir)", e)
            false
        }
    }

    // ─── Wi-Fi / Bluetooth ayar paneli ───────────────────────────────────
    /**
     * Android 10 (API 29) itibarıyla hiçbir üçüncü parti uygulama Wi-Fi/
     * Bluetooth'u kullanıcı onayı OLMADAN sessizce açıp kapatamıyor -- bu
     * yüzden burada en iyi ihtimal, ilgili hızlı ayarlar panelini/ekranını
     * açıp kullanıcının tek dokunuşla değiştirmesini sağlamak.
     */
    fun openWifiSettings(context: Context): Boolean = openSettingsIntent(
        context,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Settings.Panel.ACTION_INTERNET_CONNECTIVITY
        else Settings.ACTION_WIFI_SETTINGS
    )

    fun openBluetoothSettings(context: Context): Boolean =
        // Settings.Panel'de Bluetooth için ayrı bir hızlı panel sabiti yok
        // (sadece internet/NFC/ses paneli var), bu yüzden en güvenilir yol
        // doğrudan Bluetooth ayarlar ekranını açmak.
        openSettingsIntent(context, Settings.ACTION_BLUETOOTH_SETTINGS)

    private fun openSettingsIntent(context: Context, action: String): Boolean {
        return try {
            val intent = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.w(TAG, "Ayarlar açılamadı: $action", e)
            false
        }
    }
}
