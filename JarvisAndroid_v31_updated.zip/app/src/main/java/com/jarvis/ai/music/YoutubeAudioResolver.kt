package com.jarvis.ai.music

import android.util.Log
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

/**
 * Kullanıcı bir şarkı istediğinde ve o şarkı telefonda yerel olarak
 * bulunamadığında, YouTube uygulamasına/tarayıcıya YÖNLENDİRMEK yerine
 * doğrudan çalınabilir bir ses akış URL'si bulup arka planda MediaPlayer'a
 * veriyoruz. Ekran hiç değişmiyor, kullanıcı hiçbir şeye dokunmuyor —
 * NewPipeExtractor kütüphanesi (NewPipe uygulamasının da kullandığı,
 * resmi bir API anahtarı gerektirmeyen açık kaynak kütüphane) ile YouTube
 * arama sonuçlarını ve o videonun gerçek ses akışı adresini (googlevideo.com
 * CDN linki) çözüyoruz.
 *
 * NOT: Bu, YouTube'un resmi/desteklenen bir API'si DEĞİL — sayfa yapısını
 * "extract" ederek çalışıyor (NewPipe uygulamasının kullandığı yöntemin
 * aynısı). YouTube taraf değişiklik yaparsa kütüphane güncellemesi
 * gerekebilir; bu yüzden başarısız olursa MusicController eski YouTube
 * yönlendirme yoluna geri düşüyor (tamamen sessiz kalmasın diye).
 */
object YoutubeAudioResolver {
    private const val TAG = "YoutubeAudioResolver"

    data class ResolvedTrack(
        val streamUrl: String,
        val title: String,
        val artist: String,
        val headers: Map<String, String>
    )

    @Volatile private var initialized = false

    private fun ensureInit() {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            NewPipe.init(NewPipeDownloader.instance())
            initialized = true
        }
    }

    /** Ağ üzerinde çalışan BLOKLAYICI bir fonksiyon — çağıran taraf zaten bir
     * arka plan thread'inde (Dispatchers.IO) olmalı. */
    fun resolve(query: String): ResolvedTrack? {
        if (query.isBlank()) return null
        return try {
            ensureInit()
            val service = ServiceList.YouTube

            val searchExtractor = service.getSearchExtractor(query)
            searchExtractor.fetchPage()
            val firstVideo = searchExtractor.initialPage.items
                .filterIsInstance<StreamInfoItem>()
                .firstOrNull() ?: return null

            val info = StreamInfo.getInfo(service, firstVideo.url)
            val audioStreams = info.audioStreams
            if (audioStreams.isNullOrEmpty()) return null

            val best = pickBestAudioStream(audioStreams) ?: return null
            val url = best.content ?: return null

            ResolvedTrack(
                streamUrl = url,
                title = info.name ?: query,
                artist = info.uploaderName ?: "",
                headers = emptyMap()
            )
        } catch (e: Exception) {
            Log.w(TAG, "YouTube ses çözümlemesi başarısız: $query", e)
            null
        }
    }

    // MediaPlayer'ın en güvenilir çaldığı format mp4a (m4a) konteynerli
    // ses akışları -- varsa onu tercih et, yoksa en yüksek bit hızlı olanı al.
    private fun pickBestAudioStream(streams: List<AudioStream>): AudioStream? {
        val m4a = streams.filter { it.format?.name?.contains("M4A", ignoreCase = true) == true }
        val pool = if (m4a.isNotEmpty()) m4a else streams
        return pool.maxByOrNull { it.averageBitrate }
    }
}
