package com.jarvis.ai.weather

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class WeatherInfo(
    val city: String,
    val tempC: Int,
    val description: String,
    val emoji: String
)

/**
 * Konum izni istemeden hava durumu göstermek için:
 * 1) IP adresinden yaklaşık şehir/koordinat (ipapi.co) — ekstra izin gerekmez.
 * 2) O koordinat için anlık hava durumu (Open-Meteo, ücretsiz, API key gerekmez).
 * Android konum iznine (ACCESS_FINE_LOCATION) hiç ihtiyaç yok; sadece mevcut
 * INTERNET izni kullanılıyor.
 */
object WeatherClient {
    private const val TAG = "WeatherClient"

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    suspend fun fetchCurrentWeather(): WeatherInfo? = withContext(Dispatchers.IO) {
        try {
            val (lat, lon, city) = fetchApproxLocation() ?: return@withContext null
            fetchWeatherFor(lat, lon, city)
        } catch (e: Exception) {
            Log.w(TAG, "Weather fetch failed", e)
            null
        }
    }

    /**
     * Sol alttaki widget için: kullanıcının en son sohbette sorduğu şehrin
     * anlık hava durumu (IP'den yaklaşık konum yerine bu şehir kullanılır).
     */
    suspend fun fetchCurrentWeatherForCity(city: String): WeatherInfo? = withContext(Dispatchers.IO) {
        try {
            val (lat, lon, name) = geocodeCity(city) ?: return@withContext null
            fetchWeatherFor(lat, lon, name)
        } catch (e: Exception) {
            Log.w(TAG, "Weather fetch for city failed", e)
            null
        }
    }

    private fun geocodeCity(city: String): Triple<Double, Double, String>? = try {
        val geoUrl = "https://geocoding-api.open-meteo.com/v1/search?name=" +
            URLEncoder.encode(city.trim(), "UTF-8") + "&count=1&language=tr&format=json"
        val geoBody = client.newCall(Request.Builder().url(geoUrl).build()).execute().use {
            if (it.isSuccessful) it.body?.string().orEmpty() else ""
        }
        val first = JSONObject(geoBody.ifBlank { "{}" }).optJSONArray("results")?.optJSONObject(0)
            ?: return null
        Triple(first.optDouble("latitude"), first.optDouble("longitude"), first.optString("name", city))
    } catch (e: Exception) {
        Log.w(TAG, "geocodeCity başarısız", e)
        null
    }


    /**
     * Sohbet aracı (get_weather) için: istenen şehrin (boşsa yaklaşık konumun)
     * anlık hava durumu + günlük tahmini. Open-Meteo geocoding + forecast,
     * API anahtarı gerekmez. Ağ çağrısı yaptığı için IO thread'inde çağrılmalı.
     */
    fun forecastFor(city: String?, days: Int): JSONObject {
        return try {
            val lat: Double
            val lon: Double
            val name: String
            if (city.isNullOrBlank()) {
                val loc = fetchApproxLocation()
                    ?: return JSONObject().put("status", "error").put("message", "Konum bulunamadı, şehir adı söyler misiniz.")
                lat = loc.first; lon = loc.second; name = loc.third
            } else {
                val geo = geocodeCity(city)
                    ?: return JSONObject().put("status", "error").put("message", "\"$city\" adlı yer bulunamadı.")
                lat = geo.first; lon = geo.second; name = geo.third
            }
            val n = days.coerceIn(1, 7)
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code" +
                "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                "&timezone=auto&forecast_days=$n"
            val body = client.newCall(Request.Builder().url(url).build()).execute().use {
                if (it.isSuccessful) it.body?.string().orEmpty() else ""
            }
            if (body.isBlank()) return JSONObject().put("status", "error").put("message", "Hava servisine ulaşılamadı.")
            val root = JSONObject(body)
            val cur = root.optJSONObject("current")
            val out = JSONObject().put("status", "ok").put("city", name)
            if (cur != null) {
                out.put("now", JSONObject()
                    .put("temp_c", cur.optDouble("temperature_2m"))
                    .put("feels_like_c", cur.optDouble("apparent_temperature"))
                    .put("humidity_percent", cur.optInt("relative_humidity_2m"))
                    .put("wind_kmh", cur.optDouble("wind_speed_10m"))
                    .put("condition", describeWeatherCode(cur.optInt("weather_code", -1)).first))
            }
            val d = root.optJSONObject("daily")
            if (d != null) {
                val dates = d.optJSONArray("time") ?: JSONArray()
                val codes = d.optJSONArray("weather_code") ?: JSONArray()
                val maxs = d.optJSONArray("temperature_2m_max") ?: JSONArray()
                val mins = d.optJSONArray("temperature_2m_min") ?: JSONArray()
                val rain = d.optJSONArray("precipitation_probability_max") ?: JSONArray()
                val arr = JSONArray()
                for (i in 0 until dates.length()) {
                    arr.put(JSONObject()
                        .put("date", dates.optString(i))
                        .put("condition", describeWeatherCode(codes.optInt(i, -1)).first)
                        .put("max_c", maxs.optDouble(i))
                        .put("min_c", mins.optDouble(i))
                        .put("rain_chance_percent", rain.optInt(i)))
                }
                out.put("daily", arr)
            }
            out
        } catch (e: Exception) {
            Log.w(TAG, "forecastFor failed", e)
            JSONObject().put("status", "error").put("message", "Hava durumu alınamadı: ${e.javaClass.simpleName}")
        }
    }

    private fun fetchApproxLocation(): Triple<Double, Double, String>? =
        fetchFromIpapiCo() ?: fetchFromIpwhoIs()

    // ipapi.co: ücretsiz kotası TÜM dünyadaki kullanıcılar arasında paylaşılıyor,
    // bu yüzden kendi trafiğimiz düşük olsa bile sık sık "RateLimited" dönebiliyor
    // (HTTP 200 ama gövdede error:true olarak). Bu durumda ikinci bir sağlayıcıya
    // (ipwho.is) düşüyoruz, tek kaynağa bağımlı kalmıyoruz.
    private fun fetchFromIpapiCo(): Triple<Double, Double, String>? = try {
        val req = Request.Builder().url("https://ipapi.co/json/").build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return null
            val body = resp.body?.string() ?: return null
            val json = JSONObject(body)
            if (json.optBoolean("error", false)) return null
            val lat = json.optDouble("latitude", Double.NaN)
            val lon = json.optDouble("longitude", Double.NaN)
            if (lat.isNaN() || lon.isNaN()) return null
            val city = json.optString("city", "").ifBlank { "Konum" }
            Triple(lat, lon, city)
        }
    } catch (e: Exception) {
        Log.w(TAG, "ipapi.co başarısız", e)
        null
    }

    private fun fetchFromIpwhoIs(): Triple<Double, Double, String>? = try {
        val req = Request.Builder().url("https://ipwho.is/").build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return null
            val body = resp.body?.string() ?: return null
            val json = JSONObject(body)
            if (!json.optBoolean("success", true)) return null
            val lat = json.optDouble("latitude", Double.NaN)
            val lon = json.optDouble("longitude", Double.NaN)
            if (lat.isNaN() || lon.isNaN()) return null
            val city = json.optString("city", "").ifBlank { "Konum" }
            Triple(lat, lon, city)
        }
    } catch (e: Exception) {
        Log.w(TAG, "ipwho.is başarısız", e)
        null
    }

    private fun fetchWeatherFor(lat: Double, lon: Double, city: String): WeatherInfo? {
        val url = "https://api.open-meteo.com/v1/forecast" +
            "?latitude=$lat&longitude=$lon&current_weather=true&timezone=auto"
        val req = Request.Builder().url(url).build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return null
            val body = resp.body?.string() ?: return null
            val current = JSONObject(body).optJSONObject("current_weather") ?: return null
            val temp = current.optDouble("temperature", Double.NaN)
            if (temp.isNaN()) return null
            val code = current.optInt("weathercode", -1)
            val (desc, emoji) = describeWeatherCode(code)
            return WeatherInfo(city = city, tempC = Math.round(temp).toInt(), description = desc, emoji = emoji)
        }
    }

    /** WMO hava durumu kodları -> kısa Türkçe açıklama + emoji. */
    private fun describeWeatherCode(code: Int): Pair<String, String> = when (code) {
        0 -> "AÇIK" to "☀️"
        1, 2 -> "PARÇALI BULUTLU" to "🌤️"
        3 -> "BULUTLU" to "☁️"
        45, 48 -> "SİSLİ" to "🌫️"
        51, 53, 55 -> "ÇİSENTİ" to "🌦️"
        56, 57 -> "DONAN ÇİSENTİ" to "🌧️"
        61, 63, 65 -> "YAĞMURLU" to "🌧️"
        66, 67 -> "DONAN YAĞMUR" to "🌧️"
        71, 73, 75 -> "KARLI" to "🌨️"
        77 -> "KAR TANELERİ" to "🌨️"
        80, 81, 82 -> "SAĞANAK" to "🌦️"
        85, 86 -> "KAR SAĞANAĞI" to "🌨️"
        95 -> "GÖK GÜRÜLTÜLÜ" to "⛈️"
        96, 99 -> "DOLULU FIRTINA" to "⛈️"
        else -> "BİLİNMİYOR" to "🌡️"
    }
}
