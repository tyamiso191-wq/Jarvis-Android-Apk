package com.jarvis.ai.music

import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import java.util.concurrent.TimeUnit
import org.schabi.newpipe.extractor.downloader.Request as NewPipeRequest

/**
 * NewPipeExtractor kendi HTTP istemcisini içermiyor, dışarıdan bir
 * Downloader implementasyonu bekliyor. Burada OkHttp ile en basit,
 * standart implementasyonu sağlıyoruz (NewPipeExtractor'ın kendi
 * dokümantasyonunda önerilen kalıp).
 */
class NewPipeDownloader private constructor() : Downloader() {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    companion object {
        private const val USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

        @Volatile private var instance: NewPipeDownloader? = null

        fun instance(): NewPipeDownloader =
            instance ?: synchronized(this) {
                instance ?: NewPipeDownloader().also { instance = it }
            }
    }

    override fun execute(request: NewPipeRequest): Response {
        val httpMethod = request.httpMethod()
        val url = request.url()
        val headers = request.headers()
        val dataToSend = request.dataToSend()

        val requestBody = dataToSend?.toRequestBody()

        val builder = okhttp3.Request.Builder()
            .method(httpMethod, requestBody)
            .url(url)
            .header("User-Agent", USER_AGENT)

        for ((name, values) in headers) {
            if (values.size > 1) {
                builder.removeHeader(name)
                values.forEach { builder.addHeader(name, it) }
            } else if (values.size == 1) {
                builder.header(name, values[0])
            }
        }

        client.newCall(builder.build()).execute().use { resp ->
            if (resp.code == 429) {
                throw ReCaptchaException("reCaptcha Challenge requested", url)
            }
            val body = resp.body?.string()
            val latestUrl = resp.request.url.toString()
            return Response(resp.code, resp.message, resp.headers.toMultimap(), body, latestUrl)
        }
    }
}
