package com.jarvis.ai.vision

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.util.Log
import kotlinx.coroutines.delay
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * Windows Jarvis V3'teki analyze_screen aracının Android karşılığı.
 * Android'de ekran yakalama izni (MediaProjection) sohbet ortasında sessizce
 * alınamaz -- kullanıcının bir sistem dialog'unu onaylaması ŞART. Bu yüzden
 * (play_song/takvim izinleri gibi) bu izin de UYGULAMA AÇILIŞINDA bir kez
 * istenir (bkz. MainActivity) ve sonucu burada, süreç hayatta olduğu sürece
 * yeniden kullanılmak üzere saklanır. Kullanıcı reddederse analyze_screen
 * fonksiyonu net bir hata döner, uygulama kırılmaz.
 */
object ScreenVisionController {
    private const val TAG = "ScreenVisionController"

    @Volatile private var permissionResultCode: Int = Activity.RESULT_CANCELED
    @Volatile private var permissionData: Intent? = null

    val hasPermission: Boolean
        get() = permissionData != null && permissionResultCode == Activity.RESULT_OK

    fun buildPermissionRequestIntent(context: Context): Intent {
        val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        return manager.createScreenCaptureIntent()
    }

    /** MainActivity'nin ActivityResultLauncher callback'inden çağrılır. */
    fun onPermissionResult(resultCode: Int, data: Intent?) {
        permissionResultCode = resultCode
        permissionData = data
    }

    /**
     * @return yakalanan ekran görüntüsünün JPEG bayt dizisi. İzin
     * verilmemişse ya da yakalama başarısız olursa null.
     */
    suspend fun captureJpeg(context: Context): ByteArray? {
        val data = permissionData
        if (!hasPermission || data == null) {
            Log.w(TAG, "Ekran yakalama izni yok/verilmemiş.")
            return null
        }
        val appContext = context.applicationContext

        // Android 14+ şartı: MediaProjection SADECE mediaProjection türünde
        // bir foreground servis çalışırken kullanılabilir.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            appContext.startForegroundService(Intent(appContext, ScreenCaptureService::class.java))
            // Servisin startForeground()'u çağırması için kısa bir pay --
            // aksi halde getMediaProjection() "foreground service required"
            // hatası verebilir.
            delay(250)
        }

        val manager = appContext.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        var projection: MediaProjection? = null
        var virtualDisplay: VirtualDisplay? = null
        var imageReader: ImageReader? = null
        val handlerThread = HandlerThread("jarvis-screen-capture").apply { start() }
        return try {
            projection = manager.getMediaProjection(permissionResultCode, data)
            if (projection == null) {
                Log.w(TAG, "getMediaProjection null döndü.")
                return null
            }

            val metrics: DisplayMetrics = appContext.resources.displayMetrics
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi

            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            val handler = Handler(handlerThread.looper)

            val jpegBytes = suspendCoroutine<ByteArray?> { cont ->
                var resumed = false
                imageReader.setOnImageAvailableListener({ reader ->
                    if (resumed) return@setOnImageAvailableListener
                    val image = try { reader.acquireLatestImage() } catch (e: Exception) { null }
                    if (image == null) return@setOnImageAvailableListener
                    resumed = true
                    try {
                        val plane = image.planes[0]
                        val pixelStride = plane.pixelStride
                        val rowStride = plane.rowStride
                        val rowPadding = rowStride - pixelStride * width
                        val bitmap = Bitmap.createBitmap(
                            width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888
                        )
                        bitmap.copyPixelsFromBuffer(plane.buffer)
                        val cropped = if (rowPadding == 0) bitmap else
                            Bitmap.createBitmap(bitmap, 0, 0, width, height)
                        val out = ByteArrayOutputStream()
                        cropped.compress(Bitmap.CompressFormat.JPEG, 85, out)
                        cont.resume(out.toByteArray())
                    } catch (e: Exception) {
                        Log.w(TAG, "Kare işlenemedi", e)
                        cont.resume(null)
                    } finally {
                        image.close()
                    }
                }, handler)

                virtualDisplay = projection.createVirtualDisplay(
                    "jarvis-screen-capture",
                    width, height, density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.surface, null, handler
                )
            }
            jpegBytes
        } catch (e: Exception) {
            Log.w(TAG, "Ekran yakalanamadı", e)
            null
        } finally {
            virtualDisplay?.release()
            imageReader?.close()
            projection?.stop()
            handlerThread.quitSafely()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                appContext.stopService(Intent(appContext, ScreenCaptureService::class.java))
            }
        }
    }
}
