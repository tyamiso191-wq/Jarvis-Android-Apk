package com.jarvis.ai.video

import android.util.Log
import com.jarvis.ai.music.NewPipeDownloader
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.StreamInfoItem

/**
 * Kullanıcı "... izle" dediğinde (film, dizi, herhangi bir video) YouTube'da
 * arayıp ilk sonucun video ID'sini döndürür. Bu ID, MainScreen'deki mini
 * oynatıcıda bir YouTube "embed" (https://www.youtube.com/embed/ID) sayfası
 * olarak WebView içinde açılır — MusicController/YoutubeAudioResolver'ın
 * ses akışını çözmesine benzer şekilde NewPipeExtractor ile arama yapılır,
 * ama burada ham video akışı çözmek yerine (video için bu çok daha kırılgan
 * ve genelde şifreli/DRM'li), doğrudan YouTube'un kendi embed oynatıcısına
 * video ID'si veriliyor — bu hem çok daha güvenilir hem de YouTube'un
 * kendi oynatma altyapısını (arayüz, buferleme vb.) kullanıyor.
 */
object VideoSearchController {
    private const val TAG = "VideoSearchController"

    sealed class Result {
        data class Found(val videoId: String, val title: String, val channel: String) : Result()
        object NotFound : Result()
        data class Error(val message: String) : Result()
    }

    @Volatile private var initialized = false

    private fun ensureInit() {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            NewPipe.init(NewPipeDownloader.instance())
            initialized = true
        }
    }

    /** Ağ üzerinde çalışan BLOKLAYICI bir fonksiyon — çağıran taraf zaten
     * bir arka plan thread'inde (Dispatchers.IO) olmalı. */
    fun search(query: String): Result {
        val q = query.trim()
        if (q.isBlank()) return Result.Error("Hangi film/dizi/video izleneceği belirtilmedi.")
        return try {
            ensureInit()
            val service = ServiceList.YouTube

            val searchExtractor = service.getSearchExtractor(q)
            searchExtractor.fetchPage()
            val firstVideo = searchExtractor.initialPage.items
                .filterIsInstance<StreamInfoItem>()
                .firstOrNull() ?: return Result.NotFound

            val videoId = extractVideoId(firstVideo.url) ?: return Result.NotFound

            Result.Found(
                videoId = videoId,
                title = firstVideo.name ?: q,
                channel = firstVideo.uploaderName ?: ""
            )
        } catch (e: Exception) {
            Log.w(TAG, "YouTube video araması başarısız: $q", e)
            Result.Error(e.message ?: "bilinmeyen hata")
        }
    }

    // NewPipe watch URL'i genelde "https://www.youtube.com/watch?v=ID" biçiminde
    // döner, ama garanti olsun diye youtu.be kısa linkini de destekliyoruz.
    private fun extractVideoId(url: String?): String? {
        if (url.isNullOrBlank()) return null
        Regex("[?&]v=([a-zA-Z0-9_-]{6,})").find(url)?.let { return it.groupValues[1] }
        Regex("youtu\\.be/([a-zA-Z0-9_-]{6,})").find(url)?.let { return it.groupValues[1] }
        return null
    }
}
