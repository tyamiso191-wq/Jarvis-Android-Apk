package com.jarvis.ai.device

import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import com.jarvis.ai.weather.WeatherInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Modelin "saat kaç / cihazıma erişimim yok" demesini engellemek için, her
 * istekte TAZE bir "şu an durum" bloğu üretip isteğe ekliyoruz. Aşağıdakilerin
 * hiçbiri ek bir Android izni gerektirmiyor:
 *  - Tarih/saat: cihazın kendi saatinden (java.util.Date + TimeZone)
 *  - Telefon modeli/Android sürümü: android.os.Build (izinsiz)
 *  - Depolama: StatFs (izinsiz)
 *  - Pil yüzdesi: BatteryManager.BATTERY_PROPERTY_CAPACITY (izinsiz)
 */
object DeviceInfo {

    fun snapshot(context: Context, weather: WeatherInfo? = null): String {
        val now = Date()
        val tz = TimeZone.getDefault()
        val dateFmt = SimpleDateFormat("d MMMM yyyy, EEEE", Locale("tr", "TR")).apply { timeZone = tz }
        val timeFmt = SimpleDateFormat("HH:mm", Locale("tr", "TR")).apply { timeZone = tz }

        val storage = try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val totalGb = stat.blockCountLong * stat.blockSizeLong / (1024.0 * 1024 * 1024)
            val freeGb = stat.availableBlocksLong * stat.blockSizeLong / (1024.0 * 1024 * 1024)
            String.format(Locale.US, "%.1f GB boş / %.1f GB toplam", freeGb, totalGb)
        } catch (e: Exception) {
            "okunamadı"
        }

        val battery = try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            val pct = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
            if (pct in 0..100) "%$pct" else "okunamadı"
        } catch (e: Exception) {
            "okunamadı"
        }

        val weatherLine = if (weather != null) {
            "Hava durumu: ${weather.city}, ${weather.tempC}°C, ${weather.description} ${weather.emoji}"
        } else {
            "Hava durumu: henüz alınamadı (birazdan tekrar denenecek)"
        }

        return """
            [GÜNCEL DURUM — bu bilgiler gerçek ve taze, soru gelirse ASLA "erişimim yok" deme, doğrudan buradan cevapla]
            Tarih: ${dateFmt.format(now)}
            Saat: ${timeFmt.format(now)} (saat dilimi: ${tz.id})
            Telefon: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}
            Depolama: $storage
            Pil: $battery
            $weatherLine
        """.trimIndent()
    }
}
