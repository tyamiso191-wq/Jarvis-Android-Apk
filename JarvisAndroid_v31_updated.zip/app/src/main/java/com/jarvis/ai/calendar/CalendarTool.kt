package com.jarvis.ai.calendar

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/**
 * Takvim araçları. Windows Jarvis V3'teki actions/calendar.py'nin
 * (get_calendar_events / add_calendar_event / delete_calendar_event)
 * Android karşılığı — Android'in kendi CalendarProvider'ını (CalendarContract)
 * kullanır, yani telefonda zaten senkronize olan Google/Samsung/Outlook
 * takvimiyle doğrudan çalışır (ayrı bir "Jarvis takvimi" oluşturmaz).
 *
 * READ_CALENDAR / WRITE_CALENDAR izni gerektirir (AndroidManifest'te
 * tanımlı, MainActivity açılışta ister).
 */
object CalendarTool {
    data class EventResult(
        val id: Long,
        val title: String,
        val startMillis: Long,
        val endMillis: Long,
        val location: String,
        val calendarName: String
    )

    private fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED

    private val displayFmt = SimpleDateFormat("d MMMM yyyy HH:mm", Locale("tr", "TR"))

    /**
     * fromMillis..toMillis aralığındaki etkinlikleri döndürür.
     * limit adet döndürülür, en yakın tarihliden başlar.
     */
    fun getEvents(context: Context, fromMillis: Long, toMillis: Long, limit: Int): Result<List<EventResult>> {
        if (!hasPermission(context)) return Result.failure(SecurityException("no_permission"))
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon()
            .appendPath(fromMillis.toString())
            .appendPath(toMillis.toString())
            .build()
        val projection = arrayOf(
            CalendarContract.Instances.EVENT_ID,
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END,
            CalendarContract.Instances.EVENT_LOCATION,
            CalendarContract.Instances.CALENDAR_DISPLAY_NAME
        )
        val results = mutableListOf<EventResult>()
        context.contentResolver.query(
            uri, projection, null, null,
            "${CalendarContract.Instances.BEGIN} ASC"
        )?.use { c ->
            while (c.moveToNext() && results.size < limit) {
                results += EventResult(
                    id = c.getLong(0),
                    title = c.getString(1) ?: "(başlıksız)",
                    startMillis = c.getLong(2),
                    endMillis = c.getLong(3),
                    location = c.getString(4) ?: "",
                    calendarName = c.getString(5) ?: ""
                )
            }
        }
        return Result.success(results)
    }

    private fun defaultCalendarId(context: Context): Long? {
        val uri = CalendarContract.Calendars.CONTENT_URI
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.IS_PRIMARY,
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL
        )
        var fallback: Long? = null
        context.contentResolver.query(uri, projection, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val isPrimary = c.getInt(1)
                val access = c.getInt(2)
                if (access < CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR) continue
                if (isPrimary == 1) return id
                if (fallback == null) fallback = id
            }
        }
        return fallback
    }

    /** Yeni etkinlik ekler. startMillis/endMillis epoch ms. Eklenen event id'yi döndürür. */
    fun addEvent(
        context: Context,
        title: String,
        startMillis: Long,
        endMillis: Long,
        notes: String,
        location: String,
        allDay: Boolean
    ): Result<Long> {
        if (!hasPermission(context)) return Result.failure(SecurityException("no_permission"))
        val calId = defaultCalendarId(context)
            ?: return Result.failure(IllegalStateException("no_calendar"))
        val tz = TimeZone.getDefault()
        val values = ContentValues().apply {
            put(CalendarContract.Events.CALENDAR_ID, calId)
            put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.DESCRIPTION, notes)
            put(CalendarContract.Events.EVENT_LOCATION, location)
            put(CalendarContract.Events.DTSTART, startMillis)
            put(CalendarContract.Events.DTEND, endMillis)
            put(CalendarContract.Events.ALL_DAY, if (allDay) 1 else 0)
            put(CalendarContract.Events.EVENT_TIMEZONE, tz.id)
        }
        val uri = context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
            ?: return Result.failure(IllegalStateException("insert_failed"))
        return Result.success(ContentUris.parseId(uri))
    }

    /**
     * Başlığa göre (içeren, büyük/küçük harf duyarsız) eşleşen, gelecekteki
     * etkinlik(ler)i siler. deleteAllMatches=false ise sadece en yakın
     * olanı siler. Silinen sayıyı döndürür.
     */
    fun deleteEventsByTitle(context: Context, titleQuery: String, deleteAllMatches: Boolean): Result<Int> {
        if (!hasPermission(context)) return Result.failure(SecurityException("no_permission"))
        val now = System.currentTimeMillis()
        val oneYearAhead = now + 365L * 24 * 60 * 60 * 1000
        val found = getEvents(context, now - 60_000L, oneYearAhead, 200).getOrElse { return Result.failure(it) }
        val q = titleQuery.trim().lowercase()
        val matches = found.filter { it.title.lowercase().contains(q) }.sortedBy { it.startMillis }
        val toDelete = if (deleteAllMatches) matches else matches.take(1)
        var deleted = 0
        toDelete.forEach { ev ->
            val uri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, ev.id)
            deleted += context.contentResolver.delete(uri, null, null)
        }
        return Result.success(deleted)
    }

    fun formatEvent(e: EventResult): String {
        val start = displayFmt.format(java.util.Date(e.startMillis))
        val end = displayFmt.format(java.util.Date(e.endMillis))
        val loc = if (e.location.isNotBlank()) " (${e.location})" else ""
        return "${e.title}$loc: $start – $end"
    }

    /** "today" / "tomorrow" / "week" gibi kaba bir sorguyu epoch ms aralığına çevirir. */
    fun rangeForQuery(query: String): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val startOfToday = cal.timeInMillis
        return when {
            query.contains("yarın", true) || query.contains("tomorrow", true) -> {
                val s = startOfToday + 24 * 60 * 60 * 1000
                s to s + 24 * 60 * 60 * 1000
            }
            query.contains("hafta", true) || query.contains("week", true) -> {
                startOfToday to startOfToday + 7L * 24 * 60 * 60 * 1000
            }
            query.contains("ay", true) || query.contains("month", true) -> {
                startOfToday to startOfToday + 31L * 24 * 60 * 60 * 1000
            }
            else -> startOfToday to startOfToday + 24 * 60 * 60 * 1000 // today (default)
        }
    }
}
