package com.jarvis.ai.files

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * JARVIS'in kullanıcı için gerçek dosya (txt, herhangi bir düz metin, zip,
 * fotoğraf/görsel dahil herhangi bir ikili dosya) oluşturabilmesini sağlar.
 *
 * Android 10 (API 29) ve üstünde: MediaStore üzerinden doğrudan paylaşılan
 * "İndirilenler" (ya da görseller için "Pictures") klasörüne, HİÇBİR ek izin
 * istemeden yazılır (scoped storage).
 * Android 9 ve altında (API 26-28, bu projenin minSdk'sı): scoped storage yok
 * ve genel depolama izni gerekirdi; karmaşıklığı artırmamak için o eski
 * cihazlarda dosya uygulamanın kendi özel alanına (Context.filesDir) yazılır.
 */
object FileTool {

    data class SavedFile(val displayPath: String, val savedToDownloads: Boolean)

    /** Zip içine eklenecek tek bir girdi: metin ya da ikili (fotoğraf vb.) veri. */
    data class ZipEntryInput(val filename: String, val bytes: ByteArray)

    fun createTextFile(
        context: Context,
        filename: String,
        content: String,
        mimeType: String = "text/plain"
    ): SavedFile = createBinaryFile(context, filename, content.toByteArray(), mimeType)

    /**
     * Herhangi bir ikili dosyayı (görsel, ses, arşiv, doküman -- her türlü
     * uzantı) İndirilenler klasörüne kaydeder. AI'nin "birçok dosya türü"
     * oluşturabilmesinin temel yapı taşı; create_file, create_zip ve
     * create_image bunun üzerine kurulu.
     */
    fun createBinaryFile(
        context: Context,
        filename: String,
        bytes: ByteArray,
        mimeType: String = guessMimeType(filename)
    ): SavedFile {
        val safeName = sanitize(filename)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Dosya oluşturulamadı (MediaStore reddetti)")
            resolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: throw IOException("Dosyaya yazılamadı")
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            SavedFile("İndirilenler/$safeName", true)
        } else {
            val file = File(context.filesDir, safeName)
            FileOutputStream(file).use { it.write(bytes) }
            SavedFile(file.absolutePath, false)
        }
    }

    /**
     * AI tarafından üretilen (ya da indirilen) bir fotoğrafı/görseli, galeride
     * görünecek şekilde MediaStore.Images (Pictures) koleksiyonuna kaydeder.
     */
    fun createImageFile(
        context: Context,
        filename: String,
        bytes: ByteArray,
        mimeType: String = "image/png"
    ): SavedFile {
        val safeName = sanitize(filename, forceExt = if (mimeType.contains("jpeg")) "jpg" else "png")
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, safeName)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Görsel oluşturulamadı (MediaStore reddetti)")
            resolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: throw IOException("Görsele yazılamadı")
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            SavedFile("Resimler/$safeName", true)
        } else {
            val file = File(context.filesDir, safeName)
            FileOutputStream(file).use { it.write(bytes) }
            SavedFile(file.absolutePath, false)
        }
    }

    fun createZipFile(
        context: Context,
        zipFilename: String,
        entries: List<ZipEntryInput>
    ): SavedFile {
        val safeName = sanitize(zipFilename, forceExt = "zip")
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Zip oluşturulamadı (MediaStore reddetti)")
            resolver.openOutputStream(uri)?.use { out -> writeZip(out, entries) }
                ?: throw IOException("Zip'e yazılamadı")
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            SavedFile("İndirilenler/$safeName", true)
        } else {
            val file = File(context.filesDir, safeName)
            FileOutputStream(file).use { out -> writeZip(out, entries) }
            SavedFile(file.absolutePath, false)
        }
    }

    private fun writeZip(out: java.io.OutputStream, entries: List<ZipEntryInput>) {
        ZipOutputStream(out).use { zos ->
            entries.forEach { entry ->
                zos.putNextEntry(ZipEntry(sanitize(entry.filename)))
                zos.write(entry.bytes)
                zos.closeEntry()
            }
        }
    }

    private fun guessMimeType(filename: String): String {
        val ext = filename.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "json" -> "application/json"
            "csv" -> "text/csv"
            "md" -> "text/markdown"
            "pdf" -> "application/pdf"
            "zip" -> "application/zip"
            "xml" -> "text/xml"
            "html", "htm" -> "text/html"
            else -> "text/plain"
        }
    }

    private fun sanitize(name: String, forceExt: String? = null): String {
        var n = name.trim().ifBlank { "jarvis_dosya" }
        n = n.replace(Regex("[/\\\\:*?\"<>|]"), "_")
        if (forceExt != null && !n.endsWith(".$forceExt", ignoreCase = true)) {
            n = "$n.$forceExt"
        }
        return n
    }
}
