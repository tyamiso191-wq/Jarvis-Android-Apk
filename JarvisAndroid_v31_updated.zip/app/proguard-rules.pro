# Keep Gemini / networking related classes if minify is enabled later
-keep class com.jarvis.ai.** { *; }

# NewPipeExtractor'ın kendi önerdiği kurallar (minify açılırsa gerekiyor)
-keep class org.schabi.newpipe.extractor.timeago.patterns.** { *; }
-keep class org.mozilla.javascript.** { *; }
-keep class org.mozilla.classfile.ClassFileWriter
-dontwarn org.mozilla.javascript.tools.**
