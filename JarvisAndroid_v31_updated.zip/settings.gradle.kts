pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // NewPipeExtractor'ın dağıtıldığı yer (YouTube'da şarkı arayıp arka
        // planda direkt ses akışı olarak çalabilmek için).
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "Jarvis"
include(":app")
