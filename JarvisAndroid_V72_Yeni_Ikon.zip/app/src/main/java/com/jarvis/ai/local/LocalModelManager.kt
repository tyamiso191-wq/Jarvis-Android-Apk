package com.jarvis.ai.local

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Cihaz içi MediaPipe modelini bulur; yoksa ilk açılışta kendisi indirir (API anahtarı gerekmez).
 * Varsayılan model: Qwen2.5-1.5B-Instruct (Apache-2.0, giriş/lisans onayı istemez).
 */
object LocalModelManager {
    const val MODEL_FILE_NAME = "jarvis.task"
    const val MODEL_URL =
        "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/" +
            "Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv4096.task"

    private val downloading = AtomicBoolean(false)
    private val _progress = MutableStateFlow(-1) // -1: indirme yok, 0..100: yüzde
    val progress: StateFlow<Int> = _progress.asStateFlow()
    fun isDownloading(): Boolean = downloading.get()

    fun modelDir(context: Context): File =
        File(context.filesDir, "models").apply { mkdirs() }

    fun modelFile(context: Context): File = File(modelDir(context), MODEL_FILE_NAME)

    fun isReady(context: Context): Boolean = modelFile(context).let { it.exists() && it.length() > 1024L * 1024L }

    fun installFromAssetsIfPresent(context: Context): Boolean {
        val target = modelFile(context)
        if (isReady(context)) return true
        return try {
            context.assets.open("models/$MODEL_FILE_NAME").use { input ->
                target.outputStream().use { output -> input.copyTo(output) }
            }
            isReady(context)
        } catch (_: Exception) {
            false
        }
    }

    /** Model yoksa indirir (yarım kalan indirme kaldığı yerden devam eder). */
    suspend fun ensureModel(context: Context, onProgress: (Int) -> Unit = {}): Result<Unit> =
        withContext(Dispatchers.IO) {
            if (isReady(context)) return@withContext Result.success(Unit)
            if (!downloading.compareAndSet(false, true)) {
                return@withContext Result.failure(IOException("Model zaten indiriliyor"))
            }
            try {
                val target = modelFile(context)
                val part = File(target.parentFile, "$MODEL_FILE_NAME.part")
                var existing = if (part.exists()) part.length() else 0L
                val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
                conn.connectTimeout = 20_000
                conn.readTimeout = 30_000
                conn.instanceFollowRedirects = true
                if (existing > 0) conn.setRequestProperty("Range", "bytes=$existing-")
                conn.connect()
                val code = conn.responseCode
                if (code != 200 && code != 206) {
                    if (code == 416) part.delete()
                    throw IOException("İndirme başlatılamadı (HTTP $code)")
                }
                val append = code == 206
                if (!append) existing = 0
                val total = existing + conn.contentLengthLong
                var done = existing
                var lastPct = -1
                conn.inputStream.use { input ->
                    FileOutputStream(part, append).use { out ->
                        val buf = ByteArray(256 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val pct = (done * 100 / total).toInt().coerceIn(0, 100)
                                if (pct != lastPct) {
                                    lastPct = pct
                                    _progress.value = pct
                                    onProgress(pct)
                                }
                            }
                        }
                    }
                }
                if (total > 0 && part.length() < total) throw IOException("İndirme yarım kaldı")
                target.delete()
                if (!part.renameTo(target)) throw IOException("Model dosyası kaydedilemedi")
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            } finally {
                _progress.value = -1
                downloading.set(false)
            }
        }

    fun status(context: Context): String = when {
        isReady(context) -> "Yerel model hazır: ${modelFile(context).length() / (1024 * 1024)} MB"
        isDownloading() -> "Model indiriliyor: %${_progress.value.coerceAtLeast(0)}"
        else -> "Yerel model henüz indirilmedi."
    }
}
