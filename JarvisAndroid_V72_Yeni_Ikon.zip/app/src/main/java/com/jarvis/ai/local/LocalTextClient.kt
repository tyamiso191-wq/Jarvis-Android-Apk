package com.jarvis.ai.local

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.jarvis.ai.files.FileTool
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException

/** Cihaz üzerinde çalışan, ağ/API anahtarı gerektirmeyen metin istemcisi. */
class LocalTextClient(private val context: Context, private val persona: String) {
    @Volatile var onFileReady: ((FileTool.StagedFile) -> Unit)? = null

    suspend fun sendMessage(
        conversation: List<Pair<String, String>>,
        currentTurnText: String? = null,
        deviceContext: String = ""
    ): Result<String> = withContext(Dispatchers.Default) {
        try {
            LocalModelManager.installFromAssetsIfPresent(context)
            if (!LocalModelManager.isReady(context)) {
                val msg = if (LocalModelManager.isDownloading())
                    "Yapay zekâ modeli ilk kurulum için indiriliyor (%${LocalModelManager.progress.value.coerceAtLeast(0)}). Bitince tekrar sor."
                else
                    "Model henüz indirilmedi. İnternete bağlanıp uygulamayı kapatıp yeniden aç; indirme otomatik başlar."
                return@withContext Result.failure(IOException(msg))
            }
            val model = LocalModelManager.modelFile(context)

            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(model.absolutePath)
                .setMaxTokens(4096)
                .build()
            val inference = LlmInference.createFromOptions(context, options)
            try {
                val prompt = buildPrompt(conversation, currentTurnText, deviceContext)
                val generated = inference.generateResponse(prompt)
                Result.success(handleFileTags(generated.trim()))
            } finally {
                inference.close()
            }
        } catch (e: Exception) {
            Log.e("LocalTextClient", "Yerel model çalıştırılamadı", e)
            Result.failure(e)
        }
    }

    // Qwen2.5 sohbet biçimi (ChatML).
    private fun buildPrompt(
        conversation: List<Pair<String, String>>,
        currentTurnText: String?,
        deviceContext: String
    ): String = buildString {
        append("<|im_start|>system\n")
        append(persona.take(2500))
        append("\nSen tamamen telefon içinde çalışan, API'siz bir asistansın. İnternete erişimin yok. Türkçe cevap ver.\n")
        append("Kullanıcı dosya istediğinde dosya içeriğini üret ve yalnızca şu biçimi kullan: ")
        append("<jarvis_file name=\"dosya.txt\">DOSYA İÇERİĞİ</jarvis_file>. ")
        append("Kod veya HTML istenirse içeriği bu etiketin içine koy. Etiketi kapat.\n")
        if (deviceContext.isNotBlank()) append(deviceContext.take(800)).append('\n')
        append("<|im_end|>\n")
        conversation.takeLast(8).forEach { (role, text) ->
            append("<|im_start|>").append(if (role == "user") "user" else "assistant").append('\n')
            append(text.take(1500)).append("\n<|im_end|>\n")
        }
        if (currentTurnText != null && conversation.lastOrNull()?.second != currentTurnText) {
            append("<|im_start|>user\n").append(currentTurnText.take(3000)).append("\n<|im_end|>\n")
        }
        append("<|im_start|>assistant\n")
    }

    private fun handleFileTags(text: String): String {
        val regex = Regex("(?s)<jarvis_file\\s+name=\\\"([^\\\"]+)\\\">(.*?)</jarvis_file>")
        var reply = text
        regex.findAll(text).toList().forEach { match ->
            val name = match.groupValues[1].trim().ifBlank { "jarvis_dosya.txt" }
            val content = match.groupValues[2].trimStart('\n', ' ')
            val staged = FileTool.stageTextFile(context, name, content)
            onFileReady?.invoke(staged)
            reply = reply.replace(match.value, "📎 $name dosyasını sohbete ekledim. İndirmek için dosya kartındaki Kaydet düğmesine basabilirsin.")
        }
        return reply.trim()
    }
}
