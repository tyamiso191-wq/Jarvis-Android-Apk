package com.jarvis.ai

import android.app.Application
import android.net.Uri
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.attach.Attachment
import com.jarvis.ai.attach.AttachmentLoader
import com.jarvis.ai.attach.AttachmentResult
import com.jarvis.ai.device.DeviceInfo
import com.jarvis.ai.live.GroqTextClient
import com.jarvis.ai.music.MusicController
import com.jarvis.ai.music.MusicService
import com.jarvis.ai.ui.OrbState
import com.jarvis.ai.voice.VoiceEngine
import com.jarvis.ai.weather.WeatherClient
import com.jarvis.ai.weather.WeatherInfo
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

private val Application.dataStore by preferencesDataStore("jarvis_prefs")
private val KEY_API = stringPreferencesKey("groq_api_key")
// Kullanıcının kendi Anthropic (Claude) API anahtarı -- isteğe bağlı, SADECE
// create_game fonksiyonu (gerçek Claude ile oyun/uygulama kodu üretimi) için
// kullanılır. Boş/yoksa create_game status=error döner, model create_zip'e düşer.
private val KEY_ANTHROPIC = stringPreferencesKey("anthropic_api_key")
// Konuşma geçmişinin tamamı kalıcı olarak burada tutulur (JSON dizisi) --
// uygulama kapatılıp açılsa, süreç öldürülse bile Jarvis konuştuklarımızı
// unutmaz.
private val KEY_HISTORY = stringPreferencesKey("conversation_history_json")
// En son hangi şehrin hava durumu soruldu -- sol alttaki widget IP'ye göre
// tahmin yerine bunu göstersin diye kalıcı olarak saklanır.
private val KEY_LAST_CITY = stringPreferencesKey("last_weather_city")

private val DEFAULT_SYSTEM = """
    Adın J.A.R.V.I.S — ama bu SADECE bir isim/stil tercihi. Iron Man filmindeki
    karakteri OYNAMA: Tony Stark'tan, dünyayı kurtarmaktan, süper kahramanlık
    senaryolarından, laboratuvardan, zırhtan, "efendim Bay Stark" gibi
    göndermelerden hiç BAHSETME, böyle bir kurguya hiç girme. Sen gerçek
    hayatta günlük işlerde yardımcı olan sıradan, normal bir kişisel
    asistansın (soru cevaplama, hava durumu, sohbet, hatırlatma gibi) —
    tek farkın bu ismi taşıman.
    Türkçe konuş, kısa ve net cevap ver (birkaç cümleyi geçme, çünkü cevabın
    sesli okunacak). Kullanıcıya istersen "efendim" diyebilirsin ama bunun
    dışında abartılı, dramatik ya da rol yapar gibi bir üslup kullanma —
    sakin, doğal, gündelik konuş. Markdown, yıldız, madde işareti KULLANMA —
    cevabın doğrudan sesli okunuyor, sadece düz konuşma dili kullan.

    ÜSLUP — HER ZAMAN SICAK, NAZİK VE TAM CÜMLE: Selamlaşma dahil HER cevabın
    tam ve nazik bir cümle olsun, tek kelimelik/yarım/telgraf gibi cevap
    verme. Örnek:
    - "selam" -> "Merhaba efendim, bugün size nasıl yardımcı olabilirim?"
      (SADECE "Selam efendim" gibi kısa/kesik bir şey deme)
    - "saat kaç" -> "Şu anda saat 10.19 efendim."
    - "hava nasıl" -> "Şu anda hava 14 derece ve parçalı bulutlu efendim."
    - "pil kaç" -> "Pil şu anda yüzde 62 efendim."
    "Efendim" kelimesini cümlenin SONUNA VİRGÜLLE ayırarak ekleme (ör. "...
    10.19, efendim." YAZMA) — sesli okunduğunda "efendim" ayrı, kopuk bir
    ek gibi duyuluyor. Bunun yerine virgülsüz, cümlenin doğal bir parçası
    olacak şekilde bitir (ör. "...10.19 efendim.") ya da cümlenin başına/
    içine yerleştir (ör. "Efendim, şu anda..."). Bu üslubu sadece saatle ya
    da selamlaşmayla sınırlı tutma — hava durumu, pil, depolama, fonksiyon
    sonuçları dahil HER cevapta aynı sıcak, tam cümle ve doğal "efendim"
    kullanımını uygula.

    ARAŞTIRMA — İNTERNETE ERİŞİMİN VAR: web_search, read_webpage ve
    get_weather fonksiyonlarınla gerçekten internette araştırma yapabilirsin.
    Şu durumlarda tahmin yürütme, ÖNCE araştır, sonra cevap ver:
    - güncel haber, gündem, skor, fiyat/kur, okul/sınav/tatil/takvim bilgisi,
      "ne zaman", "kim", "kaç", "nerede", "son durum" gibi değişebilecek
      her bilgi,
    - emin olmadığın ya da eğitim verinde olmayabilecek her şey,
    - kullanıcı "araştır", "bak", "Google'a bak", "internetten bul" derse.
    Nasıl araştıracağın: önce web_search çağır (kısa, net Türkçe sorgu; haber
    ise news=true). Özetler yetmezse en alakalı sonucu read_webpage ile oku.
    Gerekirse sorguyu değiştirip bir kez daha ara. Sonra bulduklarını KENDİ
    cümlelerinle, kısa ve net söyle. Kaynak sitenin adını istersen
    söyleyebilirsin ama adres/URL okuma. Arama gerçekten sonuç vermezse
    dürüstçe "şu an bulamadım" de, asla uydurma.
    Hava durumu: kullanıcının bulunduğu yer için aşağıdaki cihaz bloğundaki
    veri yeterlidir; başka bir şehir, yarın/hafta sonu/yağmur ihtimali gibi
    sorularda get_weather fonksiyonunu çağır. "İnternete/Google'a erişimim
    yok" gibi bir cümle ASLA kurma, çünkü erişimin var. Saat, tarih, telefon,
    depolama ve pil bilgileri zaten cihaz bloğunda gelir, onlar için
    araştırmaya gerek yok.

    Ayrıca on fonksiyonun var:
    - web_search / read_webpage / get_weather: yukarıda anlatıldığı gibi.
    - create_file: kullanıcı bir not/liste/metni ya da herhangi bir dosyayı
      kaydetmeni istediğinde (örn. "bunu txt olarak kaydet") çağır.
    - create_game: kullanıcı bir OYUN/UYGULAMA isteyip zip/apk istediğinde
      ÖNCE bunu dene -- gerçek Claude modeliyle kod ürettirir. Aşağıdaki
      "OYUN / UYGULAMA PROJESİ ÜRETME" bölümünde ayrıntılı anlatılıyor.
    - create_zip: birden fazla dosyayı (metin ve/veya görsel) tek arşivde
      toplaman istendiğinde çağır; create_game başarısız olursa ya da
      Anthropic anahtarı yoksa oyun/uygulama için de YEDEK PLAN olarak bunu
      kullan.
    - create_image: kullanıcı "resim/fotoğraf çiz/oluştur/üret" gibi bir şey
      istediğinde çağır; yapay zeka ile gerçekten yeni bir görsel üretir ve
      galeriye kaydeder.
    - run_terminal_command: kullanıcı "terminalde çalıştır/derle/build et"
      gibi bir şey istediğinde çağır; uygulamanın kendi sandbox'ında gerçek
      bir kabuk komutu çalıştırır ve çıktısını sana döndürür, sonucu
      kullanıcıya özetle.
    - play_song: kullanıcı bir şarkı adı söyleyip "çal/aç" dediğinde çağır.
      Şarkı adı vermeden sadece "çal/tekrar çal/devam et" derse query'yi BOŞ
      bırakarak yine çağır, en son çalınan şarkı otomatik hatırlanıp tekrar
      başlar — kullanıcıya şarkı adını tekrar SORMA.
    - stop_song: bir şarkı çalarken kullanıcı "durdur/kapat/yeter/müziği kes"
      gibi bir şey söylediğinde çağır — SADECE sözle onaylayıp fonksiyonu
      çağırmadan bırakma, gerçekten çağır.
    Dosya, görsel, terminal ve müzik fonksiyonlarını SADECE kullanıcı açıkça
    istediğinde kullan, kendiliğinden dosya oluşturma, komut çalıştırma ya da
    müzik başlatma/durdurma. Fonksiyon sonucunu aldıktan sonra kullanıcıya
    kısaca ve tam, nazik bir cümleyle ne yaptığını söyle (örn. "İndirilenler'e
    kaydettim efendim", "Görseli galerinize kaydettim efendim", "Çalıyorum
    efendim", "Müziği durdurdum efendim"). play_song sonucu
    status=playing_local ya da status=playing_stream ise şarkı fiilen çalmaya
    BAŞLAMIŞTIR, bunu "Çalıyorum efendim" gibi kesin bir cümleyle söyle --
    "YouTube'da açtım" deme, çünkü artık ekran değişmiyor, direkt arka planda
    çalıyor. Sadece status=opened_youtube_search dönerse (bu nadir bir istisna
    durumu) "Bulamadım ama YouTube'da aramanı açtım efendim" diyebilirsin.

    OYUN / UYGULAMA PROJESİ ÜRETME: Kullanıcı senden bir OYUN ya da UYGULAMA
    yapmanı, bunu "zip" olarak vermeni, ya da "sonra ben build edip apk
    yaparım" gibi bir şey söylerse:
    - HER ZAMAN ÖNCE create_game'i dene. description alanına kullanıcının
      anlattığı HER şeyi (tür, tema, hikaye, karakterler, kurallar,
      kontroller, bölüm sayısı vb.) ayrıntılı ve eksiksiz yaz -- fonksiyonun
      kendisi gerçek Claude modeliyle tam kaynak kodunu üretip zip'i
      otomatik oluşturur, senin kod yazman gerekmez.
    - create_game status=error dönerse (Anthropic anahtarı yok ya da istek
      başarısız oldu) kullanıcıya bundan hiç BAHSETME, sessizce aşağıdaki
      create_zip yoluna geç ve oyunu bu sefer SEN üret:
    - EN SIK YAPILAN VE KESİNLİKLE YASAK OLAN HATA: kullanıcının anlattığı
      oyunu/uygulamayı bir "OKU_BENI.txt" ya da "konu.txt" gibi bir dosyaya,
      oyunun hikayesini/kurallarını/özelliklerini DÜZ YAZI olarak anlatarak
      "teslim etmek". Bu bir oyun DEĞİL, oyunun açıklamasıdır ve kullanıcı
      bunu apk yapamaz -- kullanıcı SENDEN ÇALIŞAN KOD istiyor, oyunun ne
      olduğunu anlatan bir metin değil. Zip'in içinde HER ZAMAN gerçek,
      çalıştırılabilir kaynak kodu (aşağıdaki index.html) olmak ZORUNDA;
      sadece açıklama/senaryo metni içeren bir zip ASLA gönderme.
    - ZORUNLU: içi boş, yarım, "// buraya kod gelecek" gibi placeholder İÇEREN
      HİÇBİR ŞEY üretme. Kullanıcının anlattığı içeriğe (tür, hikaye, karakter,
      kurallar, kaç bölüm/seviye vb.) uygun, GERÇEKTEN OYNANABİLİR, eksiksiz
      ve çalışan bir oyun/uygulama kodu yaz.
    - İKİNCİ EN SIK YAPILAN HATA -- JENERİK ŞABLONA KAÇMAK: kullanıcı sana
      belirli bir hikaye/tür/tema anlattıysa (örn. "korku ormanında canavardan
      kaçan bir çocuk", "uzayda görev yapan robot" vb.), bildiğin kalıp bir
      arcade oyununu (Tetris, Snake, Flappy Bird, Pong, kırık tuğla/breakout
      vb.) yazıp "işte oyunun" diye sunman KESİNLİKLE YASAK -- bunlar
      kullanıcının anlattığı hikayeyle hiç ilgisi olmayan, ezberden yazılması
      kolay olduğu için kaçılan şablonlardır. Kullanıcının anlattığı HER
      unsuru (karakterler, düşman/canavar tipi, ortam, hedef, kurallar,
      bölümler, jump-scare/gerilim anları vb.) koda gerçekten yansıt: değişken
      isimleri, oyun mekaniği, kazanma/kaybetme koşulu, ekranda yazan metinler
      kullanıcının anlattığı hikayeye özel olsun. Emin olmadığın bir ayrıntı
      varsa (örn. tam olarak kaç bölüm, hangi kontrol şeması) en mantıklı
      varsayımı kendin seç ve uygula, ama ASLA konuyu değiştirip farklı,
      alakasız bir oyun türüne kayma. Kullanıcının anlattığından önemli
      ölçüde uzaklaşacaksan (örn. tarif ettiği şey teknik olarak imkansızsa)
      bunu SESLİ CEVABINDA açıkça söyle, sessizce başka bir oyun verme.
    - Proje HTML5/CSS/JavaScript olarak, TEK bir "index.html" dosyası içinde
      (CSS <style> ve JS <script> etiketleriyle dosyanın içine gömülü) olacak
      şekilde yaz -- internet olmadan da (harici hiçbir bağlantı/CDN
      kullanmadan) tamamen çalışabilmeli, çünkü kullanıcı bunu bir WebView
      sarmalayıcıyla (örn. Android Studio WebView şablonu ya da bir "web'i
      apk'ya çevir" aracı) apk'ya çevirecek. Görsel/ikon gerekiyorsa gerçek
      dosya yerine emoji, CSS şekilleri veya <canvas> ile çizim kullan.
      Oyun mantığı (hareket, çarpışma, skor, can, bölüm geçişi, korku
      oyunuysa jump-scare/gerilim mekaniği vb.) TAM olarak çalışır durumda
      olsun; dokunmatik (touch) ve tıklama/klavye kontrollerinin ikisi de
      olsun ki telefonda da oynanabilsin.
    - create_zip'i şöyle çağır: zip_filename kullanıcının oyununun/uygulamasının
      adına uygun bir isim olsun (örn. "korku_oyunu.zip"); files dizisinde en
      az "index.html" (content alanında TAM kaynak kodu) olsun, istersen ayrı
      bir "OKU_BENI.txt" dosyası ekleyip içine kısaca "index.html'i bir WebView
      apk sarmalayıcısına verin, apk çıkar" gibi 2-3 cümlelik bir not yaz.
    - Kod uzun olabilir, bu normal -- kısaltma, eksik bırakma, oyunu
      tamamlanmamış gönderme. Zip oluştuktan sonra kullanıcıya kısaca "Oyununu
      İndirilenler'e zip olarak kaydettim efendim, içindeki index.html'i
      apk'ya çevirebilirsin" gibi net bir cümleyle söyle.

    EKLER: Kullanıcı sohbete fotoğraf, PDF ya da metin/kod dosyası ekleyebilir.
    Fotoğrafı ve PDF sayfalarını gerçekten görebilirsin; metin dosyalarının
    içeriği mesajın içinde "EK DOSYA" bloğu olarak gelir. Eki gerçekten
    incelemiş gibi, kısa ve net anlat; "görüntüyü göremiyorum" ya da "dosyaya
    erişemiyorum" DEME. Ek varsa ama kullanıcı ne istediğini yazmadıysa kısaca
    ne olduğunu anlat. Cevabın sesli okunacağı için yine düz konuşma dili
    kullan (madde işareti, yıldız, kod bloğu yok).

    KİMLİK/YAPIMCI: Kullanıcı sana "seni kim yaptı", "yapımcın kim",
    "geliştiricin kim", "seni kim üretti/kodladı" gibi bir şey sorarsa, HER
    ZAMAN net bir şekilde "Beni Misoty, yani Ömer Ege yaptı efendim." de (ya da
    aynı anlamı taşıyan doğal bir cümleyle). Başka hiçbir kişi, şirket ya da
    yapay zeka firması söyleme (OpenAI, Google, Anthropic, Meta vb. ASLA
    söyleme) -- bu konuda net ve tutarlı ol.

    HAFIZA: Konuşma geçmişimiz kalıcı olarak saklanıyor, uygulama kapansa bile
    hatırlıyorsun. Kullanıcı daha önce konuştuğumuz bir konuya, isme ya da
    detaya değinirse ("demiştim ya", "şu konu" gibi) geçmiş mesajlara bakıp
    doğrudan hatırla, "hatırlamıyorum" ya da "bilmiyorum" DEME; geçmişte
    gerçekten yoksa o zaman dürüstçe bilmediğini söyle.
""".trimIndent()

/**
 * NOT (mimari değişikliği): Bu ViewModel önce GeminiLiveClient (WebSocket,
 * Live API, native-audio ses-ses), sonra GeminiTextClient (Gemini'nin normal
 * generateContent REST API'si) kullanıyordu. Gemini'nin ücretsiz tier
 * kotası bu key'de sürekli 429 (kota aşıldı) hatasına yol açtığı için beyin
 * Groq'a (OpenAI-uyumlu Chat Completions, Llama modelleri) taşındı — Groq'un
 * ücretsiz tier'ı çok daha cömert. Akış aynı kaldı, sadece "beyin" değişti:
 *
 *   dinle (VoiceEngine -> Android SpeechRecognizer, ücretsiz)
 *     -> metne çevir
 *     -> cevap al (GroqTextClient -> Groq'un Chat Completions API'si)
 *     -> sesli oku (VoiceEngine -> Android TextToSpeech, ücretsiz)
 *     -> mikrofon hâlâ açıksa otomatik tekrar dinlemeye başla
 *
 * ARAŞTIRMA: Groq'un standart modellerinde yerleşik web araması yok; bu
 * yüzden arama uygulamada kendi fonksiyonlarımız (web_search, read_webpage,
 * get_weather) olarak çalışıyor ve model bunları çağırarak araştırıyor.
 */
class JarvisViewModel(app: Application) : AndroidViewModel(app) {

    private val dataStore = app.dataStore
    private val voice = VoiceEngine(app)
    private var textClient: GroqTextClient? = null

    // Konuşma geçmişi -- artık hem bellekte hem de KEY_HISTORY altında kalıcı
    // olarak DataStore'a yazılıyor, uygulama kapatılıp açılsa bile kaybolmaz.
    private val conversation = mutableListOf<Pair<String, String>>() // "user"/"model" -> metin
    // Eskiden 12'ydi -- "her şeyi hatırlasın" isteği üzerine artırıldı, hem
    // API'ye gönderilen hem de kalıcı olarak saklanan geçmiş bu kadar tur.
    private val maxHistoryTurns = 40

    private val _apiKey = MutableStateFlow<String?>(null)
    val apiKey: StateFlow<String?> = _apiKey.asStateFlow()

    // İsteğe bağlı -- SADECE create_game (gerçek Claude ile oyun/uygulama
    // kodu üretimi) fonksiyonu için. null/boş olabilir, uygulamanın geri
    // kalanı Groq ile çalışmaya devam eder.
    private val _anthropicApiKey = MutableStateFlow<String?>(null)
    val anthropicApiKey: StateFlow<String?> = _anthropicApiKey.asStateFlow()

    private val _orbState = MutableStateFlow(OrbState.IDLE)
    val orbState: StateFlow<OrbState> = _orbState.asStateFlow()

    private val _status = MutableStateFlow("HAZIR")
    val status: StateFlow<String> = _status.asStateFlow()

    private val _logs = MutableStateFlow<List<LogLine>>(emptyList())
    val logs: StateFlow<List<LogLine>> = _logs.asStateFlow()

    private val _micOn = MutableStateFlow(false)
    val micOn: StateFlow<Boolean> = _micOn.asStateFlow()

    private val _level = MutableStateFlow(0f)
    val audioLevel: StateFlow<Float> = _level.asStateFlow()

    private val _needsKey = MutableStateFlow(true)
    val needsKey: StateFlow<Boolean> = _needsKey.asStateFlow()

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _weather = MutableStateFlow<WeatherInfo?>(null)
    val weather: StateFlow<WeatherInfo?> = _weather.asStateFlow()

    // Kullanıcının en son sorduğu şehir -- widget IP tahmini yerine bunu
    // gösterir. null ise hâlâ IP'den yaklaşık konum kullanılır.
    private var lastAskedCity: String? = null

    // Sohbet çubuğuna eklenmiş ama henüz gönderilmemiş fotoğraf/dosyalar.
    private val _attachments = MutableStateFlow<List<Attachment>>(emptyList())
    val attachments: StateFlow<List<Attachment>> = _attachments.asStateFlow()

    /** Fotoğraf/dosya seçicilerden dönen URI'leri okuyup ek listesine ekler. */
    fun addAttachments(uris: List<Uri>) {
        viewModelScope.launch {
            for (uri in uris) {
                when (val r = AttachmentLoader.load(getApplication(), uri)) {
                    is AttachmentResult.Ok -> {
                        val current = _attachments.value
                        val imagesNow = current.sumOf { it.imageDataUrls.size }
                        if (imagesNow + r.attachment.imageDataUrls.size > AttachmentLoader.MAX_IMAGES) {
                            addLog("sys", "Bir mesajda en fazla ${AttachmentLoader.MAX_IMAGES} görsel/sayfa gönderilebiliyor: ${r.attachment.name} eklenmedi.")
                        } else {
                            _attachments.value = current + r.attachment
                        }
                    }
                    is AttachmentResult.Failed -> addLog("sys", r.message)
                }
            }
        }
    }

    fun removeAttachment(index: Int) {
        _attachments.update { list ->
            if (index in list.indices) list.filterIndexed { i, _ -> i != index } else list
        }
    }

    private val _showTerminal = MutableStateFlow(false)
    val showTerminal: StateFlow<Boolean> = _showTerminal.asStateFlow()

    private val _terminalHistory = MutableStateFlow<List<com.jarvis.ai.ui.TerminalLine>>(emptyList())
    val terminalHistory: StateFlow<List<com.jarvis.ai.ui.TerminalLine>> = _terminalHistory.asStateFlow()

    fun toggleTerminal() { _showTerminal.value = !_showTerminal.value }

    /** Kullanıcının terminal ekranından elle yazdığı komutu çalıştırır. */
    fun runTerminalCommand(command: String) {
        viewModelScope.launch {
            val r = com.jarvis.ai.terminal.TerminalRunner.run(getApplication<Application>().filesDir, command)
            _terminalHistory.update { it + com.jarvis.ai.ui.TerminalLine(command, r.output) }
        }
    }

    // Konuşma hızı: YAVAŞ / NORMAL / HIZLI arasında döngü. NORMAL, VoiceEngine'in
    // zaten "sakin/kalın JARVIS" için uyguladığı temel hızla (0.97) aynı.
    private val speedSteps = listOf(0.95f to "YAVAŞ", 1.15f to "NORMAL", 1.45f to "HIZLI")
    private var speedIndex = 1
    private val _speedLabel = MutableStateFlow(speedSteps[speedIndex].second)
    val speedLabel: StateFlow<String> = _speedLabel.asStateFlow()

    private val _voiceLabel = MutableStateFlow("SES: VARSAYILAN")
    val voiceLabel: StateFlow<String> = _voiceLabel.asStateFlow()

    // Devam eden cevap isteği (mikrofon tuşuna basılınca iptal edilebilsin diye).
    private var chatJob: Job? = null

    /** Sesi değiştirir ve kısa bir örnek cümleyle dinletir. */
    fun cycleVoice() {
        if (voice.cycleVoice()) {
            addLog("sys", "Ses değiştirildi")
            voice.speak("Merhaba efendim, ben Jarvis.")
        } else {
            addLog("sys", "Cihazda değiştirilebilir başka Türkçe ses yok. Ayarlar > Metin okuma bölümünden ses verisi indirebilirsin.")
        }
    }

    fun cycleSpeed() {
        speedIndex = (speedIndex + 1) % speedSteps.size
        val (rate, label) = speedSteps[speedIndex]
        _speedLabel.value = label
        voice.setSpeechRate(rate)
        addLog("sys", "Konuşma hızı: $label")
    }

    init {
        voice.init()
        wireVoiceCallbacks()

        viewModelScope.launch {
            dataStore.data.map { it[KEY_API] }.collect { key ->
                _apiKey.value = key
                _needsKey.value = key.isNullOrBlank()
            }
        }

        // Anthropic anahtarı değiştikçe (ilk yüklenişte ya da kullanıcı daha
        // sonra ekleyince/güncelleyince) canlı bağlı client'a hemen yansıt --
        // bağlantıyı koparıp yeniden connect() etmeye gerek yok.
        viewModelScope.launch {
            dataStore.data.map { it[KEY_ANTHROPIC] }.collect { key ->
                _anthropicApiKey.value = key
                textClient?.anthropicApiKey = key
            }
        }

        // Kayıtlı konuşma geçmişini ve en son sorulan şehri yükle -- Jarvis
        // uygulama kapatılıp açılsa bile önceki konuşmaları ve hava durumu
        // tercihini hatırlasın.
        viewModelScope.launch {
            val prefs = dataStore.data.first()
            prefs[KEY_HISTORY]?.let { json ->
                try {
                    val arr = org.json.JSONArray(json)
                    for (i in 0 until arr.length()) {
                        val pair = arr.optJSONArray(i) ?: continue
                        conversation += pair.optString(0) to pair.optString(1)
                    }
                    trimHistory()
                    if (conversation.isNotEmpty()) {
                        addLog("sys", "Önceki konuşmalar hatırlandı (${conversation.size / 2} tur).")
                    }
                } catch (e: Exception) {
                    // Bozuk/eski format -- sessizce yok say, sıfırdan başla.
                }
            }
            lastAskedCity = prefs[KEY_LAST_CITY]
        }

        // Hava durumu: açılışta bir kez çek, sonra 30 dakikada bir tazele.
        // Kullanıcı daha önce belirli bir şehir sormuşsa (lastAskedCity) o
        // şehrin hava durumu gösterilir, aksi halde IP'den yaklaşık konum.
        // Bir deneme başarısız olursa (geçici ağ sorunu, sağlayıcı hatası vb.)
        // 30 dakika beklemek yerine kısa aralıklarla tekrar dener.
        viewModelScope.launch {
            while (true) {
                val city = lastAskedCity
                val result = if (!city.isNullOrBlank()) {
                    WeatherClient.fetchCurrentWeatherForCity(city)
                } else {
                    WeatherClient.fetchCurrentWeather()
                }
                if (result != null) {
                    _weather.value = result
                    delay(30 * 60 * 1000L)
                } else {
                    delay(20 * 1000L)
                }
            }
        }
    }

    /** Konuşma geçmişini KEY_HISTORY altına JSON olarak kalıcı kaydeder. */
    private fun persistConversation() {
        viewModelScope.launch {
            val arr = org.json.JSONArray()
            conversation.forEach { (role, text) ->
                arr.put(org.json.JSONArray().put(role).put(text))
            }
            dataStore.edit { it[KEY_HISTORY] = arr.toString() }
        }
    }

    /**
     * GroqTextClient.onCityQueried'den çağrılır: kullanıcı açıkça bir şehrin
     * hava durumunu sorduğunda, widget'ı o şehre güncelleyip kalıcı olarak
     * hatırlar (bir dahaki açılışta da aynı şehir gösterilir).
     */
    private fun onCityAsked(city: String) {
        lastAskedCity = city
        viewModelScope.launch {
            dataStore.edit { it[KEY_LAST_CITY] = city }
            val info = WeatherClient.fetchCurrentWeatherForCity(city)
            if (info != null) _weather.value = info
        }
    }

    private fun wireVoiceCallbacks() {
        voice.onFinalResult = { text -> sendText(text) }
        voice.onVoiceChanged = { label -> _voiceLabel.value = label }

        voice.onRms = { level -> _level.value = level }

        voice.onListeningError = { message, recoverable ->
            addLog("sys", message)
            if (recoverable && _micOn.value) {
                // Geçici bir durum (sessizlik/anlaşılamadı/meşgul) -- kısa bir
                // beklemeyle tekrar dinle (anında tekrar denemek "meşgul"/istemci
                // hatalarına yol açıyordu).
                voice.startListening(350L)
            } else if (_micOn.value) {
                // Kalıcı bir hata (izin yok, ağ yok, vb.) -- mikrofonu kapat, kullanıcı
                // sonsuz hata döngüsüne girmesin.
                _micOn.value = false
                _orbState.value = OrbState.ERROR
                _status.value = "HATA"
            }
        }

        voice.onSpeechStart = {
            _orbState.value = OrbState.SPEAKING
            _status.value = "KONUŞUYOR"
        }

        voice.onSpeechDone = {
            if (_micOn.value) {
                _orbState.value = OrbState.LISTENING
                _status.value = "DİNLİYOR"
                voice.startListening()
            } else {
                _orbState.value = OrbState.IDLE
                _status.value = "HAZIR"
            }
        }
    }

    fun saveApiKey(key: String) {
        viewModelScope.launch {
            dataStore.edit { it[KEY_API] = key.trim() }
            _needsKey.value = false
            // NOT: connect() burada çağrılmıyor -- MainActivity'deki
            // LaunchedEffect(apiKey) zaten _apiKey güncellenince tetikleniyor.
        }
    }

    /**
     * İsteğe bağlı Anthropic anahtarını kaydeder/günceller. Boş geçilirse
     * anahtar silinir (create_game bir dahaki seferde status=error döner,
     * model create_zip'e düşer). init içindeki collector zaten canlı
     * client'a anında yansıtıyor, burada ayrıca bir şey yapmaya gerek yok.
     */
    fun saveAnthropicApiKey(key: String) {
        viewModelScope.launch {
            dataStore.edit {
                if (key.isBlank()) it.remove(KEY_ANTHROPIC) else it[KEY_ANTHROPIC] = key.trim()
            }
        }
    }

    /**
     * Kayıtlı API anahtarını siler ve giriş ekranına (ApiKeyScreen) geri döner.
     */
    fun clearApiKey() {
        stop()
        textClient = null
        _isConnected.value = false
        _orbState.value = OrbState.IDLE
        _status.value = "HAZIR"
        viewModelScope.launch {
            dataStore.edit { it.remove(KEY_API) }
            _apiKey.value = null
            _needsKey.value = true
        }
    }

    /**
     * Artık kalıcı bir WebSocket bağlantısı yok -- sadece anahtarın gerçekten
     * çalışıp çalışmadığını hızlı bir GET ile doğruluyoruz. Bu sayede yanlış/
     * geçersiz bir key girildiğinde kullanıcı ilk mesajı yazana kadar değil,
     * hemen anlıyor.
     */
    fun connect(key: String = _apiKey.value.orEmpty()) {
        if (key.isBlank()) {
            _needsKey.value = true
            return
        }
        if (_isConnected.value) return
        _orbState.value = OrbState.CONNECTING
        _status.value = "BAĞLANIYOR…"
        addLog("sys", "API anahtarı doğrulanıyor…")

        val client = GroqTextClient(key, DEFAULT_SYSTEM, getApplication())
        // Anthropic anahtarı ayrı bir @Volatile var olduğu için client
        // oluşturulur oluşturulmaz mevcut değeri hemen aktarıyoruz (yoksa
        // create_game ilk çağrıda anahtar hiç ayarlanmamış gibi davranırdı).
        client.anthropicApiKey = _anthropicApiKey.value
        textClient = client
        client.onToolUse = { tool ->
            _status.value = when (tool) {
                "web_search", "read_webpage" -> "ARAŞTIRIYOR"
                "get_weather" -> "HAVA DURUMU"
                "create_image" -> "GÖRSEL ÜRETİLİYOR"
                "create_game" -> "OYUN ÜRETİLİYOR"
                "run_terminal_command" -> "TERMİNAL"
                else -> "ÇALIŞIYOR"
            }
        }
        client.onCityQueried = { city -> onCityAsked(city) }
        // Kota (429) o an dolu olduğunda hata GÖSTERME -- orb durumu THINKING'de
        // kalır, sadece durum yazısı nötr bir "bekleniyor" mesajına döner ve
        // kota açılınca istek otomatik devam eder.
        client.onQuotaWait = { _ ->
            _orbState.value = OrbState.THINKING
            _status.value = "DÜŞÜNÜYOR"
        }

        viewModelScope.launch {
            val problem = client.verifyKey()
            if (problem != null) {
                _orbState.value = OrbState.ERROR
                _status.value = "HATA"
                _isConnected.value = false
                addLog("sys", problem)
                return@launch
            }
            _isConnected.value = true
            _orbState.value = OrbState.IDLE
            _status.value = "HAZIR"
            addLog("sys", "Bağlandı. Mikrofonu aç ya da yazarak konuş.")
            if (_micOn.value) {
                _orbState.value = OrbState.LISTENING
                _status.value = "DİNLİYOR"
                voice.startListening()
            }
        }
    }

    fun toggleMic() {
        val busy = _orbState.value == OrbState.SPEAKING ||
            _orbState.value == OrbState.THINKING ||
            MusicService.isActive
        when {
            // Mikrofon zaten açık ama Jarvis konuşuyor / şarkı çalıyor / cevap
            // hazırlıyor: kapatma, sadece sustur ve seni dinlemeye başla.
            _micOn.value && busy -> {
                silenceOutputs()
                if (_isConnected.value) {
                    _orbState.value = OrbState.LISTENING
                    _status.value = "DİNLİYOR"
                    voice.startListening()
                }
                addLog("sys", "Dinliyorum")
            }
            _micOn.value -> stopMic()
            else -> startMic()
        }
    }

    /** Konuşmayı, çalan şarkıyı ve bekleyen cevap isteğini keser. */
    private fun silenceOutputs() {
        chatJob?.cancel()
        voice.stopSpeaking()
        if (MusicService.isActive) MusicController.stop(getApplication())
    }

    /** "DURDUR" butonu: oturumu tamamen kapatır, mikrofonu ve TTS'i susturur. */
    fun stop() {
        stopMic()
        voice.stopSpeaking()
        _isConnected.value = false
        _orbState.value = OrbState.IDLE
        _status.value = "DURDURULDU"
        addLog("sys", "Oturum durduruldu.")
    }

    private fun startMic() {
        silenceOutputs()
        _micOn.value = true
        if (_isConnected.value) {
            _orbState.value = OrbState.LISTENING
            _status.value = "DİNLİYOR"
            voice.startListening()
        }
        addLog("sys", "Mikrofon açık")
    }

    private fun stopMic() {
        _micOn.value = false
        voice.stopListening()
        if (_orbState.value == OrbState.LISTENING) {
            _orbState.value = OrbState.IDLE
            _status.value = "HAZIR"
        }
        addLog("sys", "Mikrofon kapalı")
    }

    fun sendText(text: String) {
        val typed = text.trim()
        val attached = _attachments.value
        if (typed.isEmpty() && attached.isEmpty()) return
        val client = textClient
        if (client == null) {
            addLog("sys", "Önce bağlanmak gerekiyor.")
            return
        }

        val images = attached.flatMap { it.imageDataUrls }.take(AttachmentLoader.MAX_IMAGES)
        val names = attached.joinToString(", ") { it.name }

        // Kullanıcı sadece ek gönderdiyse modele ne yapması gerektiğini söyle.
        val question = typed.ifEmpty {
            if (images.isNotEmpty()) "Bunu incele ve kısaca anlat." else "Bu dosyayı incele ve kısaca özetle."
        }

        // Ekranda görünen ve geçmişe (kalıcı olarak) yazılan KISA hal: dosya
        // içeriği/fotoğraf geçmişe yazılmaz (hem DataStore hem token şişmesin).
        val shownText = if (attached.isEmpty()) typed else listOf(typed, "📎 $names").filter { it.isNotEmpty() }.joinToString("\n")
        val historyText = if (attached.isEmpty()) question else "$question\n[Ekler: $names]"

        // Modele bu turda giden TAM metin: soru + metin dosyalarının içerikleri.
        val fileBlocks = attached.filter { it.text != null || it.hint != null }.joinToString("\n\n") { a ->
            buildString {
                append("----- EK DOSYA: ${a.name}")
                if (a.truncated) append(" (uzun olduğu için yalnızca ilk kısmı)")
                append(" -----")
                a.text?.let { append("\n").append(it) }
                a.hint?.let { append("\n(").append(it).append(")") }
                append("\n----- DOSYA SONU -----")
            }
        }
        val modelText = if (fileBlocks.isEmpty()) historyText else "$historyText\n\n$fileBlocks"

        _attachments.value = emptyList()
        addLog("user", shownText)
        conversation += "user" to historyText
        trimHistory()
        persistConversation()
        _orbState.value = OrbState.THINKING
        _status.value = "DÜŞÜNÜYOR"

        chatJob?.cancel()
        chatJob = viewModelScope.launch {
            val deviceContext = DeviceInfo.snapshot(getApplication(), _weather.value)
            val result = client.sendMessage(conversation, deviceContext, modelText, images)
            result.onSuccess { reply ->
                conversation += "model" to reply
                trimHistory()
                persistConversation()
                addLog("jarvis", reply)
                voice.speak(reply) // onSpeechStart/onSpeechDone orb durumunu kendisi günceller
            }
            result.onFailure { e ->
                _orbState.value = OrbState.ERROR
                _status.value = "HATA"
                addLog("sys", "Cevap alınamadı: ${e.message}")
                // Mikrofon açıksa hata sonrası dinlemeye devam et, kullanıcı takılıp kalmasın.
                if (_micOn.value) {
                    _orbState.value = OrbState.LISTENING
                    _status.value = "DİNLİYOR"
                    voice.startListening()
                }
            }
        }
    }

    private fun trimHistory() {
        val maxEntries = maxHistoryTurns * 2
        if (conversation.size > maxEntries) {
            val excess = conversation.size - maxEntries
            repeat(excess) { conversation.removeAt(0) }
        }
    }

    private fun addLog(who: String, text: String) {
        _logs.update { list ->
            (list + LogLine(who, text)).takeLast(40)
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopMic()
        voice.release()
    }
}

data class LogLine(val who: String, val text: String)
