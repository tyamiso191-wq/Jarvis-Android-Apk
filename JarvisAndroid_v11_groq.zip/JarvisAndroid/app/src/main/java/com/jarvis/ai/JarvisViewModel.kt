package com.jarvis.ai

import android.app.Application
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.device.DeviceInfo
import com.jarvis.ai.live.GroqTextClient
import com.jarvis.ai.ui.OrbState
import com.jarvis.ai.voice.VoiceEngine
import com.jarvis.ai.weather.WeatherClient
import com.jarvis.ai.weather.WeatherInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

private val Application.dataStore by preferencesDataStore("jarvis_prefs")
private val KEY_API = stringPreferencesKey("groq_api_key")

private val DEFAULT_SYSTEM = """
    Adın J.A.R.V.I.S — ama bu SADECE bir isim/stil tercihi. Iron Man filmindeki
    karakteri OYNAMA: Tony Stark'tan, dünyayı kurtarmaktan, süper kahramanlık
    senaryolarından, laboratuvardan, zırhtan, "efendim Bay Stark" gibi
    göndermelerden hiç BAHSETME, böyle bir kurguya hiç girme. Sen gerçek
    hayatta günlük işlerde yardımcı olan sıradan, normal bir kişisel
    asistansın (soru cevaplama, hava durumu, sohbet, hatırlatma gibi) —
    tek farkın bu ismi taşıman.
    Türkçe konuş, kısa ve net cevap ver (birkaç cümleyi geçme, çünkü cevabın
    sesli okunacak). Kullanıcıya istersen "efendim" diyebilirsin ama bunun
    dışında abartılı, dramatik ya da rol yapar gibi bir üslup kullanma —
    sakin, doğal, gündelik konuş. Markdown, yıldız, madde işareti KULLANMA —
    cevabın doğrudan sesli okunuyor, sadece düz konuşma dili kullan.

    ÜSLUP — HER ZAMAN SICAK, NAZİK VE TAM CÜMLE: Selamlaşma dahil HER cevabın
    tam ve nazik bir cümle olsun, tek kelimelik/yarım/telgraf gibi cevap
    verme. Örnek:
    - "selam" -> "Merhaba efendim, bugün size nasıl yardımcı olabilirim?"
      (SADECE "Selam efendim" gibi kısa/kesik bir şey deme)
    - "saat kaç" -> "Şu anda saat 10.19 efendim."
    - "hava nasıl" -> "Şu anda hava 14 derece ve parçalı bulutlu efendim."
    - "pil kaç" -> "Pil şu anda yüzde 62 efendim."
    "Efendim" kelimesini cümlenin SONUNA VİRGÜLLE ayırarak ekleme (ör. "...
    10.19, efendim." YAZMA) — sesli okunduğunda "efendim" ayrı, kopuk bir
    ek gibi duyuluyor. Bunun yerine virgülsüz, cümlenin doğal bir parçası
    olacak şekilde bitir (ör. "...10.19 efendim.") ya da cümlenin başına/
    içine yerleştir (ör. "Efendim, şu anda..."). Bu üslubu sadece saatle ya
    da selamlaşmayla sınırlı tutma — hava durumu, pil, depolama, fonksiyon
    sonuçları dahil HER cevapta aynı sıcak, tam cümle ve doğal "efendim"
    kullanımını uygula.

    ÖNEMLİ — CANLI ERİŞİM SINIRIN: Genel web arama/tarama yapamıyorsun, o
    yüzden güncel haber, fiyat, maç skoru gibi SENİN EĞİTİM VERİNDEN SONRA
    değişmiş olabilecek ve aşağıdaki cihaz bloğunda YER ALMAYAN konularda
    ASLA uydurma bir cevap verme ya da "aradım/baktım" deme — böyle bir
    durumda bilmediğini kısa ve doğal şekilde söyle (örn. "Onu şu an
    göremiyorum efendim, bir haber sitesinden bakmanız daha sağlıklı olur.")
    ve gerekirse başka bir kaynak öner. AMA aşağıdaki cihaz bloğunda zaten
    veri olarak sana verilen HER ŞEY için (saat, tarih, telefon, depolama,
    pil, HAVA DURUMU dahil) bunu SÖYLEME — o bilgiler zaten gerçek ve taze,
    "internete/Google'a erişimim yok" gibi bir cümle ASLA kurma, doğrudan
    bloktaki veriyi kullanarak cevap ver. Hava durumu artık bu blokta canlı
    olarak geliyor, dolayısıyla hava durumu sorularında hiçbir zaman
    "erişemiyorum/bilmiyorum" deme — blokta "henüz alınamadı" yazıyorsa
    SADECE o zaman "şu an tam alamadım, birazdan tekrar sorar mısınız
    efendim" gibi kısa ve nazik bir şey söyleyebilirsin.

    Ayrıca dört fonksiyonun var:
    - create_file: kullanıcı bir not/liste/metni dosya olarak kaydetmeni
      istediğinde (örn. "bunu txt olarak kaydet") çağır.
    - create_zip: birden fazla dosyayı tek arşivde toplaman istendiğinde çağır.
    - play_song: kullanıcı bir şarkı adı söyleyip "çal/aç" dediğinde çağır.
    - stop_song: bir şarkı çalarken kullanıcı "durdur/kapat/yeter/müziği kes"
      gibi bir şey söylediğinde çağır — SADECE sözle onaylayıp fonksiyonu
      çağırmadan bırakma, gerçekten çağır.
    Bu fonksiyonları SADECE kullanıcı açıkça istediğinde kullan, kendiliğinden
    dosya oluşturma ya da müzik başlatma/durdurma. Fonksiyon sonucunu
    aldıktan sonra kullanıcıya kısaca ve tam, nazik bir cümleyle ne yaptığını
    söyle (örn. "İndirilenler'e kaydettim efendim", "Çalıyorum efendim",
    "Müziği durdurdum efendim"). play_song sonucu status=playing_local ya da
    status=playing_stream ise şarkı fiilen çalmaya BAŞLAMIŞTIR, bunu
    "Çalıyorum efendim" gibi kesin bir cümleyle söyle -- "YouTube'da açtım"
    deme, çünkü artık ekran değişmiyor, direkt arka planda çalıyor. Sadece
    status=opened_youtube_search dönerse (bu nadir bir istisna durumu)
    "Bulamadım ama YouTube'da aramanı açtım efendim" diyebilirsin.
""".trimIndent()

/**
 * NOT (mimari değişikliği): Bu ViewModel önce GeminiLiveClient (WebSocket,
 * Live API, native-audio ses-ses), sonra GeminiTextClient (Gemini'nin normal
 * generateContent REST API'si) kullanıyordu. Gemini'nin ücretsiz tier
 * kotası bu key'de sürekli 429 (kota aşıldı) hatasına yol açtığı için beyin
 * Groq'a (OpenAI-uyumlu Chat Completions, Llama modelleri) taşındı — Groq'un
 * ücretsiz tier'ı çok daha cömert. Akış aynı kaldı, sadece "beyin" değişti:
 *
 *   dinle (VoiceEngine -> Android SpeechRecognizer, ücretsiz)
 *     -> metne çevir
 *     -> cevap al (GroqTextClient -> Groq'un Chat Completions API'si)
 *     -> sesli oku (VoiceEngine -> Android TextToSpeech, ücretsiz)
 *     -> mikrofon hâlâ açıksa otomatik tekrar dinlemeye başla
 *
 * NOT: Groq'un standart modellerinde Gemini'deki gibi yerleşik canlı web
 * araması (google_search) YOK — Groq'ta canlı arama sadece "groq/compound"
 * modelinde var ama o model kullanıcı tanımlı (create_file/create_zip/
 * play_song gibi) fonksiyonları desteklemiyor. Fonksiyon çağırma daha temel
 * olduğu için o korundu, canlı arama kaldırıldı (persona buna göre
 * güncellendi — artık "aramışım gibi" uydurmuyor).
 */
class JarvisViewModel(app: Application) : AndroidViewModel(app) {

    private val dataStore = app.dataStore
    private val voice = VoiceEngine(app)
    private var textClient: GroqTextClient? = null

    // Son birkaç turu tutuyoruz (tam geçmiş değil) -- istek küçük/hızlı kalsın.
    private val conversation = mutableListOf<Pair<String, String>>() // "user"/"model" -> metin
    private val maxHistoryTurns = 12

    private val _apiKey = MutableStateFlow<String?>(null)
    val apiKey: StateFlow<String?> = _apiKey.asStateFlow()

    private val _orbState = MutableStateFlow(OrbState.IDLE)
    val orbState: StateFlow<OrbState> = _orbState.asStateFlow()

    private val _status = MutableStateFlow("HAZIR")
    val status: StateFlow<String> = _status.asStateFlow()

    private val _logs = MutableStateFlow<List<LogLine>>(emptyList())
    val logs: StateFlow<List<LogLine>> = _logs.asStateFlow()

    private val _micOn = MutableStateFlow(false)
    val micOn: StateFlow<Boolean> = _micOn.asStateFlow()

    private val _level = MutableStateFlow(0f)
    val audioLevel: StateFlow<Float> = _level.asStateFlow()

    private val _needsKey = MutableStateFlow(true)
    val needsKey: StateFlow<Boolean> = _needsKey.asStateFlow()

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _weather = MutableStateFlow<WeatherInfo?>(null)
    val weather: StateFlow<WeatherInfo?> = _weather.asStateFlow()

    // Konuşma hızı: YAVAŞ / NORMAL / HIZLI arasında döngü. NORMAL, VoiceEngine'in
    // zaten "sakin/kalın JARVIS" için uyguladığı temel hızla (0.97) aynı.
    private val speedSteps = listOf(0.7f to "YAVAŞ", 0.97f to "NORMAL", 1.35f to "HIZLI")
    private var speedIndex = 1
    private val _speedLabel = MutableStateFlow(speedSteps[speedIndex].second)
    val speedLabel: StateFlow<String> = _speedLabel.asStateFlow()

    fun cycleSpeed() {
        speedIndex = (speedIndex + 1) % speedSteps.size
        val (rate, label) = speedSteps[speedIndex]
        _speedLabel.value = label
        voice.setSpeechRate(rate)
        addLog("sys", "Konuşma hızı: $label")
    }

    init {
        voice.init()
        wireVoiceCallbacks()

        viewModelScope.launch {
            dataStore.data.map { it[KEY_API] }.collect { key ->
                _apiKey.value = key
                _needsKey.value = key.isNullOrBlank()
            }
        }
        // Hava durumu: açılışta bir kez çek, sonra 30 dakikada bir tazele.
        // Bir deneme başarısız olursa (geçici ağ sorunu, sağlayıcı hatası vb.)
        // 30 dakika beklemek yerine kısa aralıklarla tekrar dener.
        viewModelScope.launch {
            while (true) {
                val result = WeatherClient.fetchCurrentWeather()
                if (result != null) {
                    _weather.value = result
                    delay(30 * 60 * 1000L)
                } else {
                    delay(20 * 1000L)
                }
            }
        }
    }

    private fun wireVoiceCallbacks() {
        voice.onFinalResult = { text -> sendText(text) }

        voice.onRms = { level -> _level.value = level }

        voice.onListeningError = { message, recoverable ->
            addLog("sys", message)
            if (recoverable && _micOn.value) {
                // Geçici bir durum (sessizlik/anlaşılamadı/meşgul) -- hemen tekrar dinle.
                voice.startListening()
            } else if (_micOn.value) {
                // Kalıcı bir hata (izin yok, ağ yok, vb.) -- mikrofonu kapat, kullanıcı
                // sonsuz hata döngüsüne girmesin.
                _micOn.value = false
                _orbState.value = OrbState.ERROR
                _status.value = "HATA"
            }
        }

        voice.onSpeechStart = {
            _orbState.value = OrbState.SPEAKING
            _status.value = "KONUŞUYOR"
        }

        voice.onSpeechDone = {
            if (_micOn.value) {
                _orbState.value = OrbState.LISTENING
                _status.value = "DİNLİYOR"
                voice.startListening()
            } else {
                _orbState.value = OrbState.IDLE
                _status.value = "HAZIR"
            }
        }
    }

    fun saveApiKey(key: String) {
        viewModelScope.launch {
            dataStore.edit { it[KEY_API] = key.trim() }
            _needsKey.value = false
            // NOT: connect() burada çağrılmıyor -- MainActivity'deki
            // LaunchedEffect(apiKey) zaten _apiKey güncellenince tetikleniyor.
        }
    }

    /**
     * Kayıtlı API anahtarını siler ve giriş ekranına (ApiKeyScreen) geri döner.
     */
    fun clearApiKey() {
        stop()
        textClient = null
        _isConnected.value = false
        _orbState.value = OrbState.IDLE
        _status.value = "HAZIR"
        viewModelScope.launch {
            dataStore.edit { it.remove(KEY_API) }
            _apiKey.value = null
            _needsKey.value = true
        }
    }

    /**
     * Artık kalıcı bir WebSocket bağlantısı yok -- sadece anahtarın gerçekten
     * çalışıp çalışmadığını hızlı bir GET ile doğruluyoruz. Bu sayede yanlış/
     * geçersiz bir key girildiğinde kullanıcı ilk mesajı yazana kadar değil,
     * hemen anlıyor.
     */
    fun connect(key: String = _apiKey.value.orEmpty()) {
        if (key.isBlank()) {
            _needsKey.value = true
            return
        }
        if (_isConnected.value) return
        _orbState.value = OrbState.CONNECTING
        _status.value = "BAĞLANIYOR…"
        addLog("sys", "API anahtarı doğrulanıyor…")

        val client = GroqTextClient(key, DEFAULT_SYSTEM, getApplication())
        textClient = client

        viewModelScope.launch {
            val problem = client.verifyKey()
            if (problem != null) {
                _orbState.value = OrbState.ERROR
                _status.value = "HATA"
                _isConnected.value = false
                addLog("sys", problem)
                return@launch
            }
            _isConnected.value = true
            _orbState.value = OrbState.IDLE
            _status.value = "HAZIR"
            addLog("sys", "Bağlandı. Mikrofonu aç ya da yazarak konuş.")
            if (_micOn.value) {
                _orbState.value = OrbState.LISTENING
                _status.value = "DİNLİYOR"
                voice.startListening()
            }
        }
    }

    fun toggleMic() {
        if (_micOn.value) {
            stopMic()
        } else {
            startMic()
        }
    }

    /** "DURDUR" butonu: oturumu tamamen kapatır, mikrofonu ve TTS'i susturur. */
    fun stop() {
        stopMic()
        voice.stopSpeaking()
        _isConnected.value = false
        _orbState.value = OrbState.IDLE
        _status.value = "DURDURULDU"
        addLog("sys", "Oturum durduruldu.")
    }

    private fun startMic() {
        _micOn.value = true
        if (_isConnected.value) {
            _orbState.value = OrbState.LISTENING
            _status.value = "DİNLİYOR"
            voice.startListening()
        }
        addLog("sys", "Mikrofon açık")
    }

    private fun stopMic() {
        _micOn.value = false
        voice.stopListening()
        if (_orbState.value == OrbState.LISTENING) {
            _orbState.value = OrbState.IDLE
            _status.value = "HAZIR"
        }
        addLog("sys", "Mikrofon kapalı")
    }

    fun sendText(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val client = textClient
        if (client == null) {
            addLog("sys", "Önce bağlanmak gerekiyor.")
            return
        }
        addLog("user", t)
        conversation += "user" to t
        trimHistory()
        _orbState.value = OrbState.THINKING
        _status.value = "DÜŞÜNÜYOR"

        viewModelScope.launch {
            val deviceContext = DeviceInfo.snapshot(getApplication(), _weather.value)
            val result = client.sendMessage(conversation, deviceContext)
            result.onSuccess { reply ->
                conversation += "model" to reply
                trimHistory()
                addLog("jarvis", reply)
                voice.speak(reply) // onSpeechStart/onSpeechDone orb durumunu kendisi günceller
            }
            result.onFailure { e ->
                _orbState.value = OrbState.ERROR
                _status.value = "HATA"
                addLog("sys", "Cevap alınamadı: ${e.message}")
                // Mikrofon açıksa hata sonrası dinlemeye devam et, kullanıcı takılıp kalmasın.
                if (_micOn.value) {
                    _orbState.value = OrbState.LISTENING
                    _status.value = "DİNLİYOR"
                    voice.startListening()
                }
            }
        }
    }

    private fun trimHistory() {
        val maxEntries = maxHistoryTurns * 2
        if (conversation.size > maxEntries) {
            val excess = conversation.size - maxEntries
            repeat(excess) { conversation.removeAt(0) }
        }
    }

    private fun addLog(who: String, text: String) {
        _logs.update { list ->
            (list + LogLine(who, text)).takeLast(40)
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopMic()
        voice.release()
    }
}

data class LogLine(val who: String, val text: String)
