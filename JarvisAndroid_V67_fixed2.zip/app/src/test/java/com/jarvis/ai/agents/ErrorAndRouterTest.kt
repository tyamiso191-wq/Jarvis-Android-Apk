package com.jarvis.ai.agents

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ErrorAndRouterTest {

    // ---- Hata sınıflandırma: kota türleri BİRBİRİNE KARIŞMAZ ----

    @Test fun classifies402AsCredits() {
        val e = ErrorClassifier.classifyHttp(402, """{"error":{"code":402,"message":"Insufficient credits"}}""", null, mkModel("a/b"))
        assertEquals(ErrorKind.CREDITS, e.kind)
    }

    @Test fun classifies402WithRetryAfterAsInflightBudget() {
        val e = ErrorClassifier.classifyHttp(402, """{"error":{"code":402,"message":"in-flight budget exhausted"}}""", 5000, mkModel("a/b"))
        assertEquals(ErrorKind.INFLIGHT_BUDGET, e.kind)
        assertEquals(5000L, e.retryAfterMs)
    }

    @Test fun classifies429OnPaidModelAsModelRateLimit() {
        val e = ErrorClassifier.classifyHttp(429, """{"error":{"code":429,"message":"Rate limit exceeded"}}""", 2000, mkModel("a/b"))
        assertEquals(ErrorKind.RATE_LIMIT_MODEL, e.kind)
    }

    @Test fun classifies429OnFreeModelAsAccountLimit() {
        val e = ErrorClassifier.classifyHttp(
            429, """{"error":{"code":429,"message":"Rate limit exceeded: free-models-per-day"}}""", null, mkModel("a/b:free", free = true)
        )
        assertEquals(ErrorKind.RATE_LIMIT_ACCOUNT, e.kind)
        assertTrue(e.daily)
    }

    @Test fun classifiesContextOverflowSeparately() {
        val e = ErrorClassifier.classifyHttp(
            400, """{"error":{"code":400,"message":"This model's maximum context length is 8192 tokens"}}""", null, mkModel("a/b")
        )
        assertEquals(ErrorKind.CONTEXT_TOO_LONG, e.kind)
    }

    @Test fun classifiesServerAndAuthErrors() {
        assertEquals(ErrorKind.TRANSIENT_SERVER, ErrorClassifier.classifyHttp(503, "{}", null, null).kind)
        assertEquals(ErrorKind.AUTH, ErrorClassifier.classifyHttp(401, "{}", null, null).kind)
        assertEquals(ErrorKind.MODEL_UNAVAILABLE, ErrorClassifier.classifyHttp(404, "{}", null, null).kind)
        assertEquals(ErrorKind.NETWORK, ErrorClassifier.classifyThrowable(java.io.IOException("x"), "m").kind)
        assertEquals(ErrorKind.TIMEOUT, ErrorClassifier.classifyThrowable(java.net.SocketTimeoutException("t"), "m").kind)
    }

    @Test fun redactsApiKeysFromMessages() {
        val e = ErrorClassifier.classifyHttp(400, """{"error":{"message":"bad key sk-or-v1-abcdef1234567890"}}""", null, null)
        assertFalse(e.message!!.contains("abcdef1234567890"))
    }

    // ---- Görev analizi: basit sohbet çoklu ajana GİTMEZ ----

    @Test fun simpleChatStaysSingleModel() {
        val p = TaskAnalyzer.analyze("merhaba nasılsın")
        assertEquals(TaskType.CHAT, p.type)
        assertFalse(TaskAnalyzer.shouldUseMultiAgent(p, AgentSettings()))
    }

    @Test fun bigProjectUsesMultiAgentButDeviceActionDoesNot() {
        val big = TaskAnalyzer.analyze(
            "Sıfırdan baştan sona bir android uygulaması geliştirmek istiyorum. Kotlin ile mimari tasarla, kod yaz, " +
                "api entegrasyonunu araştır, test senaryoları hazırla ve güvenlik risklerini değerlendir. Detaylı olsun."
        )
        assertEquals(Complexity.HIGH, big.complexity)
        assertTrue(TaskAnalyzer.shouldUseMultiAgent(big, AgentSettings()))
        assertFalse(TaskAnalyzer.shouldUseMultiAgent(big, AgentSettings(multiAgentEnabled = false)))
        val device = TaskAnalyzer.analyze("müzik aç ve alarm kur")
        assertFalse(TaskAnalyzer.shouldUseMultiAgent(device, AgentSettings()))
    }

    // ---- Model seçimi görev türüne göre değişir (katalog verisinden, sabit ad YOK) ----

    @Test fun routerPicksDifferentModelsPerTaskType() {
        val catalog = listOf(
            mkModel("acme/super-coder"),
            mkModel("acme/deep-think", reasoning = true),
            mkModel("acme/fast-flash"),
            mkModel("acme/vision-pro", images = true),
            mkModel("acme/plain-model")
        )
        val router = ModelRouter()
        val health = HealthTracker()
        val s = AgentSettings()
        fun top(t: TaskType, images: Boolean = false) =
            router.rank(TaskProfile(t, Complexity.MEDIUM, needsImages = images), catalog, health, s).first().id
        assertEquals("acme/super-coder", top(TaskType.CODING))
        assertEquals("acme/deep-think", top(TaskType.REASONING))
        assertEquals("acme/fast-flash", top(TaskType.CHAT))
        assertEquals("acme/vision-pro", top(TaskType.VISION, images = true))
    }

    @Test fun routerSkipsModelsLackingRequiredCapabilities() {
        val catalog = listOf(mkModel("a/no-tools", tools = false), mkModel("b/small-ctx", ctx = 500), mkModel("c/good"))
        val r = ModelRouter().rank(
            TaskProfile(TaskType.CHAT, needsTools = true, estimatedInputTokens = 2000), catalog, HealthTracker(), AgentSettings()
        )
        assertEquals(listOf("c/good"), r.map { it.id })
    }

    @Test fun routerKeepsAFreeEscapeHatchAndRespectsPins() {
        val catalog = (1..12).map { mkModel("p$it/m$it") } + mkModel("f/free:free", free = true)
        val s = AgentSettings(pinned = mapOf(TaskType.CHAT to listOf("p7/m7")))
        val r = ModelRouter().rank(TaskProfile(TaskType.CHAT), catalog, HealthTracker(), s, limit = 4)
        assertEquals("p7/m7", r.first().id)
        assertTrue(r.any { it.isFree })
    }

    @Test fun routerAvoidsModelsOnCooldown() {
        val catalog = listOf(mkModel("a/one"), mkModel("b/two"))
        val health = HealthTracker()
        health.onFailure(catalog[0], LlmException(ErrorKind.RATE_LIMIT_MODEL, 429, null, "x", "a/one"))
        val r = ModelRouter().rank(TaskProfile(TaskType.CHAT), catalog, health, AgentSettings())
        assertEquals(listOf("b/two"), r.map { it.id })
    }

    // ---- Plan doğrulama ----

    @Test fun planParserDropsCyclesAndDuplicates() {
        val json = """{"tasks":[
            {"id":"a","role":"CODING","goal":"x","depends_on":["b"]},
            {"id":"b","role":"REVIEW","goal":"y","depends_on":["a"]},
            {"id":"c","role":"CODING","goal":"x","depends_on":[]}]}"""
        val plan = AgentPlan.parse(json, 10)
        assertNotNull(plan)
        assertEquals(2, plan!!.size)                 // tekrar eden hedef elendi
        assertTrue(plan.all { it.dependsOn.isEmpty() }) // döngü bağımlılıkları temizledi
    }

    @Test fun planFitDropsLowPriorityRolesFirst() {
        val plan = AgentPlan.template(TaskType.PROJECT, "x", 10)
        val fitted = AgentPlan.fit(plan, 4)
        assertEquals(4, fitted.size)
        assertTrue(fitted.any { it.role == AgentRole.CODING })
    }
}
