package com.jarvis.ai.agents

/**
 * Görev analizi YEREL yapılır (ek API çağrısı yok): basit sorular için çoklu ajan masrafı
 * oluşmasın diye. Anahtar kelime sezgisidir; kusursuz değildir, kullanıcı çoklu ajanı
 * ayarlardan kapatabilir.
 */
object TaskAnalyzer {

    private val coding = listOf(
        "kod", "fonksiyon", "hata ver", "bug", "derle", "compile", "kotlin", "python", "java", "javascript",
        "class ", "gradle", "stack trace", "exception", "script", "algoritma", "refactor", "api", "sql",
        "android", "html", "css", "react", "```", "unit test", "debug"
    )
    private val reasoning = listOf(
        "neden", "kanıtla", "mantık", "hesapla", "problem", "optimizasyon", "adım adım", "matematik",
        "olasılık", "strateji", "karşılaştır", "analiz et", "değerlendir", "çöz"
    )
    private val research = listOf(
        "araştır", "kaynak", "güncel", "haber", "son durum", "internette", "web'de", "rapor", "literatür", "derinlemesine"
    )
    private val writing = listOf(
        "yaz ", "yazı", "özetle", "özet", "mektup", "makale", "e-posta", "eposta", "çevir", "düzenle", "dilekçe", "blog"
    )
    private val review = listOf("incele", "denetle", "gözden geçir", "review", "hata var mı", "kontrol et", "doğrula")
    private val project = listOf(
        "uygulama geliştir", "uygulama yap", "proje", "mimari", "sistem tasarla", "baştan sona", "sıfırdan",
        "oyun yap", "geliştir", "tam bir", "komple", "full stack", "backend", "çoklu ajan", "ajanlarla", "ajanları kullan"
    )
    /** Telefonu / dosyayı / terminali / cihazı kullanan istekler: bunlar ana Jarvis araç yolundan geçer. */
    private val deviceActions = listOf(
        "müzik", "şarkı", "alarm", "hatırlat", "kamera", "ekran", "whatsapp", "mesaj gönder", "tv", "televizyon",
        "terminal", "dosya oluştur", "zip", "uygulamayı aç", "aç ", "çal ", "kapat", "ara ", "hava durumu",
        "takvim", "fotoğraf çek", "bildirim", "wifi", "bluetooth", "parlaklık", "ses seviyesi"
    )

    private fun hits(text: String, words: List<String>) = words.count { text.contains(it) }

    fun analyze(
        text: String,
        history: List<Pair<String, String>> = emptyList(),
        hasImages: Boolean = false,
        hasFiles: Boolean = false
    ): TaskProfile {
        val t = text.lowercase()
        val scores = mapOf(
            TaskType.CODING to hits(t, coding),
            TaskType.REASONING to hits(t, reasoning),
            TaskType.RESEARCH to hits(t, research),
            TaskType.WRITING to hits(t, writing),
            TaskType.REVIEW to hits(t, review),
            TaskType.PROJECT to hits(t, project)
        )
        val deviceHits = hits(t, deviceActions)
        val projectHits = scores.getValue(TaskType.PROJECT)
        val categoriesHit = scores.count { it.value > 0 }

        var type = scores.filter { it.value > 0 }.maxByOrNull { it.value }?.key ?: TaskType.CHAT
        // Proje + kodlama birlikte → büyük proje.
        if (projectHits > 0 && scores.getValue(TaskType.CODING) > 0) type = TaskType.PROJECT
        if (hasImages) type = TaskType.VISION

        val complexity = when {
            projectHits > 0 && t.length > 160 -> Complexity.HIGH
            t.length > 900 || categoriesHit >= 3 -> Complexity.HIGH
            t.length > 220 || categoriesHit == 2 || type != TaskType.CHAT -> Complexity.MEDIUM
            else -> Complexity.LOW
        }

        val histChars = history.takeLast(16).sumOf { it.second.length }
        val estIn = ((t.length + histChars) / 3).coerceAtLeast(50)
        val estOut = when (type) {
            TaskType.CHAT -> 600
            TaskType.CODING, TaskType.PROJECT -> 3000
            TaskType.WRITING, TaskType.RESEARCH -> 1500
            else -> 1200
        }
        return TaskProfile(
            type = type,
            complexity = complexity,
            needsTools = false,
            needsImages = hasImages,
            estimatedInputTokens = estIn,
            expectedOutputTokens = estOut,
            deviceAction = deviceHits > 0 || (hasFiles && type == TaskType.CHAT)
        )
    }

    /**
     * Çoklu ajan yalnızca: açık + karmaşık (HIGH) + cihaz eylemi içermeyen + görsel olmayan görevlerde.
     * Sohbet ve basit sorular ASLA çoklu ajana gitmez.
     */
    fun shouldUseMultiAgent(profile: TaskProfile, settings: AgentSettings): Boolean =
        settings.multiAgentEnabled &&
            settings.maxConcurrent >= 2 &&
            profile.complexity == Complexity.HIGH &&
            !profile.deviceAction &&
            !profile.needsImages &&
            profile.type in setOf(TaskType.PROJECT, TaskType.CODING, TaskType.RESEARCH, TaskType.REASONING)
}
