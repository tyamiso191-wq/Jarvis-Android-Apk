package com.jarvis.ai.agents

import org.json.JSONObject
import java.io.InterruptedIOException
import java.net.SocketTimeoutException

/**
 * OpenRouter HTTP hatalarını ve ağ istisnalarını ErrorKind'a çevirir. Belgelenen davranışlar:
 * 401 geçersiz anahtar, 402 kredi yok (Retry-After varsa geçici "in-flight" bütçesi),
 * 429 hız sınırı (Retry-After olabilir), 408/5xx geçici hatalar.
 */
object ErrorClassifier {

    private fun parseError(body: String): Pair<String, String> {
        return try {
            val o = JSONObject(body)
            val err = o.optJSONObject("error")
            if (err != null) {
                val msg = err.optString("message", "")
                val meta = err.optJSONObject("metadata")?.toString().orEmpty()
                msg to meta
            } else body.take(300) to ""
        } catch (e: Exception) {
            body.take(300) to ""
        }
    }

    fun classifyHttp(code: Int, body: String, retryAfterMs: Long?, model: ModelInfo?): LlmException {
        val (rawMsg, meta) = parseError(body)
        val msg = Redactor.redact(rawMsg).take(300)
        val low = (rawMsg + " " + meta).lowercase()
        val modelId = model?.id
        val isFree = model?.isFree == true || modelId?.endsWith(":free") == true

        fun ex(kind: ErrorKind, daily: Boolean = false) =
            LlmException(kind, code, retryAfterMs, "${kind.label} (HTTP $code): $msg".trim(), modelId, daily)

        return when {
            code == 401 -> ex(ErrorKind.AUTH)
            code == 402 -> when {
                retryAfterMs != null || low.contains("in_flight") || low.contains("in-flight") ->
                    ex(ErrorKind.INFLIGHT_BUDGET)
                low.contains("weight_exceeds_budget") -> ex(ErrorKind.BAD_REQUEST)
                else -> ex(ErrorKind.CREDITS)
            }
            code == 403 -> if (low.contains("moderat") || low.contains("flagged")) ex(ErrorKind.MODERATION)
            else ex(ErrorKind.AUTH)
            code == 404 -> ex(ErrorKind.MODEL_UNAVAILABLE)
            code == 408 -> ex(ErrorKind.TIMEOUT)
            code == 429 -> {
                val daily = low.contains("per-day") || low.contains("per day") || low.contains("daily")
                val upstream = meta.contains("provider_name") || low.contains("upstream") ||
                    low.contains("provider returned error")
                if (isFree && !upstream) ex(ErrorKind.RATE_LIMIT_ACCOUNT, daily)
                else ex(ErrorKind.RATE_LIMIT_MODEL, daily)
            }
            code == 400 -> when {
                low.contains("context length") || low.contains("maximum context") ||
                    low.contains("context_length") || low.contains("too many tokens") ||
                    low.contains("prompt is too long") || low.contains("token_limit_exceeded") ||
                    low.contains("input is too long") -> ex(ErrorKind.CONTEXT_TOO_LONG)
                (low.contains("tool") || low.contains("function")) &&
                    (low.contains("not support") || low.contains("no endpoints found that support")) ->
                    ex(ErrorKind.MODEL_INCOMPATIBLE)
                low.contains("image") &&
                    (low.contains("not support") || low.contains("no endpoints found that support")) ->
                    ex(ErrorKind.MODEL_INCOMPATIBLE)
                low.contains("not a valid model") || low.contains("model not found") ||
                    low.contains("no endpoints found") -> ex(ErrorKind.MODEL_UNAVAILABLE)
                else -> ex(ErrorKind.BAD_REQUEST)
            }
            code in 500..599 -> ex(ErrorKind.TRANSIENT_SERVER)
            else -> ex(ErrorKind.BAD_REQUEST)
        }
    }

    fun classifyThrowable(t: Throwable, modelId: String?): LlmException {
        if (t is LlmException) return t
        val msg = Redactor.redact(t.message ?: t.javaClass.simpleName).take(200)
        return when (t) {
            is SocketTimeoutException, is InterruptedIOException ->
                LlmException(ErrorKind.TIMEOUT, null, null, "${ErrorKind.TIMEOUT.label}: $msg", modelId)
            else -> LlmException(ErrorKind.NETWORK, null, null, "${ErrorKind.NETWORK.label}: $msg", modelId)
        }
    }
}
