package com.jarvis.ai.agents

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlin.random.Random

/**
 * Fallback Manager. Aday listesini sırayla dener; hata türüne göre davranır:
 *  - AUTH: durur (başka model yardımcı olmaz).
 *  - CREDITS: ücretli modeller bırakılır, yalnızca ücretsiz modeller bir kez denenir; olmazsa durur.
 *  - RATE_LIMIT_*: ilgili model/sınıf beklemeye alınır, sıradaki uygun modele geçilir.
 *  - CONTEXT_TOO_LONG: yalnızca DAHA GENİŞ bağlamlı modeller denenir.
 *  - Geçici sunucu/ağ/zaman aşımı: aynı modelde tek kısa yeniden deneme, sonra sıradaki model.
 *  Sonsuz döngü yoktur: toplam deneme sayısı ve bekleme turu sınırlıdır.
 */
class FallbackRunner(
    private val health: HealthTracker,
    private val events: EventLog,
    private val delayFn: suspend (Long) -> Unit = { delay(it) },
    private val random: Random = Random.Default
) {
    companion object {
        const val SAME_MODEL_RETRIES = 1
        const val MAX_WAIT_ROUNDS = 2
    }

    suspend fun <T> run(
        taskId: String,
        label: String,
        candidates: List<ModelInfo>,
        maxAttempts: Int = 6,
        maxWaitMs: Long = 45_000L,
        attempt: suspend (ModelInfo) -> T
    ): T {
        if (candidates.isEmpty()) {
            throw AiUnavailableException(
                "Bu görev için uygun model bulunamadı (katalog boş ya da gerekli özelliği destekleyen model yok).",
                emptyList()
            )
        }
        val queue = candidates.toMutableList()
        val excluded = HashSet<String>()
        val errors = mutableListOf<LlmException>()
        var attempts = 0
        var waitRounds = 0
        var networkFails = 0
        var previousFailed: ModelInfo? = null
        var lastReason: ErrorKind? = null

        while (true) {
            currentCoroutineContext().ensureActive()
            val usable = queue.filter { it.id !in excluded && health.isUsable(it) }
            if (usable.isEmpty()) {
                val wait = health.soonestAvailableMs(queue.filter { it.id !in excluded })
                if (wait != null && wait <= maxWaitMs && waitRounds < MAX_WAIT_ROUNDS && attempts < maxAttempts) {
                    waitRounds++
                    events.add(
                        EventKind.INFO, "Tüm uygun modeller geçici beklemede; ${wait / 1000 + 1} sn sonra yeniden denenecek.",
                        taskId, notifyUser = true
                    )
                    delayFn(wait + 200)
                    continue
                }
                throw AiUnavailableException(buildMessage(errors, health), errors.map { it.kind }.distinct())
            }
            if (attempts >= maxAttempts) {
                throw AiUnavailableException(
                    "Deneme sınırına ulaşıldı. " + buildMessage(errors, health), errors.map { it.kind }.distinct()
                )
            }
            val model = usable.first()
            var sameModelTries = 0
            var finished = false
            while (!finished) {
                attempts++
                try {
                    val result = attempt(model)
                    health.onSuccess(model)
                    val prev = previousFailed
                    if (prev != null) {
                        events.add(
                            EventKind.FALLBACK,
                            "Yedek model kullanıldı ($label): ${prev.id} → ${model.id}" +
                                (lastReason?.let { " (sebep: ${it.label})" } ?: ""),
                            taskId, model.id, notifyUser = true
                        )
                    }
                    return result
                } catch (e: CancellationException) {
                    throw e
                } catch (e: LlmException) {
                    errors += e
                    health.onFailure(model, e)
                    events.add(EventKind.ERROR, "${model.id}: ${e.message}", taskId, model.id)
                    lastReason = e.kind
                    when (e.kind) {
                        ErrorKind.AUTH -> throw AiUnavailableException(
                            "OpenRouter API anahtarı geçersiz ya da erişim reddedildi. Ayarlardan anahtarı yenile.",
                            listOf(ErrorKind.AUTH)
                        )
                        ErrorKind.CREDITS -> {
                            if (model.isFree) {
                                throw AiUnavailableException(buildMessage(errors, health), errors.map { it.kind }.distinct())
                            }
                            queue.removeAll { !it.isFree }
                            finished = true
                        }
                        ErrorKind.CONTEXT_TOO_LONG -> {
                            queue.removeAll { it.contextLength <= model.contextLength }
                            excluded += model.id
                            finished = true
                        }
                        ErrorKind.TRANSIENT_SERVER, ErrorKind.NETWORK, ErrorKind.TIMEOUT,
                        ErrorKind.EMPTY_RESPONSE, ErrorKind.INFLIGHT_BUDGET -> {
                            if (e.kind == ErrorKind.NETWORK) networkFails++
                            if (networkFails >= 3) {
                                throw AiUnavailableException(
                                    "OpenRouter'a ulaşılamıyor (bağlantı hatası). İnternet bağlantını kontrol et.",
                                    listOf(ErrorKind.NETWORK)
                                )
                            }
                            if (sameModelTries < SAME_MODEL_RETRIES && attempts < maxAttempts) {
                                sameModelTries++
                                val backoff = (e.retryAfterMs ?: (800L * (1 shl sameModelTries) + random.nextLong(0, 400)))
                                    .coerceAtMost(maxWaitMs)
                                delayFn(backoff)
                            } else {
                                excluded += model.id
                                finished = true
                            }
                        }
                        else -> {
                            // Hız sınırı, model yok/uyumsuz, moderasyon, geçersiz istek: sıradaki modele geç.
                            excluded += model.id
                            finished = true
                        }
                    }
                }
            }
            previousFailed = model
        }
    }

    private fun buildMessage(errors: List<LlmException>, health: HealthTracker): String {
        if (errors.isEmpty()) return "Hiçbir model şu an kullanılamıyor."
        val kinds = errors.map { it.kind }.distinct()
        val parts = mutableListOf<String>()
        if (ErrorKind.CREDITS in kinds) {
            parts += "OpenRouter hesabında kredi yok. Başka model denemek bu sorunu çözmez; openrouter.ai üzerinden kredi eklemelisin" +
                " (ücretsiz modeller de hesap durumuna bağlı olarak kullanılamayabilir)."
        }
        if (ErrorKind.RATE_LIMIT_ACCOUNT in kinds) parts += "Ücretsiz katman limiti doldu; bir süre sonra tekrar dene ya da kredi ekle."
        if (ErrorKind.RATE_LIMIT_MODEL in kinds) parts += "Denenen modeller hız sınırına takıldı; biraz sonra tekrar dene."
        if (ErrorKind.INFLIGHT_BUDGET in kinds) parts += "Eşzamanlı istek bütçesi geçici olarak dolu; ajan sayısını azaltmayı dene."
        if (ErrorKind.CONTEXT_TOO_LONG in kinds) parts += "İstek, uygun modellerin bağlam penceresine sığmadı; metni kısalt."
        if (ErrorKind.NETWORK in kinds || ErrorKind.TIMEOUT in kinds) parts += "Bağlantı/zaman aşımı sorunları yaşandı."
        if (ErrorKind.TRANSIENT_SERVER in kinds) parts += "Sağlayıcılarda geçici sunucu hataları var."
        if (ErrorKind.MODEL_UNAVAILABLE in kinds || ErrorKind.MODEL_INCOMPATIBLE in kinds) parts += "Bazı modeller erişilemez ya da gerekli özelliği desteklemiyor."
        if (ErrorKind.MODERATION in kinds) parts += "İçerik bazı sağlayıcılarca reddedildi."
        if (parts.isEmpty()) parts += "Son hata: ${errors.last().message}"
        return "Hiçbir model kullanılamadı. " + parts.joinToString(" ")
    }
}
