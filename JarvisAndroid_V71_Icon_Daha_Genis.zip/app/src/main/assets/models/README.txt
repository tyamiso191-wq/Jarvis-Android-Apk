API'siz yerel sohbet için uyumlu MediaPipe LLM modelini bu klasöre jarvis.task adıyla koyun.

Model dosyası büyük olduğu için kaynak arşivine dahil edilmemiştir. Uygulama ilk açılışta bu dosyayı /data/data/com.jarvis.ai/files/models/jarvis.task konumuna kopyalar.
