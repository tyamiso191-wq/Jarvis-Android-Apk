package com.jarvis.ai.agents

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class RawResponse(val code: Int, val body: String, val retryAfterMs: Long?)

/** Test edilebilirlik için: gerçek ağ ya da sahte (mock) taşıyıcı. */
interface ChatTransport {
    /** /chat/completions isteği gönderir. İptal edilirse HTTP çağrısı da iptal edilir. */
    suspend fun post(body: JSONObject): RawResponse
}

sealed class KeyStatus {
    data class Valid(
        val label: String?,
        val usageUsd: Double?,
        val limitUsd: Double?,
        val limitRemainingUsd: Double?,
        val isFreeTier: Boolean?
    ) : KeyStatus()

    data class Invalid(val message: String) : KeyStatus()
    data class Unreachable(val message: String) : KeyStatus()
}

/**
 * Tek API geçidi: TÜM model çağrıları OpenRouter üzerinden yapılır.
 * https://openrouter.ai/api/v1  (Bearer anahtar). Anahtar yalnızca isteğin Authorization
 * başlığında gider; loglara/hata mesajlarına yazılmaz.
 */
class OpenRouterClient(
    private val keyProvider: () -> String?,
    private val http: OkHttpClient = defaultHttp()
) : ChatTransport {

    companion object {
        const val BASE_URL = "https://openrouter.ai/api/v1"

        fun defaultHttp(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .callTimeout(150, TimeUnit.SECONDS)
            .build()
    }

    private fun requireKey(): String =
        keyProvider()?.takeIf { it.isNotBlank() }
            ?: throw LlmException(ErrorKind.AUTH, null, null, "OpenRouter API anahtarı girilmemiş.")

    private fun base(url: String, key: String): Request.Builder =
        Request.Builder().url(url)
            .header("Authorization", "Bearer $key")
            .header("X-Title", "Judo Android")

    override suspend fun post(body: JSONObject): RawResponse {
        val key = requireKey()
        val req = base("$BASE_URL/chat/completions", key)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        return execute(req)
    }

    /** Anahtarın geçerliliğini ve kalan krediyi GET /api/v1/key ile kontrol eder. */
    suspend fun validateKey(candidate: String? = null): KeyStatus {
        val key = (candidate ?: keyProvider())?.trim()?.takeIf { it.isNotEmpty() }
            ?: return KeyStatus.Invalid("API anahtarı boş.")
        return try {
            val raw = execute(base("$BASE_URL/key", key).get().build())
            when {
                raw.code == 401 || raw.code == 403 ->
                    KeyStatus.Invalid("Bu OpenRouter anahtarı geçersiz ya da devre dışı.")
                raw.code in 200..299 -> {
                    val d = JSONObject(raw.body).optJSONObject("data") ?: JSONObject()
                    fun dbl(name: String): Double? =
                        if (d.has(name) && !d.isNull(name)) d.optDouble(name) else null
                    KeyStatus.Valid(
                        label = d.optString("label").takeIf { it.isNotBlank() },
                        usageUsd = dbl("usage"),
                        limitUsd = dbl("limit"),
                        limitRemainingUsd = dbl("limit_remaining"),
                        isFreeTier = if (d.has("is_free_tier")) d.optBoolean("is_free_tier") else null
                    )
                }
                else -> KeyStatus.Unreachable("OpenRouter beklenmeyen yanıt verdi (HTTP ${raw.code}).")
            }
        } catch (e: IOException) {
            KeyStatus.Unreachable("OpenRouter'a ulaşılamadı: ${Redactor.redact(e.message ?: "bağlantı hatası")}")
        } catch (e: Exception) {
            KeyStatus.Unreachable("Anahtar kontrol edilemedi: ${Redactor.redact(e.message ?: e.javaClass.simpleName)}")
        }
    }

    /** Model kataloğunu GET /api/v1/models ile alır (sayfalama varsa izler). */
    suspend fun fetchModels(): List<ModelInfo> {
        val key = keyProvider()?.takeIf { it.isNotBlank() } ?: ""
        val all = mutableListOf<ModelInfo>()
        var url: String? = "$BASE_URL/models"
        var pages = 0
        while (url != null && pages < 6) {
            val builder = if (key.isNotEmpty()) base(url, key) else Request.Builder().url(url)
            val raw = execute(builder.get().build())
            if (raw.code !in 200..299) {
                throw ErrorClassifier.classifyHttp(raw.code, raw.body, raw.retryAfterMs, null)
            }
            all += ModelParser.parseApi(raw.body)
            val next = try { JSONObject(raw.body).optString("next", "") } catch (e: Exception) { "" }
            url = if (next.startsWith("/")) "https://openrouter.ai$next" else null
            pages++
        }
        return all
    }

    private fun retryAfterOf(resp: Response): Long? {
        val ra = resp.header("Retry-After")?.trim()?.toLongOrNull()
        if (ra != null && ra >= 0) return (ra * 1000L).coerceAtMost(10 * 60_000L)
        val reset = resp.header("X-RateLimit-Reset")?.trim()?.toLongOrNull()
        if (reset != null) {
            val wait = reset - System.currentTimeMillis()
            if (wait > 0) return wait.coerceAtMost(24 * 3_600_000L)
        }
        return null
    }

    private suspend fun execute(req: Request): RawResponse = suspendCancellableCoroutine { cont ->
        val call: Call = http.newCall(req)
        cont.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (cont.isActive) cont.resumeWithException(e)
            }

            override fun onResponse(call: Call, response: Response) {
                try {
                    val text = response.use { it.body?.string().orEmpty() }
                    val retryAfter = retryAfterOf(response)
                    if (cont.isActive) cont.resume(RawResponse(response.code, text, retryAfter))
                } catch (e: IOException) {
                    if (cont.isActive) cont.resumeWithException(e)
                }
            }
        })
    }
}
