package com.jarvis.ai.social

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import org.json.JSONObject

/**
 * Windows Judo V3'teki send_whatsapp_message / save_whatsapp_contact
 * araçlarının Android karşılığı -- kullanıcının isteği üzerine Instagram ve
 * TikTok'a da genişletildi.
 *
 * İKİ YOL VAR:
 *  1) Bu dosyadaki open/send fonksiyonları: ilgili ekranı açar, gönderimi
 *     kullanıcı yapar (Erişilebilirlik servisi kapalıyken kullanılan yol).
 *  2) automation/AppAutomation: kullanıcı Erişilebilirlik servisini kendisi
 *     açtıysa uygulama küçük pencerede açılır ve mesaj senin yerine yazılıp
 *     gönderilir. Sadece kullanıcı komut verdiğinde çalışır, ekranda DURDUR
 *     düğmesi görünür.
 *
 * PLATFORM FARKLARI:
 *  - WhatsApp: mesaj METNİ prefill edilebiliyor (wa.me/whatsapp:// text=).
 *  - Instagram: SADECE o kullanıcıyla DM ekranı açılabiliyor (ig.me/m/user),
 *    metin prefill etmenin resmi/genel bir yolu yok -- kullanıcı kendi yazar.
 *  - TikTok: DM ekranını doğrudan açacak genel bir link YOK -- sadece
 *    kullanıcının profili açılabiliyor, mesajı oradan kendisi başlatır.
 */
object SocialMessagingTool {
    private const val TAG = "SocialMessagingTool"
    private const val PREFS_NAME = "social_contacts"

    enum class Platform(val key: String) { WHATSAPP("whatsapp"), INSTAGRAM("instagram"), TIKTOK("tiktok") }

    // ─── Rehber (isim -> telefon/kullanıcı adı), platform bazlı ──────────
    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private fun contactKey(name: String) = name.trim().lowercase()

    fun saveContact(context: Context, platform: Platform, name: String, handle: String): Boolean {
        val cleanName = name.trim()
        val cleanHandle = handle.trim()
        if (cleanName.isBlank() || cleanHandle.isBlank()) return false
        val json = JSONObject(prefs(context).getString(platform.key, "{}") ?: "{}")
        json.put(contactKey(cleanName), cleanHandle)
        prefs(context).edit().putString(platform.key, json.toString()).apply()
        return true
    }

    private fun lookupContact(context: Context, platform: Platform, name: String): String? {
        val json = JSONObject(prefs(context).getString(platform.key, "{}") ?: "{}")
        return json.optString(contactKey(name)).takeIf { it.isNotBlank() }
    }

    /**
     * "recipient" bir kayıtlı isim OLABİLİR (rehberden çözülür) ya da
     * doğrudan telefon numarası/kullanıcı adı OLABİLİR -- ikisi de denenir.
     */
    private fun resolveHandle(context: Context, platform: Platform, recipient: String): String {
        val saved = lookupContact(context, platform, recipient)
        return saved ?: recipient.trim()
    }

    // ─── Telefon numarası normalizasyonu (Windows'takiyle aynı mantık) ───
    private fun normalizePhone(raw: String): String? {
        var digits = raw.filter { it.isDigit() }
        if (digits.isEmpty()) return null
        if (digits.length == 11 && digits.startsWith("0")) {
            digits = "90" + digits.substring(1)
        } else if (digits.length == 10) {
            digits = "90$digits"
        }
        return digits.takeIf { it.length in 8..15 }
    }

    /** Otomasyon için: kayıtlı isim ya da numara -> normalleştirilmiş telefon (yoksa null). */
    fun resolvePhone(context: Context, recipient: String): String? =
        normalizePhone(resolveHandle(context, Platform.WHATSAPP, recipient))

    /**
     * Otomasyon için kullanıcı adı çözümü: kayıtlı kişiyse kayıttaki ad; değilse
     * yalnızca açıkça kullanıcı adına benzeyen girdi (@ile başlayan ya da . _ rakam
     * içeren, boşluksuz) kabul edilir. Düz bir isim ("Ahmet") null döner ve uygulama
     * içi aramayla bulunur.
     */
    fun resolveUsername(context: Context, platform: Platform, recipient: String): String? {
        lookupContact(context, platform, recipient)?.let { return it.removePrefix("@") }
        val r = recipient.trim()
        if (r.isBlank() || r.any { it.isWhitespace() }) return null
        val looksLikeHandle = r.startsWith("@") || r.any { it == '.' || it == '_' || it.isDigit() }
        return if (looksLikeHandle) r.removePrefix("@") else null
    }

    // ─── WhatsApp ─────────────────────────────────────────────────────────
    sealed class SendResult {
        data class Opened(val label: String) : SendResult()
        data class NoContact(val name: String) : SendResult()
        object InvalidPhone : SendResult()
        object Failed : SendResult()
    }

    fun sendWhatsAppMessage(context: Context, recipient: String, message: String): SendResult {
        if (recipient.isBlank()) return SendResult.NoContact(recipient)
        val handle = resolveHandle(context, Platform.WHATSAPP, recipient)
        val phone = normalizePhone(handle) ?: run {
            // Rehberde de yoktu, verilen şey de numaraya benzemiyordu.
            if (lookupContact(context, Platform.WHATSAPP, recipient) == null) {
                return SendResult.NoContact(recipient)
            }
            return SendResult.InvalidPhone
        }
        val encodedMsg = Uri.encode(message)
        return try {
            // Önce doğrudan WhatsApp uygulamasını hedefleyen şema, yoksa
            // wa.me (WhatsApp yüklüyse onu açar, değilse tarayıcıda web.whatsapp.com'a düşer).
            val appIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://api.whatsapp.com/send?phone=$phone&text=$encodedMsg")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(appIntent)
            SendResult.Opened("+$phone")
        } catch (e: Exception) {
            Log.w(TAG, "WhatsApp açılamadı", e)
            SendResult.Failed
        }
    }

    // ─── Instagram ─────────────────────────────────────────────────────────
    sealed class DmResult {
        data class Opened(val username: String) : DmResult()
        object NoContact : DmResult()
        object Failed : DmResult()
    }

    fun openInstagramDm(context: Context, recipient: String): DmResult {
        if (recipient.isBlank()) return DmResult.NoContact
        val username = resolveHandle(context, Platform.INSTAGRAM, recipient).removePrefix("@")
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://ig.me/m/$username"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            DmResult.Opened(username)
        } catch (e: Exception) {
            Log.w(TAG, "Instagram DM açılamadı", e)
            DmResult.Failed
        }
    }

    // ─── TikTok ─────────────────────────────────────────────────────────
    fun openTikTokProfile(context: Context, recipient: String): DmResult {
        if (recipient.isBlank()) return DmResult.NoContact
        val username = resolveHandle(context, Platform.TIKTOK, recipient).removePrefix("@")
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/@$username"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            DmResult.Opened(username)
        } catch (e: Exception) {
            Log.w(TAG, "TikTok profili açılamadı", e)
            DmResult.Failed
        }
    }
}
