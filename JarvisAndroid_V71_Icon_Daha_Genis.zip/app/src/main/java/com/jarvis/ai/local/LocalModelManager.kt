package com.jarvis.ai.local

import android.content.Context
import java.io.File

/**
 * API'siz çalışma için cihazdaki MediaPipe .task/.litertlm modelini bulur.
 * Model dosyası APK'ye gömülmez; boyutu çoğu zaman yüzlerce MB olduğu için
 * release paketine ayrıca eklenmesi veya ilk kurulumda bu klasöre kopyalanması gerekir.
 */
object LocalModelManager {
    const val MODEL_FILE_NAME = "jarvis.task"

    fun modelDir(context: Context): File =
        File(context.filesDir, "models").apply { mkdirs() }

    fun modelFile(context: Context): File = File(modelDir(context), MODEL_FILE_NAME)

    fun isReady(context: Context): Boolean = modelFile(context).let { it.exists() && it.length() > 1024L * 1024L }

    fun installFromAssetsIfPresent(context: Context): Boolean {
        val target = modelFile(context)
        if (isReady(context)) return true
        return try {
            context.assets.open("models/$MODEL_FILE_NAME").use { input ->
                target.outputStream().use { output -> input.copyTo(output) }
            }
            isReady(context)
        } catch (_: Exception) {
            false
        }
    }

    fun status(context: Context): String = if (isReady(context)) {
        "Yerel model hazır: ${modelFile(context).length() / (1024 * 1024)} MB"
    } else {
        "Yerel model bulunamadı. models/$MODEL_FILE_NAME dosyasını uygulama verilerine koyun."
    }
}
