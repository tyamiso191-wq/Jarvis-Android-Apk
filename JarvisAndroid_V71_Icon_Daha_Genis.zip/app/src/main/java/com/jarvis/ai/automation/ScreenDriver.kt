package com.jarvis.ai.automation

import android.content.Context
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject
import java.util.Locale

/**
 * Judo'in HERHANGİ bir uygulamayı (örn. Vestel klima uygulaması) senin yerine
 * adım adım kullanabilmesi için genel araçlar: ekranı oku, düğmeye bas, yaz,
 * kaydır, geri git. Model her adımda ekranı okuyup bir sonraki hamleyi seçer.
 *
 * GÜVENLİK ÖNLEMLERİ:
 *  - Sadece kullanıcı bir komut verdiğinde çağrılır; çalışırken DURDUR şeridi görünür.
 *  - Banka/ödeme/şifre yöneticisi/Play Store gibi hassas uygulamalarda kapalıdır.
 *  - Art arda en fazla [MAX_STEPS] adım (5 dk hareketsizlikten sonra sıfırlanır).
 *  - DURDUR'a basılınca 15 sn boyunca tüm adımlar reddedilir.
 */
object ScreenDriver {
    private const val MAX_STEPS = 40
    private const val IDLE_RESET_MS = 5 * 60 * 1000L

    private val BLOCKED = listOf(
        "bank", "banka", "wallet", "cuzdan", "paypal", "papara", "payment", "finans", "fintech",
        "authenticator", "password", "parola", "keepass", "bitwarden", "lastpass",
        "com.android.vending", "ziraat", "garanti", "isbank", "akbank", "yapikredi",
        "denizbank", "qnb", "kuveyt", "vakif", "halkbank", "enpara", "fibabanka", "tosla", "param"
    )

    private var steps = 0
    private var lastAt = 0L
    private var cancelUntil = 0L

    private fun fold(s: String) = s.lowercase(Locale("tr", "TR"))
        .replace('ı', 'i').replace('ş', 's').replace('ğ', 'g')
        .replace('ü', 'u').replace('ö', 'o').replace('ç', 'c').trim()

    private fun err(msg: String) = JSONObject().put("status", "error").put("message", msg)

    private fun gate(svc: JarvisAccessibilityService?): JSONObject? {
        if (svc == null) return err("NEEDS_ACCESSIBILITY")
        val now = System.currentTimeMillis()
        if (JarvisAccessibilityService.cancelRequested) {
            JarvisAccessibilityService.cancelRequested = false
            cancelUntil = now + 15_000
        }
        if (now < cancelUntil) return err("DURDURULDU: kullanıcı DURDUR'a bastı, devam etme, kullanıcıya söyle.")
        if (now - lastAt > IDLE_RESET_MS) steps = 0
        if (steps >= MAX_STEPS) return err("Adım sınırı doldu ($MAX_STEPS). Kullanıcıya durumu anlat ve devam edip etmeyeceğini sor.")
        steps++
        lastAt = now
        svc.showOverlay("JUDO ekranı kullanıyor…")
        svc.hideOverlayDelayed(8000)
        return null
    }

    private fun isBlocked(pkg: String): Boolean {
        val p = fold(pkg)
        return BLOCKED.any { p.contains(it) }
    }

    /** Ön plandaki asıl uygulama penceresi (Judo ve sistem arayüzü hariç, en büyük olan). */
    private fun pickRoot(svc: JarvisAccessibilityService, ctx: Context): AccessibilityNodeInfo? {
        val skip = setOf(ctx.packageName, "com.android.systemui")
        return svc.allRoots()
            .filter { it.packageName?.toString() !in skip }
            .maxByOrNull { n -> Rect().also { n.getBoundsInScreen(it) }.let { it.width().toLong() * it.height() } }
    }

    private fun rowFor(svc: JarvisAccessibilityService, n: AccessibilityNodeInfo): String? {
        val label = svc.labelOf(n).replace("\n", " ").take(60)
        val kind = when {
            n.isEditable -> "yazı-alanı"
            n.isCheckable -> if (n.isChecked) "anahtar:AÇIK" else "anahtar:KAPALI"
            n.isClickable -> "düğme"
            else -> "metin"
        }
        if (label.isBlank() && kind != "yazı-alanı") return null
        if (kind == "metin" && label.length < 2) return null
        return "[$kind] ${if (n.isPassword) "(parola alanı)" else label}"
    }

    fun read(ctx: Context): JSONObject {
        val svc = JarvisAccessibilityService.instance
        gate(svc)?.let { return it }
        val root = pickRoot(svc!!, ctx) ?: return err("Okunacak uygulama penceresi yok (önce uygulamayı aç).")
        val pkg = root.packageName?.toString().orEmpty()
        if (isBlocked(pkg)) return err("Güvenlik gereği bu uygulamada ekran kontrolü kapalı: $pkg")
        val rows = LinkedHashSet<String>()
        svc.findAll(root) { true }.forEach { n -> rowFor(svc, n)?.let { rows.add(it) } }
        return JSONObject().put("status", "ok").put("app", pkg)
            .put("screen", rows.take(70).joinToString("\n"))
    }

    /** action: click | type | back | home | scroll_down | scroll_up */
    fun act(ctx: Context, action: String, target: String, text: String): JSONObject {
        val svc = JarvisAccessibilityService.instance
        gate(svc)?.let { return it }
        svc!!
        val result: JSONObject = when (action.trim().lowercase()) {
            "back" -> if (svc.back()) ok() else err("Geri gidilemedi")
            "home" -> if (svc.home()) ok() else err("Ana ekrana gidilemedi")
            else -> {
                val root = pickRoot(svc, ctx) ?: return err("Uygulama penceresi yok (önce uygulamayı aç).")
                val pkg = root.packageName?.toString().orEmpty()
                if (isBlocked(pkg)) return err("Güvenlik gereği bu uygulamada ekran kontrolü kapalı: $pkg")
                when (action.trim().lowercase()) {
                    "click" -> {
                        val t = fold(target)
                        if (t.isBlank()) return err("target (basılacak yazı) gerekli")
                        val hits = svc.findAll(root) { n -> fold(svc.labelOf(n)).contains(t) }
                        // Önce tıklanabilir ve etiketi hedefe en yakın (en kısa) olan.
                        val best = hits.sortedWith(compareByDescending<AccessibilityNodeInfo> { it.isClickable }
                            .thenBy { svc.labelOf(it).length }).firstOrNull { svc.click(it) }
                        if (best != null) ok() else err("'$target' yazılı basılabilir öğe bulunamadı. Ekranı yeniden oku.")
                    }
                    "type" -> {
                        if (text.isEmpty()) return err("text gerekli")
                        val fields = svc.findAll(root) { it.isEditable && it.isEnabled && !it.isPassword }
                        val field = if (target.isNotBlank()) {
                            fields.firstOrNull { fold(svc.labelOf(it)).contains(fold(target)) } ?: fields.firstOrNull()
                        } else fields.firstOrNull { it.isFocused } ?: fields.firstOrNull()
                        if (field != null && svc.setText(field, text)) ok() else err("Yazılacak alan bulunamadı")
                    }
                    "scroll_down", "scroll_up" -> {
                        val list = svc.findAll(root) { it.isScrollable }.maxByOrNull { n ->
                            Rect().also { n.getBoundsInScreen(it) }.let { it.width().toLong() * it.height() }
                        }
                        val a = if (action.trim().lowercase() == "scroll_down") AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                        else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                        if (list != null && list.performAction(a)) ok() else err("Kaydırılabilir alan yok")
                    }
                    else -> err("Bilinmeyen action. Geçerli: click, type, back, home, scroll_down, scroll_up")
                }
            }
        }
        UiWait.sleep(700) // ekranın yerleşmesini bekle, sonraki okuma güncel olsun
        return result
    }

    private fun ok() = JSONObject().put("status", "ok")
}
