package com.jarvis.ai.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val JudoColorScheme = darkColorScheme(
    primary = Teal,
    onPrimary = Bg,
    secondary = TealDim,
    background = Bg,
    surface = Panel,
    onBackground = Text,
    onSurface = Text,
    error = Red
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = JudoColorScheme,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(16.dp),
            small = RoundedCornerShape(16.dp),
            medium = RoundedCornerShape(20.dp),
            large = RoundedCornerShape(24.dp)
        ),
        content = content
    )
}
