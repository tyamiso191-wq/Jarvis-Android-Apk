# Judo V71 — API'siz telefon içi AI

Bu sürümde ana sohbet yolu Gemini/OpenRouter kullanmaz ve API anahtarı istemez. Model doğrudan Android telefonda, MediaPipe LLM Inference ile çalışır. Uygulama açılışında API anahtarı ekranı atlanır.

## Yerel model kurulumu

Model dosyası büyük olduğu için APK'ye otomatik gömülmez. Uyumlu bir MediaPipe `.task` veya `.litertlm` modeli `jarvis.task` adıyla uygulamanın özel dosya alanındaki `models/` klasörüne koyulmalıdır. Kod bu dosyayı şu konumda arar:

`/data/data/com.jarvis.ai/files/models/jarvis.task`

Pratik seçenekler:

1. Uyumlu modeli `app/src/main/assets/models/jarvis.task` olarak projeye ekleyip yeniden derle. Uygulama ilk açılışta otomatik kopyalar.
2. Ya da Android Studio Device File Explorer ile model dosyasını uygulamanın `files/models/` klasörüne kopyala.

Model olmadan kamera, sesli okuma, basit çevrimdışı komutlar ve dosya altyapısı çalışır; serbest sohbet için model dosyası gerekir. Telefon RAM'ine uygun küçük quantized bir model kullanılması önerilir.

## Dosya oluşturma

Yerel model, dosya istediğinde `<jarvis_file name="...">...</jarvis_file>` biçiminde çıktı üretirse uygulama bunu otomatik gerçek dosyaya dönüştürür. Dosya önce sohbet kartına eklenir; kullanıcı karttaki **Kaydet** düğmesine basınca Android'in İndirilenler klasörüne yazılır. Mevcut `FileTool` ayrıca ZIP, metin, JSON, HTML ve ikili dosya altyapısını korur.

## Derleme notu

`com.google.mediapipe:tasks-genai:0.10.27` bağımlılığı eklenmiştir. Projede bulunan `gradlew` dosyası yalnızca sistem Gradle'ını çağıran bir yer tutucudur; GitHub Actions veya Gradle 8.9 yüklü bir ortamda derlenmelidir.

---

# V65 notları

- **İlk açılışta yatay açılma + API anahtarı ekranının atlanması:** Android'in otomatik yedeği (allowBackup) eski sürümün ayarlarını (ekran yönü, kayıtlı anahtar) yeniden kurulumda geri yüklüyordu. Yedekleme kapatıldı; yeni kurulumda uygulama DİKEY açılır ve anahtarı sorar. NOT: üstüne güncelleme yapıyorsan eski ayar kalır; test için önce uygulamayı sil, sonra kur.
- **Yazı alanı:** Enter artık yeni satır açıyor (en fazla 5 satıra kadar büyüyor); göndermek için sağdaki oka bas.

# V64 notları

- **Ekle (+) menüsü:** sohbet çubuğundaki düğme artık "+" ve Kamera / Fotoğraf / Dosya seçeneklerinin üçünü birden açıyor (V63'te sadece kamera vardı).

# V63 notları

- **Kamera:** sohbet çubuğundaki ataç menüsü (fotoğraf/dosya seç) kaldırıldı; yerine kamera düğmesi geldi. Dokununca kamera açılır, çektiğin fotoğraf ek olarak eklenir, gönder'e basınca mesajla gider (ilk seferde kamera izni sorar).
- **Yan menü:** üstteki ☰ ve açılır liste yerine soldan kayan yan menü (ekranın yaklaşık 5'te 1'i, çok dar ekranda en az 190dp). İçinde Hafıza, Terminal, Arka Plan Modu, Konuşma hızı, Ses, Ekran yönü, Anahtarı değiştir var.
- **Emoji yerine simgeler:** menü, düğmeler, gönder, kapat, ek kartları artık ince çizgili vektör simgelerle çiziliyor (ek bağımlılık yok). DERLENMEDİ / telefonda GÖRÜLMEDİ.

# V62 notları

- **Yeni, yumuşak arayüz:** keskin neon çerçeveli "terminal" görünümü yerine yuvarlak köşeli, yarı saydam paneller, hafif lacivert-petrol degrade zemin, mat pastel renkler ve düz (monospace olmayan) yazı tipi. Düğmeler hap şeklinde, sohbet balon şeklinde, yazı alanı ve gönder/ek düğmeleri yuvarlak. Terminal ekranı bilerek eski haliyle kaldı. DERLENMEDİ / telefonda GÖRÜLMEDİ: yerleşim kayarsa ekran görüntüsünü gönder.

# V61 notları

- **Arka Plan Modu:** menüdeki "🎙 Arka Plan Modu"nu açınca Judo arka planda/ekran kapalıyken dinler, bildirim alanında kalıcı bildirim görünür (Durdur düğmesiyle kapanır). "Judo" demeden hiçbir şey yapmaz. "Judo, ekranımda ne var" dersen ekranı görür; Android 14+'ta ekran izni her seferinde sorulduğu için bir bildirim çıkar, ona dokunup izin vermen gerekir.
- **"Din din" sesleri:** dinleme başlarken/biterken çalan bip sesleri, dinleme sürerken bildirim/sistem (ve müzik çalmıyorsa medya) sesleri geçici susturularak engellendi. Not: müzik/video çalarken medya akışı susturulmadığı için bip duyulabilir. DERLENMEDİ / telefonda DENENMEDİ.

# V60 notları (tam tarama + düzeltmeler)

- DERLENMEDİ: sandbox'ta derleme yapılamadı, sadece statik inceleme yapıldı. Derleme hatası olursa mesajı ilet.
- **Uyandırma kelimesi:** komut artık modele kullanıcı mesajı olarak gerçekten gidiyor (eskiden boş liste gidiyordu); foreground servis başlatılamazsa çökmeden duruyor.
- **Takvim:** tüm gün etkinlikleri UTC gece yarısıyla ekleniyor (gün kayması yok); "bugün" sorusu artık 31 günlük liste döndürmüyor.
- **Seslendirme:** "14:30" gibi saatler doğru okunuyor.
- **Ekran görüntüsü (Android 14+):** izin tek kullanımlık olduğundan artık analiz istendiğinde isteniyor; MediaProjection callback eklendi.
- **El kontrolü:** model ilk kullanımda indirilip kaydediliyor (internet gerekir).
- **Çevrimdışı:** "saat kaç" kalıbı daraltıldı, teşekkür/veda/selam sadece kısa cümlelerde; "sonradan X çalacaksın" favori kalıbı eklendi.
- **TV:** eşleşme gerekiyorsa mesaj NEEDS_PAIRING ile başlıyor; sistem metinleri güncellendi.

# V59 notları

- **Televizyon (TCL Google TV):** Wi-Fi üzerinden Google TV kumanda protokolüyle: aç/kapat, ses, kanal, yön tuşları, uygulama açma. İlk kullanımda bir kez eşleştirme (TV ekranındaki 6 haneli kodu Judo'e söyle). Telefon ve TV aynı Wi-Fi'de olmalı.
- **Klima (Vestel Wi-Fi):** Telefonda IR yok (Redmi 12C), klimanın açık API'si de yok; bu yüzden Judo klima uygulamasını senin yerine kullanıyor (ekranı oku / düğmeye bas, adım adım, sonucu doğrulayarak). Erişilebilirlik servisi açık olmalı. Banka/ödeme uygulamalarında kapalı, DURDUR şeridi var.
- DERLENMEDİ / TV ve klimada DENENMEDİ. TV protokolü elle yazıldı; eşleşme/komut aşamasında hata olursa mesajı bana ilet.

# V58 notları

- **Instagram:** artık önce DM kutusunu açıp kişiyi listede (gerekirse kaydırarak) buluyor, sohbete girip yazıyor ve gönderiyor. Arama kutusu / profil sadece yedek.
- **Hız:** bekleme süreleri kısaltıldı, serbest pencere bir kez başarısız olursa tekrar beklenmiyor, zaten küçük pencerede ise tekrar bölünmüyor.

# V57 notları

- **"Sıkıldım" diye mesaj gönder hatası:** mesaj içindeki "sıkıldım" kelimesi çevrimdışı aktivite önerisini tetikleyip komutu modele hiç göndermiyordu. Instagram/WhatsApp/TikTok/Google/mesaj geçen komutlar artık çevrimdışı kalıpları atlayıp doğrudan modele (araç çağrısına) gidiyor.

# V56 notları

- **Instagram profilde takılma düzeltildi:** "Mesaj" düğmesi artık yazı/açıklama alanlarından birine tam eşleşerek bulunuyor (eskiden "Mesaj Mesaj" gibi birleşik etiket yüzünden kaçırılıyordu), basınca sohbetin açılması bekleniyor. Takılırsa hata mesajı ekranda görünen yazıları listeler.
- **Küçük pencere:** serbest (kayan) pencere artık özellik bayrağı görünmese de FREEFORM moduyla denenir (sol üst, dikeyde üst yarı / yatayda çeyrek). Telefon desteklemezse bölünmüş ekrana düşer. Garanti için: Geliştirici seçenekleri > "Serbest biçimli pencereleri etkinleştir" + yeniden başlat.

# V55 notları

- **Derleme hatası düzeltildi:** `SocialMessagingTool.kt` yorumundaki `*/` yorumu erken kapatıyordu (V53/V54 derlenmiyordu).

# V54 notları

- **Hata düzeltme:** Judo "düşünürken" uygulama kapatılıp sonra yeni soru sorulunca eski sorunun cevabı geliyordu. Cevapsız kalan son soru artık açılışta ve yeni soru/hata anında geçmişten temizleniyor; iptal edilen eski isteğin sonucu da yeni soruya karışmıyor.

# V53 notları (v52 üzerine)

- **Küçük ekran otomasyonu:** "X'e Instagram'dan şunu yaz" dediğinde uygulama küçük pencerede açılır (dikey: üst yarı, yatay: çeyrek), kişi bulunur, mesaj yazılıp gönderilir. WhatsApp, Instagram, TikTok + Google araması + "X'i küçük ekranda aç".
- **Kurulum (bir kez):** Ayarlar > Erişilebilirlik > Judo > Aç. Android 13+ yan yüklemede önce Uygulama bilgisi > ⋮ > "Kısıtlı ayarlara izin ver".
- **Pencere boyutu:** serbest pencere (freeform) açıksa tam yarı/çeyrek; değilse bölünmüş ekran (yatayda yarım); o da olmazsa tam ekran. Otomasyon üçünde de çalışır.
- Çalışırken ekranda DURDUR şeridi görünür.
- DERLENMEDİ / cihazda DENENMEDİ (ortamda Android SDK yok). Düğme eşleştirmesi uygulama arayüzlerine bağlı; takılırsa sonuçtaki `stage` alanı hangi adım olduğunu söyler.

# V52 notları (v51 üzerine)

- **API sağlayıcısı Gemini'ye alındı:** `https://generativelanguage.googleapis.com/v1beta/openai/` (OpenAI uyumlu uç nokta, Bearer anahtar).
  Modeller: `gemini-3.8-flash` → `gemini-3.5-flash-lite` → `gemini-3.5-flash` (2.x ve 2.0 kapatıldı; `gemini-3.5-flash` kullanımdan kaldırıldı, Google otomatik yeni sürüme yönlendiriyor).
- Görsel mesaj biçimi Gemini'nin beklediği `image_url: {url: ...}` yapısına çevrildi (sohbet + kamera/ekran analizi).
- Anahtar kayıt adı `gemini_api_key` oldu: eski Mistral anahtarı Gemini'de geçersiz olduğundan uygulama açılışta yeni anahtarı ister.
- Anahtar: https://aistudio.google.com/apikey
- DERLENMEDİ / cihazda DENENMEDİ (ortamda Gradle/Android SDK yoktu). İlk derlemede hata çıkarsa bildir.

# Judo — Android

Koyu teal / cyan Iron Man tarzı arayüz + Gemini destekli sesli sohbet.

---

## Bilgisayar olmadan APK alma (GitHub Actions)

### 1. GitHub hesabı aç
Telefondan: https://github.com → Sign up

### 2. Yeni repo oluştur
1. Sağ üstte **+** → **New repository**
2. Repository name: `JudoAndroid` (istediğin isim)
3. **Public** seç
4. **Create repository**

### 3. Dosyaları yükle
1. Bu `JudoAndroid` klasörünün **içindeki tüm dosyaları** GitHub’a yükle.
2. Telefondan:
   - Repoya gir → **uploading an existing file** (veya Add file)
   - Tüm dosya ve klasörleri seç (özellikle **.github** klasörü de gelsin)
   - **Commit changes**

### 4. Otomatik derleme
- **Actions** sekmesine gir
- **Build APK** işinin yeşil tik almasını bekle (3–8 dk)
- İş bitince:
  - İşin üzerine tıkla
  - En altta **Artifacts** → **Judo-APK** indir
  - Zip içinden `app-debug.apk` çıkar

### 5. Telefona yükle
- `app-debug.apk` dosyasını aç → Yükle
- İlk açılışta Gemini API anahtarını gir (bir kere)
- Sonraki açılışlarda sormaz

---

## Gemini API anahtarı

https://aistudio.google.com/apikey
→ Create new key → kopyala → uygulamaya yapıştır

---

## Elle tekrar derlemek

GitHub → **Actions** → **Build APK** → **Run workflow**

---

## Notlar

- Model adı değişirse: `MistralTextClient.kt` içindeki `CANDIDATES` listesini güncelle (varsayılan: gemini-3.8-flash → 3.5-flash-lite → 3.5-flash)
- Artifact 14 gün saklanır

---

## v47 — Mistral + "telefonu kendin kullan" (turuncu çerçeve)

- **API:** Gemini yerine **Mistral** (`https://api.mistral.ai/v1`). Anahtar kaydı yeni
  isimle tutulduğu için uygulama açılışta Mistral anahtarını yeniden ister.
  `create_image` (Gemini'ye özgü görsel üretim) kaldırıldı.
- **Sol üst mini pencere silindi.** Siteler/videolar artık gerçek uygulamalarda açılır.
- **Yeni: `open_website` ve `control_phone`.** "Google'dan X sitesini aç" dediğinde
  ekranın etrafı turuncu olur → ana ekrana gelir → Google açılır → site aranır → siteye
  girilir. Aynı mekanizma her şey için (uygulama içi gezinme, oyunlarda dokunma) çalışır:
  `agent/PhoneAgent.kt` (gözlem → karar → eylem döngüsü) + `agent/JarvisAccessibilityService.kt`.
- **KURULUM (bir kez):** Ayarlar → Erişilebilirlik → Judo → Aç. Android bunu
  uygulamanın kendi kendine açmasına izin vermez. Açık değilse Judo ayarları kendisi açar.
- **DURDUR** tuşu çalışan telefon görevini de hemen keser.
- Manifest'e `<queries>` eklendi (Android 11+'ta "X uygulamasını aç"ın yüklü uygulamaları
  görebilmesi için).

---

## Bu sürümde eklenenler (v26) -- KRİTİK TOKEN/KOTA DÜZELTMESİ

**Not:** Bu sürümde `EMBEDDED_API_KEY` tekrar boş (`""`) -- yani v25'teki
"key koda gömülü, giriş ekranı yok" davranışı KALDIRILDI, uygulama eskisi
gibi açılışta Gemini API anahtarını soruyor.

**Kök neden bulundu:** `GeminiTextClient.kt`, sistem promptundaki (persona)
"OYUN/UYGULAMA ÜRETME" ve dosya/terminal fonksiyon açıklamaları gibi ağır,
SADECE ilgili istekte gerekli olan bölümleri `@@B@@ ... @@/B@@` işaretleri
arasına alıp, gerekmediğinde (`needsBuilderTools()` false ise, örn. "Selam
Judo" ya da bir trivia sorusu gibi sıradan sohbette) bu bölümleri
prompttan SİLEREK gönderiyordu -- bu, normal sohbeti ucuz tutan asıl
mekanizmaydı.

Önceki bir düzenlemede (Claude API'yi kaldırırken) bu `@@B@@`/`@@/B@@`
işaretleri "anlamsız artık metin" sanılıp YANLIŞLIKLA silinmişti. Sonuç:
işaretler bulunamayınca kısaltma hiç çalışmıyordu, HER mesajda (selam bile
olsa) ~1170 token'lık gereksiz "oyun üretme" talimatı gönderiliyordu. Üstüne,
"kaç/ne zaman/kim" gibi araştırma gerektiren sorular birden fazla araç turu
(web_search + read_webpage + cevap) tetiklediği için bu şişkin prompt AYNI
soruda 2-3 KEZ gönderiliyor, ücretsiz Gemini kotası birkaç mesajda tükeniyordu.

**Düzeltme:** İki `@@B@@ ... @@/B@@` bloğu (fonksiyon açıklamaları ve OYUN/
UYGULAMA ÜRETME bölümü) `JarvisViewModel.kt`'de tam eski konumlarına geri
kondu. Artık normal sohbette persona ~1480 token, sadece dosya/oyun/terminal
isteği geçen mesajlarda ~2650 token gönderiliyor -- yani kota tekrar eskisi
gibi (ve v22 öncesi kadar) verimli tüketiliyor.

---

## Bu sürümde eklenenler (v25)

**API key koda gömülü, giriş ekranı yok -- SADECE bu derleme için**
- `JarvisViewModel.kt` içindeki `EMBEDDED_API_KEY` sabiti dolu bırakıldı;
  uygulama açılışta ApiKeyScreen'i hiç göstermeden doğrudan bu key'le
  bağlanıyor.
- ⚠️ GÜVENLİK: bu key apk içinde düz metin olarak duruyor, dekompile
  edilirse okunabilir. Reponun **Private** olduğundan emin ol.
- **v26 için:** `JarvisViewModel.kt`'de `EMBEDDED_API_KEY = "..."` satırını
  `EMBEDDED_API_KEY = ""` yap -- kod otomatik olarak eskisi gibi (giriş
  ekranında key sorarak) çalışır, başka hiçbir şeye dokunmana gerek yok.

---

## Bu sürümde eklenenler (v24)

**TV kumandası (D-pad) desteği**
- BAŞLAT / DURDUR / 🎙 MİKROFON butonları artık kumandanın ok tuşlarıyla
  gezilebiliyor ve orta (DPAD_CENTER/Enter) tuşuyla tetiklenebiliyor
  (Compose'un `clickable` + `focusable` desteği zaten buna izin veriyordu,
  eksik olan SADECE hangi butonun o an odakta olduğunu gösteren görsel bir
  vurguydu -- artık odaklanan butonun çerçevesi beyaza dönüp kalınlaşıyor).
- Ekran ilk açıldığında BAŞLAT butonuna otomatik odak veriliyor, kumandayla
  hemen gezinmeye başlanabiliyor.
- `AndroidManifest.xml`'deki mikrofon donanımı zorunluluğu (`required=true`)
  `false` yapıldı -- yerleşik mikrofonu olmayan Android TV/Google TV
  cihazlarında kurulumu engellemesin diye. Ayrıca dokunmatik ekran donanımı
  da artık zorunlu değil.

---

## Bu sürümde eklenenler (v23)

**Anthropic (Claude) API bağımlılığı kaldırıldı**
- v22'de oyun/uygulama kodu üretimini asıl modele değil ayrı bir Claude API'sine yaptıran
  `create_game` fonksiyonu ve `ClaudeGameClient.kt` tamamen kaldırıldı --
  kullanıcının kendi Claude API anahtarı çok hızlı tükeniyordu (ücretli/
  kotalı).
- Claude'a verilen kalite kuralları (jenerik şablona kaçmama, placeholder
  yasağı, tam çalışan tek dosyalık HTML5 oyun, dokunmatik+klavye kontrolü
  vb.) AYNEN korunup doğrudan asıl modelin `create_zip` talimatına taşındı --
  yani kalite kuralları kayıp olmadı, sadece hangi modelin uyguladığı
  değişti (artık tamamen tek bir ücretsiz Gemini anahtarı).
- Giriş ekranındaki (ApiKeyScreen) ikinci "Anthropic API anahtarı" alanı ve
  buna bağlı tüm saklama/aktarma kodu kaldırıldı; uygulama tekrar tek bir
  (ücretsiz Gemini) API anahtarıyla çalışıyor.

---

## Bu sürümde eklenenler (v14)

**1. Fotoğraf / çoklu dosya üretimi**
- `create_file` artık her türlü dosyayı (txt, json, html… ve `content_base64`
  ile herhangi bir ikili dosyayı) İndirilenler'e kaydedebiliyor.
- `create_zip` metin + ikili dosyaları karışık olarak tek arşivde toplayabiliyor.
- Yeni `create_image` aracı: Pollinations.ai (API anahtarı gerekmez) ile
  gerçek bir AI görseli üretip galeriye kaydediyor. "Bana ... resmi çiz"
  dediğinizde çalışır.

**2. Uygulama içi terminal**
- Üst çubuktaki **⌨** ikonuna dokunarak açılan, uygulamanın kendi sandbox'ında
  (`terminal_workspace/`) gerçek bir kabuk (`sh`) çalıştıran terminal ekranı.
- Judo da `run_terminal_command` fonksiyonuyla aynı terminali kendisi
  kullanabiliyor ("terminalde şunu çalıştır/derle" dediğinizde).
- ÖNEMLİ SINIRLAMA: telefonda root/Gradle/JDK olmadığı için bu, gerçek bir
  Android/Gradle derlemesi (APK build) YAPAMAZ — sadece dosya/klasör
  işlemleri ve basit script'ler için gerçek bir kabuktur.

**3. Kalıcı hafıza**
- Konuşma geçmişi artık cihazda kalıcı olarak saklanıyor (uygulama kapatılıp
  açılsa bile Judo önceki konuşmaları hatırlıyor), tutulan tur sayısı 40'a
  çıkarıldı.
- Müzik: "çal" dedikten sonra "kapat" deyip tekrar sadece "çal" derseniz
  (şarkı adı vermeden), en son çalınan şarkı otomatik olarak hatırlanıp
  yeniden başlatılıyor — tekrar şarkı adı sormuyor.

**4. Hava durumu widget'ı**
- Sohbette açıkça bir şehrin hava durumunu sorduğunuzda (örn. "İstanbul'da
  hava nasıl"), sol alttaki widget artık IP'den tahmin edilen konum yerine
  o şehri gösteriyor ve bunu kalıcı olarak hatırlıyor.

---

## Bu sürümde eklenenler (v16)

**1. Oyun / uygulama projesi üretme (zip → apk)**
- "Bana şöyle bir korku oyunu yap, zip olarak ver" dediğinizde, Judo artık
  `create_zip` fonksiyonuyla **gerçekten çalışan, tek dosyalık
  (`index.html` içine gömülü CSS+JS) bir HTML5 oyunu** üretip İndirilenler'e
  zip olarak kaydediyor. Bu index.html tamamen internetsiz çalışacak şekilde
  yazılıyor (harici bağlantı yok), dokunmatik ve klavye kontrolleri birlikte
  geliyor.
- Zip'i indirdikten sonra `index.html`'i bir **WebView sarmalayıcı** aracıyla
  (Android Studio'nun boş WebView şablonu, ya da bir "web sitesini apk'ya
  çevir" aracı) kendi tarafınızda apk'ya çeviriyorsunuz — Judo'in kendisi
  hâlâ gerçek bir Gradle/Android derlemesi yapmıyor (telefonda buna gerek
  yok, tarayıcıda/WebView'da oynanabilir tam bir oyun üretiyor).
- Kota (429) anlarında istek düşürülmüyor: model çıktı üretirken (uzun oyun
  kodu dahil) kesilmesin diye yanıt token sınırı ve ağ zaman aşımı süreleri
  büyütüldü.

---

## Bu sürümde eklenenler (v15)

**1. Sohbete fotoğraf / dosya ekleme**
- Sohbet yazı çubuğunun solundaki **📎** tuşu: **Fotoğraf** (sistem foto
  seçicisi) ya da **Dosya** (sistem dosya seçicisi) seçtirir. Ek izni gerekmez.
- Seçilenler yazı çubuğunun üstünde küçük etiketler olarak durur (dokununca
  kaldırılır), gönder tuşuna basınca mesajla birlikte gider. Sadece ek göndermek
  de mümkün ("Bunu incele ve kısaca anlat" varsayılan istemi kullanılır).
- Fotoğraflar (ve PDF'in ilk 2 sayfası) küçültülüp Gemini'nin görsel destekli
  modeline (`meta-llama/llama-4-scout-17b-16e-instruct`, yedek `qwen/qwen3.6-27b`, `qwen/qwen3.8-27b`; 404 veren model otomatik atlanır) gönderilir. Bir
  mesajda en fazla 3 görsel/sayfa.
- Metin ve kod dosyaları (txt, md, json, csv, kt, py, html…) mesajın içine
  yazılır (ilk ~8000 karakter). Word/Excel gibi biçimler henüz okunamıyor.
- Geçmişe ve DataStore'a sadece kısa not yazılır ("[Ekler: kedi.jpg]");
  fotoğraf/dosya içeriği kalıcı olarak saklanmaz.

**2. Klavyeyle birlikte hareket eden yazı çubuğu**
- Klavye açılınca yazı çubuğu ekranın altına, klavyenin hemen üstüne, tam
  genişlikte çıkar; klavye kapanınca sağ sohbet panelinin altındaki küçük
  yerine geri döner. (Eskiden klavye çubuğun üstünü kapatıyordu.)

---
## v50
"Telefonu kendin kullan" (erisilebilirlik servisi) ozelligi KALDIRILDI: Play Protect "Yine de yukle" secenegini engelliyordu. open_website artik siteyi dogrudan tarayicida acar.

## v51
Dikey ekran eklendi (ilk acilista varsayilan). ☰ menusunden Yatay/Dikey gecis yapilir; tercih kaydedilir. Yatay ekran degismedi.
