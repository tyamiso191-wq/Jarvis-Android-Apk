package com.jarvis.ai.live

import android.content.Context
import android.util.Log
import com.jarvis.ai.files.FileTool
import com.jarvis.ai.music.MusicController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Gemini'nin NORMAL, düz metin API'si (generateContent, REST) ile konuşur.
 *
 * NEDEN BU SINIF VAR: Live API'nin (BidiGenerateContent, WebSocket, native
 * audio) bu projenin key'inde sürekli "WebSocket açılıyor ama setupComplete
 * hiç gelmiyor" şeklinde bir entitlement/preview-access sorunu çıkarıyordu
 * (bkz. eski GeminiLiveClient.kt — artık kaldırıldı). generateContent ise
 * Gemini'nin en temel, herkesin ücretsiz tier key'inde stabil çalışan
 * endpoint'i; preview erişimi gerektirmiyor. Ses girişi/çıkışı artık
 * VoiceEngine (Android'in kendi ücretsiz SpeechRecognizer + TextToSpeech'i)
 * üzerinden yapılıyor — bu sınıf sadece metin ↔ metin konuşuyor, sesle hiç
 * ilgilenmiyor.
 *
 * FONKSİYON ÇAĞIRMA (function calling): google_search'e ek olarak modele
 * create_file / create_zip / play_song fonksiyonlarını da tanımlıyoruz.
 * Model bunlardan birini çağırmak isterse (functionCall), bu sınıf onu
 * GERÇEKTEN çalıştırır (FileTool / MusicController üzerinden, appContext
 * ile), sonucu modele geri besler ve modelin bunu doğal dille özetlediği
 * NİHAİ cevabı döndürür — çağıran taraf (ViewModel) tek bir sendMessage()
 * çağrısıyla hem "dosya oluştur" hem "cevabı söyle" akışını tek seferde alır.
 */
class GeminiTextClient(
    private val apiKey: String,
    private val persona: String,
    private val appContext: Context
) {
    companion object {
        private const val TAG = "GeminiTextClient"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

        // HTTP 429 alan bir model bu süre boyunca tekrar denenmez.
        private const val COOLDOWN_MS = 60_000L

        // Bir sendMessage() çağrısında en fazla bu kadar farklı model
        // denenir. Onlarca modeli gecikmesiz art arda denemek, hiçbiri
        // "kötü" olmasa dahi hesabın dakikalık istek limitini (RPM) tek
        // başına tetikleyebilir. 2: normalde çalışan model 1. denemede
        // başarılı olur; 2. deneme sadece o model gerçekten deprecate/
        // kota dolu olduğunda tek bir yedek sağlar.
        private const val MAX_ATTEMPTS_PER_MESSAGE = 2

        // Art arda bu kadar model 429 döndürürse, sorun tek bir modelin
        // kotası değil hesabın genel limiti demektir — daha fazla denemek
        // yerine erken kesip anlamlı bir hata döndürüyoruz.
        private const val MAX_CONSECUTIVE_429 = 2

        // Başarısız denemeler arasında küçük bir bekleme; art arda
        // patlama (burst) halinde istek atıp rate-limit'i tetiklememek için.
        private const val ATTEMPT_DELAY_MS = 400L

        // Kalıcı önbelleğin (SharedPreferences) ne kadar süre "taze"
        // sayılacağı. Bu süre içinde uygulama yeniden başlasa bile
        // discoverTextModels() TEKRAR ÇAĞRILMAZ, doğrudan son bilinen
        // çalışan modelle denenir — böylece her açılışta/mesajda gereksiz
        // istek atılmaz.
        private const val CACHE_TTL_MS = 24 * 60 * 60 * 1000L
        private const val PREFS_NAME = "gemini_text_client_cache"
        private const val PREF_CANDIDATES = "candidates"
        private const val PREF_WORKING_MODEL = "working_model"
        private const val PREF_TIMESTAMP = "timestamp"
    }

    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)   // Google Search grounding bazen ekstra sürüyor
        .callTimeout(50, TimeUnit.SECONDS)
        .build()

    // Süreç boyunca hatırlanan, en son başarılı olan model. Bir dahaki
    // sendMessage() çağrısında önce bu denenir. Uygulama yeniden başlasa
    // bile kaybolmasın diye SharedPreferences'tan (bkz. loadPersistedCache())
    // önceden doldurulur.
    @Volatile private var workingModel: String? = null

    // GET /v1beta/models sonucunun önbelleği. Google model adlarını sık
    // değiştirdiği için (bkz. Live API'de yaşanan "gemini-2.0-flash artık
    // yok" sorunu — aynısı burada da oldu) TEK BİR SABİT İSME GÜVENMİYORUZ;
    // her istekte gerçekten kullanılabilir olan generateContent modellerini
    // sorup en olası adaydan başlayarak deniyoruz. Aynı süreçte tekrar tekrar
    // ağ çağrısı yapmamak için sonucu önbellekliyoruz; önbellekteki hiçbir
    // model çalışmazsa (hepsi deprecate olmuş olabilir) önbelleği ATIP bir
    // kez daha taze listeyi çekiyoruz.
    //
    // KALICI ÖNBELLEK: discoverTextModels() bu key'e açık modelleri listelemek
    // için ayrı bir GET isteği atıyor. Bu istek generateContent kotasını
    // TÜKETMESE de, her uygulama açılışında/reconnect'te tekrar atılması
    // gereksiz gecikme ve trafik demek. Bu yüzden sonucu CACHE_TTL_MS süreyle
    // SharedPreferences'a da yazıyoruz (bkz. loadPersistedCache/
    // persistCandidates) — uygulama yeniden başlasa bile taze sayılan bir
    // önbellek varsa discoverTextModels() hiç çağrılmıyor.
    @Volatile private var cachedCandidates: List<String>? = null

    init {
        loadPersistedCache()
    }

    private fun loadPersistedCache() {
        val ts = prefs.getLong(PREF_TIMESTAMP, 0L)
        if (System.currentTimeMillis() - ts > CACHE_TTL_MS) return // bayat, yok say
        val saved = prefs.getString(PREF_CANDIDATES, null)
        if (!saved.isNullOrBlank()) {
            cachedCandidates = saved.split(",").filter { it.isNotBlank() }
        }
        workingModel = prefs.getString(PREF_WORKING_MODEL, null)
    }

    private fun persistCandidates(candidates: List<String>) {
        prefs.edit()
            .putString(PREF_CANDIDATES, candidates.joinToString(","))
            .putLong(PREF_TIMESTAMP, System.currentTimeMillis())
            .apply()
    }

    private fun persistWorkingModel(model: String) {
        prefs.edit().putString(PREF_WORKING_MODEL, model).apply()
    }

    // HTTP 429 (kota aşıldı) alınan modeller burada, tekrar denenebilecekleri
    // zaman damgasıyla tutulur. "nano-banana-pro-preview" olayında olduğu
    // gibi listeye sızan ama kotası anında dolan bir model varsa, bu model
    // COOLDOWN_MS boyunca tekrar tekrar denenip zaman kaybettirmesin diye.
    private val modelCooldownUntil = ConcurrentHashMap<String, Long>()

    private fun isOnCooldown(model: String): Boolean {
        val until = modelCooldownUntil[model] ?: return false
        return System.currentTimeMillis() < until
    }

    private fun markCooldown(model: String) {
        modelCooldownUntil[model] = System.currentTimeMillis() + COOLDOWN_MS
    }

    /** Basit bir GET ile key'in geçerli olup olmadığını hızlıca doğrular. */
    suspend fun verifyKey(): String? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .build()
            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    null
                } else {
                    val body = try { resp.body?.string()?.take(300) } catch (e: Exception) { null }
                    "API anahtarı kontrolü başarısız: HTTP ${resp.code}${if (!body.isNullOrBlank()) " — $body" else ""}"
                }
            }
        } catch (e: Exception) {
            "Ağa ulaşılamıyor (${e.javaClass.simpleName}: ${e.message}). İnternet bağlantını kontrol et."
        }
    }

    /**
     * GET /v1beta/models üzerinden bu key'e gerçekten açık olan, metinle
     * konuşabilen (generateContent destekleyen) modelleri çeker ve en olası
     * çalışacak adaydan en az olasıya sıralar.
     *
     * embedding/tts/görsel-üretim/native-audio/live/transcribe gibi sohbet
     * için uygun olmayan modeller elenir. "flash" ailesi (hızlı/ucuz, geniş
     * kotalı) ve "-latest" alias'ı (her zaman güncel modele işaret eder)
     * öne alınır; "pro"/"exp"/"preview" biraz geride tutulur ama tamamen
     * elenmez.
     *
     * WHITELIST + BLACKLIST birlikte: "nano-banana-pro-preview" olayından
     * (bir görsel üretim modelinin adında sohbet modeliyle ortak hiçbir
     * anahtar kelime olmaması, sadece "banana" hariç tutularak yamanması)
     * sonra, TEK BAŞINA büyüyen bir dışlama listesine güvenmek yerine önce
     * adında "gemini" GEÇMEYEN hiçbir modeli kabul etmiyoruz (inclusion).
     * Böylece Google ileride yeni bir kod adıyla (ör. "banana" yerine
     * başka bir meyve/kod adı) başka bir görsel/ses modelini generateContent
     * altına eklerse, bu model "gemini" içermiyorsa otomatik elenir.
     * excluded listesi ise "gemini-*" ÖNEKİYLE YAYINLANAN ama yine de
     * sohbete uygun olmayan alt modelleri (gemini-*-tts, gemini-*-live,
     * gemini-*-image gibi) elemeye devam eder.
     */
    private suspend fun discoverTextModels(): List<String> = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("$BASE_URL?key=$apiKey")
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                throw IOException("Model listesi HTTP ${resp.code} döndürdü")
            }
            val json = JSONObject(resp.body?.string() ?: "{}")
            val modelsArray = json.optJSONArray("models") ?: JSONArray()

            val excluded = listOf(
                "embedding", "aqa", "tts", "image-generation", "imagen",
                "image", "native-audio", "-live", "transcribe", "video", "gemma",
                "banana", "computer-use", "vision-only", "audio",
                // "gemini-3.1-pro-preview-customtools" olayı: bash/ajan araç
                // kullanımına özel, pahalı (Pro seviyesi) bir preview uç
                // noktası — genel sohbet için değil, ücretsiz kotası pratikte
                // sıfıra yakın. Aynı "nano-banana" mantığıyla baştan ele.
                "customtools", "-tools", "coder"
            )

            val allGenerateContentModels = mutableListOf<String>()
            val scored = mutableListOf<Pair<String, Int>>()
            for (i in 0 until modelsArray.length()) {
                val m = modelsArray.optJSONObject(i) ?: continue
                val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
                var supportsGenerate = false
                for (j in 0 until methods.length()) {
                    if (methods.optString(j) == "generateContent") {
                        supportsGenerate = true
                        break
                    }
                }
                if (!supportsGenerate) continue

                val rawName = m.optString("name").takeIf { it.isNotBlank() } ?: continue
                val name = rawName.removePrefix("models/")
                val lower = name.lowercase()
                allGenerateContentModels += name

                // INCLUSION: sadece resmi "gemini" ailesini kabul et. Kod
                // adlı (ör. "banana") deneysel modeller adında "gemini"
                // geçmediği için burada kategorik olarak elenir.
                if (!lower.contains("gemini")) continue
                // BLACKLIST: gemini-* önekiyle gelen ama sohbete uygun
                // olmayan alt aileleri ele (tts/live/image/audio/vb).
                if (excluded.any { lower.contains(it) }) continue

                var score = 0
                if (lower.contains("latest")) score += 60
                if (lower.contains("flash")) score += 50
                if (lower.contains("lite")) score += 5
                if (lower.contains("pro")) score -= 10
                if (lower.contains("exp") || lower.contains("preview")) score -= 20
                if (lower.contains("thinking")) score -= 5
                scored += name to score
            }

            // Debug: bu API key'e generateContent için açık olan TÜM
            // modelleri (filtre öncesi) logla — sorun tekrarlarsa hangi
            // modellerin göründüğünü görmek için Logcat'te "GeminiTextClient"
            // etiketiyle aranabilir.
            Log.i(TAG, "generateContent destekleyen ham model listesi: $allGenerateContentModels")

            val result = scored
                .sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenBy { it.first })
                .map { it.first }
            Log.i(TAG, "Filtrelenmiş/sıralanmış aday modeller: $result")
            result
        }
    }

    /**
     * conversation: sırayla ("user", metin) / ("model", metin) geçmişi.
     * Tüm geçmişi değil, çağıran taraf (ViewModel) zaten sadece son birkaç
     * turu gönderiyor — istek küçük ve hızlı kalsın diye.
     *
     * deviceContext: her çağrıda TAZE üretilen "şu an saat/tarih/telefon/
     * depolama/pil" bloğu (bkz. DeviceInfo.kt). Persona'nın (sabit kişilik
     * talimatı) sonuna eklenir, böylece model her seferinde güncel cihaz
     * durumunu bilir.
     */
    suspend fun sendMessage(
        conversation: List<Pair<String, String>>,
        deviceContext: String = ""
    ): Result<String> =
        withContext(Dispatchers.IO) {
            val fullInstruction = if (deviceContext.isBlank()) persona else "$persona\n\n$deviceContext"

            var candidates = cachedCandidates
            var usedCache = candidates != null
            if (candidates == null) {
                candidates = try {
                    discoverTextModels()
                } catch (e: Exception) {
                    return@withContext Result.failure(
                        IOException("Model listesi alınamadı: ${e.javaClass.simpleName}: ${e.message}")
                    )
                }
                cachedCandidates = candidates
                persistCandidates(candidates)
            }
            if (candidates.isEmpty()) {
                return@withContext Result.failure(
                    IOException("Bu API anahtarında generateContent destekleyen hiçbir model bulunamadı.")
                )
            }

            val baseOrder = workingModel?.let { pref ->
                listOf(pref) + candidates.filterNot { it == pref }
            } ?: candidates

            // 429 (kota aşıldı) alıp cooldown'da olan modelleri en sona at
            // (tamamen çıkarma — hepsi cooldown'daysa yine de bir şey
            // denenebilsin diye), böylece kotası dolu bir model art arda
            // tekrar tekrar denenip zaman/istek kaybettirmez.
            // Ayrıca deneme sayısını MAX_ATTEMPTS_PER_MESSAGE ile sınırlıyoruz:
            // onlarca modeli gecikmesiz art arda denemek, hiçbiri "kötü" model
            // olmasa bile hesabın dakikalık istek limitini (RPM) TEK BAŞINA
          // tetikleyip zincirleme 429'a yol açabilir.
            val order = baseOrder
                .sortedBy { if (isOnCooldown(it)) 1 else 0 }
                .take(MAX_ATTEMPTS_PER_MESSAGE)

            var lastError: String? = null
            var consecutive429 = 0
            for (model in order) {
                val result = callModel(model, conversation, fullInstruction)
                if (result.isSuccess) {
                    workingModel = model
                    persistWorkingModel(model)
                    return@withContext result
                }
                lastError = result.exceptionOrNull()?.message
                if (lastError?.contains("HTTP 429") == true) {
                    markCooldown(model)
                    consecutive429++
                    // Art arda birden fazla FARKLI modelden 429 gelmesi,
                    // tek bir modelin kotası değil, hesabın/anahtarın genel
                    // dakikalık istek limitine takıldığına işaret eder —
                    // bu durumda kalan adayları da denemek sadece limiti
                    // daha da doldurur, o yüzden erken kes.
                    if (consecutive429 >= MAX_CONSECUTIVE_429) {
                        Log.w(TAG, "Art arda $consecutive429 model 429 döndürdü, muhtemelen hesap genelinde kota/rate-limit doldu — deneme durduruldu.")
                        break
                    }
                } else {
                    consecutive429 = 0
                }
                if (result.isFailure) delay(ATTEMPT_DELAY_MS)
                Log.w(TAG, "Model başarısız, sıradaki deneniyor: $model → $lastError")
            }

            // Önbellekteki hiçbir model çalışmadıysa (muhtemelen hepsi
            // deprecate olmuş) önbelleği atıp bir kez daha taze liste
            // çekiyoruz — Google'ın model adlarını değiştirmesi artık
            // uygulamayı hiç kırmasın diye. Hesap genelinde kota/rate-limit
            // doldu diye erken kesildiyse bunu TEKRAR denemiyoruz (zaten
            // aynı sorunla karşılaşır, sadece daha fazla istek harcanır).
            if (usedCache && consecutive429 < MAX_CONSECUTIVE_429) {
                val fresh = try { discoverTextModels() } catch (e: Exception) { null }
                if (!fresh.isNullOrEmpty() && fresh != candidates) {
                    cachedCandidates = fresh
                    persistCandidates(fresh)
                    workingModel = null
                    val freshOrder = fresh
                        .sortedBy { if (isOnCooldown(it)) 1 else 0 }
                        .take(MAX_ATTEMPTS_PER_MESSAGE)
                    for (model in freshOrder) {
                        val result = callModel(model, conversation, fullInstruction)
                        if (result.isSuccess) {
                            workingModel = model
                            persistWorkingModel(model)
                            return@withContext result
                        }
                        lastError = result.exceptionOrNull()?.message
                        if (lastError?.contains("HTTP 429") == true) {
                            markCooldown(model)
                            consecutive429++
                            if (consecutive429 >= MAX_CONSECUTIVE_429) break
                        } else {
                            consecutive429 = 0
                        }
                        delay(ATTEMPT_DELAY_MS)
                    }
                }
            }

            val finalMessage = if (consecutive429 >= MAX_CONSECUTIVE_429) {
                "Birden fazla model art arda 429 (kota aşıldı) döndürdü — büyük olasılıkla belirli bir model değil, API anahtarının genel istek/kota limiti doldu. Google AI Studio'dan anahtarın kota ve plan durumunu kontrol et, ya da biraz bekleyip tekrar dene. Son hata: $lastError"
            } else {
                lastError ?: "Bilinmeyen hata"
            }


            Result.failure(IOException(finalMessage))
        }

    private fun callModel(
        model: String,
        conversation: List<Pair<String, String>>,
        systemInstruction: String
    ): Result<String> = try {
        val contents = JSONArray().apply {
            conversation.forEach { (role, text) ->
                put(JSONObject().apply {
                    put("role", role)
                    put("parts", JSONArray().put(JSONObject().put("text", text)))
                })
            }
        }

        var lastText = ""
        // En fazla 4 tur: normal cevap 1 turda gelir; bir fonksiyon çağrısı
        // (dosya oluştur / şarkı çal) 1 ekstra tur daha gerektirir. 4, art
        // arda birkaç fonksiyon çağrısı zincirlenirse bile makul bir üst sınır.
        repeat(4) {
            val body = JSONObject().apply {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
                })
                put("contents", contents)
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.8)
                    put("maxOutputTokens", 400)
                })
                // google_search (canlı arama) + functionDeclarations (dosya/
                // müzik) aynı istekte birlikte gönderiliyor — Gemini 2.x/3.x
                // flash ailesi ikisini birlikte destekliyor.
                put("tools", buildTools())
            }

            val req = Request.Builder()
                .url("$BASE_URL/$model:generateContent?key=$apiKey")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val modelContent = client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return Result.failure(IOException("$model → HTTP ${resp.code}: ${raw.take(200)}"))
                }
                JSONObject(raw).optJSONArray("candidates")
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
            } ?: return Result.failure(IOException("$model → boş yanıt döndü"))

            val parts = modelContent.optJSONArray("parts") ?: JSONArray()
            val text = buildString {
                for (i in 0 until parts.length()) {
                    val t = parts.optJSONObject(i)?.optString("text", "") ?: ""
                    if (t.isNotEmpty()) append(t)
                }
            }

            val functionCalls = mutableListOf<JSONObject>()
            for (i in 0 until parts.length()) {
                parts.optJSONObject(i)?.optJSONObject("functionCall")?.let { functionCalls += it }
            }

            if (functionCalls.isEmpty()) {
                if (text.isBlank()) {
                    return Result.failure(IOException("$model → boş yanıt döndü"))
                }
                return Result.success(text)
            }

            // Modelin fonksiyon çağırma turunu sohbet geçmişine ekle.
            contents.put(JSONObject().apply {
                put("role", "model")
                put("parts", parts)
            })

            // Her fonksiyon çağrısını GERÇEKTEN çalıştır, sonucu modele geri besle.
            val responseParts = JSONArray()
            for (fc in functionCalls) {
                val name = fc.optString("name")
                val args = fc.optJSONObject("args") ?: JSONObject()
                val outcome = executeFunction(name, args)
                responseParts.put(JSONObject().apply {
                    put("functionResponse", JSONObject().apply {
                        put("name", name)
                        put("response", outcome)
                    })
                })
            }
            contents.put(JSONObject().apply {
                put("role", "user")
                put("parts", responseParts)
            })

            lastText = text
        }

        if (lastText.isNotBlank()) Result.success(lastText)
        else Result.failure(IOException("$model → fonksiyon döngüsü tamamlanamadı"))
    } catch (e: Exception) {
        Result.failure(e)
    }

    private fun buildTools(): JSONArray {
        val functionDeclarations = JSONArray()
            .put(JSONObject().apply {
                put("name", "create_file")
                put(
                    "description",
                    "Kullanıcı için düz metin bir dosya (örn. .txt, .md, .json, .csv) oluşturup İndirilenler klasörüne kaydeder. Kullanıcı açıkça bir not/liste/metin kaydetmeni istediğinde çağır."
                )
                put("parameters", JSONObject().apply {
                    put("type", "OBJECT")
                    put("properties", JSONObject().apply {
                        put("filename", JSONObject().apply {
                            put("type", "STRING")
                            put("description", "Uzantılı dosya adı, örn. notlar.txt")
                        })
                        put("content", JSONObject().apply {
                            put("type", "STRING")
                            put("description", "Dosyanın tam içeriği")
                        })
                    })
                    put("required", JSONArray().put("filename").put("content"))
                })
            })
            .put(JSONObject().apply {
                put("name", "create_zip")
                put(
                    "description",
                    "Birden fazla metin dosyasını tek bir zip arşivinde birleştirip İndirilenler klasörüne kaydeder."
                )
                put("parameters", JSONObject().apply {
                    put("type", "OBJECT")
                    put("properties", JSONObject().apply {
                        put("zip_filename", JSONObject().apply {
                            put("type", "STRING")
                            put("description", "Arşiv adı, .zip uzantılı ya da uzantısız")
                        })
                        put("files", JSONObject().apply {
                            put("type", "ARRAY")
                            put("items", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("filename", JSONObject().put("type", "STRING"))
                                    put("content", JSONObject().put("type", "STRING"))
                                })
                                put("required", JSONArray().put("filename").put("content"))
                            })
                        })
                    })
                    put("required", JSONArray().put("zip_filename").put("files"))
                })
            })
            .put(JSONObject().apply {
                put("name", "play_song")
                put(
                    "description",
                    "Kullanıcının istediği şarkıyı çalmaya başlar: önce telefonun yerel müzik kütüphanesinde arar (bulursa arka planda çalar), yoksa YouTube'da açar."
                )
                put("parameters", JSONObject().apply {
                    put("type", "OBJECT")
                    put("properties", JSONObject().apply {
                        put("query", JSONObject().apply {
                            put("type", "STRING")
                            put("description", "Şarkı adı ve varsa sanatçı, örn. 'Tarkan Kuzu Kuzu'")
                        })
                    })
                    put("required", JSONArray().put("query"))
                })
            })

        return JSONArray()
            .put(JSONObject().put("google_search", JSONObject()))
            .put(JSONObject().put("functionDeclarations", functionDeclarations))
    }

    private fun executeFunction(name: String, args: JSONObject): JSONObject = try {
        when (name) {
            "create_file" -> {
                val filename = args.optString("filename").ifBlank { "not.txt" }
                val content = args.optString("content")
                val saved = FileTool.createTextFile(appContext, filename, content)
                JSONObject().put("status", "ok").put("path", saved.displayPath)
            }
            "create_zip" -> {
                val zipName = args.optString("zip_filename").ifBlank { "arsiv.zip" }
                val filesArr = args.optJSONArray("files") ?: JSONArray()
                val entries = mutableListOf<Pair<String, String>>()
                for (i in 0 until filesArr.length()) {
                    val f = filesArr.optJSONObject(i) ?: continue
                    entries += f.optString("filename", "dosya_$i.txt") to f.optString("content")
                }
                val saved = FileTool.createZipFile(appContext, zipName, entries)
                JSONObject().put("status", "ok").put("path", saved.displayPath)
            }
            "play_song" -> {
                val query = args.optString("query")
                when (val result = MusicController.play(appContext, query)) {
                    is MusicController.PlayResult.PlayingLocal ->
                        JSONObject().put("status", "playing_local")
                            .put("title", result.title).put("artist", result.artist)
                    is MusicController.PlayResult.OpenedYoutubeSearch ->
                        JSONObject().put("status", "opened_youtube_search").put("query", result.query)
                    is MusicController.PlayResult.PermissionMissing ->
                        JSONObject().put("status", "error").put("message", result.message)
                    is MusicController.PlayResult.Error ->
                        JSONObject().put("status", "error").put("message", result.message)
                }
            }
            else -> JSONObject().put("status", "error").put("message", "Bilinmeyen fonksiyon: $name")
        }
    } catch (e: Exception) {
        JSONObject().put("status", "error").put("message", e.message ?: "bilinmeyen hata")
    }
}
