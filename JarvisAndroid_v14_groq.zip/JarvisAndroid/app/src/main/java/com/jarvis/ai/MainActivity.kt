package com.jarvis.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.jarvis.ai.theme.JarvisTheme
import com.jarvis.ai.ui.ApiKeyScreen
import com.jarvis.ai.ui.MainScreen
import com.jarvis.ai.ui.TerminalScreen

class MainActivity : ComponentActivity() {

    private val vm: JarvisViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            // Mic permission granted – user can toggle mic
        }
    }

    // Yerel müzik kütüphanesini okuma + (API 33+) bildirim izni. play_song
    // fonksiyonu her çağrıldığında kullanıcıya izin sormak Android'de mümkün
    // değil (arka planda, konuşma ortasında bir dialog açmak kötü bir deneyim
    // olurdu) — bu yüzden açılışta bir kez soruyoruz. Reddedilirse
    // MusicController otomatik olarak YouTube arama moduna düşüyor, uygulama
    // kırılmıyor.
    private val musicPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* sonuçla ilgilenmemize gerek yok; MusicController kendi kontrol ediyor */ }

    private fun requestMusicPermissionsIfNeeded() {
        val perms = mutableListOf<String>()
        perms += if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms += Manifest.permission.POST_NOTIFICATIONS
        }
        val notGranted = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (notGranted.isNotEmpty()) {
            musicPermissionLauncher.launch(notGranted.toTypedArray())
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        enableImmersiveMode()
        requestMusicPermissionsIfNeeded()

        setContent {
            JarvisTheme {
                val needsKey by vm.needsKey.collectAsState()
                val orbState by vm.orbState.collectAsState()
                val status by vm.status.collectAsState()
                val logs by vm.logs.collectAsState()
                val micOn by vm.micOn.collectAsState()
                val level by vm.audioLevel.collectAsState()
                val apiKey by vm.apiKey.collectAsState()
                val isConnected by vm.isConnected.collectAsState()
                val weather by vm.weather.collectAsState()
                val speedLabel by vm.speedLabel.collectAsState()
                val voiceLabel by vm.voiceLabel.collectAsState()
                val showTerminal by vm.showTerminal.collectAsState()
                val terminalHistory by vm.terminalHistory.collectAsState()

                LaunchedEffect(apiKey) {
                    if (!apiKey.isNullOrBlank()) {
                        vm.connect(apiKey!!)
                    }
                }

                if (needsKey) {
                    ApiKeyScreen(onSave = { key ->
                        vm.saveApiKey(key)
                    })
                } else if (showTerminal) {
                    TerminalScreen(
                        history = terminalHistory,
                        onRunCommand = { vm.runTerminalCommand(it) },
                        onClose = { vm.toggleTerminal() }
                    )
                } else {
                    MainScreen(
                        orbState = orbState,
                        status = status,
                        logs = logs,
                        micOn = micOn,
                        isConnected = isConnected,
                        audioLevel = level,
                        weather = weather,
                        speedLabel = speedLabel,
                        onCycleSpeed = { vm.cycleSpeed() },
                        voiceLabel = voiceLabel,
                        onCycleVoice = { vm.cycleVoice() },
                        onToggleMic = {
                            ensureMicPermission {
                                vm.toggleMic()
                            }
                        },
                        onStart = { vm.connect() },
                        onStop = { vm.stop() },
                        onSendText = { vm.sendText(it) },
                        onChangeKey = { vm.clearApiKey() },
                        onOpenTerminal = { vm.toggleTerminal() }
                    )
                }
            }
        }
    }

    private fun ensureMicPermission(onGranted: () -> Unit) {
        when {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED -> onGranted()
            else -> permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    /**
     * Sistem çubuklarını (nav bar + status bar) gizler. Oyunlardaki gibi:
     * kenardan içeri kaydırınca geçici olarak görünür, sonra kendiliğinden
     * tekrar gizlenir. Kullanıcı ekranın yanındaki geri/ana ekran tuşlarını
     * sürekli görmek istemiyordu.
     */
    private fun enableImmersiveMode() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Sistem çubukları başka bir pencere/dialog vs. yüzünden tekrar açığa
        // çıkarsa (odak geri geldiğinde), immersive modu yeniden uygula.
        if (hasFocus) enableImmersiveMode()
    }
}
