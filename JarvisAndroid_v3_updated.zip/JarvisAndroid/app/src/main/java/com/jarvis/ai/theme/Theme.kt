package com.jarvis.ai.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val JarvisColorScheme = darkColorScheme(
    primary = Teal,
    onPrimary = Bg,
    secondary = TealDim,
    background = Bg,
    surface = Panel,
    onBackground = Text,
    onSurface = Text,
    error = Red
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = JarvisColorScheme,
        content = content
    )
}
