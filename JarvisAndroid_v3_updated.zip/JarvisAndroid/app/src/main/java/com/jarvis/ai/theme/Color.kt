package com.jarvis.ai.theme

import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF010A0A)
val Panel = Color(0xFF030F0F)
val Teal = Color(0xFF00D4C0)
val TealDim = Color(0xFF006A62)
val TealMid = Color(0xFF0A2A28)
val Text = Color(0xFF7DFFF6)
val Dim = Color(0xFF3A8A82)
val Green = Color(0xFF00FF88)
val Red = Color(0xFFFF3344)
val Gold = Color(0xFFFFCC00)
val Blue = Color(0xFF4488FF)
val Orange = Color(0xFFFF6600)
val Muted = Color(0xFFCC2255)
