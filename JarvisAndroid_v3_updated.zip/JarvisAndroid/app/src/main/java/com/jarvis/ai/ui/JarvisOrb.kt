package com.jarvis.ai.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import com.jarvis.ai.theme.*
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Radar ekranındaki sabit "blip" (yıldız/nokta): pozisyonu sabit, sadece parlaklığı titrer. */
private data class Star(
    val angle: Float,   // radyan
    val r: Float,        // 0..1 (baseR'ye göre oran)
    val size: Float,
    val phase: Float,    // titreme faz farkı
    val speed: Float,    // titreme hızı çarpanı
    val baseAlpha: Float
)

/** Sabit tohumla bir kez üretilir; pozisyonlar hiç değişmez, sadece twinkle fazı değişir. */
private fun generateStars(seed: Long, count: Int): List<Star> {
    val rnd = Random(seed)
    return List(count) {
        Star(
            angle = rnd.nextFloat() * (Math.PI * 2).toFloat(),
            r = 0.12f + rnd.nextFloat() * 0.92f,
            size = 1f + rnd.nextFloat() * 2.4f,
            phase = rnd.nextFloat() * (Math.PI * 2).toFloat(),
            speed = 0.5f + rnd.nextFloat() * 1.6f,
            baseAlpha = 0.25f + rnd.nextFloat() * 0.55f
        )
    }
}

/**
 * JARVIS tarzı dönen radar / yıldız haritası orb'u.
 * - Noktaların (star) YERİ sabit, sadece parlaklığı titrer (radar blip hissi).
 * - İnce eş merkezli halkalar + kırık dış tık halkası yavaşça döner.
 * - Merkezden kenara doğru sönümlenen bir "radar süpürme" çizgi grubu döner.
 * - Renk, önceki sürümdeki gibi OrbState'e göre değişir (dinliyor=yeşil, konuşuyor=mavi, vb).
 */
@Composable
fun JarvisOrb(
    state: OrbState,
    audioLevel: Float = 0f,
    modifier: Modifier = Modifier
) {
    val infinite = rememberInfiniteTransition(label = "orb")

    // Dış tık halkasının ve radar süpürmesinin dönüşü
    val rotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(22000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rot"
    )

    // Yıldızların titremesi için sürekli artan faz (0..2π döngüsü)
    val twinkle by infinite.animateFloat(
        initialValue = 0f,
        targetValue = (Math.PI * 2).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "twinkle"
    )

    val pulse by infinite.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val stars = remember { generateStars(seed = 7L, count = 140) }
    val coreStars = remember { generateStars(seed = 99L, count = 40) }

    val color = when (state) {
        OrbState.LISTENING -> Green
        OrbState.SPEAKING -> Blue
        OrbState.THINKING -> Gold
        OrbState.MUTED -> Muted
        OrbState.ERROR -> Red
        OrbState.CONNECTING -> Orange
        OrbState.IDLE -> Teal
    }

    val level = audioLevel.coerceIn(0f, 1f)
    val scale = pulse + level * 0.2f

    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val baseR = size.minDimension / 2f * 0.46f * scale
        val center = Offset(cx, cy)

        // Dış yumuşak parlama
        for (i in 3 downTo 1) {
            drawCircle(
                color = color.copy(alpha = 0.05f + (3 - i) * 0.025f),
                radius = baseR + i * 20f + level * 10f,
                center = center,
                style = Stroke(width = 1f)
            )
        }

        // Eş merkezli radar halkaları (sabit, dönmez — radar ekranındaki mesafe çemberleri gibi)
        listOf(0.34f, 0.60f, 0.84f, 1.0f).forEach { f ->
            drawCircle(
                color = color.copy(alpha = 0.22f),
                radius = baseR * f,
                center = center,
                style = Stroke(width = 1f)
            )
        }

        // Kırık dış tık halkası (radar/dial hissi) — yavaşça döner
        rotate(rotation * 0.4f, center) {
            val ticks = 72
            for (i in 0 until ticks) {
                if (i % 3 == 0) continue
                val a = (i * 2 * Math.PI / ticks).toFloat()
                val rOut = baseR * 1.08f
                val rIn = baseR * (0.98f + (i % 5) * 0.006f)
                drawLine(
                    color = color.copy(alpha = 0.30f),
                    start = Offset(cx + cos(a) * rIn, cy + sin(a) * rIn),
                    end = Offset(cx + cos(a) * rOut, cy + sin(a) * rOut),
                    strokeWidth = 1.2f,
                    cap = StrokeCap.Round
                )
            }
        }

        // Radar süpürme: merkezden kenara, dönen ve arkasında sönümlenen çizgi grubu
        val sweepSteps = 22
        val sweepSpanDeg = 46f
        for (i in 0 until sweepSteps) {
            val fraction = i / sweepSteps.toFloat()
            val angleDeg = rotation - fraction * sweepSpanDeg
            val angleRad = Math.toRadians(angleDeg.toDouble()).toFloat()
            val alpha = (1f - fraction) * 0.45f
            drawLine(
                color = color.copy(alpha = alpha),
                start = center,
                end = Offset(cx + cos(angleRad) * baseR, cy + sin(angleRad) * baseR),
                strokeWidth = 1.4f,
                cap = StrokeCap.Round
            )
        }

        // Sabit "yıldız/blip" alanı — pozisyon sabit, sadece parlaklık titrer
        stars.forEach { s ->
            val alpha = (s.baseAlpha + sin(twinkle * s.speed + s.phase) * 0.35f).coerceIn(0.05f, 1f)
            val p = Offset(cx + cos(s.angle) * baseR * s.r, cy + sin(s.angle) * baseR * s.r)
            drawCircle(color = color.copy(alpha = alpha), radius = s.size, center = p)
        }

        // Merkeze yakın daha yoğun yıldız kümesi (referans fotoğraftaki parlak çekirdek hissi)
        coreStars.forEach { s ->
            val r = s.r * 0.30f
            val alpha = (s.baseAlpha + sin(twinkle * s.speed + s.phase) * 0.4f).coerceIn(0.1f, 1f)
            val p = Offset(cx + cos(s.angle) * baseR * r, cy + sin(s.angle) * baseR * r)
            drawCircle(color = color.copy(alpha = alpha), radius = s.size * 0.9f, center = p)
        }

        // Parlak çekirdek
        drawCircle(
            color = color.copy(alpha = 0.95f),
            radius = baseR * 0.09f,
            center = center
        )
        drawCircle(
            color = color.copy(alpha = 0.4f),
            radius = baseR * 0.15f,
            center = center,
            style = Stroke(width = 1.5f)
        )
    }
}
