package com.jarvis.ai

import android.app.Application
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.live.GeminiTextClient
import com.jarvis.ai.ui.OrbState
import com.jarvis.ai.voice.VoiceEngine
import com.jarvis.ai.weather.WeatherClient
import com.jarvis.ai.weather.WeatherInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

private val Application.dataStore by preferencesDataStore("jarvis_prefs")
private val KEY_API = stringPreferencesKey("gemini_api_key")

private val DEFAULT_SYSTEM = """
    Sen J.A.R.V.I.S'sin. Türkçe konuşan, zeki, yardımcı ve hafif esprili bir kişisel asistansın.
    Kısa ve net cevap ver (birkaç cümleyi geçme, çünkü cevabın sesli okunacak).
    Kullanıcıya "efendim" diye hitap edebilirsin. Markdown, yıldız, madde işareti KULLANMA —
    cevabın doğrudan sesli okunuyor, sadece düz konuşma dili kullan.
""".trimIndent()

/**
 * NOT (mimari değişikliği): Bu ViewModel eskiden GeminiLiveClient (WebSocket,
 * Live API, native-audio ses-ses) + AudioEngine (ham PCM kayıt/oynatma)
 * kullanıyordu. Live API bu projenin key'inde sürekli "setupComplete hiç
 * gelmiyor" şeklinde bir entitlement sorunu çıkardığı için mimari tamamen
 * değiştirildi:
 *
 *   dinle (VoiceEngine -> Android SpeechRecognizer, ücretsiz)
 *     -> metne çevir
 *     -> cevap al (GeminiTextClient -> Gemini'nin normal, ücretsiz generateContent API'si)
 *     -> sesli oku (VoiceEngine -> Android TextToSpeech, ücretsiz)
 *     -> mikrofon hâlâ açıksa otomatik tekrar dinlemeye başla
 *
 * Hiçbir adımda preview/entitlement gerektiren bir API yok; hepsi ya
 * cihazın kendi ücretsiz servisleri ya da Gemini'nin standart metin API'si.
 */
class JarvisViewModel(app: Application) : AndroidViewModel(app) {

    private val dataStore = app.dataStore
    private val voice = VoiceEngine(app)
    private var textClient: GeminiTextClient? = null

    // Son birkaç turu tutuyoruz (tam geçmiş değil) -- istek küçük/hızlı kalsın.
    private val conversation = mutableListOf<Pair<String, String>>() // "user"/"model" -> metin
    private val maxHistoryTurns = 12

    private val _apiKey = MutableStateFlow<String?>(null)
    val apiKey: StateFlow<String?> = _apiKey.asStateFlow()

    private val _orbState = MutableStateFlow(OrbState.IDLE)
    val orbState: StateFlow<OrbState> = _orbState.asStateFlow()

    private val _status = MutableStateFlow("HAZIR")
    val status: StateFlow<String> = _status.asStateFlow()

    private val _logs = MutableStateFlow<List<LogLine>>(emptyList())
    val logs: StateFlow<List<LogLine>> = _logs.asStateFlow()

    private val _micOn = MutableStateFlow(false)
    val micOn: StateFlow<Boolean> = _micOn.asStateFlow()

    private val _level = MutableStateFlow(0f)
    val audioLevel: StateFlow<Float> = _level.asStateFlow()

    private val _needsKey = MutableStateFlow(true)
    val needsKey: StateFlow<Boolean> = _needsKey.asStateFlow()

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _weather = MutableStateFlow<WeatherInfo?>(null)
    val weather: StateFlow<WeatherInfo?> = _weather.asStateFlow()

    init {
        voice.init()
        wireVoiceCallbacks()

        viewModelScope.launch {
            dataStore.data.map { it[KEY_API] }.collect { key ->
                _apiKey.value = key
                _needsKey.value = key.isNullOrBlank()
            }
        }
        // Hava durumu: açılışta bir kez çek, sonra 30 dakikada bir tazele.
        viewModelScope.launch {
            while (true) {
                _weather.value = WeatherClient.fetchCurrentWeather() ?: _weather.value
                delay(30 * 60 * 1000L)
            }
        }
    }

    private fun wireVoiceCallbacks() {
        voice.onFinalResult = { text -> sendText(text) }

        voice.onRms = { level -> _level.value = level }

        voice.onListeningError = { message, recoverable ->
            addLog("sys", message)
            if (recoverable && _micOn.value) {
                // Geçici bir durum (sessizlik/anlaşılamadı/meşgul) -- hemen tekrar dinle.
                voice.startListening()
            } else if (_micOn.value) {
                // Kalıcı bir hata (izin yok, ağ yok, vb.) -- mikrofonu kapat, kullanıcı
                // sonsuz hata döngüsüne girmesin.
                _micOn.value = false
                _orbState.value = OrbState.ERROR
                _status.value = "HATA"
            }
        }

        voice.onSpeechStart = {
            _orbState.value = OrbState.SPEAKING
            _status.value = "KONUŞUYOR"
        }

        voice.onSpeechDone = {
            if (_micOn.value) {
                _orbState.value = OrbState.LISTENING
                _status.value = "DİNLİYOR"
                voice.startListening()
            } else {
                _orbState.value = OrbState.IDLE
                _status.value = "HAZIR"
            }
        }
    }

    fun saveApiKey(key: String) {
        viewModelScope.launch {
            dataStore.edit { it[KEY_API] = key.trim() }
            _needsKey.value = false
            // NOT: connect() burada çağrılmıyor -- MainActivity'deki
            // LaunchedEffect(apiKey) zaten _apiKey güncellenince tetikleniyor.
        }
    }

    /**
     * Kayıtlı API anahtarını siler ve giriş ekranına (ApiKeyScreen) geri döner.
     */
    fun clearApiKey() {
        stop()
        textClient = null
        _isConnected.value = false
        _orbState.value = OrbState.IDLE
        _status.value = "HAZIR"
        viewModelScope.launch {
            dataStore.edit { it.remove(KEY_API) }
            _apiKey.value = null
            _needsKey.value = true
        }
    }

    /**
     * Artık kalıcı bir WebSocket bağlantısı yok -- sadece anahtarın gerçekten
     * çalışıp çalışmadığını hızlı bir GET ile doğruluyoruz. Bu sayede yanlış/
     * geçersiz bir key girildiğinde kullanıcı ilk mesajı yazana kadar değil,
     * hemen anlıyor.
     */
    fun connect(key: String = _apiKey.value.orEmpty()) {
        if (key.isBlank()) {
            _needsKey.value = true
            return
        }
        if (_isConnected.value) return
        _orbState.value = OrbState.CONNECTING
        _status.value = "BAĞLANIYOR…"
        addLog("sys", "API anahtarı doğrulanıyor…")

        val client = GeminiTextClient(key, DEFAULT_SYSTEM)
        textClient = client

        viewModelScope.launch {
            val problem = client.verifyKey()
            if (problem != null) {
                _orbState.value = OrbState.ERROR
                _status.value = "HATA"
                _isConnected.value = false
                addLog("sys", problem)
                return@launch
            }
            _isConnected.value = true
            _orbState.value = OrbState.IDLE
            _status.value = "HAZIR"
            addLog("sys", "Bağlandı. Mikrofonu aç ya da yazarak konuş.")
            if (_micOn.value) {
                _orbState.value = OrbState.LISTENING
                _status.value = "DİNLİYOR"
                voice.startListening()
            }
        }
    }

    fun toggleMic() {
        if (_micOn.value) {
            stopMic()
        } else {
            startMic()
        }
    }

    /** "DURDUR" butonu: oturumu tamamen kapatır, mikrofonu ve TTS'i susturur. */
    fun stop() {
        stopMic()
        voice.stopSpeaking()
        _isConnected.value = false
        _orbState.value = OrbState.IDLE
        _status.value = "DURDURULDU"
        addLog("sys", "Oturum durduruldu.")
    }

    private fun startMic() {
        _micOn.value = true
        if (_isConnected.value) {
            _orbState.value = OrbState.LISTENING
            _status.value = "DİNLİYOR"
            voice.startListening()
        }
        addLog("sys", "Mikrofon açık")
    }

    private fun stopMic() {
        _micOn.value = false
        voice.stopListening()
        if (_orbState.value == OrbState.LISTENING) {
            _orbState.value = OrbState.IDLE
            _status.value = "HAZIR"
        }
        addLog("sys", "Mikrofon kapalı")
    }

    fun sendText(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val client = textClient
        if (client == null) {
            addLog("sys", "Önce bağlanmak gerekiyor.")
            return
        }
        addLog("user", t)
        conversation += "user" to t
        trimHistory()
        _orbState.value = OrbState.THINKING
        _status.value = "DÜŞÜNÜYOR"

        viewModelScope.launch {
            val result = client.sendMessage(conversation)
            result.onSuccess { reply ->
                conversation += "model" to reply
                trimHistory()
                addLog("jarvis", reply)
                voice.speak(reply) // onSpeechStart/onSpeechDone orb durumunu kendisi günceller
            }
            result.onFailure { e ->
                _orbState.value = OrbState.ERROR
                _status.value = "HATA"
                addLog("sys", "Cevap alınamadı: ${e.message}")
                // Mikrofon açıksa hata sonrası dinlemeye devam et, kullanıcı takılıp kalmasın.
                if (_micOn.value) {
                    _orbState.value = OrbState.LISTENING
                    _status.value = "DİNLİYOR"
                    voice.startListening()
                }
            }
        }
    }

    private fun trimHistory() {
        val maxEntries = maxHistoryTurns * 2
        if (conversation.size > maxEntries) {
            val excess = conversation.size - maxEntries
            repeat(excess) { conversation.removeAt(0) }
        }
    }

    private fun addLog(who: String, text: String) {
        _logs.update { list ->
            (list + LogLine(who, text)).takeLast(40)
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopMic()
        voice.release()
    }
}

data class LogLine(val who: String, val text: String)
