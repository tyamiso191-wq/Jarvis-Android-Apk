package com.jarvis.ai.ui

enum class OrbState {
    IDLE,
    LISTENING,
    SPEAKING,
    THINKING,
    MUTED,
    ERROR,
    CONNECTING
}
