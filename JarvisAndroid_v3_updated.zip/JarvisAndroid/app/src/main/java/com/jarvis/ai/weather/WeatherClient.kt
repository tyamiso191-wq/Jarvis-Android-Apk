package com.jarvis.ai.weather

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class WeatherInfo(
    val city: String,
    val tempC: Int,
    val description: String,
    val emoji: String
)

/**
 * Konum izni istemeden hava durumu göstermek için:
 * 1) IP adresinden yaklaşık şehir/koordinat (ipapi.co) — ekstra izin gerekmez.
 * 2) O koordinat için anlık hava durumu (Open-Meteo, ücretsiz, API key gerekmez).
 * Android konum iznine (ACCESS_FINE_LOCATION) hiç ihtiyaç yok; sadece mevcut
 * INTERNET izni kullanılıyor.
 */
object WeatherClient {
    private const val TAG = "WeatherClient"

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    suspend fun fetchCurrentWeather(): WeatherInfo? = withContext(Dispatchers.IO) {
        try {
            val (lat, lon, city) = fetchApproxLocation() ?: return@withContext null
            fetchWeatherFor(lat, lon, city)
        } catch (e: Exception) {
            Log.w(TAG, "Weather fetch failed", e)
            null
        }
    }

    private fun fetchApproxLocation(): Triple<Double, Double, String>? {
        val req = Request.Builder().url("https://ipapi.co/json/").build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return null
            val body = resp.body?.string() ?: return null
            val json = JSONObject(body)
            val lat = json.optDouble("latitude", Double.NaN)
            val lon = json.optDouble("longitude", Double.NaN)
            if (lat.isNaN() || lon.isNaN()) return null
            val city = json.optString("city", "").ifBlank { "Konum" }
            return Triple(lat, lon, city)
        }
    }

    private fun fetchWeatherFor(lat: Double, lon: Double, city: String): WeatherInfo? {
        val url = "https://api.open-meteo.com/v1/forecast" +
            "?latitude=$lat&longitude=$lon&current_weather=true&timezone=auto"
        val req = Request.Builder().url(url).build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return null
            val body = resp.body?.string() ?: return null
            val current = JSONObject(body).optJSONObject("current_weather") ?: return null
            val temp = current.optDouble("temperature", Double.NaN)
            if (temp.isNaN()) return null
            val code = current.optInt("weathercode", -1)
            val (desc, emoji) = describeWeatherCode(code)
            return WeatherInfo(city = city, tempC = Math.round(temp).toInt(), description = desc, emoji = emoji)
        }
    }

    /** WMO hava durumu kodları -> kısa Türkçe açıklama + emoji. */
    private fun describeWeatherCode(code: Int): Pair<String, String> = when (code) {
        0 -> "AÇIK" to "☀️"
        1, 2 -> "PARÇALI BULUTLU" to "🌤️"
        3 -> "BULUTLU" to "☁️"
        45, 48 -> "SİSLİ" to "🌫️"
        51, 53, 55 -> "ÇİSENTİ" to "🌦️"
        56, 57 -> "DONAN ÇİSENTİ" to "🌧️"
        61, 63, 65 -> "YAĞMURLU" to "🌧️"
        66, 67 -> "DONAN YAĞMUR" to "🌧️"
        71, 73, 75 -> "KARLI" to "🌨️"
        77 -> "KAR TANELERİ" to "🌨️"
        80, 81, 82 -> "SAĞANAK" to "🌦️"
        85, 86 -> "KAR SAĞANAĞI" to "🌨️"
        95 -> "GÖK GÜRÜLTÜLÜ" to "⛈️"
        96, 99 -> "DOLULU FIRTINA" to "⛈️"
        else -> "BİLİNMİYOR" to "🌡️"
    }
}
