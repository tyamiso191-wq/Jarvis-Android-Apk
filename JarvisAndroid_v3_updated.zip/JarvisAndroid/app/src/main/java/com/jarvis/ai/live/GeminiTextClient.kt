package com.jarvis.ai.live

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Gemini'nin NORMAL, düz metin API'si (generateContent, REST) ile konuşur.
 *
 * NEDEN BU SINIF VAR: Live API'nin (BidiGenerateContent, WebSocket, native
 * audio) bu projenin key'inde sürekli "WebSocket açılıyor ama setupComplete
 * hiç gelmiyor" şeklinde bir entitlement/preview-access sorunu çıkarıyordu
 * (bkz. eski GeminiLiveClient.kt — artık kaldırıldı). generateContent ise
 * Gemini'nin en temel, herkesin ücretsiz tier key'inde stabil çalışan
 * endpoint'i; preview erişimi gerektirmiyor. Ses girişi/çıkışı artık
 * VoiceEngine (Android'in kendi ücretsiz SpeechRecognizer + TextToSpeech'i)
 * üzerinden yapılıyor — bu sınıf sadece metin ↔ metin konuşuyor, sesle hiç
 * ilgilenmiyor.
 */
class GeminiTextClient(
    private val apiKey: String,
    private val systemInstruction: String
) {
    companion object {
        private const val TAG = "GeminiTextClient"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

        // Sırayla denenecek metin modelleri. generateContent tüm bu adlarda
        // stabil çalışıyor; yine de model adları zamanla değişebildiği için
        // (Live API tarafında yaşanan sorunun aynısı burada da olabilir)
        // tek bir isme güvenmek yerine küçük bir fallback listesi tutuyoruz.
        private val MODEL_CANDIDATES = listOf(
            "gemini-2.5-flash",
            "gemini-flash-latest",
            "gemini-2.0-flash"
        )
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(35, TimeUnit.SECONDS)
        .build()

    // Süreç boyunca hatırlanan, en son başarılı olan model. Bir dahaki
    // sendMessage() çağrısında önce bu denenir.
    @Volatile private var workingModel: String? = null

    /** Basit bir GET ile key'in geçerli olup olmadığını hızlıca doğrular. */
    suspend fun verifyKey(): String? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .build()
            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    null
                } else {
                    val body = try { resp.body?.string()?.take(300) } catch (e: Exception) { null }
                    "API anahtarı kontrolü başarısız: HTTP ${resp.code}${if (!body.isNullOrBlank()) " — $body" else ""}"
                }
            }
        } catch (e: Exception) {
            "Ağa ulaşılamıyor (${e.javaClass.simpleName}: ${e.message}). İnternet bağlantını kontrol et."
        }
    }

    /**
     * conversation: sırayla ("user", metin) / ("model", metin) geçmişi.
     * Tüm geçmişi değil, çağıran taraf (ViewModel) zaten sadece son birkaç
     * turu gönderiyor — istek küçük ve hızlı kalsın diye.
     */
    suspend fun sendMessage(conversation: List<Pair<String, String>>): Result<String> =
        withContext(Dispatchers.IO) {
            val order = workingModel?.let { pref ->
                listOf(pref) + MODEL_CANDIDATES.filterNot { it == pref }
            } ?: MODEL_CANDIDATES

            var lastError: String? = null
            for (model in order) {
                val result = callModel(model, conversation)
                if (result.isSuccess) {
                    workingModel = model
                    return@withContext result
                }
                lastError = result.exceptionOrNull()?.message
                Log.w(TAG, "Model başarısız, sıradaki deneniyor: $model → $lastError")
            }
            Result.failure(IOException(lastError ?: "Bilinmeyen hata"))
        }

    private fun callModel(model: String, conversation: List<Pair<String, String>>): Result<String> = try {
        val body = JSONObject().apply {
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
            })
            put("contents", JSONArray().apply {
                conversation.forEach { (role, text) ->
                    put(JSONObject().apply {
                        put("role", role)
                        put("parts", JSONArray().put(JSONObject().put("text", text)))
                    })
                }
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.8)
                put("maxOutputTokens", 400)
            })
        }

        val req = Request.Builder()
            .url("$BASE_URL/$model:generateContent?key=$apiKey")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                return Result.failure(IOException("$model → HTTP ${resp.code}: ${raw.take(200)}"))
            }
            val json = JSONObject(raw)
            val text = json.optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
                ?.optJSONObject(0)
                ?.optString("text")
            if (text.isNullOrBlank()) {
                return Result.failure(IOException("$model → boş yanıt döndü"))
            }
            Result.success(text)
        }
    } catch (e: Exception) {
        Result.failure(e)
    }
}
