package com.jarvis.ai.live

import android.content.Context
import android.util.Log
import com.jarvis.ai.files.FileTool
import com.jarvis.ai.music.MusicController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Gemini'nin NORMAL, düz metin API'si (generateContent, REST) ile konuşur.
 *
 * NEDEN BU SINIF VAR: Live API'nin (BidiGenerateContent, WebSocket, native
 * audio) bu projenin key'inde sürekli "WebSocket açılıyor ama setupComplete
 * hiç gelmiyor" şeklinde bir entitlement/preview-access sorunu çıkarıyordu
 * (bkz. eski GeminiLiveClient.kt — artık kaldırıldı). generateContent ise
 * Gemini'nin en temel, herkesin ücretsiz tier key'inde stabil çalışan
 * endpoint'i; preview erişimi gerektirmiyor. Ses girişi/çıkışı artık
 * VoiceEngine (Android'in kendi ücretsiz SpeechRecognizer + TextToSpeech'i)
 * üzerinden yapılıyor — bu sınıf sadece metin ↔ metin konuşuyor, sesle hiç
 * ilgilenmiyor.
 *
 * FONKSİYON ÇAĞIRMA (function calling): google_search'e ek olarak modele
 * create_file / create_zip / play_song fonksiyonlarını da tanımlıyoruz.
 * Model bunlardan birini çağırmak isterse (functionCall), bu sınıf onu
 * GERÇEKTEN çalıştırır (FileTool / MusicController üzerinden, appContext
 * ile), sonucu modele geri besler ve modelin bunu doğal dille özetlediği
 * NİHAİ cevabı döndürür — çağıran taraf (ViewModel) tek bir sendMessage()
 * çağrısıyla hem "dosya oluştur" hem "cevabı söyle" akışını tek seferde alır.
 */
class GeminiTextClient(
    private val apiKey: String,
    private val persona: String,
    private val appContext: Context
) {
    companion object {
        private const val TAG = "GeminiTextClient"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)   // Google Search grounding bazen ekstra sürüyor
        .callTimeout(50, TimeUnit.SECONDS)
        .build()

    // Süreç boyunca hatırlanan, en son başarılı olan model. Bir dahaki
    // sendMessage() çağrısında önce bu denenir.
    @Volatile private var workingModel: String? = null

    // GET /v1beta/models sonucunun önbelleği. Google model adlarını sık
    // değiştirdiği için (bkz. Live API'de yaşanan "gemini-2.0-flash artık
    // yok" sorunu — aynısı burada da oldu) TEK BİR SABİT İSME GÜVENMİYORUZ;
    // her istekte gerçekten kullanılabilir olan generateContent modellerini
    // sorup en olası adaydan başlayarak deniyoruz. Aynı süreçte tekrar tekrar
    // ağ çağrısı yapmamak için sonucu önbellekliyoruz; önbellekteki hiçbir
    // model çalışmazsa (hepsi deprecate olmuş olabilir) önbelleği ATIP bir
    // kez daha taze listeyi çekiyoruz.
    @Volatile private var cachedCandidates: List<String>? = null

    /** Basit bir GET ile key'in geçerli olup olmadığını hızlıca doğrular. */
    suspend fun verifyKey(): String? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .build()
            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    null
                } else {
                    val body = try { resp.body?.string()?.take(300) } catch (e: Exception) { null }
                    "API anahtarı kontrolü başarısız: HTTP ${resp.code}${if (!body.isNullOrBlank()) " — $body" else ""}"
                }
            }
        } catch (e: Exception) {
            "Ağa ulaşılamıyor (${e.javaClass.simpleName}: ${e.message}). İnternet bağlantını kontrol et."
        }
    }

    /**
     * GET /v1beta/models üzerinden bu key'e gerçekten açık olan, metinle
     * konuşabilen (generateContent destekleyen) modelleri çeker ve en olası
     * çalışacak adaydan en az olasıya sıralar.
     *
     * embedding/tts/görsel-üretim/native-audio/live/transcribe gibi sohbet
     * için uygun olmayan modeller elenir. "flash" ailesi (hızlı/ucuz, geniş
     * kotalı) ve "-latest" alias'ı (her zaman güncel modele işaret eder)
     * öne alınır; "pro"/"exp"/"preview" biraz geride tutulur ama tamamen
     * elenmez.
     */
    private suspend fun discoverTextModels(): List<String> = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("$BASE_URL?key=$apiKey")
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                throw IOException("Model listesi HTTP ${resp.code} döndürdü")
            }
            val json = JSONObject(resp.body?.string() ?: "{}")
            val modelsArray = json.optJSONArray("models") ?: JSONArray()

            val excluded = listOf(
                "embedding", "aqa", "tts", "image-generation", "imagen",
                "native-audio", "-live", "transcribe", "video", "gemma"
            )

            val scored = mutableListOf<Pair<String, Int>>()
            for (i in 0 until modelsArray.length()) {
                val m = modelsArray.optJSONObject(i) ?: continue
                val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
                var supportsGenerate = false
                for (j in 0 until methods.length()) {
                    if (methods.optString(j) == "generateContent") {
                        supportsGenerate = true
                        break
                    }
                }
                if (!supportsGenerate) continue

                val rawName = m.optString("name").takeIf { it.isNotBlank() } ?: continue
                val name = rawName.removePrefix("models/")
                val lower = name.lowercase()
                if (excluded.any { lower.contains(it) }) continue

                var score = 0
                if (lower.contains("latest")) score += 60
                if (lower.contains("flash")) score += 50
                if (lower.contains("lite")) score += 5
                if (lower.contains("pro")) score -= 10
                if (lower.contains("exp") || lower.contains("preview")) score -= 20
                if (lower.contains("thinking")) score -= 5
                scored += name to score
            }

            scored
                .sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenBy { it.first })
                .map { it.first }
        }
    }

    /**
     * conversation: sırayla ("user", metin) / ("model", metin) geçmişi.
     * Tüm geçmişi değil, çağıran taraf (ViewModel) zaten sadece son birkaç
     * turu gönderiyor — istek küçük ve hızlı kalsın diye.
     *
     * deviceContext: her çağrıda TAZE üretilen "şu an saat/tarih/telefon/
     * depolama/pil" bloğu (bkz. DeviceInfo.kt). Persona'nın (sabit kişilik
     * talimatı) sonuna eklenir, böylece model her seferinde güncel cihaz
     * durumunu bilir.
     */
    suspend fun sendMessage(
        conversation: List<Pair<String, String>>,
        deviceContext: String = ""
    ): Result<String> =
        withContext(Dispatchers.IO) {
            val fullInstruction = if (deviceContext.isBlank()) persona else "$persona\n\n$deviceContext"

            var candidates = cachedCandidates
            var usedCache = candidates != null
            if (candidates == null) {
                candidates = try {
                    discoverTextModels()
                } catch (e: Exception) {
                    return@withContext Result.failure(
                        IOException("Model listesi alınamadı: ${e.javaClass.simpleName}: ${e.message}")
                    )
                }
                cachedCandidates = candidates
            }
            if (candidates.isEmpty()) {
                return@withContext Result.failure(
                    IOException("Bu API anahtarında generateContent destekleyen hiçbir model bulunamadı.")
                )
            }

            val order = workingModel?.let { pref ->
                listOf(pref) + candidates.filterNot { it == pref }
            } ?: candidates

            var lastError: String? = null
            for (model in order) {
                val result = callModel(model, conversation, fullInstruction)
                if (result.isSuccess) {
                    workingModel = model
                    return@withContext result
                }
                lastError = result.exceptionOrNull()?.message
                Log.w(TAG, "Model başarısız, sıradaki deneniyor: $model → $lastError")
            }

            // Önbellekteki hiçbir model çalışmadıysa (muhtemelen hepsi
            // deprecate olmuş) önbelleği atıp bir kez daha taze liste
            // çekiyoruz — Google'ın model adlarını değiştirmesi artık
            // uygulamayı hiç kırmasın diye.
            if (usedCache) {
                val fresh = try { discoverTextModels() } catch (e: Exception) { null }
                if (!fresh.isNullOrEmpty() && fresh != candidates) {
                    cachedCandidates = fresh
                    workingModel = null
                    for (model in fresh) {
                        val result = callModel(model, conversation, fullInstruction)
                        if (result.isSuccess) {
                            workingModel = model
                            return@withContext result
                        }
                        lastError = result.exceptionOrNull()?.message
                    }
                }
            }

            Result.failure(IOException(lastError ?: "Bilinmeyen hata"))
        }

    private fun callModel(
        model: String,
        conversation: List<Pair<String, String>>,
        systemInstruction: String
    ): Result<String> = try {
        val contents = JSONArray().apply {
            conversation.forEach { (role, text) ->
                put(JSONObject().apply {
                    put("role", role)
                    put("parts", JSONArray().put(JSONObject().put("text", text)))
                })
            }
        }

        var lastText = ""
        // En fazla 4 tur: normal cevap 1 turda gelir; bir fonksiyon çağrısı
        // (dosya oluştur / şarkı çal) 1 ekstra tur daha gerektirir. 4, art
        // arda birkaç fonksiyon çağrısı zincirlenirse bile makul bir üst sınır.
        repeat(4) {
            val body = JSONObject().apply {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
                })
                put("contents", contents)
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.8)
                    put("maxOutputTokens", 400)
                })
                // google_search (canlı arama) + functionDeclarations (dosya/
                // müzik) aynı istekte birlikte gönderiliyor — Gemini 2.x/3.x
                // flash ailesi ikisini birlikte destekliyor.
                put("tools", buildTools())
            }

            val req = Request.Builder()
                .url("$BASE_URL/$model:generateContent?key=$apiKey")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val modelContent = client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return Result.failure(IOException("$model → HTTP ${resp.code}: ${raw.take(200)}"))
                }
                JSONObject(raw).optJSONArray("candidates")
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
            } ?: return Result.failure(IOException("$model → boş yanıt döndü"))

            val parts = modelContent.optJSONArray("parts") ?: JSONArray()
            val text = buildString {
                for (i in 0 until parts.length()) {
                    val t = parts.optJSONObject(i)?.optString("text", "") ?: ""
                    if (t.isNotEmpty()) append(t)
                }
            }

            val functionCalls = mutableListOf<JSONObject>()
            for (i in 0 until parts.length()) {
                parts.optJSONObject(i)?.optJSONObject("functionCall")?.let { functionCalls += it }
            }

            if (functionCalls.isEmpty()) {
                if (text.isBlank()) {
                    return Result.failure(IOException("$model → boş yanıt döndü"))
                }
                return Result.success(text)
            }

            // Modelin fonksiyon çağırma turunu sohbet geçmişine ekle.
            contents.put(JSONObject().apply {
                put("role", "model")
                put("parts", parts)
            })

            // Her fonksiyon çağrısını GERÇEKTEN çalıştır, sonucu modele geri besle.
            val responseParts = JSONArray()
            for (fc in functionCalls) {
                val name = fc.optString("name")
                val args = fc.optJSONObject("args") ?: JSONObject()
                val outcome = executeFunction(name, args)
                responseParts.put(JSONObject().apply {
                    put("functionResponse", JSONObject().apply {
                        put("name", name)
                        put("response", outcome)
                    })
                })
            }
            contents.put(JSONObject().apply {
                put("role", "user")
                put("parts", responseParts)
            })

            lastText = text
        }

        if (lastText.isNotBlank()) Result.success(lastText)
        else Result.failure(IOException("$model → fonksiyon döngüsü tamamlanamadı"))
    } catch (e: Exception) {
        Result.failure(e)
    }

    private fun buildTools(): JSONArray {
        val functionDeclarations = JSONArray()
            .put(JSONObject().apply {
                put("name", "create_file")
                put(
                    "description",
                    "Kullanıcı için düz metin bir dosya (örn. .txt, .md, .json, .csv) oluşturup İndirilenler klasörüne kaydeder. Kullanıcı açıkça bir not/liste/metin kaydetmeni istediğinde çağır."
                )
                put("parameters", JSONObject().apply {
                    put("type", "OBJECT")
                    put("properties", JSONObject().apply {
                        put("filename", JSONObject().apply {
                            put("type", "STRING")
                            put("description", "Uzantılı dosya adı, örn. notlar.txt")
                        })
                        put("content", JSONObject().apply {
                            put("type", "STRING")
                            put("description", "Dosyanın tam içeriği")
                        })
                    })
                    put("required", JSONArray().put("filename").put("content"))
                })
            })
            .put(JSONObject().apply {
                put("name", "create_zip")
                put(
                    "description",
                    "Birden fazla metin dosyasını tek bir zip arşivinde birleştirip İndirilenler klasörüne kaydeder."
                )
                put("parameters", JSONObject().apply {
                    put("type", "OBJECT")
                    put("properties", JSONObject().apply {
                        put("zip_filename", JSONObject().apply {
                            put("type", "STRING")
                            put("description", "Arşiv adı, .zip uzantılı ya da uzantısız")
                        })
                        put("files", JSONObject().apply {
                            put("type", "ARRAY")
                            put("items", JSONObject().apply {
                                put("type", "OBJECT")
                                put("properties", JSONObject().apply {
                                    put("filename", JSONObject().put("type", "STRING"))
                                    put("content", JSONObject().put("type", "STRING"))
                                })
                                put("required", JSONArray().put("filename").put("content"))
                            })
                        })
                    })
                    put("required", JSONArray().put("zip_filename").put("files"))
                })
            })
            .put(JSONObject().apply {
                put("name", "play_song")
                put(
                    "description",
                    "Kullanıcının istediği şarkıyı çalmaya başlar: önce telefonun yerel müzik kütüphanesinde arar (bulursa arka planda çalar), yoksa YouTube'da açar."
                )
                put("parameters", JSONObject().apply {
                    put("type", "OBJECT")
                    put("properties", JSONObject().apply {
                        put("query", JSONObject().apply {
                            put("type", "STRING")
                            put("description", "Şarkı adı ve varsa sanatçı, örn. 'Tarkan Kuzu Kuzu'")
                        })
                    })
                    put("required", JSONArray().put("query"))
                })
            })

        return JSONArray()
            .put(JSONObject().put("google_search", JSONObject()))
            .put(JSONObject().put("functionDeclarations", functionDeclarations))
    }

    private fun executeFunction(name: String, args: JSONObject): JSONObject = try {
        when (name) {
            "create_file" -> {
                val filename = args.optString("filename").ifBlank { "not.txt" }
                val content = args.optString("content")
                val saved = FileTool.createTextFile(appContext, filename, content)
                JSONObject().put("status", "ok").put("path", saved.displayPath)
            }
            "create_zip" -> {
                val zipName = args.optString("zip_filename").ifBlank { "arsiv.zip" }
                val filesArr = args.optJSONArray("files") ?: JSONArray()
                val entries = mutableListOf<Pair<String, String>>()
                for (i in 0 until filesArr.length()) {
                    val f = filesArr.optJSONObject(i) ?: continue
                    entries += f.optString("filename", "dosya_$i.txt") to f.optString("content")
                }
                val saved = FileTool.createZipFile(appContext, zipName, entries)
                JSONObject().put("status", "ok").put("path", saved.displayPath)
            }
            "play_song" -> {
                val query = args.optString("query")
                when (val result = MusicController.play(appContext, query)) {
                    is MusicController.PlayResult.PlayingLocal ->
                        JSONObject().put("status", "playing_local")
                            .put("title", result.title).put("artist", result.artist)
                    is MusicController.PlayResult.OpenedYoutubeSearch ->
                        JSONObject().put("status", "opened_youtube_search").put("query", result.query)
                    is MusicController.PlayResult.PermissionMissing ->
                        JSONObject().put("status", "error").put("message", result.message)
                    is MusicController.PlayResult.Error ->
                        JSONObject().put("status", "error").put("message", result.message)
                }
            }
            else -> JSONObject().put("status", "error").put("message", "Bilinmeyen fonksiyon: $name")
        }
    } catch (e: Exception) {
        JSONObject().put("status", "error").put("message", e.message ?: "bilinmeyen hata")
    }
}
