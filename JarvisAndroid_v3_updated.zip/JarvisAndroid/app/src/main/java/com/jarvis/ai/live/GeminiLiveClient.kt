package com.jarvis.ai.live

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Gemini Live API client using WebSocket.
 * Model: gemini-2.5-flash-native-audio-latest, with automatic one-time fallback to
 * gemini-3.5-transcribe-live if the primary model is rejected.
 * Sends 16 kHz PCM16 audio, receives audio + text.
 *
 * NOTE (Sept 2026): "gemini-3.8-live" and "gemini-3.1-flash-live-preview" are NOT
 * enabled for every API key/project — GET
 * https://generativelanguage.googleapis.com/v1beta/models?key=YOUR_KEY
 * showed neither in this project's model list. Only two models supported
 * bidiGenerateContent for this key: gemini-3.5-transcribe-live (transcription
 * only, not full duplex chat) and gemini-2.5-flash-native-audio-latest (real
 * conversational live model — this is what we now use). If you later request/
 * get allowlist access to a newer live model, just swap MODEL below — check
 * the models endpoint above first to confirm it's actually listed for your key.
 */
class GeminiLiveClient(
    private val apiKey: String,
    private val systemInstruction: String = DEFAULT_SYSTEM,
    private val voiceName: String = "Charon"
) {
    companion object {
        private const val TAG = "GeminiLive"
        // Official Live endpoint (Google AI Studio key) — must be v1beta for plain API-key auth.
        // v1alpha is ONLY for the ephemeral-token flow (access_token query param) and will
        // reject/close a plain "?key=" connection, which is what caused the earlier
        // "bağlantı kesildi" bug. Do not switch this back to v1alpha.
        private const val WS_URL =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"

        // NOT "gemini-2.0-flash": that is a plain text model, was never a BidiGenerateContent
        // (Live API) model, and its dedicated live variant (gemini-2.0-flash-live-001) was
        // already shut down by Google in Dec 2025 / Jun 2026. Using it will make the socket
        // close immediately after "setup" (or the setup will simply never complete), which
        // looks exactly like the 15s timeout you're seeing.
        //
        // Verified against this project's own key via the /v1beta/models endpoint
        // (Sept 2026) — these are the only two models it lists with
        // "bidiGenerateContent" support:
        //   - "models/gemini-2.5-flash-native-audio-latest" (real conversational live model, primary)
        //   - "models/gemini-3.5-transcribe-live"            (transcription-only, used only as last-resort fallback)
        private const val MODEL = "models/gemini-2.5-flash-native-audio-latest"
        private const val MODEL_FALLBACK = "models/gemini-3.5-transcribe-live"

        val DEFAULT_SYSTEM = """
            Sen J.A.R.V.I.S'sin. Türkçe konuşan, zeki, yardımcı ve hafif esprili bir kişisel asistansın.
            Kısa ve net cevap ver. Kullanıcıya "efendim" diye hitap edebilirsin.
            Gereksiz uzun açıklama yapma. Sesli sohbet için uygunsun.
        """.trimIndent()
    }

    // ÖNEMLİ DÜZELTME: WebSocket ve düz REST (preflight) çağrıları artık AYRI
    // OkHttpClient örnekleri kullanıyor. Öncesinde ikisi de aynı `client`'ı
    // paylaşıyordu ve o client'ta `callTimeout(10, SECONDS)` vardı. callTimeout,
    // TÜM çağrının süresini sınırlar; bazı OkHttp sürümlerinde/durumlarında bu,
    // WebSocket bağlantısı için de (sadece handshake değil, bağlantı ömrü boyunca)
    // devreye girip 10. saniyede soketi sessizce iptal edebiliyor — kendi 15sn/20sn
    // watchdog'umuz hiç devreye girmeden, "Socket closed" gibi belirsiz bir hatayla.
    // Bu YANLIŞLIKLA erken kapanma ihtimalini tamamen ortadan kaldırmak için WS
    // client'ında callTimeout tamamen kapalı (0), connectTimeout de mobil ağlar için
    // 10sn'den 20sn'ye çıkarıldı.
    private val restClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .callTimeout(10, TimeUnit.SECONDS)
        .build()

    private val wsClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .callTimeout(0, TimeUnit.MILLISECONDS)   // WS bağlantısının ömrünü callTimeout kesmesin
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private var webSocket: WebSocket? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val connected = AtomicBoolean(false)
    private val setupDone = AtomicBoolean(false)
    private var watchdogJob: Job? = null
    private var currentModel = MODEL
    private var usedFallback = false

    private val _events = MutableSharedFlow<LiveEvent>(extraBufferCapacity = 64)
    val events: SharedFlow<LiveEvent> = _events

    fun connect() {
        if (connected.get()) return
        currentModel = MODEL
        usedFallback = false
        scope.launch {
            _events.emit(LiveEvent.Log("Ağ ve API anahtarı kontrol ediliyor…"))
            val problem = preflightCheck()
            if (problem != null) {
                Log.e(TAG, "Preflight failed: $problem")
                _events.emit(LiveEvent.Error(problem))
                return@launch
            }
            _events.emit(LiveEvent.Log("Ön kontrol OK, canlı oturum açılıyor…"))
            openWebSocket()
        }
    }

    /**
     * WebSocket açmadan önce düz bir REST çağrısıyla "API key geçerli mi,
     * Live API bu key'e açık mı, ağ genel olarak Google'a ulaşabiliyor mu"
     * sorusunu ayrı ayrı cevaplar. Önceden WS sessizce hiçbir şey döndürmeden
     * takılıp kalıyordu; artık en azından somut bir HTTP kodu/mesaj görürüz.
     */
    private suspend fun preflightCheck(): String? = try {
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models?key=$apiKey")
            .build()
        withContext(Dispatchers.IO) {
            restClient.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    null
                } else {
                    val body = try { resp.body?.string()?.take(300) } catch (e: Exception) { null }
                    "API kontrolü başarısız: HTTP ${resp.code}${if (!body.isNullOrBlank()) " — $body" else ""}"
                }
            }
        }
    } catch (e: Exception) {
        "Ağa ulaşılamıyor (${e.javaClass.simpleName}: ${e.message}). İnternet bağlantını / VPN-güvenlik duvarı ayarlarını kontrol et."
    }

    private fun openWebSocket() {
        val url = "$WS_URL?key=$apiKey"
        val request = Request.Builder().url(url).build()
        // Bu deneme (attempt) için oluşturulan soketi ayrıca yerel bir değişkende de
        // tutuyoruz. SEBEP: `webSocket` alanı, fallback modele geçildiğinde YENİ bir
        // soketle DEĞİŞTİRİLİYOR. Aşağıdaki watchdog eskiden `webSocket` alanını (sınıf
        // değişkenini) referans alıyordu; fallback tetiklendiğinde yeni soket ata
        // atanır atanmaz, watchdog'un sondaki `webSocket?.cancel()` çağrısı YANLIŞLIKLA
        // yeni açılan fallback soketini iptal edebiliyordu (race condition) — ekranda
        // gördüğün "fallback'e geçiliyor" mesajının hemen ardından gelen "Socket closed"
        // hatasının gerçek sebebi buydu, model veya ağ sorunu değildi.
        // Çözüm: watchdog artık HER ZAMAN kendi attempt'ine ait `thisSocket`'i iptal
        // ediyor, hangi soketin o an `webSocket` alanında olduğuna bakmaksızın.
        lateinit var thisSocket: WebSocket
        thisSocket = wsClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.i(TAG, "WebSocket open (model=$currentModel)")
                connected.set(true)
                sendSetup()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                Log.d(TAG, "Message: $text")
                handleMessage(text)
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                Log.w(TAG, "Closing: $code $reason")
                connected.set(false)
                setupDone.set(false)
                watchdogJob?.cancel()
                // 1008 right after "setup" usually means the server rejected the model/config —
                // retry once with the fallback model instead of just reporting a dead end.
                if (code == 1008 && maybeRetryWithFallback(reason)) return
                scope.launch { _events.emit(LiveEvent.Disconnected("$code $reason")) }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                // response body carries the real reason on handshake rejection
                // (bad API key, model not found for this API version, etc.).
                val bodySnippet = try { response?.body?.string()?.take(300) } catch (e: Exception) { null }
                val detail = listOfNotNull(
                    response?.let { "HTTP ${it.code}" },
                    bodySnippet,
                    "${t.javaClass.simpleName}: ${t.message}",
                    t.cause?.let { "neden: ${it.javaClass.simpleName}: ${it.message}" }
                ).joinToString(" - ").ifBlank { "Bağlantı hatası" }
                Log.e(TAG, "Failure: $detail", t)
                connected.set(false)
                setupDone.set(false)
                watchdogJob?.cancel()
                if (maybeRetryWithFallback(detail)) return
                scope.launch { _events.emit(LiveEvent.Error(detail)) }
            }
        })
        webSocket = thisSocket

        // Watchdog: sunucu setup'ı ne kabul eder ne reddeder (ne setupComplete
        // ne error/close gelir) diye sonsuza kadar "bağlanıyor"da takılı kalmasın.
        // 15sn -> 20sn: mobil ağlarda (Termux/hotspot) ilk TLS+WS handshake bazen
        // 15sn'yi geçebiliyor; bu sadece bizim yerel bekleme süremiz, sunucu tarafında
        // ayarlanabilecek bir şey değil.
        watchdogJob = scope.launch {
            delay(20_000)
            if (!setupDone.get()) {
                Log.w(TAG, "Setup timeout (model=$currentModel)")
                if (!maybeRetryWithFallback("20sn içinde setupComplete gelmedi")) {
                    _events.emit(
                        LiveEvent.Error(
                            "Zaman aşımı: sunucudan 20 saniyede yanıt gelmedi. " +
                                "Muhtemel nedenler: (1) API anahtarında Live API erişimi kapalı, " +
                                "(2) model bu anahtar/bölge için etkin değil, " +
                                "(3) ağ/güvenlik duvarı WSS(443) trafiğini engelliyor."
                        )
                    )
                }
                thisSocket.cancel()
            }
        }
    }

    /**
     * "$currentModel" reddedildiğinde (1008 close, handshake failure ya da sessiz timeout)
     * ve henüz fallback denenmediyse, tek seferlik olarak MODEL_FALLBACK ile yeniden dener.
     * Aynı model ile sonsuz döngüye girmemek için sadece bir kez çalışır.
     */
    private fun maybeRetryWithFallback(reason: String): Boolean {
        if (usedFallback || currentModel == MODEL_FALLBACK) return false
        usedFallback = true
        currentModel = MODEL_FALLBACK
        Log.w(TAG, "Retrying with fallback model $MODEL_FALLBACK after: $reason")
        scope.launch {
            _events.emit(LiveEvent.Log("\"$MODEL\" ile bağlanılamadı ($reason). \"$MODEL_FALLBACK\" ile tekrar deneniyor…"))
            openWebSocket()
        }
        return true
    }

    private fun sendSetup() {
        val setup = JSONObject().apply {
            put("setup", JSONObject().apply {
                put("model", currentModel)
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().put("AUDIO"))
                    put("speechConfig", JSONObject().apply {
                        put("voiceConfig", JSONObject().apply {
                            put("prebuiltVoiceConfig", JSONObject().apply {
                                put("voiceName", voiceName)
                            })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
                })
            })
        }
        webSocket?.send(setup.toString())
        Log.i(TAG, "Setup sent")
    }

    private fun handleMessage(text: String) {
        try {
            val json = JSONObject(text)

            if (json.has("setupComplete")) {
                setupDone.set(true)
                watchdogJob?.cancel()
                scope.launch { _events.emit(LiveEvent.Ready) }
                Log.i(TAG, "Setup complete (model=$currentModel)")
                return
            }

            // Server-side rejection sent as a JSON error frame instead of a socket close.
            json.optJSONObject("error")?.let { err ->
                val msg = err.optString("message", "Sunucu hatası")
                Log.e(TAG, "Server error: $msg")
                scope.launch { _events.emit(LiveEvent.Error(msg)) }
                return
            }

            val serverContent = json.optJSONObject("serverContent") ?: return

            // Interrupted
            if (serverContent.optBoolean("interrupted", false)) {
                scope.launch { _events.emit(LiveEvent.Interrupted) }
            }

            // Model turn parts
            val modelTurn = serverContent.optJSONObject("modelTurn")
            modelTurn?.optJSONArray("parts")?.let { parts ->
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    // Inline audio
                    part.optJSONObject("inlineData")?.let { inline ->
                        val mime = inline.optString("mimeType", "")
                        val data = inline.optString("data", "")
                        if (data.isNotEmpty() && mime.contains("audio")) {
                            val bytes = Base64.decode(data, Base64.DEFAULT)
                            scope.launch { _events.emit(LiveEvent.Audio(bytes)) }
                        }
                    }
                    // Text
                    part.optString("text", "").takeIf { it.isNotBlank() }?.let { t ->
                        scope.launch { _events.emit(LiveEvent.Text(t)) }
                    }
                }
            }

            if (serverContent.optBoolean("turnComplete", false)) {
                scope.launch { _events.emit(LiveEvent.TurnComplete) }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Parse error", e)
        }
    }

    /** Send 16-bit PCM audio chunk (16 kHz mono recommended). */
    fun sendAudio(pcm16: ByteArray) {
        if (!setupDone.get()) return
        val b64 = Base64.encodeToString(pcm16, Base64.NO_WRAP)
        val msg = JSONObject().apply {
            put("realtimeInput", JSONObject().apply {
                put("mediaChunks", JSONArray().put(JSONObject().apply {
                    put("mimeType", "audio/pcm;rate=16000")
                    put("data", b64)
                }))
            })
        }
        webSocket?.send(msg.toString())
    }

    fun sendText(text: String) {
        if (!setupDone.get() || text.isBlank()) return
        val msg = JSONObject().apply {
            put("clientContent", JSONObject().apply {
                put("turns", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", text)))
                }))
                put("turnComplete", true)
            })
        }
        webSocket?.send(msg.toString())
    }

    fun close() {
        watchdogJob?.cancel()
        webSocket?.close(1000, "bye")
        webSocket = null
        connected.set(false)
        setupDone.set(false)
        scope.cancel()
    }

    fun isReady(): Boolean = setupDone.get()
}

sealed class LiveEvent {
    data object Ready : LiveEvent()
    data class Audio(val pcm: ByteArray) : LiveEvent()
    data class Text(val text: String) : LiveEvent()
    data object TurnComplete : LiveEvent()
    data object Interrupted : LiveEvent()
    data class Disconnected(val reason: String) : LiveEvent()
    data class Error(val message: String) : LiveEvent()
    data class Log(val message: String) : LiveEvent()
}
