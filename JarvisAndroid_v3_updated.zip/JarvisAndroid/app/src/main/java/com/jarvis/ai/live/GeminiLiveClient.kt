package com.jarvis.ai.live

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Gemini Live API client using WebSocket.
 *
 * MODEL ADI ARTIK HARDCODE DEĞİL — OTOMATİK KEŞİF:
 * Google, Live API (bidiGenerateContent) modellerini sık sık değiştiriyor:
 * "-latest" takma adları farklı zamanlarda farklı pinned model'e işaret ediyor,
 * "-preview-09-2025" gibi tarihli sürümler deprecate edilip yenisiyle
 * değiştiriliyor, ve quota/entitlement sistemleri bazen bir alias'ı hiç
 * tanımıyor (bkz. eski not: "-latest" alias'ı quota ekranında hiç görünmüyordu).
 * Bu yüzden tek bir sabit model adına güvenmek yerine, her connect() çağrısında
 * bu API key için gerçekten kullanılabilir olan modelleri GET /v1beta/models
 * üzerinden kendimiz sorguluyoruz, adayları en olası olandan en az olasıya
 * sıralıyoruz ve her birine gerçekten bağlanıp setupComplete bekleyerek
 * sırayla deniyoruz. Bir model çalışırsa süreç boyunca (preferredModel)
 * hatırlanır ve bir sonraki bağlantıda önce o denenir.
 *
 * Sends 16 kHz PCM16 audio, receives audio + text.
 */
class GeminiLiveClient(
    private val apiKey: String,
    private val systemInstruction: String = DEFAULT_SYSTEM,
    private val voiceName: String = "Charon"
) {
    companion object {
        private const val TAG = "GeminiLive"
        // Official Live endpoint (Google AI Studio key) — must be v1beta for plain API-key auth.
        // v1alpha is ONLY for the ephemeral-token flow (access_token query param) and will
        // reject/close a plain "?key=" connection, which is what caused the earlier
        // "bağlantı kesildi" bug. Do not switch this back to v1alpha.
        private const val WS_URL =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"

        private const val MODELS_LIST_URL =
            "https://generativelanguage.googleapis.com/v1beta/models"

        // Tek bir modele 20sn yerine daha kısa bir süre veriyoruz, çünkü artık
        // birden fazla adayı sırayla deneyebiliyoruz; hepsine 20sn verilirse
        // 4-5 aday olduğunda kullanıcı 1-2 dakika "bağlanıyor" ekranında kalır.
        // Tek aday kaldıysa (keşif tek model döndürdüyse) bu yine de yeterli.
        private const val ATTEMPT_TIMEOUT_MS = 12_000L

        // Süreç boyunca hatırlanan, en son başarılı olan model adı. Bir sonraki
        // connect() çağrısında (aynı uygulama oturumunda) önce bu denenir, böylece
        // her seferinde baştan keşif+deneme sırasına girilmez.
        @Volatile
        private var preferredModel: String? = null

        val DEFAULT_SYSTEM = """
            Sen J.A.R.V.I.S'sin. Türkçe konuşan, zeki, yardımcı ve hafif esprili bir kişisel asistansın.
            Kısa ve net cevap ver. Kullanıcıya "efendim" diye hitap edebilirsin.
            Gereksiz uzun açıklama yapma. Sesli sohbet için uygunsun.
        """.trimIndent()
    }

    private sealed class AttemptResult {
        data class Success(val model: String) : AttemptResult()
        data class Failure(val reason: String) : AttemptResult()
    }

    // ÖNEMLİ DÜZELTME: WebSocket ve düz REST (preflight/model listesi) çağrıları
    // AYRI OkHttpClient örnekleri kullanıyor. Öncesinde ikisi de aynı `client`'ı
    // paylaşıyordu ve o client'ta `callTimeout(10, SECONDS)` vardı. callTimeout,
    // TÜM çağrının süresini sınırlar; bazı OkHttp sürümlerinde/durumlarında bu,
    // WebSocket bağlantısı için de (sadece handshake değil, bağlantı ömrü boyunca)
    // devreye girip 10. saniyede soketi sessizce iptal edebiliyor — kendi
    // watchdog'umuz hiç devreye girmeden, "Socket closed" gibi belirsiz bir hatayla.
    // Bu YANLIŞLIKLA erken kapanma ihtimalini tamamen ortadan kaldırmak için WS
    // client'ında callTimeout tamamen kapalı (0), connectTimeout de mobil ağlar için
    // 10sn'den 20sn'ye çıkarıldı.
    private val restClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .callTimeout(10, TimeUnit.SECONDS)
        .build()

    private val wsClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .callTimeout(0, TimeUnit.MILLISECONDS)   // WS bağlantısının ömrünü callTimeout kesmesin
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private var webSocket: WebSocket? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val connected = AtomicBoolean(false)
    private val setupDone = AtomicBoolean(false)
    private var watchdogJob: Job? = null

    // O anki denemenin sonucunu bekleyen deferred. handleMessage() içinde
    // setupComplete / error frame geldiğinde bu tamamlanır; WS listener'ında
    // onClosing/onFailure geldiğinde de tamamlanır. Aynı anda tek bir deneme
    // olduğu için (sıralı deniyoruz) tek değişken yeterli.
    private var pendingAttempt: CompletableDeferred<AttemptResult>? = null
    private var currentModel: String = ""

    private val _events = MutableSharedFlow<LiveEvent>(extraBufferCapacity = 64)
    val events: SharedFlow<LiveEvent> = _events

    fun connect() {
        if (connected.get()) return
        scope.launch {
            _events.emit(LiveEvent.Log("Ağ ve API anahtarı kontrol ediliyor…"))
            val problem = preflightCheck()
            if (problem != null) {
                Log.e(TAG, "Preflight failed: $problem")
                _events.emit(LiveEvent.Error(problem))
                return@launch
            }

            _events.emit(LiveEvent.Log("Ön kontrol OK, kullanılabilir modeller aranıyor…"))
            val candidates = try {
                discoverLiveModels()
            } catch (e: Exception) {
                Log.e(TAG, "Model listesi alınamadı", e)
                _events.emit(
                    LiveEvent.Error("Model listesi alınamadı: ${e.javaClass.simpleName}: ${e.message}")
                )
                return@launch
            }

            if (candidates.isEmpty()) {
                _events.emit(
                    LiveEvent.Error(
                        "Bu API anahtarında sesli canlı sohbet destekleyen (bidiGenerateContent " +
                            "yeteneğine sahip) hiçbir model bulunamadı. AI Studio'da bu anahtarın " +
                            "Live API erişimi olduğundan emin ol."
                    )
                )
                return@launch
            }

            _events.emit(LiveEvent.Log("Denenecek modeller (öncelik sırasıyla): ${candidates.joinToString(", ")}"))

            val failures = mutableListOf<String>()
            for (model in candidates) {
                _events.emit(LiveEvent.Log("Deneniyor: $model"))
                when (val result = tryModel(model)) {
                    is AttemptResult.Success -> {
                        preferredModel = result.model
                        Log.i(TAG, "Bağlantı başarılı, kullanılan model: ${result.model}")
                        // setupComplete zaten handleMessage() içinde LiveEvent.Ready
                        // yayınladı; burada tekrar bağlanmaya devam etmiyoruz.
                        return@launch
                    }
                    is AttemptResult.Failure -> {
                        failures += "$model → ${result.reason}"
                        _events.emit(LiveEvent.Log("Başarısız ($model): ${result.reason}"))
                    }
                }
            }

            _events.emit(
                LiveEvent.Error(
                    "Hiçbir model bağlantıyı tamamlayamadı. Denenenler:\n" +
                        failures.joinToString("\n")
                )
            )
        }
    }

    /**
     * WebSocket açmadan önce düz bir REST çağrısıyla "API key geçerli mi,
     * ağ genel olarak Google'a ulaşabiliyor mu" sorusunu ayrı ayrı cevaplar.
     * Önceden WS sessizce hiçbir şey döndürmeden takılıp kalıyordu; artık en
     * azından somut bir HTTP kodu/mesaj görürüz. (Model bazlı kontrol artık
     * discoverLiveModels() + tryModel() ikilisinde yapılıyor.)
     */
    private suspend fun preflightCheck(): String? = try {
        val req = Request.Builder()
            .url("$MODELS_LIST_URL?key=$apiKey")
            .build()
        withContext(Dispatchers.IO) {
            restClient.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    null
                } else {
                    val body = try { resp.body?.string()?.take(300) } catch (e: Exception) { null }
                    "API kontrolü başarısız: HTTP ${resp.code}${if (!body.isNullOrBlank()) " — $body" else ""}"
                }
            }
        }
    } catch (e: Exception) {
        "Ağa ulaşılamıyor (${e.javaClass.simpleName}: ${e.message}). İnternet bağlantını / VPN-güvenlik duvarı ayarlarını kontrol et."
    }

    /**
     * GET /v1beta/models üzerinden bu API key'e gerçekten açık olan modelleri
     * çeker, supportedGenerationMethods içinde "bidiGenerateContent" olanları
     * filtreler ve en olası çalışacak adaydan en az olasıya doğru sıralar.
     *
     * Sıralama sezgisel bir skorla yapılır:
     *  - "native-audio" içeriyorsa yüksek puan (asıl aradığımız aile bu)
     *  - "flash" içeriyorsa orta puan (pro'dan daha hızlı/ucuz, genelde daha
     *    geniş kotayla açık)
     *  - "dialog" içeriyorsa küçük bir bonus (pinned, "-latest" alias'ı değil;
     *    alias'ların quota/entitlement tarafında bazen hiç tanınmadığı
     *    görülmüştü)
     *  - "transcribe"/"transcription" içeriyorsa AĞIR ceza: bu varyant
     *    transkripsiyon-only olup responseModalities=AUDIO isteğini sunucu
     *    tarafında reddediyor (1007 ile kapanıyor). bidiGenerateContent
     *    listede görünse bile sesli sohbet için kullanılamıyor — yine de tüm
     *    diğer adaylar tükenirse en son çare olarak listede kalsın diye
     *    tamamen çıkarmıyoruz, sadece en sona atıyoruz.
     *  - "thinking" / "exp" / "preview" içeriyorsa hafif ceza (daha kararsız
     *    veya daha yavaş olma ihtimali)
     * Daha önce bu süreçte başarılı olmuş bir model varsa (preferredModel),
     * skor sırasından bağımsız olarak listenin en başına alınır.
     */
    private suspend fun discoverLiveModels(): List<String> = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("$MODELS_LIST_URL?key=$apiKey")
            .build()
        restClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                throw IOException("Model listesi HTTP ${resp.code} döndürdü")
            }
            val body = resp.body?.string() ?: "{}"
            val json = JSONObject(body)
            val modelsArray = json.optJSONArray("models") ?: JSONArray()

            val scored = mutableListOf<Pair<String, Int>>()
            for (i in 0 until modelsArray.length()) {
                val m = modelsArray.optJSONObject(i) ?: continue
                val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
                var hasBidi = false
                for (j in 0 until methods.length()) {
                    if (methods.optString(j) == "bidiGenerateContent") {
                        hasBidi = true
                        break
                    }
                }
                if (!hasBidi) continue

                val name = m.optString("name").takeIf { it.isNotBlank() } ?: continue
                val lower = name.lowercase()
                var score = 0
                if (lower.contains("native-audio")) score += 100
                if (lower.contains("flash")) score += 50
                if (lower.contains("dialog")) score += 20
                if (lower.contains("thinking")) score -= 10
                if (lower.contains("exp") || lower.contains("preview")) score -= 5
                if (lower.contains("transcribe") || lower.contains("transcription")) score -= 500
                scored += name to score
            }

            val ordered = scored
                .sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenBy { it.first })
                .map { it.first }

            val pref = preferredModel
            if (pref != null && ordered.contains(pref)) {
                listOf(pref) + ordered.filterNot { it == pref }
            } else {
                ordered
            }
        }
    }

    /**
     * Belirli bir modeli gerçekten deneyip setupComplete gelene, sunucu bir
     * error frame'i gönderene, soket kapanana/başarısız olana ya da zaman
     * aşımına uğrayana kadar bekler. Sonucu AttemptResult olarak döndürür,
     * connect()'teki döngü bir sonraki adaya geçip geçmeyeceğine buna göre
     * karar verir.
     */
    private suspend fun tryModel(model: String): AttemptResult {
        val deferred = CompletableDeferred<AttemptResult>()
        pendingAttempt = deferred
        currentModel = model
        setupDone.set(false)

        val url = "$WS_URL?key=$apiKey"
        val request = Request.Builder().url(url).build()

        /**
         * Bu deneme (attempt) için oluşturulan soketi ayrıca yerel bir değişkende de
         * tutuyoruz. SEBEP: eskiden watchdog, sınıf değişkeni `webSocket`'i referans
         * alıyordu; bu, farklı denemeler arasında race condition'a yol açabiliyordu.
         * Artık watchdog HER ZAMAN kendi attempt'ine ait `thisSocket`'i iptal ediyor.
         */
        lateinit var thisSocket: WebSocket
        thisSocket = wsClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.i(TAG, "WebSocket open (model=$model)")
                connected.set(true)
                sendSetup(model)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                Log.d(TAG, "Message: $text")
                handleMessage(text)
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                Log.w(TAG, "Closing: $code $reason (model=$model)")
                connected.set(false)
                val wasSetup = setupDone.get()
                setupDone.set(false)
                watchdogJob?.cancel()
                scope.launch { _events.emit(LiveEvent.Disconnected("$code $reason")) }
                if (!wasSetup) {
                    // Setup tamamlanmadan kapandıysa bu denemenin başarısız
                    // sayılması lazım ki sıradaki adaya geçilebilsin.
                    deferred.complete(AttemptResult.Failure("bağlantı kapandı: $code $reason"))
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                // response body carries the real reason on handshake rejection
                // (bad API key, model not found for this API version, etc.).
                val bodySnippet = try { response?.body?.string()?.take(300) } catch (e: Exception) { null }
                val detail = listOfNotNull(
                    response?.let { "HTTP ${it.code}" },
                    bodySnippet,
                    "${t.javaClass.simpleName}: ${t.message}",
                    t.cause?.let { "neden: ${it.javaClass.simpleName}: ${it.message}" }
                ).joinToString(" - ").ifBlank { "Bağlantı hatası" }
                Log.e(TAG, "Failure (model=$model): $detail", t)
                connected.set(false)
                setupDone.set(false)
                watchdogJob?.cancel()
                deferred.complete(AttemptResult.Failure(detail))
            }
        })
        webSocket = thisSocket

        // Watchdog: sunucu setup'ı ne kabul eder ne reddeder (ne setupComplete
        // ne error/close gelir) diye bu adayda sonsuza kadar takılı kalmasın.
        watchdogJob = scope.launch {
            delay(ATTEMPT_TIMEOUT_MS)
            if (!setupDone.get()) {
                Log.w(TAG, "Setup timeout (model=$model)")
                thisSocket.cancel()
                deferred.complete(
                    AttemptResult.Failure("${ATTEMPT_TIMEOUT_MS / 1000}sn içinde setupComplete gelmedi (zaman aşımı)")
                )
            }
        }

        val result = deferred.await()
        watchdogJob?.cancel()
        if (result is AttemptResult.Failure) {
            // Başarısız denemenin soketini temizle ki bir sonraki adayın
            // soketiyle karışmasın.
            thisSocket.cancel()
        }
        pendingAttempt = null
        return result
    }

    private fun sendSetup(model: String) {
        val setup = JSONObject().apply {
            put("setup", JSONObject().apply {
                put("model", model)
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().put("AUDIO"))
                    put("speechConfig", JSONObject().apply {
                        put("voiceConfig", JSONObject().apply {
                            put("prebuiltVoiceConfig", JSONObject().apply {
                                put("voiceName", voiceName)
                            })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
                })
            })
        }
        webSocket?.send(setup.toString())
        Log.i(TAG, "Setup sent (model=$model)")
    }

    private fun handleMessage(text: String) {
        try {
            val json = JSONObject(text)

            if (json.has("setupComplete")) {
                setupDone.set(true)
                watchdogJob?.cancel()
                scope.launch { _events.emit(LiveEvent.Ready) }
                Log.i(TAG, "Setup complete (model=$currentModel)")
                pendingAttempt?.complete(AttemptResult.Success(currentModel))
                return
            }

            // Server-side rejection sent as a JSON error frame instead of a socket close.
            json.optJSONObject("error")?.let { err ->
                val msg = err.optString("message", "Sunucu hatası")
                Log.e(TAG, "Server error (model=$currentModel): $msg")
                scope.launch { _events.emit(LiveEvent.Error(msg)) }
                pendingAttempt?.complete(AttemptResult.Failure(msg))
                return
            }

            val serverContent = json.optJSONObject("serverContent") ?: return

            // Interrupted
            if (serverContent.optBoolean("interrupted", false)) {
                scope.launch { _events.emit(LiveEvent.Interrupted) }
            }

            // Model turn parts
            val modelTurn = serverContent.optJSONObject("modelTurn")
            modelTurn?.optJSONArray("parts")?.let { parts ->
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    // Inline audio
                    part.optJSONObject("inlineData")?.let { inline ->
                        val mime = inline.optString("mimeType", "")
                        val data = inline.optString("data", "")
                        if (data.isNotEmpty() && mime.contains("audio")) {
                            val bytes = Base64.decode(data, Base64.DEFAULT)
                            scope.launch { _events.emit(LiveEvent.Audio(bytes)) }
                        }
                    }
                    // Text
                    part.optString("text", "").takeIf { it.isNotBlank() }?.let { t ->
                        scope.launch { _events.emit(LiveEvent.Text(t)) }
                    }
                }
            }

            if (serverContent.optBoolean("turnComplete", false)) {
                scope.launch { _events.emit(LiveEvent.TurnComplete) }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Parse error", e)
        }
    }

    /** Send 16-bit PCM audio chunk (16 kHz mono recommended). */
    fun sendAudio(pcm16: ByteArray) {
        if (!setupDone.get()) return
        val b64 = Base64.encodeToString(pcm16, Base64.NO_WRAP)
        val msg = JSONObject().apply {
            put("realtimeInput", JSONObject().apply {
                put("mediaChunks", JSONArray().put(JSONObject().apply {
                    put("mimeType", "audio/pcm;rate=16000")
                    put("data", b64)
                }))
            })
        }
        webSocket?.send(msg.toString())
    }

    fun sendText(text: String) {
        if (!setupDone.get() || text.isBlank()) return
        val msg = JSONObject().apply {
            put("clientContent", JSONObject().apply {
                put("turns", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", text)))
                }))
                put("turnComplete", true)
            })
        }
        webSocket?.send(msg.toString())
    }

    fun close() {
        watchdogJob?.cancel()
        pendingAttempt?.cancel()
        pendingAttempt = null
        webSocket?.close(1000, "bye")
        webSocket = null
        connected.set(false)
        setupDone.set(false)
        scope.cancel()
    }

    fun isReady(): Boolean = setupDone.get()
}

sealed class LiveEvent {
    data object Ready : LiveEvent()
    data class Audio(val pcm: ByteArray) : LiveEvent()
    data class Text(val text: String) : LiveEvent()
    data object TurnComplete : LiveEvent()
    data object Interrupted : LiveEvent()
    data class Disconnected(val reason: String) : LiveEvent()
    data class Error(val message: String) : LiveEvent()
    data class Log(val message: String) : LiveEvent()
}
