package com.jarvis.ai.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import com.jarvis.ai.theme.*
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Tek bir devre izi: merkezden dışa doğru bir radyal parça + ucunda hafif teğetsel bir kıvrım. */
private data class Trace(
    val angle: Float,      // radyan
    val rStart: Float,     // 0..1 (baseR'ye göre oran)
    val rEnd: Float,
    val bend: Float,       // teğetsel sapma (radyan)
    val width: Float,
    val alpha: Float,
    val node: Boolean      // ucunda küçük parlak nokta var mı
)

/** Sabit tohumla bir kez üretilir; her karede sadece döndürülür, yeniden hesaplanmaz. */
private fun generateTraces(seed: Long, count: Int): List<Trace> {
    val rnd = Random(seed)
    return List(count) {
        val angle = rnd.nextFloat() * (Math.PI * 2).toFloat()
        val rStart = 0.30f + rnd.nextFloat() * 0.55f
        val rEnd = (rStart + 0.05f + rnd.nextFloat() * 0.20f).coerceAtMost(1.05f)
        Trace(
            angle = angle,
            rStart = rStart,
            rEnd = rEnd,
            bend = (rnd.nextFloat() - 0.5f) * 0.5f,
            width = 1f + rnd.nextFloat() * 2f,
            alpha = 0.18f + rnd.nextFloat() * 0.55f,
            node = rnd.nextFloat() > 0.78f
        )
    }
}

@Composable
fun JarvisOrb(
    state: OrbState,
    audioLevel: Float = 0f,
    modifier: Modifier = Modifier
) {
    val infinite = rememberInfiniteTransition(label = "orb")

    val rotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(26000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rot"
    )

    val rotation2 by infinite.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(19000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rot2"
    )

    val pulse by infinite.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Devre izleri sadece bir kez üretilir (performans); dönme animasyonu
    // canvas transform ile yapılır, veri yeniden hesaplanmaz.
    val traces = remember { generateTraces(seed = 7L, count = 160) }
    val innerTraces = remember { generateTraces(seed = 42L, count = 90) }

    val color = when (state) {
        OrbState.LISTENING -> Green
        OrbState.SPEAKING -> Blue
        OrbState.THINKING -> Gold
        OrbState.MUTED -> Muted
        OrbState.ERROR -> Red
        OrbState.CONNECTING -> Orange
        OrbState.IDLE -> Teal
    }

    val level = audioLevel.coerceIn(0f, 1f)
    val scale = pulse + level * 0.2f

    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val baseR = size.minDimension / 2f * 0.46f * scale
        val center = Offset(cx, cy)

        // Dış yumuşak parlama
        for (i in 3 downTo 1) {
            drawCircle(
                color = color.copy(alpha = 0.05f + (3 - i) * 0.025f),
                radius = baseR + i * 20f + level * 10f,
                center = center,
                style = Stroke(width = 1f)
            )
        }

        // Dış çerçeve halkası
        drawCircle(
            color = color.copy(alpha = 0.28f),
            radius = baseR,
            center = center,
            style = Stroke(width = 1.2f)
        )

        // Ana devre dokusu — dıştan içe dönen kalın grup
        rotate(rotation, center) {
            traces.forEach { t ->
                val a1 = t.angle
                val p1 = Offset(
                    cx + cos(a1) * baseR * t.rStart,
                    cy + sin(a1) * baseR * t.rStart
                )
                val p2 = Offset(
                    cx + cos(a1) * baseR * t.rEnd,
                    cy + sin(a1) * baseR * t.rEnd
                )
                drawLine(
                    color = color.copy(alpha = t.alpha),
                    start = p1,
                    end = p2,
                    strokeWidth = t.width,
                    cap = StrokeCap.Round
                )
                // teğetsel kıvrım (devre köşesi hissi)
                val a2 = a1 + t.bend
                val p3 = Offset(
                    cx + cos(a2) * baseR * (t.rEnd + 0.04f),
                    cy + sin(a2) * baseR * (t.rEnd + 0.04f)
                )
                drawLine(
                    color = color.copy(alpha = t.alpha * 0.8f),
                    start = p2,
                    end = p3,
                    strokeWidth = t.width * 0.8f,
                    cap = StrokeCap.Round
                )
                if (t.node) {
                    drawCircle(
                        color = color.copy(alpha = (t.alpha + 0.3f).coerceAtMost(1f)),
                        radius = t.width * 1.4f,
                        center = p3
                    )
                }
            }
        }

        // İkinci, ters yönde dönen daha ince/iç doku katmanı (derinlik hissi)
        rotate(-rotation2, center) {
            innerTraces.forEach { t ->
                val a1 = t.angle
                val r1 = baseR * t.rStart * 0.6f
                val r2 = baseR * t.rEnd * 0.62f
                val p1 = Offset(cx + cos(a1) * r1, cy + sin(a1) * r1)
                val p2 = Offset(cx + cos(a1) * r2, cy + sin(a1) * r2)
                drawLine(
                    color = color.copy(alpha = t.alpha * 0.55f),
                    start = p1,
                    end = p2,
                    strokeWidth = t.width * 0.7f,
                    cap = StrokeCap.Round
                )
            }
        }

        // Kırık, çok ince dış tık halkası (radar/dial hissi)
        rotate(rotation * 0.4f, center) {
            val ticks = 72
            for (i in 0 until ticks) {
                if (i % 3 == 0) continue // kırık görünüm
                val a = (i * 2 * Math.PI / ticks).toFloat()
                val rOut = baseR * 1.08f
                val rIn = baseR * (0.98f + (i % 5) * 0.006f)
                drawLine(
                    color = color.copy(alpha = 0.30f),
                    start = Offset(cx + cos(a) * rIn, cy + sin(a) * rIn),
                    end = Offset(cx + cos(a) * rOut, cy + sin(a) * rOut),
                    strokeWidth = 1.2f,
                    cap = StrokeCap.Round
                )
            }
        }

        // Merkezdeki "göz/girdap" — üst üste binen yaylarla spiral bir iris
        rotate(rotation * 0.6f, center) {
            val eyeR = baseR * 0.34f
            val stroke = Stroke(width = 2.6f, cap = StrokeCap.Round)
            drawArc(
                color = color.copy(alpha = 0.85f),
                startAngle = 20f,
                sweepAngle = 260f,
                useCenter = false,
                topLeft = Offset(cx - eyeR, cy - eyeR),
                size = Size(eyeR * 2, eyeR * 2),
                style = stroke
            )
            val eyeR2 = eyeR * 0.62f
            drawArc(
                color = color.copy(alpha = 0.7f),
                startAngle = 160f,
                sweepAngle = 240f,
                useCenter = false,
                topLeft = Offset(cx - eyeR2, cy - eyeR2),
                size = Size(eyeR2 * 2, eyeR2 * 2),
                style = Stroke(width = 2f, cap = StrokeCap.Round)
            )
        }

        // Parlak çekirdek
        drawCircle(
            color = color.copy(alpha = 0.9f),
            radius = baseR * 0.10f,
            center = center
        )
        drawCircle(
            color = color.copy(alpha = 0.35f),
            radius = baseR * 0.16f,
            center = center,
            style = Stroke(width = 1.5f)
        )
    }
}
