package com.jarvis.ai.audio

import android.media.*
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Captures 16 kHz mono PCM16 from mic and plays 24 kHz PCM16 output.
 */
class AudioEngine {

    companion object {
        private const val TAG = "AudioEngine"
        const val INPUT_RATE = 16000
        const val OUTPUT_RATE = 24000
        private const val CHANNEL = AudioFormat.CHANNEL_IN_MONO
        private const val ENCODING = AudioFormat.ENCODING_PCM_16BIT
    }

    private var recorder: AudioRecord? = null
    private var track: AudioTrack? = null
    private val recording = AtomicBoolean(false)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level

    var onPcmChunk: ((ByteArray) -> Unit)? = null

    fun startRecording() {
        if (recording.get()) return
        val minBuf = AudioRecord.getMinBufferSize(INPUT_RATE, CHANNEL, ENCODING)
        val bufSize = maxOf(minBuf, INPUT_RATE * 2 / 10) // ~100 ms

        try {
            recorder = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                INPUT_RATE,
                CHANNEL,
                ENCODING,
                bufSize
            )
            if (recorder?.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "AudioRecord init failed")
                return
            }
            recorder?.startRecording()
            recording.set(true)

            scope.launch {
                val buf = ByteArray(bufSize)
                while (recording.get()) {
                    val read = recorder?.read(buf, 0, buf.size) ?: -1
                    if (read > 0) {
                        val chunk = buf.copyOf(read)
                        computeLevel(chunk)
                        onPcmChunk?.invoke(chunk)
                    }
                }
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "Permission missing", e)
        } catch (e: Exception) {
            Log.e(TAG, "startRecording", e)
        }
    }

    fun stopRecording() {
        recording.set(false)
        try {
            recorder?.stop()
            recorder?.release()
        } catch (_: Exception) {}
        recorder = null
        _level.value = 0f
    }

    fun playPcm(pcm: ByteArray) {
        if (pcm.isEmpty()) return
        scope.launch {
            try {
                ensureTrack()
                track?.write(pcm, 0, pcm.size)
            } catch (e: Exception) {
                Log.e(TAG, "playPcm", e)
            }
        }
    }

    private fun ensureTrack() {
        if (track != null) return
        val minBuf = AudioTrack.getMinBufferSize(
            OUTPUT_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            ENCODING
        )
        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(OUTPUT_RATE)
                    .setEncoding(ENCODING)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(minBuf * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track?.play()
    }

    fun stopPlayback() {
        try {
            track?.stop()
            track?.release()
        } catch (_: Exception) {}
        track = null
    }

    fun release() {
        stopRecording()
        stopPlayback()
        scope.cancel()
    }

    private fun computeLevel(pcm: ByteArray) {
        var sum = 0.0
        var i = 0
        while (i + 1 < pcm.size) {
            val sample = (pcm[i].toInt() and 0xFF) or (pcm[i + 1].toInt() shl 8)
            val s = sample.toShort().toInt()
            sum += s * s
            i += 2
        }
        val n = pcm.size / 2
        if (n > 0) {
            val rms = Math.sqrt(sum / n) / 32768.0
            _level.value = rms.toFloat().coerceIn(0f, 1f)
        }
    }
}
