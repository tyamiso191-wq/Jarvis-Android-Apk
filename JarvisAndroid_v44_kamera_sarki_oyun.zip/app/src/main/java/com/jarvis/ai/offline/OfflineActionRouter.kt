package com.jarvis.ai.offline

import android.content.Context
import com.jarvis.ai.music.FavoriteSongStore
import com.jarvis.ai.music.MusicController
import com.jarvis.ai.vision.CameraRecorderController
import java.util.Locale

/**
 * OfflineResponder sadece "cevap gerektiren" (metin) istekleri karşılıyordu.
 * Burası ise EYLEM gerektiren ama YİNE DE tamamen cihaz üzerinde, internete
 * hiç çıkmadan yapılabilecek istekleri karşılıyor:
 *
 *  - "Jarvis kamerayı başlat"            -> ön kameradan video kaydı başlatır
 *  - "Jarvis kamerayı durdur"            -> kaydı durdurur
 *  - "favori şarkım ... olsun"           -> ileride kullanılacak şarkıyı ezberler
 *  - "Jarvis kamerayı ve şarkıyı başlat" -> ezberlenen şarkıyı yerelden çalar
 *                                            + kamerayı aynı anda başlatır
 *  - "aktivite öner"                     -> rastgele bir şey önerir
 *  - "oyun oynayalım" / "taş kağıt makas"-> basit, tamamen offline bir oyun
 *
 * JarvisViewModel.sendText() içinde, OfflineResponder'dan HEMEN ÖNCE
 * çağrılır -- eşleşirse Gemini'ye hiç gidilmez.
 */
object OfflineActionRouter {

    // Kullanıcılar bazen Türkçe klavye yerine ASCII klavyeyle yazıyor
    // ("baslat" / "başlat", "sarki" / "şarkı" karışık gelebiliyor). Eşleşme
    // hatalarını önlemek için hem metni hem kalıpları Türkçe karakterleri
    // ASCII'ye sadeleştirerek karşılaştırıyoruz.
    private fun foldTurkish(s: String): String = s
        .replace('ş', 's').replace('Ş', 's')
        .replace('ı', 'i').replace('İ', 'i')
        .replace('ğ', 'g').replace('Ğ', 'g')
        .replace('ü', 'u').replace('Ü', 'u')
        .replace('ö', 'o').replace('Ö', 'o')
        .replace('ç', 'c').replace('Ç', 'c')

    private val CAMERA_WORD = Regex("kamera")
    private val SONG_WORD = Regex("sarki|muzik")
    private val START_WORD = Regex("baslat|\\bac\\b|calistir")
    private val STOP_WORD = Regex("durdur|kapat")

    private val SET_FAVORITE = Regex(
        "favori sarkim (.+?) olsun|" +
            "sarki olarak (.+?)(?:'yi|'yi|'i|'i)? (?:kaydet|ayarla)|" +
            "(.+?) sarkisini (?:favorim yap|kaydet|ayarla)|" +
            "sonra(?:dan)? (.+?) cal(?:acaksin)?$|" +
            "ileride (.+?) cal(?:acaksin)?$"
    )

    private val CAMERA_START = Regex("kamera(?:yi|nin|ni)?.*(?:baslat|\\bac\\b)")
    private val CAMERA_STOP = Regex("kamera(?:yi|nin|ni)?.*(?:durdur|kapat)")

    private val ACTIVITY_SUGGEST = Regex(
        "aktivite oner|ne yapsam|ne yapabilirim|sikildim|bir sey oner|aktivite onerisi|bana.*aktivite"
    )

    private val GAME_START = Regex(
        "oyun oyna|birlikte oyna|beraber oyna|tas kagit makas oyna|oyun oynayalim|hadi oyna"
    )

    data class Result(val reply: String)

    /**
     * @return eşleşip işlendiyse konuşulacak/loglara yazılacak cevap metni,
     * eşleşmediyse null (bu durumda normal akışa -- OfflineResponder/Gemini'ye -- devam edilir).
     */
    suspend fun tryHandle(context: Context, rawText: String): Result? {
        // rawLower: orijinal Türkçe karakterler korunur (şarkı adı MediaStore
        // aramasına gidecek, "ı"/"ş"/"ğ" kaybolursa yerel eşleşme bozulabilir).
        // text: kalıp eşleştirme için ASCII'ye sadeleştirilmiş hali. foldTurkish
        // her Türkçe karakteri TEK bir ASCII karakterle değiştirdiğinden
        // (uzunluk hiç değişmez), text üzerindeki bir eşleşmenin index aralığı
        // rawLower üzerinde de aynı karşılığa denk gelir -- şarkı adını
        // rawLower'dan bu aralıkla kesip diakritikleri koruyoruz.
        val rawLower = rawText.trim().lowercase(Locale("tr", "TR"))
        val text = foldTurkish(rawLower)
        if (text.isBlank()) return null

        // Oyun aktifse önce hamleyi kontrol et (taş/kağıt/makas gibi tek
        // kelimelik cevaplar başka hiçbir kalıpla karışmasın diye en başta).
        if (RockPaperScissorsGame.isActive) {
            RockPaperScissorsGame.tryHandleMove(text)?.let { return Result(it) }
        }

        val hasCamera = CAMERA_WORD.containsMatchIn(text)
        val hasSong = SONG_WORD.containsMatchIn(text)
        val hasStart = START_WORD.containsMatchIn(text)
        val hasStop = STOP_WORD.containsMatchIn(text)

        // "Kamerayı ve şarkıyı durdur" gibi kombo durdurma.
        if (hasCamera && hasSong && hasStop) {
            MusicController.stop(context)
            val path = CameraRecorderController.stopRecording(context)
            return Result(
                if (path != null) "Şarkıyı ve kamerayı durdurdum efendim. Kayıt şurada: $path"
                else "Şarkıyı durdurdum efendim, kamera zaten kapalıydı."
            )
        }

        // "Kamerayı ve şarkıyı başlat" gibi kombo başlatma -- ezberlenen
        // favori şarkı + ön kamera kaydı aynı anda.
        if (hasCamera && hasSong && hasStart) {
            val favorite = FavoriteSongStore.get(context)
            if (favorite == null) {
                return Result(
                    "Kamerayı başlatabilirim efendim ama önce hangi şarkıyı çalacağımı söylemediniz. " +
                        "\"Favori şarkım <şarkı adı> olsun\" deyip bir kere kaydedin, sonra bu komut hep onu çalar."
                )
            }
            val musicResult = MusicController.play(context, favorite)
            val videoPath = CameraRecorderController.startRecording(context, useFrontCamera = true)
            val musicMsg = when (musicResult) {
                is MusicController.PlayResult.PlayingLocal -> "\"${musicResult.title}\" çalıyor"
                is MusicController.PlayResult.PlayingStream -> "\"${musicResult.title}\" çalıyor"
                is MusicController.PlayResult.OpenedYoutubeSearch -> "şarkı için arama açtım"
                is MusicController.PlayResult.PermissionMissing -> "şarkı için izin eksik"
                is MusicController.PlayResult.Error -> "şarkı çalınamadı"
            }
            return Result(
                if (videoPath != null) "Kamerayı başlattım ve $musicMsg efendim."
                else "$musicMsg efendim ama kamerayı başlatamadım -- kamera izni verilmemiş olabilir."
            )
        }

        // Sadece şarkı hatırlama isteği (kamera/başlat sinyali yok).
        SET_FAVORITE.find(text)?.let { match ->
            val group = match.groups.drop(1).filterNotNull().firstOrNull { it.value.isNotBlank() }
            val song = group?.let { rawLower.substring(it.range.first, it.range.last + 1) }?.trim()
            if (!song.isNullOrBlank()) {
                FavoriteSongStore.set(context, song)
                return Result("Tamamdır efendim, bundan sonra \"kamerayı ve şarkıyı başlat\" dediğinizde \"$song\" çalacağım.")
            }
        }

        // Sadece kamerayı durdur (şarkı kelimesi yok).
        if (!hasSong && CAMERA_STOP.containsMatchIn(text)) {
            val path = CameraRecorderController.stopRecording(context)
            return Result(
                if (path != null) "Kamerayı durdurdum efendim. Kayıt şurada: $path"
                else "Kamera zaten kapalıydı efendim."
            )
        }

        // Sadece kamerayı başlat (şarkı kelimesi yok) -- ön kameradan video kaydı.
        if (!hasSong && CAMERA_START.containsMatchIn(text)) {
            if (!CameraRecorderController.hasCameraPermission(context)) {
                return Result("Kamera izni vermemişsiniz efendim, önce ayarlardan kamera iznini açar mısınız?")
            }
            val path = CameraRecorderController.startRecording(context, useFrontCamera = true)
            return Result(
                if (path != null) "Sizi ön kameradan kayda alıyorum efendim. \"Kamerayı durdur\" deyince bitiririm."
                else "Kamerayı başlatamadım efendim, izin ya da donanım sorunu olabilir."
            )
        }

        if (GAME_START.containsMatchIn(text)) {
            return Result(RockPaperScissorsGame.start())
        }

        if (ACTIVITY_SUGGEST.containsMatchIn(text)) {
            return Result(ActivitySuggester.suggest())
        }

        return null
    }
}
