package com.jarvis.ai.music

import android.content.Context

/**
 * "Sonra çalacağın şarkı X olsun" gibi ÖNCEDEN söylenen bir şarkı adını
 * hatırlar. MusicController.lastPlayedQuery'den FARKLI olarak bu değer
 * kullanıcı yeni bir şarkı çaldıkça DEĞİŞMEZ -- yalnızca kullanıcı açıkça
 * "favori şarkım ... olsun" dediğinde güncellenir. "Kamerayı ve şarkıyı
 * başlat" gibi kombo komutlarda hangi şarkının çalınacağını bulmak için
 * kullanılır.
 */
object FavoriteSongStore {
    private const val PREFS_NAME = "favorite_song_store"
    private const val PREF_FAVORITE = "favorite_song_query"

    fun get(context: Context): String? =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(PREF_FAVORITE, null)
            ?.takeIf { it.isNotBlank() }

    fun set(context: Context, songQuery: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(PREF_FAVORITE, songQuery.trim()).apply()
    }
}
