package com.jarvis.ai.ui

import android.annotation.SuppressLint
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.jarvis.ai.LogLine
import com.jarvis.ai.files.FileTool
import com.jarvis.ai.MiniWindowContent
import com.jarvis.ai.attach.Attachment
import com.jarvis.ai.theme.*
import com.jarvis.ai.weather.WeatherInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MainScreen(
    orbState: OrbState,
    status: String,
    logs: List<LogLine>,
    micOn: Boolean,
    isConnected: Boolean,
    audioLevel: Float,
    weather: WeatherInfo?,
    speedLabel: String,
    onCycleSpeed: () -> Unit,
    voiceLabel: String,
    onCycleVoice: () -> Unit,
    onToggleMic: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onSendText: (String) -> Unit,
    attachments: List<Attachment> = emptyList(),
    onPickPhoto: () -> Unit = {},
    onPickFile: () -> Unit = {},
    onRemoveAttachment: (Int) -> Unit = {},
    onChangeKey: () -> Unit = {},
    wakeWordEnabled: Boolean = false,
    onToggleWakeWord: () -> Unit = {},
    memoryCount: Int = 0,
    onOpenMemory: () -> Unit = {},
    onOpenTerminal: () -> Unit = {},
    miniWindow: MiniWindowContent? = null,
    onCloseMiniWindow: () -> Unit = {},
    onSaveAttachment: (FileTool.StagedFile) -> Unit = {}
) {
    // Yazı alanı TEK bir yerde (en dış Box'ta) duruyor: klavye kapalıyken sağ
    // sohbet panelinin altındaki küçük yerinde, klavye açılınca ekranın altında
    // klavyenin hemen üstünde tam genişlikte. Aynı composable'ın sadece
    // konumu/genişliği değiştiği için klavye açıkken odak (imleç) kaybolmuyor.
    var input by rememberSaveable { mutableStateOf("") }
    val density = LocalDensity.current
    var barHeightPx by remember { mutableIntStateOf(0) }
    val imeVisible = WindowInsets.ime.getBottom(density) > 0

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
    ) {
        val barWidth by animateDpAsState(
            targetValue = if (imeVisible) maxWidth else CHAT_PANEL_WIDTH,
            label = "chatBarWidth"
        )
        // Çubuğun kapladığı yükseklik (ekler satırı dahil) kadar yeri sohbet
        // panelinde boş bırak; panelin kendi alt iç boşluğu (10dp) zaten var.
        val inputReserve = with(density) { barHeightPx.toDp() } - 10.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Panel)
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "J.A.R.V.I.S",
                        color = Teal,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 3.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "MOBILE",
                        color = Dim,
                        fontSize = 10.sp,
                        letterSpacing = 2.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                StatusBadge(orbState)
                Spacer(Modifier.width(10.dp))
                // Tüm işlev düğmeleri (terminal / uyandırma kelimesi / anahtar
                // değiştir) artık tek tek sağ üstte durmuyor, buradaki ☰ menüsüne
                // toplandı -- üst çubuk sadeleşsin diye.
                var menuExpanded by remember { mutableStateOf(false) }
                Box {
                    Text(
                        "☰",
                        color = Teal,
                        fontSize = 20.sp,
                        modifier = Modifier.clickable { menuExpanded = true }
                    )
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false },
                        modifier = Modifier.background(Panel)
                    ) {
                        // "Geliştikçe öğrenme" göstergesi: Jarvis'in kendiliğinden
                        // biriktirdiği kalıcı not sayısı, zamanla büyür -- tıklanamaz,
                        // sadece bilgi amaçlı.
                        DropdownMenuItem(
                            text = { Text("🧠  Hafıza: $memoryCount not öğrendi", color = Teal, fontFamily = FontFamily.Monospace, fontSize = 13.sp) },
                            onClick = { menuExpanded = false; onOpenMemory() }
                        )
                        DropdownMenuItem(
                            text = { Text("⌨  Terminal", color = Text, fontFamily = FontFamily.Monospace, fontSize = 13.sp) },
                            onClick = { menuExpanded = false; onOpenTerminal() }
                        )
                        // "Jarvis" uyandırma kelimesi (ekran kapalıyken/arka planda
                        // dinleme) açık/kapalı göstergesi -- açıkken yeşil, kapalıyken
                        // soluk metinle.
                        DropdownMenuItem(
                            text = {
                                Text(
                                    if (wakeWordEnabled) "🎙  Arka plan dinleme: AÇIK" else "🎙  Arka plan dinleme: KAPALI",
                                    color = if (wakeWordEnabled) Green else Text,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 13.sp
                                )
                            },
                            onClick = { menuExpanded = false; onToggleWakeWord() }
                        )
                        // API anahtarını değiştirmek için: eskiden bu ekrandan geri
                        // dönüşün hiçbir yolu yoktu (anahtar bir kere kaydedilince
                        // ApiKeyScreen bir daha hiç gösterilmiyordu). Yeni/yanlış
                        // anahtar girildiğinde kullanıcının tekrar giriş ekranına
                        // dönebilmesi için eklendi.
                        DropdownMenuItem(
                            text = { Text("🔑  Anahtarı değiştir", color = Text, fontFamily = FontFamily.Monospace, fontSize = 13.sp) },
                            onClick = { menuExpanded = false; onChangeKey() }
                        )
                    }
                }
            }

            // Body: sol saat paneli | orta orb + kontroller | sağ sohbet paneli
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                ClockPanel(
                    weather = weather,
                    modifier = Modifier
                        .width(150.dp)
                        .fillMaxHeight()
                )

                CenterPanel(
                    orbState = orbState,
                    status = status,
                    audioLevel = audioLevel,
                    micOn = micOn,
                    isConnected = isConnected,
                    speedLabel = speedLabel,
                    onCycleSpeed = onCycleSpeed,
                    voiceLabel = voiceLabel,
                    onCycleVoice = onCycleVoice,
                    onToggleMic = onToggleMic,
                    onStart = onStart,
                    onStop = onStop,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                )

                ChatPanel(
                    logs = logs,
                    inputReserve = inputReserve.coerceAtLeast(0.dp),
                    onSaveAttachment = onSaveAttachment,
                    modifier = Modifier
                        .width(CHAT_PANEL_WIDTH)
                        .fillMaxHeight()
                )
            }
        }

        ChatInputBar(
            input = input,
            onInputChange = { input = it },
            attachments = attachments,
            expanded = imeVisible,
            onPickPhoto = onPickPhoto,
            onPickFile = onPickFile,
            onRemoveAttachment = onRemoveAttachment,
            onSend = {
                onSendText(input)
                input = ""
            },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .imePadding()
                .width(barWidth)
                .onSizeChanged { barHeightPx = it.height }
        )

        if (miniWindow != null) {
            MiniWindowOverlay(
                content = miniWindow,
                onClose = onCloseMiniWindow
            )
        }
    }
}

/**
 * watch_video / open_website ile açılan sol üst mini pencere: küçükken
 * ekranın sol üst köşesinde küçük bir kutu olarak durur (dokununca büyütme/
 * kapatma tuşları belirir), "⤢" (büyüt) tuşuna basınca tüm ekranı kaplar.
 * İçerik video ise YouTube'un embed oynatıcısı, site ise doğrudan o sayfa
 * bir WebView içinde gösterilir.
 */
@Composable
private fun BoxWithConstraintsScope.MiniWindowOverlay(
    content: MiniWindowContent,
    onClose: () -> Unit
) {
    val key = when (content) {
        is MiniWindowContent.Video -> content.videoId
        is MiniWindowContent.Site -> content.url
    }
    val title = when (content) {
        is MiniWindowContent.Video -> content.title
        is MiniWindowContent.Site -> content.title
    }

    // Yeni bir video/site açıldığında her zaman küçük haliyle başlasın.
    var expanded by remember(key) { mutableStateOf(false) }
    // Küçükken tek dokunuşla büyütme/kapatma tuşları belirsin, sonra
    // otomatik gizlensin -- kullanıcı tarif ettiği akış zaten "dokun,
    // sonra büyüt tuşuna bas" şeklinde.
    var controlsVisible by remember(key) { mutableStateOf(true) }

    LaunchedEffect(controlsVisible, expanded) {
        if (controlsVisible && !expanded) {
            delay(4000)
            controlsVisible = false
        }
    }

    val targetWidth = if (expanded) maxWidth else 176.dp
    val targetHeight = if (expanded) maxHeight else 100.dp
    val animatedWidth by animateDpAsState(targetValue = targetWidth, label = "miniWindowWidth")
    val animatedHeight by animateDpAsState(targetValue = targetHeight, label = "miniWindowHeight")

    Box(
        modifier = Modifier
            .align(Alignment.TopStart)
            .padding(if (expanded) 0.dp else 12.dp)
            .size(width = animatedWidth, height = animatedHeight)
            .clip(RoundedCornerShape(if (expanded) 0.dp else 10.dp))
            .background(Color.Black)
            .border(
                1.dp,
                if (expanded) Color.Transparent else TealDim,
                RoundedCornerShape(if (expanded) 0.dp else 10.dp)
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { controlsVisible = true }
    ) {
        when (content) {
            is MiniWindowContent.Video -> YoutubeEmbedWebView(
                videoId = content.videoId,
                modifier = Modifier.fillMaxSize()
            )
            is MiniWindowContent.Site -> SiteWebView(
                url = content.url,
                modifier = Modifier.fillMaxSize()
            )
        }

        if (controlsVisible || expanded) {
            // Üstte hafif bir gölge + başlık + büyüt/küçült ve kapat tuşları.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    title,
                    color = Text,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    if (expanded) "⤡" else "⤢",
                    color = Teal,
                    fontSize = 14.sp,
                    modifier = Modifier.clickable {
                        expanded = !expanded
                        controlsVisible = true
                    }
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "✕",
                    color = Red,
                    fontSize = 13.sp,
                    modifier = Modifier.clickable { onClose() }
                )
            }
        }
    }
}

/** Herhangi bir web sitesini olduğu gibi (normal gezinme ile) gösteren WebView. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun SiteWebView(url: String, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                // Kullanıcı sayfa içinde linke basarsa tarayıcıya/başka bir
                // uygulamaya sıçramadan, aynı mini pencerede kalmaya devam
                // etsin diye kendi WebViewClient'ı.
                webViewClient = android.webkit.WebViewClient()
                webChromeClient = WebChromeClient()
                setBackgroundColor(android.graphics.Color.WHITE)
                // browser_control aracının (geri/ileri/yenile) o an açık
                // olan bu WebView'i sesli komutla yönetebilmesi için.
                com.jarvis.ai.web.BrowserController.attach(this)
            }
        },
        update = { webView ->
            if (webView.tag != url) {
                webView.tag = url
                webView.loadUrl(url)
            }
            com.jarvis.ai.web.BrowserController.attach(webView)
        },
        onRelease = { webView -> com.jarvis.ai.web.BrowserController.detach(webView) }
    )
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun YoutubeEmbedWebView(videoId: String, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                webChromeClient = WebChromeClient()
                setBackgroundColor(android.graphics.Color.BLACK)
            }
        },
        update = { webView ->
            // Sadece video değiştiğinde yeniden yükle -- her recomposition'da
            // aynı içeriği tekrar yüklemek oynatmayı baştan sarıp duruyor.
            if (webView.tag != videoId) {
                webView.tag = videoId
                // ÖNEMLİ: embed URL'sini doğrudan loadUrl ile açmak "Hata 153 -
                // Video oynatıcı yapılandırma hatası" veriyordu -- YouTube,
                // yerleştirilmiş (embed) oynatıcının GEÇERLİ bir Referer/origin
                // ile geldiğini istiyor (bkz. developers.google.com/youtube/
                // terms/required-minimum-functionality), boş Referer'lı bir
                // WebView isteğinde bunu reddediyor. Çözüm: embed iframe'ini
                // kendi ürettiğimiz küçük bir HTML sayfasının içine koyup
                // loadDataWithBaseURL ile GERÇEK bir https base URL (burada
                // youtube.com'un kendisi) vererek yüklüyoruz -- böylece
                // iframe isteği geçerli bir origin/referrer ile gidiyor.
                val html = """
                    <!DOCTYPE html>
                    <html>
                    <head>
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <style>
                        html, body { margin:0; padding:0; background:#000; height:100%; overflow:hidden; }
                        iframe { position:absolute; top:0; left:0; width:100%; height:100%; border:0; }
                    </style>
                    </head>
                    <body>
                    <iframe
                        src="https://www.youtube.com/embed/$videoId?autoplay=1&playsinline=1&rel=0"
                        allow="autoplay; encrypted-media; fullscreen"
                        allowfullscreen>
                    </iframe>
                    </body>
                    </html>
                """.trimIndent()
                webView.loadDataWithBaseURL(
                    "https://www.youtube.com",
                    html,
                    "text/html",
                    "UTF-8",
                    null
                )
            }
        }
    )
}


private val CHAT_PANEL_WIDTH = 260.dp

@Composable
private fun ClockPanel(weather: WeatherInfo?, modifier: Modifier = Modifier) {
    var time by remember { mutableStateOf(SimpleDateFormat("HH:mm", Locale("tr")).format(Date())) }
    var date by remember { mutableStateOf(SimpleDateFormat("d MMMM", Locale("tr")).format(Date())) }
    var day by remember { mutableStateOf(SimpleDateFormat("EEEE", Locale("tr")).format(Date())) }

    LaunchedEffect(Unit) {
        while (true) {
            val now = Date()
            time = SimpleDateFormat("HH:mm", Locale("tr")).format(now)
            date = SimpleDateFormat("d MMMM", Locale("tr")).format(now)
            day = SimpleDateFormat("EEEE", Locale("tr")).format(now)
            delay(1000)
        }
    }

    Column(
        modifier = modifier
            .border(1.dp, TealDim.copy(alpha = 0.4f))
            .padding(14.dp)
    ) {
        Text(
            "SAAT",
            color = Dim,
            fontSize = 10.sp,
            letterSpacing = 2.sp,
            fontFamily = FontFamily.Monospace
        )
        Spacer(Modifier.height(6.dp))
        Text(
            time,
            color = Teal,
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Spacer(Modifier.height(4.dp))
        Text(
            date.uppercase(Locale("tr")),
            color = Text,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            day.uppercase(Locale("tr")),
            color = Dim,
            fontSize = 11.sp,
            letterSpacing = 1.sp,
            fontFamily = FontFamily.Monospace
        )

        // Saat/tarih ile hava durumu arasındaki boşluğu esnek bırak,
        // hava durumu her zaman panelin en altına yaslansın.
        Spacer(Modifier.weight(1f))

        WeatherRow(weather)
    }
}

@Composable
private fun WeatherRow(weather: WeatherInfo?) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, TealDim.copy(alpha = 0.3f))
            .padding(10.dp)
    ) {
        Text(
            "HAVA DURUMU",
            color = Dim,
            fontSize = 9.sp,
            letterSpacing = 1.5.sp,
            fontFamily = FontFamily.Monospace
        )
        Spacer(Modifier.height(6.dp))
        if (weather == null) {
            Text(
                "…",
                color = Dim,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(weather.emoji, fontSize = 20.sp)
                Spacer(Modifier.width(6.dp))
                Text(
                    "${weather.tempC}°",
                    color = Teal,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(Modifier.height(2.dp))
            Text(
                weather.description,
                color = Text,
                fontSize = 10.sp,
                letterSpacing = 0.5.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                weather.city.uppercase(Locale("tr")),
                color = Dim,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun CenterPanel(
    orbState: OrbState,
    status: String,
    audioLevel: Float,
    micOn: Boolean,
    isConnected: Boolean,
    speedLabel: String,
    onCycleSpeed: () -> Unit,
    voiceLabel: String,
    onCycleVoice: () -> Unit,
    onToggleMic: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            JarvisOrb(
                state = orbState,
                audioLevel = audioLevel,
                modifier = Modifier.size(230.dp)
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = status,
                color = Dim,
                fontSize = 12.sp,
                letterSpacing = 2.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(Modifier.height(6.dp))
            // Konuşma hızı ve ses: dokununca sırayla değişir.
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "HIZ: $speedLabel  ⟳",
                    color = Teal,
                    fontSize = 10.sp,
                    letterSpacing = 1.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .clickable(onClick = onCycleSpeed)
                        .background(Teal.copy(alpha = 0.08f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
                Text(
                    text = "$voiceLabel  ⟳",
                    color = Teal,
                    fontSize = 10.sp,
                    letterSpacing = 1.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .clickable(onClick = onCycleVoice)
                        .background(Teal.copy(alpha = 0.08f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }

        // Durdur | Başlat | Mikrofon
        // TV kumandasıyla açılışta hemen bir yere odaklanılsın diye BAŞLAT
        // butonuna varsayılan odak veriliyor -- kumanda kullanıcısı ekrana
        // girer girmez sağ/sol ile gezinebilir, orta tuşla tetikleyebilir.
        val startFocusRequester = remember { FocusRequester() }
        LaunchedEffect(Unit) {
            runCatching { startFocusRequester.requestFocus() }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ModeButton(
                label = "DURDUR",
                active = !isConnected,
                activeColor = Gold,
                onClick = onStop,
                modifier = Modifier.weight(1f)
            )
            ModeButton(
                label = "BAŞLAT",
                active = isConnected && !micOn,
                activeColor = Green,
                onClick = onStart,
                modifier = Modifier.weight(1f),
                focusRequester = startFocusRequester
            )
            ModeButton(
                label = "🎙 MİKROFON",
                active = micOn,
                activeColor = Blue,
                onClick = onToggleMic,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun ModeButton(
    label: String,
    active: Boolean,
    activeColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester? = null
) {
    // Eski sürüm düz/mat dolgulu bir Material Button'du ("çok yumuşak" görünüyordu).
    // Bunun yerine ince çerçeveli, camsı/neon dolgulu bir HUD butonu: pasifken bile
    // çerçeve ve yazı rengi belirgin, aktifken çerçeve+dolgu+yazı tam parlaklığa çıkıyor.
    val borderAlpha = if (active) 1f else 0.55f
    val fillAlpha = if (active) 0.24f else 0.08f
    val textAlpha = if (active) 1f else 0.8f

    // TV kumandası / klavye ok tuşlarıyla gezinirken hangi butonun odakta
    // olduğu belli olsun diye: clickable zaten DPAD/Enter ile tetiklemeyi
    // ve ok tuşlarıyla odak değişimini otomatik destekliyor (Compose'un
    // yerleşik davranışı), burada SADECE odaklandığında görünür bir vurgu
    // (kalın beyazımsı çerçeve + hafif parlama) ekliyoruz -- aksi halde
    // kumandayla hangi butonda olduğunu göremezsin.
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    val focusBorderWidth by animateDpAsState(if (isFocused) 2.6.dp else 1.4.dp, label = "focusBorder")

    Box(
        modifier = modifier
            .height(50.dp)
            .background(Bg)
            .border(1.dp, activeColor.copy(alpha = borderAlpha * 0.35f), RoundedCornerShape(4.dp))
            .padding(2.dp)
            .background(
                activeColor.copy(alpha = if (isFocused) fillAlpha + 0.18f else fillAlpha),
                RoundedCornerShape(3.dp)
            )
            .border(
                focusBorderWidth,
                if (isFocused) Color.White.copy(alpha = 0.9f) else activeColor.copy(alpha = borderAlpha),
                RoundedCornerShape(3.dp)
            )
            .let { if (focusRequester != null) it.focusRequester(focusRequester) else it }
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.foundation.LocalIndication.current,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (isFocused) Color.White else activeColor.copy(alpha = textAlpha),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun ChatPanel(
    logs: List<LogLine>,
    inputReserve: Dp,
    onSaveAttachment: (FileTool.StagedFile) -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            scope.launch { listState.animateScrollToItem(logs.lastIndex) }
        }
    }

    Column(
        modifier = modifier
            .border(1.dp, TealDim.copy(alpha = 0.4f))
            .padding(10.dp)
    ) {
        Text(
            "SOHBET",
            color = Dim,
            fontSize = 10.sp,
            letterSpacing = 2.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            items(logs) { line ->
                LogRow(line, onSaveAttachment)
            }
        }

        // Yazı çubuğu ekranın en dış katmanında çiziliyor (bkz. MainScreen /
        // ChatInputBar); burada sadece onun oturacağı yeri boş bırakıyoruz.
        Spacer(Modifier.height(inputReserve))
    }
}

/**
 * Sohbet yazı çubuğu: 📎 (fotoğraf/dosya ekle) + yazı alanı + gönder.
 *
 * [expanded] (= klavye açık) iken çağıran taraf bunu ekranın altında,
 * klavyenin üstünde tam genişlikte konumlar; kapalıyken sohbet panelinin
 * altındaki küçük yerine oturur. Bu composable sadece görünümü çizer.
 */
@Composable
private fun ChatInputBar(
    input: String,
    onInputChange: (String) -> Unit,
    attachments: List<Attachment>,
    expanded: Boolean,
    onPickPhoto: () -> Unit,
    onPickFile: () -> Unit,
    onRemoveAttachment: (Int) -> Unit,
    onSend: () -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    var menuOpen by remember { mutableStateOf(false) }
    var focused by remember { mutableStateOf(false) }
    val canSend = input.isNotBlank() || attachments.isNotEmpty()

    // Klavye kapanınca (geri tuşu vb.) alan odağı bıraksın: bir sonraki
    // dokunuşta klavye sorunsuz tekrar açılır.
    LaunchedEffect(expanded) {
        if (!expanded) focusManager.clearFocus()
    }

    Column(
        modifier = modifier
            .background(if (expanded) Bg else Color.Transparent)
            .drawBehind {
                if (expanded) {
                    drawLine(
                        color = TealDim,
                        start = Offset(0f, 0f),
                        end = Offset(size.width, 0f),
                        strokeWidth = 1.dp.toPx()
                    )
                }
            }
            .padding(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 10.dp)
    ) {
        if (attachments.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                attachments.forEachIndexed { i, a ->
                    AttachmentChip(a) { onRemoveAttachment(i) }
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Box {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .border(1.dp, TealDim, RoundedCornerShape(8.dp))
                        .clickable { menuOpen = true },
                    contentAlignment = Alignment.Center
                ) {
                    Text("📎", fontSize = 16.sp)
                }
                DropdownMenu(
                    expanded = menuOpen,
                    onDismissRequest = { menuOpen = false },
                    modifier = Modifier.background(Panel)
                ) {
                    DropdownMenuItem(
                        text = {
                            Text("🖼  Fotoğraf", color = Text, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                        },
                        onClick = { menuOpen = false; onPickPhoto() }
                    )
                    DropdownMenuItem(
                        text = {
                            Text("📄  Dosya", color = Text, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                        },
                        onClick = { menuOpen = false; onPickFile() }
                    )
                }
            }

            Spacer(Modifier.width(6.dp))

            BasicTextField(
                value = input,
                onValueChange = onInputChange,
                singleLine = true,
                textStyle = TextStyle(
                    color = Text,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace
                ),
                cursorBrush = SolidColor(Teal),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() }),
                modifier = Modifier
                    .weight(1f)
                    .onFocusChanged { focused = it.isFocused },
                decorationBox = { inner ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .border(
                                1.dp,
                                if (focused) Teal else TealDim,
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 10.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        if (input.isEmpty()) {
                            Text(
                                "Yaz…",
                                color = Dim,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp
                            )
                        }
                        inner()
                    }
                }
            )

            Spacer(Modifier.width(6.dp))

            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(Teal.copy(alpha = if (canSend) 1f else 0.4f), RoundedCornerShape(8.dp))
                    .clickable(enabled = canSend, onClick = onSend),
                contentAlignment = Alignment.Center
            ) {
                Text("➤", color = Bg, fontSize = 16.sp)
            }
        }
    }
}

@Composable
private fun AttachmentChip(attachment: Attachment, onRemove: () -> Unit) {
    Row(
        modifier = Modifier
            .background(Teal.copy(alpha = 0.10f), RoundedCornerShape(6.dp))
            .border(1.dp, TealDim, RoundedCornerShape(6.dp))
            .clickable(onClick = onRemove)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(attachment.icon, fontSize = 11.sp)
        Spacer(Modifier.width(4.dp))
        Text(
            attachment.name,
            color = Text,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 110.dp)
        )
        Spacer(Modifier.width(6.dp))
        Text("✕", color = Dim, fontSize = 10.sp)
    }
}

@Composable
private fun StatusBadge(state: OrbState) {
    val (label, color) = when (state) {
        OrbState.LISTENING -> "DİNLİYOR" to Green
        OrbState.SPEAKING -> "KONUŞUYOR" to Blue
        OrbState.THINKING -> "DÜŞÜNÜYOR" to Gold
        OrbState.CONNECTING -> "BAĞLANIYOR" to Orange
        OrbState.ERROR -> "HATA" to Red
        OrbState.MUTED -> "SESSİZ" to Muted
        OrbState.IDLE -> "HAZIR" to Dim
    }
    Text(
        text = label,
        color = color,
        fontSize = 10.sp,
        letterSpacing = 1.sp,
        fontFamily = FontFamily.Monospace,
        modifier = Modifier
            .background(color.copy(alpha = 0.12f), RoundedCornerShape(4.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
private fun LogRow(line: LogLine, onSaveAttachment: (FileTool.StagedFile) -> Unit) {
    val (prefix, color) = when (line.who) {
        "user" -> "SİZ:" to Teal
        "jarvis", "jarvis_file" -> "JARVIS:" to Green
        else -> "SYS:" to Dim
    }
    Column(modifier = Modifier.padding(vertical = 3.dp)) {
        Text(
            prefix,
            color = color,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        val attachment = line.attachment
        if (attachment != null) {
            AttachmentCard(attachment, onSave = { onSaveAttachment(attachment) })
        } else {
            Text(
                line.text,
                color = Text.copy(alpha = 0.85f),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

/** Sohbete eklenen ama henüz cihaza KAYDEDİLMEMİŞ bir dosya/görsel kartı. */
@Composable
private fun AttachmentCard(attachment: FileTool.StagedFile, onSave: () -> Unit) {
    var saved by remember(attachment.uri) { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .padding(top = 2.dp)
            .widthIn(max = 220.dp)
            .background(Teal.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
            .border(1.dp, TealDim, RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        if (attachment.isImage) {
            coil.compose.AsyncImage(
                model = attachment.uri,
                contentDescription = attachment.filename,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 180.dp)
                    .clip(RoundedCornerShape(6.dp)),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop
            )
            Spacer(Modifier.height(6.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (attachment.isImage) "🖼" else "📄", fontSize = 13.sp)
            Spacer(Modifier.width(6.dp))
            Text(
                attachment.filename,
                color = Text,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(if (saved) TealDim.copy(alpha = 0.2f) else Teal, RoundedCornerShape(6.dp))
                .clickable(enabled = !saved) { saved = true; onSave() }
                .padding(vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (saved) "✓ Kaydedildi" else "⬇ Kaydet",
                color = if (saved) Dim else Bg,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
