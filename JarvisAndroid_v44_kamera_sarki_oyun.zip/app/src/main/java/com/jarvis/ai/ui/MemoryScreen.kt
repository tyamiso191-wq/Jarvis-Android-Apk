package com.jarvis.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.memory.MemoryStore
import com.jarvis.ai.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * "Geliştikçe öğrenme" hissini SOMUT/DÜRÜST hale getiren ekran: Jarvis'in
 * kendiliğinden (ya da "hatırla" ile) biriktirdiği her notu, ne zaman
 * öğrendiğiyle birlikte kronolojik gösterir -- bir günlük/log gibi. Kendi
 * kodunu yeniden yazmıyor; ama gerçekten zamanla büyüyen, gerçekten
 * davranışını etkileyen bir profil bu -- ekran bunu şeffafça gösteriyor.
 */
@Composable
fun MemoryScreen(
    items: List<MemoryStore.MemoryItem>,
    onDelete: (String) -> Unit,
    onClose: () -> Unit
) {
    val dateFmt = remember { SimpleDateFormat("d MMMM, HH:mm", Locale("tr", "TR")) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Panel)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "🧠 GELİŞİM GÜNLÜĞÜ",
                color = Teal,
                fontSize = 15.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Text(
                "Kapat ✕",
                color = Dim,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.clickable { onClose() }
            )
        }

        Text(
            "Jarvis'in şu ana kadar seninle ilgili kendiliğinden fark edip " +
                "kaydettiği ${items.size} not. Her sohbette bunları hatırlıyor, " +
                "cevapları zamanla buna göre şekilleniyor.",
            color = Dim,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(16.dp)
        )

        if (items.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(
                    "Henüz bir şey öğrenmedi. Konuştukça burası dolacak.",
                    color = Dim,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().weight(1f, fill = false),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(items.sortedByDescending { it.savedAtMillis }) { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(TealDim.copy(alpha = 0.06f), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                item.text,
                                color = Text,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                dateFmt.format(Date(item.savedAtMillis)),
                                color = Dim,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "🗑",
                            fontSize = 14.sp,
                            modifier = Modifier.clickable { onDelete(item.id) }
                        )
                    }
                }
            }
        }
    }
}
