package com.jarvis.ai.offline

import kotlin.random.Random

/**
 * "Oyun oynayalım" dendiğinde başlayan, tamamen cihaz üzerinde (rastgele
 * sayı üretimiyle) oynanan taş-kağıt-makas. İnternet gerekmez, Gemini'ye
 * hiç gidilmez -- OfflineActionRouter üzerinden çağrılır.
 */
object RockPaperScissorsGame {
    @Volatile var isActive: Boolean = false
        private set

    private var jarvisScore = 0
    private var userScore = 0

    // Görüntülenen (Türkçe) ve karşılaştırma için kullanılan (ASCII) adlar.
    // NOT: tryHandleMove'a OfflineActionRouter'dan zaten Türkçe karakterleri
    // sadeleştirilmiş (foldTurkish) metin geliyor, o yüzden anahtarlar ASCII.
    private val MOVES = listOf("tas" to "taş", "kagit" to "kağıt", "makas" to "makas")

    fun start(): String {
        isActive = true
        jarvisScore = 0
        userScore = 0
        return "Hadi taş kağıt makas oynayalım efendim! \"Taş\", \"kağıt\" ya da \"makas\" deyin. " +
            "\"Oyunu bitir\" dediğinizde durdururum."
    }

    /**
     * @param foldedText OfflineActionRouter tarafından zaten küçük harfe
     * çevrilip Türkçe karakterleri ASCII'ye sadeleştirilmiş metin (tas/kagit/makas).
     * @return oyun aktifken kullanıcının mesajıyla eşleşen bir cevap, yoksa null.
     */
    fun tryHandleMove(foldedText: String): String? {
        if (!isActive) return null

        if (Regex("oyunu bitir|oyunu durdur|yeter|dur artik").containsMatchIn(foldedText)) {
            isActive = false
            return "Oyunu bitirdik efendim. Skor: Siz $userScore - $jarvisScore Ben. Keyifliydi!"
        }

        val userMove = MOVES.firstOrNull { (asciiKey, _) -> foldedText.contains(asciiKey) }
            ?: return "Anlamadım efendim, \"taş\", \"kağıt\" veya \"makas\" deyin (ya da \"oyunu bitir\")."

        val jarvisMove = MOVES[Random.nextInt(MOVES.size)]
        val outcome = decide(userMove.first, jarvisMove.first)
        val outcomeText = when (outcome) {
            1 -> { userScore++; "Kazandınız!" }
            -1 -> { jarvisScore++; "Ben kazandım!" }
            else -> "Berabere!"
        }
        return "Siz: ${userMove.second}, Ben: ${jarvisMove.second} -- $outcomeText (Skor: Siz $userScore - $jarvisScore Ben)"
    }

    /** @return 1 kullanıcı kazandı, -1 jarvis kazandı, 0 berabere (parametreler ASCII: tas/kagit/makas). */
    private fun decide(user: String, jarvis: String): Int {
        if (user == jarvis) return 0
        return when (user to jarvis) {
            "tas" to "makas", "kagit" to "tas", "makas" to "kagit" -> 1
            else -> -1
        }
    }
}
