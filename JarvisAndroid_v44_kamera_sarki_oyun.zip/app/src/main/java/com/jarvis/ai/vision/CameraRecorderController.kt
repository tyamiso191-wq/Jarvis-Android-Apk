package com.jarvis.ai.vision

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.os.Environment
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.PendingRecording
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/**
 * "Jarvis kamerayı başlat" komutu için: CameraVisionController'daki tek kare
 * (analyze_webcam) yakalamanın aksine, burası GERÇEK bir video kaydı başlatır
 * ve durdurulana kadar (ya da "kamerayı durdur" denene kadar) kayda devam
 * eder. Tamamen cihaz üzerinde çalışır, hiçbir ağ isteği atmaz -- tek
 * gereksinim CAMERA (ve varsa RECORD_AUDIO) izinleri, ikisi de manifestte
 * zaten mevcut.
 *
 * Video, uygulamanın kendi özel dış depolama alanına (Movies/Jarvis) yazılır
 * -- Android sürümü ne olursa olsun ekstra bir depolama izni GEREKMEZ.
 */
object CameraRecorderController {
    private const val TAG = "CameraRecorderController"

    private class SimpleLifecycleOwner : LifecycleOwner {
        val registry = LifecycleRegistry.createUnsafe(this)
        override val lifecycle: Lifecycle get() = registry
    }

    @Volatile private var cachedProvider: ProcessCameraProvider? = null
    @Volatile private var activeRecording: Recording? = null
    @Volatile private var activeLifecycleOwner: SimpleLifecycleOwner? = null
    @Volatile var isRecording: Boolean = false
        private set
    @Volatile private var lastOutputFile: File? = null

    fun hasCameraPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun hasAudioPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /**
     * @param useFrontCamera true ise ön kamera ("bizi çeksin" senaryosu için
     * varsayılan budur).
     * @return başarılıysa kayıt dosyasının yolu, izin yoksa/hata olursa null.
     */
    @SuppressLint("MissingPermission") // RECORD_AUDIO/CAMERA izinleri çağrı öncesi elle kontrol ediliyor
    suspend fun startRecording(context: Context, useFrontCamera: Boolean = true): String? {
        if (isRecording) return lastOutputFile?.absolutePath
        if (!hasCameraPermission(context)) {
            Log.w(TAG, "Kamera izni yok, kayıt başlatılamıyor")
            return null
        }
        val appContext = context.applicationContext

        val provider = try {
            getCameraProvider(appContext)
        } catch (e: Exception) {
            Log.w(TAG, "Kamera sağlayıcısı alınamadı", e)
            return null
        }

        val lifecycleOwner = SimpleLifecycleOwner()
        lifecycleOwner.registry.currentState = Lifecycle.State.STARTED

        val recorder = Recorder.Builder()
            .setQualitySelector(QualitySelector.from(Quality.HD))
            .build()
        val videoCapture = VideoCapture.withOutput(recorder)

        val selector = if (useFrontCamera) {
            CameraSelector.DEFAULT_FRONT_CAMERA
        } else {
            CameraSelector.DEFAULT_BACK_CAMERA
        }

        val moviesDir = File(appContext.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "Jarvis")
        if (!moviesDir.exists()) moviesDir.mkdirs()
        val fileName = "jarvis_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date()) + ".mp4"
        val outputFile = File(moviesDir, fileName)

        return try {
            withContextMain(appContext) {
                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, selector, videoCapture)
            }

            val outputOptions = FileOutputOptions.Builder(outputFile).build()
            val pending: PendingRecording = recorder.prepareRecording(appContext, outputOptions).apply {
                if (hasAudioPermission(appContext)) withAudioEnabled()
            }

            activeRecording = pending.start(ContextCompat.getMainExecutor(appContext)) { event ->
                if (event is VideoRecordEvent.Finalize) {
                    if (event.hasError()) {
                        Log.w(TAG, "Video kaydı hata ile bitti: ${event.error}")
                    }
                }
            }
            activeLifecycleOwner = lifecycleOwner
            lastOutputFile = outputFile
            isRecording = true
            outputFile.absolutePath
        } catch (e: Exception) {
            Log.w(TAG, "Video kaydı başlatılamadı", e)
            withContextMain(appContext) { provider.unbindAll() }
            lifecycleOwner.registry.currentState = Lifecycle.State.DESTROYED
            null
        }
    }

    /** @return durdurulan kaydın dosya yolu (varsa), kayıt zaten yoksa null. */
    suspend fun stopRecording(context: Context): String? {
        if (!isRecording) return null
        val appContext = context.applicationContext
        val filePath = lastOutputFile?.absolutePath
        try {
            activeRecording?.stop()
        } catch (e: Exception) {
            Log.w(TAG, "Kayıt durdurulurken hata", e)
        }
        activeRecording = null
        try {
            withContextMain(appContext) { cachedProvider?.unbindAll() }
        } catch (_: Exception) {
        }
        activeLifecycleOwner?.registry?.currentState = Lifecycle.State.DESTROYED
        activeLifecycleOwner = null
        isRecording = false
        return filePath
    }

    private suspend fun withContextMain(context: Context, block: () -> Unit) {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { block() }
    }

    private suspend fun getCameraProvider(context: Context): ProcessCameraProvider {
        cachedProvider?.let { return it }
        return suspendCoroutine { cont ->
            val future = ProcessCameraProvider.getInstance(context)
            future.addListener({
                try {
                    val provider = future.get()
                    cachedProvider = provider
                    cont.resume(provider)
                } catch (e: Exception) {
                    cont.resumeWithException(e)
                }
            }, ContextCompat.getMainExecutor(context))
        }
    }
}
