package com.jarvis.ai.offline

/** "Aktivite öner" için internet gerektirmeyen sabit öneri listesi. */
object ActivitySuggester {
    private val SUGGESTIONS = listOf(
        "Biraz müzik açıp dans edebiliriz, isterseniz \"şarkı çal\" deyin efendim.",
        "Birlikte taş kağıt makas oynayabiliriz, \"oyun oynayalım\" demeniz yeterli.",
        "Kısa bir mola verip biraz esneyebilirsiniz efendim, göz ve boyun egzersizleri iyi gelir.",
        "İsterseniz kamerayı açıp kısa bir video kaydı alalım, güzel bir an yakalayabiliriz.",
        "Bugün için küçük bir yapılacaklar listesi çıkaralım mı efendim?",
        "Biraz kitap ya da makale okumak için iyi bir zaman olabilir.",
        "Odayı toparlamak ya da masanızı düzenlemek zihin açıcı olabilir efendim."
    )

    fun suggest(): String = SUGGESTIONS.random()
}
