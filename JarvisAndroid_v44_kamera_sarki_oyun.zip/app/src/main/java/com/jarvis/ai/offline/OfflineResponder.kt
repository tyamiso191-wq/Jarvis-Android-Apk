package com.jarvis.ai.offline

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.jarvis.ai.sysinfo.SysInfoTool
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Kullanıcı isteği: "selam, nasılsın, saat kaç gibi internet gerekmeyen
 * HERŞEYİ internetsiz yap". Bu obje, mesaj Gemini'ye hiç gönderilmeden ÖNCE
 * çalışır -- eşleşirse cevap ANINDA, tamamen cihaz üzerinde, internet
 * OLMASA BİLE üretilir (hem hızlı hem API kotasından tasarruf hem de
 * internet yokken bile çalışır).
 *
 * NET SINIR: burası sadece GERÇEKTEN internet gerektirmeyen, basit/sabit
 * şeyler için -- hava durumu, web arama, genel sohbet, araç çağırma
 * gerektiren HERHANGİ bir şey burada YOK, o zaman normal Gemini akışına
 * düşer (internet varsa çalışır, yoksa JarvisViewModel dürüstçe "internetim
 * yok" der, uydurma cevap vermez).
 */
object OfflineResponder {

    private val dateFmt = SimpleDateFormat("d MMMM yyyy, EEEE", Locale("tr", "TR"))
    private val timeFmt = SimpleDateFormat("HH:mm", Locale("tr", "TR"))

    private val GREETING = Regex("\\b(selam|merhaba|hey jarvis|hey|naber|n'aber|nasılsın|nasilsin|iyi misin|ne haber)\\b")
    private val THANKS = Regex("\\b(teşekkür|tesekkur|sağol|sagol|sağ ol|eyvallah)\\b")
    private val BYE = Regex("\\b(görüşürüz|gorusuruz|hoşça kal|hoscakal|bay bay|kendine iyi bak|iyi geceler)\\b")
    private val TIME_Q = Regex("saat kaç|saat ne|kaç oldu|saati söyle")
    private val DATE_Q = Regex("bugün.*tarih|tarih ne|ayın kaçı|hangi gündeyiz|bugün günlerden|hangi ay")
    private val BATTERY_Q = Regex("\\b(pil|şarj|batarya)\\b")
    private val RAM_Q = Regex("\\bram\\b")
    private val DISK_Q = Regex("depolama|hafıza kart|disk durumu")

    // Bunlardan biri geçiyorsa İNTERNET GEREKEBİLİR (arama, hava durumu,
    // genel bilgi vb.) -- yanlışlıkla offline'a düşüp yarım/yanlış cevap
    // vermesin diye bu kelimeler varsa offline eşleştirme YAPILMAZ.
    private val NEEDS_INTERNET_HINT = Regex(
        "hava durumu|kaç derece|ara|arat|search|kimdir|nedir|haberler|fiyat|kur ne|dolar|euro|youtube|video|müzik|şarkı|whatsapp|instagram|tiktok"
    )

    private val GREETING_REPLIES = listOf(
        "İyiyim efendim, teşekkür ederim. Siz nasılsınız?",
        "Her zamanki gibi hazırım efendim, buyrun.",
        "İyiyim, sağ olun efendim. Size nasıl yardımcı olabilirim?"
    )

    /**
     * SysInfoTool bir Context istiyor -- bu Context her sendText çağrısında
     * dışarıdan veriliyor (bkz. JarvisViewModel), burada saklanmıyor.
     */
    fun tryRespond(context: Context, rawText: String): String? {
        val text = rawText.trim().lowercase(Locale("tr", "TR"))
        if (text.isBlank()) return null
        if (NEEDS_INTERNET_HINT.containsMatchIn(text)) return null

        if (TIME_Q.containsMatchIn(text)) return "Saat şu an ${timeFmt.format(Date())} efendim."
        if (DATE_Q.containsMatchIn(text)) return "Bugün ${dateFmt.format(Date())} efendim."
        if (BATTERY_Q.containsMatchIn(text)) return SysInfoTool.query(context, "battery") + " efendim."
        if (RAM_Q.containsMatchIn(text)) return SysInfoTool.query(context, "ram") + " efendim."
        if (DISK_Q.containsMatchIn(text)) return SysInfoTool.query(context, "disk") + " efendim."
        if (THANKS.containsMatchIn(text)) return "Rica ederim efendim."
        if (BYE.containsMatchIn(text)) return "Görüşmek üzere efendim."
        if (GREETING.containsMatchIn(text)) return GREETING_REPLIES.random()

        return null
    }

    fun hasInternet(context: Context): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            true // emin olamıyorsak normal akışa (Gemini denemesine) izin ver
        }
    }
}
