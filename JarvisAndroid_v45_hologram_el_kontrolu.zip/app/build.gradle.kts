plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.jarvis.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jarvis.ai"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")

    // OkHttp for WebSocket (Gemini Live fallback / direct)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // JSON
    implementation("org.json:json:20240303")

    // Preference for API key storage
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // YouTube'da şarkı arayıp doğrudan ses akış URL'sini çıkarmak için
    // (yerelde bulunamayan şarkıları YouTube uygulamasına geçmeden, arka
    // planda MediaPlayer ile çalabilmek amacıyla).
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.26.5")

    // Windows Jarvis V3'ten taşınan webcam analizi (analyze_webcam) için:
    // önizleme göstermeden, arka planda tek bir kare yakalayıp Gemini'ye
    // gönderiyoruz.
    implementation("androidx.camera:camera-core:1.4.1")
    implementation("androidx.camera:camera-camera2:1.4.1")
    implementation("androidx.camera:camera-lifecycle:1.4.1")
    // "Kamerayı başlat" komutuyla gerçek video kaydı (analyze_webcam'in tek
    // kare yakalamasından farklı olarak) için: CameraRecorderController.
    implementation("androidx.camera:camera-video:1.4.1")

    // "Kamerayı aç" dedikten sonra ELİYLE Orb'u büyütüp küçültebilmesi /
    // döndürebilmesi için: MediaPipe Hand Landmarker (el eklem noktalarını
    // TAMAMEN CİHAZ ÜZERİNDE, internetsiz tespit eder). Bkz. gesture/HandGestureController.kt
    // ÖNEMLİ: bu kütüphane bir .task model dosyası ister, o dosya APK'ye
    // GÖMÜLÜ DEĞİL -- bkz. o dosyadaki üstteki not.
    implementation("com.google.mediapipe:tasks-vision:0.10.14")

    // Sohbete eklenen (henüz cihaza kaydedilmemiş) görsel ön izlemelerini
    // content:// Uri'den basitçe göstermek için.
    implementation("io.coil-kt:coil-compose:2.6.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
