package com.jarvis.ai.ui

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** "Hologram modu aç/kapat" komutuyla değiştirilen basit paylaşılan durum. */
object HologramModeState {
    private val _isActive = MutableStateFlow(false)
    val isActive: StateFlow<Boolean> = _isActive

    fun setActive(active: Boolean) {
        _isActive.value = active
    }

    fun toggle() {
        _isActive.value = !_isActive.value
    }
}
