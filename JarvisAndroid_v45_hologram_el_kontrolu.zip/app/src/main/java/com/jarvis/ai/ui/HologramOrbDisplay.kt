package com.jarvis.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * "Hologram modu" -- ekranın ortasına küçük bir şeffaf piramit (CD kutusundan
 * kesilmiş ya da hazır alınmış) konduğunda, Orb'un havada duran/dönen bir
 * hologram gibi görünmesini sağlayan klasik "Pepper's Ghost" illüzyonu.
 *
 * Fikir: aynı Orb'un 4 kopyası, piramidin 4 yüzüne denk gelecek şekilde
 * (üst/alt/sol/sağ) ekrana YERLEŞTİRİLİR ve HER BİRİ O YÜZE YANSIYINCA doğru
 * görünecek açıya DÖNDÜRÜLÜR. Telefon düz yatırılıp piramit tam ortaya
 * konunca, 4 yansıma birleşip ortada 3 boyutluymuş gibi duran bir Orb
 * görüntüsü oluşturur.
 *
 * Ekran arkaplanının SİYAH olması şart -- piramit yalnızca parlak pikselleri
 * yansıtır, siyah kısımlar şeffaf/görünmez kalır.
 */
@Composable
fun HologramOrbDisplay(
    orbState: OrbState,
    audioLevel: Float,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .background(Color.Black)
    ) {
        val side = minOf(maxWidth, maxHeight) * 0.32f

        // ÜST kenar: piramidin üst yüzüne yansıyacak kopya -- baş aşağı (180°).
        Box(Modifier.align(Alignment.TopCenter).size(side)) {
            JarvisOrb(state = orbState, audioLevel = audioLevel, modifier = Modifier.size(side), externalRotationDeg = 180f)
        }
        // ALT kenar: normal yön (0°) -- izleyiciye en yakın yüz genelde budur.
        Box(Modifier.align(Alignment.BottomCenter).size(side)) {
            JarvisOrb(state = orbState, audioLevel = audioLevel, modifier = Modifier.size(side), externalRotationDeg = 0f)
        }
        // SOL kenar: 90° döndürülmüş kopya.
        Box(Modifier.align(Alignment.CenterStart).size(side)) {
            JarvisOrb(state = orbState, audioLevel = audioLevel, modifier = Modifier.size(side), externalRotationDeg = 90f)
        }
        // SAĞ kenar: -90° (270°) döndürülmüş kopya.
        Box(Modifier.align(Alignment.CenterEnd).size(side)) {
            JarvisOrb(state = orbState, audioLevel = audioLevel, modifier = Modifier.size(side), externalRotationDeg = 270f)
        }
    }
}
