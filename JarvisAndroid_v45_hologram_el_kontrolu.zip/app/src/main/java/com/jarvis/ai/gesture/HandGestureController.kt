package com.jarvis.ai.gesture

/**
 * =============================================================================
 * ÖNEMLİ -- BU DOSYA BİR MODEL DOSYASI GEREKTİRİR (elle bir kere indirilmeli):
 * =============================================================================
 * MediaPipe Hand Landmarker, elin 21 eklem noktasını (parmak uçları, bilek vb.)
 * bulabilmek için küçük bir model dosyasına (.task) ihtiyaç duyar. Bu dosya
 * yaklaşık 5-8 MB'tır ve APK'nin İÇİNDE GÖMÜLÜ DEĞİLDİR -- benim bu ortamda
 * internet erişimim olmadığı için o dosyayı senin için indirip projeye
 * koyamadım. Uygulamanın "el ile kontrol" özelliğinin ÇALIŞABİLMESİ için SEN
 * (bir kere, kurulum sırasında) şunu yapmalısın:
 *
 *   1) Şu adresten "hand_landmarker.task" dosyasını indir:
 *      https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task
 *   2) Bu dosyayı projede şu klasöre koy:
 *      app/src/main/assets/hand_landmarker.task
 *      (assets klasörü yoksa: app/src/main -> New -> Directory -> "assets")
 *
 * Bu indirme SADECE BİR KERE, geliştirme/kurulum sırasında yapılıyor --
 * dosya projeye/APK'ye gömülüp telefona öyle kurulduğu için UYGULAMA
 * ÇALIŞIRKEN (telefonda) hiçbir internet gerekmez, her şey cihaz üzerinde
 * (offline) çalışır.
 *
 * Model dosyası assets'e konmadan bu özellik sessizce başarısız olur (init
 * hata loglar, "el kontrolü başlatılamadı" der) -- uygulamanın geri kalanını
 * ETKİLEMEZ.
 * =============================================================================
 */

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.YuvImage
import android.graphics.ImageFormat
import android.graphics.Rect
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.ByteArrayOutputStream
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * "Jarvis kamerayı aç" (video KAYDETMEDEN, sadece canlı el takibi için) dendiğinde
 * devreye girer: ön kameradan sürekli kare alır, MediaPipe ile elin eklem
 * noktalarını bulur ve:
 *  - başparmak-işaret parmağı arasındaki mesafeden (pinch) -> Orb'un BÜYÜKLÜĞÜNÜ,
 *  - elin bilek-orta parmak açısından -> Orb'un DÖNÜŞ açısını hesaplar.
 * Sonuçlar orbScale / orbRotationDeg StateFlow'larına yazılır; JarvisOrb
 * composable'ı bunları toplayıp gerçek zamanlı uygular. Tamamen cihaz
 * üzerinde çalışır, hiçbir ağ isteği YOKTUR.
 */
object HandGestureController {
    private const val TAG = "HandGestureController"
    private const val MODEL_ASSET = "hand_landmarker.task"

    private class SimpleLifecycleOwner : LifecycleOwner {
        val registry = LifecycleRegistry.createUnsafe(this)
        override val lifecycle: Lifecycle get() = registry
    }

    private val _orbScale = MutableStateFlow(1f)
    val orbScale: StateFlow<Float> = _orbScale

    private val _orbRotationDeg = MutableStateFlow(0f)
    val orbRotationDeg: StateFlow<Float> = _orbRotationDeg

    @Volatile var isActive: Boolean = false
        private set

    @Volatile private var handLandmarker: HandLandmarker? = null
    @Volatile private var cameraProvider: ProcessCameraProvider? = null
    @Volatile private var lifecycleOwner: SimpleLifecycleOwner? = null

    // Ham ölçüm çok titrek olduğu için yumuşatma (üstel hareketli ortalama).
    private const val SMOOTHING = 0.25f

    /** @return true ise başarıyla başladı, false ise (izin/model eksik vb.) başlayamadı. */
    fun start(context: Context): Boolean {
        if (isActive) return true
        val appContext = context.applicationContext

        val landmarker = try {
            val baseOptions = BaseOptions.builder().setModelAssetPath(MODEL_ASSET).build()
            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setResultListener { result, _ -> onResult(result) }
                .setErrorListener { e -> Log.w(TAG, "El takibi hatası", e) }
                .build()
            HandLandmarker.createFromOptions(appContext, options)
        } catch (e: Exception) {
            // Büyük ihtimalle assets/hand_landmarker.task eksik -- bkz. dosya başındaki not.
            Log.w(TAG, "El takibi başlatılamadı (model dosyası eksik olabilir: assets/$MODEL_ASSET)", e)
            return false
        }
        handLandmarker = landmarker

        val owner = SimpleLifecycleOwner()
        owner.registry.currentState = Lifecycle.State.STARTED
        lifecycleOwner = owner

        val future = ProcessCameraProvider.getInstance(appContext)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider

                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(ContextCompat.getMainExecutor(appContext)) { imageProxy ->
                    processFrame(imageProxy)
                }

                provider.unbindAll()
                provider.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
                isActive = true
            } catch (e: Exception) {
                Log.w(TAG, "Kameraya bağlanılamadı", e)
            }
        }, ContextCompat.getMainExecutor(appContext))

        return true
    }

    fun stop() {
        isActive = false
        try {
            cameraProvider?.unbindAll()
        } catch (_: Exception) {
        }
        cameraProvider = null
        lifecycleOwner?.registry?.currentState = Lifecycle.State.DESTROYED
        lifecycleOwner = null
        try {
            handLandmarker?.close()
        } catch (_: Exception) {
        }
        handLandmarker = null
        _orbScale.value = 1f
        _orbRotationDeg.value = 0f
    }

    private fun processFrame(imageProxy: ImageProxy) {
        val landmarker = handLandmarker
        if (landmarker == null) {
            imageProxy.close()
            return
        }
        try {
            val bitmap = imageProxyToBitmap(imageProxy)
            if (bitmap != null) {
                val mpImage = BitmapImageBuilder(bitmap).build()
                landmarker.detectAsync(mpImage, System.currentTimeMillis())
            }
        } catch (e: Exception) {
            Log.w(TAG, "Kare işlenemedi", e)
        } finally {
            imageProxy.close()
        }
    }

    private fun onResult(result: HandLandmarkerResult) {
        val hands = result.landmarks()
        if (hands.isEmpty()) return
        val hand = hands[0]
        if (hand.size < 21) return

        // 4 = başparmak ucu, 8 = işaret parmağı ucu, 0 = bilek, 9 = orta parmak kökü.
        val thumbTip = hand[4]
        val indexTip = hand[8]
        val wrist = hand[0]
        val middleMcp = hand[9]

        val pinchDist = hypot((thumbTip.x() - indexTip.x()).toDouble(), (thumbTip.y() - indexTip.y()).toDouble()).toFloat()
        // Normalize edilmiş (0..1) koordinatlarda tipik pinch mesafesi ~0.03 (kapalı) ile ~0.35 (açık) arası.
        val targetScale = mapRange(pinchDist, 0.03f, 0.35f, 0.5f, 2.2f).coerceIn(0.5f, 2.2f)

        val angleRad = atan2(
            (middleMcp.y() - wrist.y()).toDouble(),
            (middleMcp.x() - wrist.x()).toDouble()
        )
        // El dikeyken (parmaklar yukarı) açı -90°'ye yakın olur -- Orb'u 0°'de tutmak için offset uygulanıyor.
        val targetRotation = (Math.toDegrees(angleRad).toFloat() + 90f)

        _orbScale.value = lerp(_orbScale.value, targetScale, SMOOTHING)
        _orbRotationDeg.value = lerp(_orbRotationDeg.value, targetRotation, SMOOTHING)
    }

    private fun lerp(from: Float, to: Float, t: Float): Float = from + (to - from) * t

    private fun mapRange(v: Float, inMin: Float, inMax: Float, outMin: Float, outMax: Float): Float {
        val clamped = min(max(v, inMin), inMax)
        return outMin + (clamped - inMin) * (outMax - outMin) / (inMax - inMin)
    }

    /** YUV_420_888 (ImageAnalysis'in varsayılan formatı) -> dik çevrilmiş, ön kamera için aynalanmış Bitmap. */
    private fun imageProxyToBitmap(imageProxy: ImageProxy): Bitmap? {
        val image = imageProxy.image ?: return null
        val yBuffer = image.planes[0].buffer
        val uBuffer = image.planes[1].buffer
        val vBuffer = image.planes[2].buffer

        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()

        val nv21 = ByteArray(ySize + uSize + vSize)
        yBuffer.get(nv21, 0, ySize)
        vBuffer.get(nv21, ySize, vSize)
        uBuffer.get(nv21, ySize + vSize, uSize)

        val yuvImage = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
        val out = ByteArrayOutputStream()
        yuvImage.compressToJpeg(Rect(0, 0, image.width, image.height), 80, out)
        val bytes = out.toByteArray()
        val bitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null

        val rotationDeg = imageProxy.imageInfo.rotationDegrees
        val matrix = Matrix().apply {
            postRotate(rotationDeg.toFloat())
            // Ön kamera görüntüsü ayna gibi ters gelir -- doğal his için yatayda aynalıyoruz.
            postScale(-1f, 1f)
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }
}
