package com.jarvis.ai.ui

import android.annotation.SuppressLint
import android.view.ViewGroup
import com.jarvis.ai.gesture.HandGestureController
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.jarvis.ai.LogLine
import com.jarvis.ai.files.FileTool
import com.jarvis.ai.attach.Attachment
import com.jarvis.ai.theme.*
import com.jarvis.ai.weather.WeatherInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    orbState: OrbState,
    status: String,
    logs: List<LogLine>,
    micOn: Boolean,
    isConnected: Boolean,
    audioLevel: Float,
    weather: WeatherInfo?,
    speedLabel: String,
    onCycleSpeed: () -> Unit,
    voiceLabel: String,
    onCycleVoice: () -> Unit,
    onToggleMic: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onSendText: (String) -> Unit,
    attachments: List<Attachment> = emptyList(),
    onPickPhoto: () -> Unit = {},
    onPickFile: () -> Unit = {},
    onRemoveAttachment: (Int) -> Unit = {},
    onChangeKey: () -> Unit = {},
    wakeWordEnabled: Boolean = false,
    onToggleWakeWord: () -> Unit = {},
    memoryCount: Int = 0,
    onOpenMemory: () -> Unit = {},
    onOpenTerminal: () -> Unit = {},
    onSaveAttachment: (FileTool.StagedFile) -> Unit = {},
    portrait: Boolean = false,
    onToggleOrientation: () -> Unit = {}
,
    onTakePhoto: () -> Unit = {}
) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    // Yan menü ekranın ~5'te 1'i kadar; çok dar telefonlarda yazılar sığsın diye alt sınır 190dp.
    val screenW = LocalConfiguration.current.screenWidthDp.dp
    val drawerW = maxOf(screenW * 0.2f, 190.dp)
    val closeDrawer: () -> Unit = { scope.launch { drawerState.close() } }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier.width(drawerW),
                drawerContainerColor = Panel,
                drawerContentColor = Text,
                drawerShape = RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp)
            ) {
                DrawerContent(
                    portrait = portrait,
                    memoryCount = memoryCount,
                    wakeWordEnabled = wakeWordEnabled,
                    speedLabel = speedLabel,
                    voiceLabel = voiceLabel,
                    onClose = closeDrawer,
                    onOpenMemory = { closeDrawer(); onOpenMemory() },
                    onOpenTerminal = { closeDrawer(); onOpenTerminal() },
                    onToggleWakeWord = { closeDrawer(); onToggleWakeWord() },
                    onCycleSpeed = onCycleSpeed,
                    onCycleVoice = onCycleVoice,
                    onToggleOrientation = { closeDrawer(); onToggleOrientation() },
                    onChangeKey = { closeDrawer(); onChangeKey() }
                )
            }
        }
    ) {
        MainScreenBody(
        orbState = orbState,
        status = status,
        logs = logs,
        micOn = micOn,
        isConnected = isConnected,
        audioLevel = audioLevel,
        weather = weather,
        speedLabel = speedLabel,
        onCycleSpeed = onCycleSpeed,
        voiceLabel = voiceLabel,
        onCycleVoice = onCycleVoice,
        onToggleMic = onToggleMic,
        onStart = onStart,
        onStop = onStop,
        onSendText = onSendText,
        attachments = attachments,
        onPickPhoto = onPickPhoto,
        onPickFile = onPickFile,
        onRemoveAttachment = onRemoveAttachment,
        onChangeKey = onChangeKey,
        wakeWordEnabled = wakeWordEnabled,
        onToggleWakeWord = onToggleWakeWord,
        memoryCount = memoryCount,
        onOpenMemory = onOpenMemory,
        onOpenTerminal = onOpenTerminal,
        onSaveAttachment = onSaveAttachment,
        portrait = portrait,
        onToggleOrientation = onToggleOrientation,
        onTakePhoto = onTakePhoto,
        onOpenMenu = { scope.launch { drawerState.open() } }
        )
    }
}

@Composable
private fun DrawerContent(
    portrait: Boolean,
    memoryCount: Int,
    wakeWordEnabled: Boolean,
    speedLabel: String,
    voiceLabel: String,
    onClose: () -> Unit,
    onOpenMemory: () -> Unit,
    onOpenTerminal: () -> Unit,
    onToggleWakeWord: () -> Unit,
    onCycleSpeed: () -> Unit,
    onCycleVoice: () -> Unit,
    onToggleOrientation: () -> Unit,
    onChangeKey: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxHeight()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 10.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 8.dp, end = 4.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("J.A.R.V.I.S", color = Teal, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.5.sp, fontFamily = UiFont)
            Box(
                modifier = Modifier.size(32.dp).clip(CircleShape).clickable(onClick = onClose),
                contentAlignment = Alignment.Center
            ) { JIcon(JI.Close, tint = Dim, size = 18.dp) }
        }
        DrawerItem(JI.Sparkles, "Hafıza", "$memoryCount not", onClick = onOpenMemory)
        DrawerItem(JI.Terminal, "Terminal", onClick = onOpenTerminal)
        DrawerItem(
            JI.Moon, "Arka Plan Modu", if (wakeWordEnabled) "Açık" else "Kapalı",
            highlight = wakeWordEnabled, onClick = onToggleWakeWord
        )
        DrawerItem(JI.Speed, "Konuşma hızı", speedLabel, onClick = onCycleSpeed)
        DrawerItem(JI.Volume, "Ses", voiceLabel, onClick = onCycleVoice)
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.07f)))
        Spacer(Modifier.height(6.dp))
        DrawerItem(JI.Rotate, if (portrait) "Yatay ekran" else "Dikey ekran", onClick = onToggleOrientation)
        DrawerItem(JI.Key, "Anahtarı değiştir", onClick = onChangeKey)
    }
}

@Composable
private fun DrawerItem(
    icon: JI,
    label: String,
    sub: String? = null,
    highlight: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (highlight) Green.copy(alpha = 0.12f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        JIcon(icon, tint = if (highlight) Green else Teal, size = 20.dp)
        Spacer(Modifier.width(10.dp))
        Column {
            Text(label, color = Text, fontSize = 13.sp, fontFamily = UiFont, fontWeight = FontWeight.Medium)
            if (sub != null) {
                Text(sub, color = if (highlight) Green else Dim, fontSize = 11.sp, fontFamily = UiFont)
            }
        }
    }
}

@Composable
private fun MenuButton(onClick: () -> Unit) {
    Box(
        modifier = Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { JIcon(JI.Menu, tint = Text, size = 24.dp) }
}

@Composable
private fun MainScreenBody(
    orbState: OrbState,
    status: String,
    logs: List<LogLine>,
    micOn: Boolean,
    isConnected: Boolean,
    audioLevel: Float,
    weather: WeatherInfo?,
    speedLabel: String,
    onCycleSpeed: () -> Unit,
    voiceLabel: String,
    onCycleVoice: () -> Unit,
    onToggleMic: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onSendText: (String) -> Unit,
    attachments: List<Attachment> = emptyList(),
    onPickPhoto: () -> Unit = {},
    onPickFile: () -> Unit = {},
    onRemoveAttachment: (Int) -> Unit = {},
    onChangeKey: () -> Unit = {},
    wakeWordEnabled: Boolean = false,
    onToggleWakeWord: () -> Unit = {},
    memoryCount: Int = 0,
    onOpenMemory: () -> Unit = {},
    onOpenTerminal: () -> Unit = {},
    onSaveAttachment: (FileTool.StagedFile) -> Unit = {},
    portrait: Boolean = false,
    onToggleOrientation: () -> Unit = {}
,
    onTakePhoto: () -> Unit = {},
    onOpenMenu: () -> Unit = {}
) {
    // Yazı alanı TEK bir yerde (en dış Box'ta) duruyor: klavye kapalıyken sağ
    // sohbet panelinin altındaki küçük yerinde, klavye açılınca ekranın altında
    // klavyenin hemen üstünde tam genişlikte. Aynı composable'ın sadece
    // konumu/genişliği değiştiği için klavye açıkken odak (imleç) kaybolmuyor.
    var input by rememberSaveable { mutableStateOf("") }
    val density = LocalDensity.current
    var barHeightPx by remember { mutableIntStateOf(0) }
    val imeVisible = WindowInsets.ime.getBottom(density) > 0

    if (portrait) {
        PortraitScreen(
            orbState = orbState, status = status, logs = logs, micOn = micOn,
            isConnected = isConnected, audioLevel = audioLevel, weather = weather,
            speedLabel = speedLabel, onCycleSpeed = onCycleSpeed,
            voiceLabel = voiceLabel, onCycleVoice = onCycleVoice,
            onToggleMic = onToggleMic, onStart = onStart, onStop = onStop,
            input = input, onInputChange = { input = it },
            onSendText = onSendText,
            attachments = attachments, onPickPhoto = onPickPhoto, onPickFile = onPickFile,
            onRemoveAttachment = onRemoveAttachment, onChangeKey = onChangeKey,
            wakeWordEnabled = wakeWordEnabled, onToggleWakeWord = onToggleWakeWord,
            memoryCount = memoryCount, onOpenMemory = onOpenMemory,
            onOpenTerminal = onOpenTerminal, onSaveAttachment = onSaveAttachment,
            onToggleOrientation = onToggleOrientation,
            onTakePhoto = onTakePhoto,
            onOpenMenu = onOpenMenu
        )
        return
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BgTop, Bg)))
    ) {
        val barWidth by animateDpAsState(
            targetValue = if (imeVisible) maxWidth else CHAT_PANEL_WIDTH,
            label = "chatBarWidth"
        )
        // Çubuğun kapladığı yükseklik (ekler satırı dahil) kadar yeri sohbet
        // panelinde boş bırak; panelin kendi alt iç boşluğu (10dp) zaten var.
        val inputReserve = with(density) { barHeightPx.toDp() } - 20.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "J.A.R.V.I.S",
                        color = Teal,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                        fontFamily = UiFont
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "MOBILE",
                        color = Dim,
                        fontSize = 10.sp,
                        letterSpacing = 2.sp,
                        fontFamily = UiFont
                    )
                }
                StatusBadge(orbState)
                Spacer(Modifier.width(10.dp))
                // Tüm işlev düğmeleri (terminal / uyandırma kelimesi / anahtar
                // değiştir) artık tek tek sağ üstte durmuyor, buradaki ☰ menüsüne
                // toplandı -- üst çubuk sadeleşsin diye.
                MenuButton(onOpenMenu)
            }

            // Body: sol saat paneli | orta orb + kontroller | sağ sohbet paneli
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                ClockPanel(
                    weather = weather,
                    modifier = Modifier
                        .width(150.dp)
                        .fillMaxHeight()
                )

                CenterPanel(
                    orbState = orbState,
                    status = status,
                    audioLevel = audioLevel,
                    micOn = micOn,
                    isConnected = isConnected,
                    speedLabel = speedLabel,
                    onCycleSpeed = onCycleSpeed,
                    voiceLabel = voiceLabel,
                    onCycleVoice = onCycleVoice,
                    onToggleMic = onToggleMic,
                    onStart = onStart,
                    onStop = onStop,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                )

                ChatPanel(
                    logs = logs,
                    inputReserve = inputReserve.coerceAtLeast(0.dp),
                    onSaveAttachment = onSaveAttachment,
                    modifier = Modifier
                        .width(CHAT_PANEL_WIDTH)
                        .fillMaxHeight()
                )
            }
        }

        ChatInputBar(
            input = input,
            onInputChange = { input = it },
            attachments = attachments,
            expanded = imeVisible,
            onPickPhoto = onPickPhoto,
            onPickFile = onPickFile,
            onTakePhoto = onTakePhoto,
            onRemoveAttachment = onRemoveAttachment,
            onSend = {
                onSendText(input)
                input = ""
            },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .imePadding()
                .width(barWidth)
                .onSizeChanged { barHeightPx = it.height }
        )
    }
}

private val CHAT_PANEL_WIDTH = 260.dp

@Composable
private fun ClockPanel(weather: WeatherInfo?, modifier: Modifier = Modifier) {
    var time by remember { mutableStateOf(SimpleDateFormat("HH:mm", Locale("tr")).format(Date())) }
    var date by remember { mutableStateOf(SimpleDateFormat("d MMMM", Locale("tr")).format(Date())) }
    var day by remember { mutableStateOf(SimpleDateFormat("EEEE", Locale("tr")).format(Date())) }

    LaunchedEffect(Unit) {
        while (true) {
            val now = Date()
            time = SimpleDateFormat("HH:mm", Locale("tr")).format(now)
            date = SimpleDateFormat("d MMMM", Locale("tr")).format(now)
            day = SimpleDateFormat("EEEE", Locale("tr")).format(now)
            delay(1000)
        }
    }

    Column(
        modifier = modifier
            .padding(8.dp)
            .softPanel()
            .padding(16.dp)
    ) {
        Text(
            "SAAT",
            color = Dim,
            fontSize = 10.sp,
            letterSpacing = 2.sp,
            fontFamily = UiFont
        )
        Spacer(Modifier.height(6.dp))
        Text(
            time,
            color = Teal,
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = UiFont
        )
        Spacer(Modifier.height(4.dp))
        Text(
            date.uppercase(Locale("tr")),
            color = Text,
            fontSize = 12.sp,
            fontFamily = UiFont
        )
        Text(
            day.uppercase(Locale("tr")),
            color = Dim,
            fontSize = 11.sp,
            letterSpacing = 1.sp,
            fontFamily = UiFont
        )

        // Saat/tarih ile hava durumu arasındaki boşluğu esnek bırak,
        // hava durumu her zaman panelin en altına yaslansın.
        Spacer(Modifier.weight(1f))

        WeatherRow(weather)
    }
}

@Composable
private fun WeatherRow(weather: WeatherInfo?) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .padding(12.dp)
    ) {
        Text(
            "HAVA DURUMU",
            color = Dim,
            fontSize = 9.sp,
            letterSpacing = 1.5.sp,
            fontFamily = UiFont
        )
        Spacer(Modifier.height(6.dp))
        if (weather == null) {
            Text(
                "…",
                color = Dim,
                fontSize = 12.sp,
                fontFamily = UiFont
            )
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(weather.emoji, fontSize = 20.sp)
                Spacer(Modifier.width(6.dp))
                Text(
                    "${weather.tempC}°",
                    color = Teal,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = UiFont
                )
            }
            Spacer(Modifier.height(2.dp))
            Text(
                weather.description,
                color = Text,
                fontSize = 10.sp,
                letterSpacing = 0.5.sp,
                fontFamily = UiFont
            )
            Text(
                weather.city.uppercase(Locale("tr")),
                color = Dim,
                fontSize = 9.sp,
                fontFamily = UiFont
            )
        }
    }
}

@Composable
private fun CenterPanel(
    orbState: OrbState,
    status: String,
    audioLevel: Float,
    micOn: Boolean,
    isConnected: Boolean,
    speedLabel: String,
    onCycleSpeed: () -> Unit,
    voiceLabel: String,
    onCycleVoice: () -> Unit,
    onToggleMic: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    modifier: Modifier = Modifier
) {
    // "Hologram modu aç" komutuyla açılır -- ekranın ortasına konan küçük bir
    // piramitle Orb'u havada duruyormuş gibi göstermek için 4 kopya çizer.
    val hologramActive by HologramModeState.isActive.collectAsState()
    // "Kamerayı aç" ile başlayan el takibi -- parmak açıklığı Orb'u
    // büyütüp küçültür, el açısı Orb'u döndürür (bkz. HandGestureController).
    val handScale by HandGestureController.orbScale.collectAsState()
    val handRotation by HandGestureController.orbRotationDeg.collectAsState()

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (hologramActive) {
            HologramOrbDisplay(
                orbState = orbState,
                audioLevel = audioLevel,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            )
        } else {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            JarvisOrb(
                state = orbState,
                audioLevel = audioLevel,
                modifier = Modifier.size(230.dp),
                externalScale = handScale,
                externalRotationDeg = handRotation
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = status,
                color = Dim,
                fontSize = 12.sp,
                letterSpacing = 2.sp,
                fontFamily = UiFont
            )
            Spacer(Modifier.height(6.dp))
            // Konuşma hızı ve ses: dokununca sırayla değişir.
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "HIZ: $speedLabel",
                    color = Teal,
                    fontSize = 10.sp,
                    letterSpacing = 1.sp,
                    fontFamily = UiFont,
                    modifier = Modifier
                        .clickable(onClick = onCycleSpeed)
                        .background(Teal.copy(alpha = 0.10f), CircleShape)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
                Text(
                    text = voiceLabel,
                    color = Teal,
                    fontSize = 10.sp,
                    letterSpacing = 1.sp,
                    fontFamily = UiFont,
                    modifier = Modifier
                        .clickable(onClick = onCycleVoice)
                        .background(Teal.copy(alpha = 0.10f), CircleShape)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }
        }

        // Durdur | Başlat | Mikrofon
        // TV kumandasıyla açılışta hemen bir yere odaklanılsın diye BAŞLAT
        // butonuna varsayılan odak veriliyor -- kumanda kullanıcısı ekrana
        // girer girmez sağ/sol ile gezinebilir, orta tuşla tetikleyebilir.
        val startFocusRequester = remember { FocusRequester() }
        LaunchedEffect(Unit) {
            runCatching { startFocusRequester.requestFocus() }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ModeButton(
                label = "DURDUR",
                active = !isConnected,
                activeColor = Gold,
                onClick = onStop,
                modifier = Modifier.weight(1f)
            )
            ModeButton(
                label = "BAŞLAT",
                active = isConnected && !micOn,
                activeColor = Green,
                onClick = onStart,
                modifier = Modifier.weight(1f),
                focusRequester = startFocusRequester
            )
            ModeButton(
                label = "MİKROFON",
                icon = JI.Mic,
                active = micOn,
                activeColor = Blue,
                onClick = onToggleMic,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun ModeButton(
    label: String,
    active: Boolean,
    activeColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester? = null,
    icon: JI? = null
) {
    // Eski sürüm düz/mat dolgulu bir Material Button'du ("çok yumuşak" görünüyordu).
    // Bunun yerine ince çerçeveli, camsı/neon dolgulu bir HUD butonu: pasifken bile
    // çerçeve ve yazı rengi belirgin, aktifken çerçeve+dolgu+yazı tam parlaklığa çıkıyor.
    val borderAlpha = if (active) 1f else 0.55f
    val fillAlpha = if (active) 0.22f else 0.07f
    val textAlpha = if (active) 1f else 0.8f

    // TV kumandası / klavye ok tuşlarıyla gezinirken hangi butonun odakta
    // olduğu belli olsun diye: clickable zaten DPAD/Enter ile tetiklemeyi
    // ve ok tuşlarıyla odak değişimini otomatik destekliyor (Compose'un
    // yerleşik davranışı), burada SADECE odaklandığında görünür bir vurgu
    // (kalın beyazımsı çerçeve + hafif parlama) ekliyoruz -- aksi halde
    // kumandayla hangi butonda olduğunu göremezsin.
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    val focusBorderWidth by animateDpAsState(if (isFocused) 2.dp else 1.dp, label = "focusBorder")

    Box(
        modifier = modifier
            .height(52.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(
                activeColor.copy(alpha = if (isFocused) fillAlpha + 0.18f else fillAlpha)
            )
            .border(
                focusBorderWidth,
                if (isFocused) Color.White.copy(alpha = 0.85f) else activeColor.copy(alpha = borderAlpha * 0.45f),
                RoundedCornerShape(26.dp)
            )
            .let { if (focusRequester != null) it.focusRequester(focusRequester) else it }
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.foundation.LocalIndication.current,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) {
            JIcon(icon, tint = if (isFocused) Color.White else activeColor.copy(alpha = textAlpha), size = 18.dp)
            Spacer(Modifier.width(6.dp))
        }
        Text(
            label,
            color = if (isFocused) Color.White else activeColor.copy(alpha = textAlpha),
            fontFamily = UiFont,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.sp,
            fontSize = 13.sp
        )
        }
    }
}

@Composable
private fun ChatPanel(
    logs: List<LogLine>,
    inputReserve: Dp,
    onSaveAttachment: (FileTool.StagedFile) -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            scope.launch { listState.animateScrollToItem(logs.lastIndex) }
        }
    }

    Column(
        modifier = modifier
            .padding(8.dp)
            .softPanel()
            .padding(12.dp)
    ) {
        Text(
            "SOHBET",
            color = Dim,
            fontSize = 10.sp,
            letterSpacing = 2.sp,
            fontFamily = UiFont,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            items(logs) { line ->
                LogRow(line, onSaveAttachment)
            }
        }

        // Yazı çubuğu ekranın en dış katmanında çiziliyor (bkz. MainScreen /
        // ChatInputBar); burada sadece onun oturacağı yeri boş bırakıyoruz.
        Spacer(Modifier.height(inputReserve))
    }
}

/**
 * Sohbet yazı çubuğu: 📎 (fotoğraf/dosya ekle) + yazı alanı + gönder.
 *
 * [expanded] (= klavye açık) iken çağıran taraf bunu ekranın altında,
 * klavyenin üstünde tam genişlikte konumlar; kapalıyken sohbet panelinin
 * altındaki küçük yerine oturur. Bu composable sadece görünümü çizer.
 */
@Composable
private fun ChatInputBar(
    input: String,
    onInputChange: (String) -> Unit,
    attachments: List<Attachment>,
    expanded: Boolean,
    onPickPhoto: () -> Unit,
    onPickFile: () -> Unit,
    onTakePhoto: () -> Unit,
    onRemoveAttachment: (Int) -> Unit,
    onSend: () -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    var menuOpen by remember { mutableStateOf(false) }
    var focused by remember { mutableStateOf(false) }
    val canSend = input.isNotBlank() || attachments.isNotEmpty()

    // Klavye kapanınca (geri tuşu vb.) alan odağı bıraksın: bir sonraki
    // dokunuşta klavye sorunsuz tekrar açılır.
    LaunchedEffect(expanded) {
        if (!expanded) focusManager.clearFocus()
    }

    Column(
        modifier = modifier
            .background(if (expanded) Bg else Color.Transparent)
            .drawBehind {
                if (expanded) {
                    drawLine(
                        color = Color.White.copy(alpha = 0.08f),
                        start = Offset(0f, 0f),
                        end = Offset(size.width, 0f),
                        strokeWidth = 1.dp.toPx()
                    )
                }
            }
            .padding(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 10.dp)
    ) {
        if (attachments.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                attachments.forEachIndexed { i, a ->
                    AttachmentChip(a) { onRemoveAttachment(i) }
                }
            }
        }

        Row(verticalAlignment = Alignment.Bottom) {
            Box {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.08f))
                        .clickable { menuOpen = true },
                    contentAlignment = Alignment.Center
                ) {
                    JIcon(JI.Plus, tint = Teal, size = 22.dp)
                }
                DropdownMenu(
                    expanded = menuOpen,
                    onDismissRequest = { menuOpen = false },
                    modifier = Modifier.background(Panel)
                ) {
                    AttachMenuItem(JI.Camera, "Kamera") { menuOpen = false; onTakePhoto() }
                    AttachMenuItem(JI.Image, "Fotoğraf") { menuOpen = false; onPickPhoto() }
                    AttachMenuItem(JI.File, "Dosya") { menuOpen = false; onPickFile() }
                }
            }

            Spacer(Modifier.width(6.dp))

            BasicTextField(
                value = input,
                onValueChange = onInputChange,
                singleLine = false,
                minLines = 1,
                maxLines = 5,
                textStyle = TextStyle(
                    color = Text,
                    fontSize = 13.sp,
                    fontFamily = UiFont
                ),
                cursorBrush = SolidColor(Teal),
                keyboardOptions = KeyboardOptions(
                    capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.Sentences,
                    imeAction = ImeAction.Default
                ),
                modifier = Modifier
                    .weight(1f)
                    .onFocusChanged { focused = it.isFocused },
                decorationBox = { inner ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 42.dp)
                            .clip(RoundedCornerShape(21.dp))
                            .background(Color.White.copy(alpha = 0.08f))
                            .border(
                                1.dp,
                                if (focused) Teal.copy(alpha = 0.7f) else Color.White.copy(alpha = 0.08f),
                                RoundedCornerShape(21.dp)
                            )
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        if (input.isEmpty()) {
                            Text(
                                "Yaz…",
                                color = Dim,
                                fontFamily = UiFont,
                                fontSize = 12.sp
                            )
                        }
                        inner()
                    }
                }
            )

            Spacer(Modifier.width(6.dp))

            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Teal.copy(alpha = if (canSend) 0.95f else 0.35f))
                    .clickable(enabled = canSend, onClick = onSend),
                contentAlignment = Alignment.Center
            ) {
                JIcon(JI.Send, tint = Bg, size = 20.dp)
            }
        }
    }
}

@Composable
private fun AttachmentChip(attachment: Attachment, onRemove: () -> Unit) {
    Row(
        modifier = Modifier
            .background(Teal.copy(alpha = 0.12f), RoundedCornerShape(14.dp))
            .border(1.dp, Teal.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
            .clickable(onClick = onRemove)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        JIcon(if (attachment.icon == "🖼") JI.Image else JI.File, tint = Teal, size = 14.dp)
        Spacer(Modifier.width(4.dp))
        Text(
            attachment.name,
            color = Text,
            fontSize = 10.sp,
            fontFamily = UiFont,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 110.dp)
        )
        Spacer(Modifier.width(6.dp))
        JIcon(JI.Close, tint = Dim, size = 12.dp)
    }
}

@Composable
private fun StatusBadge(state: OrbState) {
    val (label, color) = when (state) {
        OrbState.LISTENING -> "DİNLİYOR" to Green
        OrbState.SPEAKING -> "KONUŞUYOR" to Blue
        OrbState.THINKING -> "DÜŞÜNÜYOR" to Gold
        OrbState.CONNECTING -> "BAĞLANIYOR" to Orange
        OrbState.ERROR -> "HATA" to Red
        OrbState.MUTED -> "SESSİZ" to Muted
        OrbState.IDLE -> "HAZIR" to Dim
    }
    Text(
        text = label,
        color = color,
        fontSize = 10.sp,
        letterSpacing = 1.sp,
        fontFamily = UiFont,
        modifier = Modifier
            .background(color.copy(alpha = 0.14f), CircleShape)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
private fun LogRow(line: LogLine, onSaveAttachment: (FileTool.StagedFile) -> Unit) {
    val (prefix, color) = when (line.who) {
        "user" -> "Sen" to Teal
        "jarvis", "jarvis_file" -> "Jarvis" to Green
        else -> "Sistem" to Dim
    }
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(
            prefix,
            color = color.copy(alpha = 0.9f),
            fontSize = 10.sp,
            fontFamily = UiFont,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(start = 6.dp, bottom = 2.dp)
        )
        val attachment = line.attachment
        if (attachment != null) {
            AttachmentCard(attachment, onSave = { onSaveAttachment(attachment) })
        } else {
            Text(
                line.text,
                color = Text.copy(alpha = 0.92f),
                fontSize = 12.sp,
                lineHeight = 17.sp,
                fontFamily = UiFont,
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(color.copy(alpha = if (line.who == "sys") 0.06f else 0.12f))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }
    }
}

/** Sohbete eklenen ama henüz cihaza KAYDEDİLMEMİŞ bir dosya/görsel kartı. */
@Composable
private fun AttachmentCard(attachment: FileTool.StagedFile, onSave: () -> Unit) {
    var saved by remember(attachment.uri) { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .padding(top = 2.dp)
            .widthIn(max = 220.dp)
            .background(Teal.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
            .border(1.dp, Teal.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
            .padding(8.dp)
    ) {
        if (attachment.isImage) {
            coil.compose.AsyncImage(
                model = attachment.uri,
                contentDescription = attachment.filename,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 180.dp)
                    .clip(RoundedCornerShape(12.dp)),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop
            )
            Spacer(Modifier.height(6.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            JIcon(if (attachment.isImage) JI.Image else JI.File, tint = Teal, size = 16.dp)
            Spacer(Modifier.width(6.dp))
            Text(
                attachment.filename,
                color = Text,
                fontSize = 11.sp,
                fontFamily = UiFont,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(if (saved) TealDim.copy(alpha = 0.2f) else Teal, RoundedCornerShape(12.dp))
                .clickable(enabled = !saved) { saved = true; onSave() }
                .padding(vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (saved) "Kaydedildi" else "Kaydet",
                color = if (saved) Dim else Bg,
                fontSize = 11.sp,
                fontFamily = UiFont,
                fontWeight = FontWeight.Bold
            )
        }
    }
}


// ─────────────────────────────────────────────────────────────────────
// DİKEY EKRAN: üstte (hava durumu + saat) ve sağında ☰, altında Orb, sonra
// DURDUR / BAŞLAT / MİKROFON tuşları, en altta sohbet; en alt solda J.A.R.V.I.S.
// ─────────────────────────────────────────────────────────────────────
@Composable
private fun PortraitScreen(
    orbState: OrbState,
    status: String,
    logs: List<LogLine>,
    micOn: Boolean,
    isConnected: Boolean,
    audioLevel: Float,
    weather: WeatherInfo?,
    speedLabel: String,
    onCycleSpeed: () -> Unit,
    voiceLabel: String,
    onCycleVoice: () -> Unit,
    onToggleMic: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    input: String,
    onInputChange: (String) -> Unit,
    onSendText: (String) -> Unit,
    attachments: List<Attachment>,
    onPickPhoto: () -> Unit,
    onPickFile: () -> Unit,
    onRemoveAttachment: (Int) -> Unit,
    onChangeKey: () -> Unit,
    wakeWordEnabled: Boolean,
    onToggleWakeWord: () -> Unit,
    memoryCount: Int,
    onOpenMemory: () -> Unit,
    onOpenTerminal: () -> Unit,
    onSaveAttachment: (FileTool.StagedFile) -> Unit,
    onToggleOrientation: () -> Unit,
    onTakePhoto: () -> Unit,
    onOpenMenu: () -> Unit
) {
    val imeVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    val hologramActive by HologramModeState.isActive.collectAsState()
    val handScale by HandGestureController.orbScale.collectAsState()
    val handRotation by HandGestureController.orbRotationDeg.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BgTop, Bg)))
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        // 1) Üst satır: hava durumu + saat (yatay) | ☰
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.Top
        ) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(modifier = Modifier.weight(1f)) { WeatherRow(weather) }
                PortraitClock(modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.width(10.dp))
            MenuButton(onOpenMenu)
        }

        // 2) Orb (kalan boşluğun büyük kısmı)
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1.15f),
            contentAlignment = Alignment.Center
        ) {
            if (hologramActive) {
                HologramOrbDisplay(
                    orbState = orbState,
                    audioLevel = audioLevel,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                val orbSize = (minOf(maxWidth, maxHeight - 28.dp) * 0.92f).coerceIn(40.dp, 320.dp)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    JarvisOrb(
                        state = orbState,
                        audioLevel = audioLevel,
                        modifier = Modifier.size(orbSize),
                        externalScale = handScale,
                        externalRotationDeg = handRotation
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = status,
                        color = Dim,
                        fontSize = 12.sp,
                        letterSpacing = 2.sp,
                        fontFamily = UiFont
                    )
                }
            }
        }

        // 3) DURDUR | BAŞLAT | MİKROFON
        val startFocusRequester = remember { FocusRequester() }
        LaunchedEffect(Unit) { runCatching { startFocusRequester.requestFocus() } }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ModeButton(
                label = "DURDUR",
                active = !isConnected,
                activeColor = Gold,
                onClick = onStop,
                modifier = Modifier.weight(1f)
            )
            ModeButton(
                label = "BAŞLAT",
                active = isConnected && !micOn,
                activeColor = Green,
                onClick = onStart,
                modifier = Modifier.weight(1f),
                focusRequester = startFocusRequester
            )
            ModeButton(
                label = "MİKROFON",
                icon = JI.Mic,
                active = micOn,
                activeColor = Blue,
                onClick = onToggleMic,
                modifier = Modifier.weight(1f)
            )
        }

        // 4) Sohbet (en altta) + yazı çubuğu
        ChatPanel(
            logs = logs,
            inputReserve = 0.dp,
            onSaveAttachment = onSaveAttachment,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 12.dp)
        )
        ChatInputBar(
            input = input,
            onInputChange = onInputChange,
            attachments = attachments,
            expanded = imeVisible,
            onPickPhoto = onPickPhoto,
            onPickFile = onPickFile,
            onTakePhoto = onTakePhoto,
            onRemoveAttachment = onRemoveAttachment,
            onSend = {
                onSendText(input)
                onInputChange("")
            },
            modifier = Modifier.fillMaxWidth()
        )

        // 5) En alt sol: J.A.R.V.I.S
        Text(
            "J.A.R.V.I.S",
            color = Teal,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 3.sp,
            fontFamily = UiFont,
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 14.dp, end = 14.dp, bottom = 8.dp)
        )
    }
}

/** Dikey düzendeki küçük saat kutusu (saat + tarih), hava durumu kutusuyla yan yana durur. */
@Composable
private fun PortraitClock(modifier: Modifier = Modifier) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(1000)
        }
    }
    val tr = Locale("tr")
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .padding(12.dp)
    ) {
        Text(
            "SAAT",
            color = Dim,
            fontSize = 9.sp,
            letterSpacing = 1.5.sp,
            fontFamily = UiFont
        )
        Spacer(Modifier.height(6.dp))
        Text(
            SimpleDateFormat("HH:mm", tr).format(now),
            color = Teal,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = UiFont
        )
        Spacer(Modifier.height(2.dp))
        Text(
            SimpleDateFormat("d MMMM", tr).format(now).uppercase(tr),
            color = Text,
            fontSize = 10.sp,
            fontFamily = UiFont
        )
        Text(
            SimpleDateFormat("EEEE", tr).format(now).uppercase(tr),
            color = Dim,
            fontSize = 9.sp,
            fontFamily = UiFont
        )
    }
}


private val SoftShape = RoundedCornerShape(24.dp)

/** Yumuşak, yarı saydam, yuvarlak köşeli panel (eski sert çerçeveli kutuların yerine). */
private fun Modifier.softPanel(): Modifier = this
    .clip(SoftShape)
    .background(Panel.copy(alpha = 0.72f))
    .border(1.dp, Color.White.copy(alpha = 0.06f), SoftShape)

@Composable
private fun AttachMenuItem(icon: JI, label: String, onClick: () -> Unit) {
    DropdownMenuItem(
        leadingIcon = { JIcon(icon, tint = Teal, size = 20.dp) },
        text = { Text(label, color = Text, fontFamily = UiFont, fontSize = 14.sp) },
        onClick = onClick
    )
}
