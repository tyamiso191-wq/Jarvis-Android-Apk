package com.jarvis.ai.wakeword

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import com.jarvis.ai.DEFAULT_SYSTEM
import com.jarvis.ai.MainActivity
import com.jarvis.ai.device.DeviceInfo
import com.jarvis.ai.live.GeminiTextClient
import com.jarvis.ai.memory.MemoryStore
import com.jarvis.ai.reminders.ReminderStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

/**
 * Kullanıcı isteği: "Jarvis" (ya da benzeri) dediğimde, ekran kapalıyken /
 * uygulama arka plandayken bile uyanıp dinlesin -- "Jarvis saat kaç" gibi
 * kısa bir komutu anlayıp sesli cevap versin.
 *
 * NASIL ÇALIŞIYOR (dürüstçe, sınırlarıyla):
 *  - Android'de HİÇBİR üçüncü parti uygulama (Jarvis dahil) telefon
 *    GERÇEKTEN kapalıyken (pil bittiğinde/kapatıldığında) çalışamaz -- bu
 *    fiziksel olarak imkansız. Burada "kapalıyken" = EKRAN KAPALI / uygulama
 *    arka planda, telefon açık.
 *  - Google Asistan'ın kullandığı donanım seviyesi "her zaman dinleyen" DSP
 *    çipine 3. parti uygulamalar erişemiyor (sadece OEM/Google'a özel). Bu
 *    yüzden burada Picovoice Porcupine adlı, pil/CPU dostu, ON-DEVICE bir
 *    uyandırma kelimesi motoru kullanılıyor -- "Jarvis" onun ÜCRETSİZ hazır
 *    kelimelerinden biri, ayrıca eğitim gerekmiyor.
 *  - Bu servis bir FOREGROUND SERVICE (mikrofon türünde) -- Android bunun
 *    için SÜREKLİ görünen bir bildirim istiyor (gizlenemez, işletim
 *    sisteminin gizlilik kuralı). Bildirimden "Durdur"a basarak her an
 *    kapatılabilir.
 *  - Picovoice'un ÜCRETSİZ ama AYRI bir hesap/AccessKey'i gerekiyor
 *    (console.picovoice.ai) -- Gemini anahtarından farklı.
 *  - "Jarvis alarmı kapat" gibi bir komut ŞU AN çalışmaz: alarmlar telefonun
 *    kendi Saat uygulamasında kurulduğu için (set_alarm ile), o çalan
 *    alarmı SADECE Saat uygulaması durdurabilir, Jarvis'in ona erişimi yok
 *    (Android bunu izin vermiyor). "Jarvis saat kaç", "Jarvis hava durumu"
 *    gibi bilgi/kontrol komutları ise NORMAL ÇALIŞIR.
 */
class WakeWordService : Service() {

    companion object {
        private const val TAG = "WakeWordService"
        const val ACTION_STOP = "com.jarvis.ai.wakeword.STOP"
        private const val CHANNEL_ID = "jarvis_wakeword"
        private const val NOTIF_ID = 5959
        private const val PREFS = "wakeword_prefs"
        private const val KEY_ACCESS_KEY = "picovoice_access_key"
        private const val KEY_ENABLED = "wakeword_enabled"

        private fun prefs(context: Context): SharedPreferences =
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        fun savePicovoiceKey(context: Context, key: String) {
            prefs(context).edit().putString(KEY_ACCESS_KEY, key.trim()).apply()
        }

        fun getPicovoiceKey(context: Context): String =
            prefs(context).getString(KEY_ACCESS_KEY, "").orEmpty()

        fun isEnabled(context: Context): Boolean =
            prefs(context).getBoolean(KEY_ENABLED, false)

        fun setEnabled(context: Context, enabled: Boolean) {
            prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
            if (enabled) start(context) else stop(context)
        }

        fun start(context: Context) {
            val i = Intent(context, WakeWordService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i)
            } else {
                context.startService(i)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, WakeWordService::class.java))
        }

        /**
         * JarvisViewModel, Gemini anahtarı her değiştiğinde bunu çağırır.
         * DataStore aynı dosya için süreç içinde SADECE tek bir örnek
         * kabul ettiğinden (ikincisi "multiple DataStores active" ile
         * çöker), bu servis anahtarı DataStore yerine düz bir
         * SharedPreferences aynasından okuyor.
         */
        fun mirrorGeminiKey(context: Context, key: String) {
            prefs(context).edit().putString("gemini_api_key_mirror", key).apply()
        }

        private fun readMirroredGeminiKey(context: Context): String =
            prefs(context).getString("gemini_api_key_mirror", "").orEmpty()
    }

    private var porcupineManager: PorcupineManager? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var client: GeminiTextClient? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            setEnabled(this, false)
            stopSelf()
            return START_NOT_STICKY
        }
        startForegroundNotification()
        if (porcupineManager == null) initPorcupineAndListen()
        return START_STICKY
    }

    private fun startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Jarvis uyandırma kelimesi", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, WakeWordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("J.A.R.V.I.S dinliyor")
            .setContentText("\"Jarvis\" demeni bekliyorum")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, "Durdur", stopIntent)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun initPorcupineAndListen() {
        val accessKey = getPicovoiceKey(this)
        if (accessKey.isBlank()) {
            Log.w(TAG, "Picovoice AccessKey girilmemiş, uyandırma kelimesi başlatılamadı.")
            updateNotificationError("Picovoice anahtarı eksik -- Jarvis'e sohbetten ekle")
            return
        }
        try {
            porcupineManager = PorcupineManager.Builder()
                .setAccessKey(accessKey)
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .setSensitivity(0.6f)
                .build(applicationContext, PorcupineManagerCallback { onWakeWordDetected() })
            porcupineManager?.start()
        } catch (e: Exception) {
            Log.e(TAG, "Porcupine başlatılamadı", e)
            updateNotificationError("Uyandırma kelimesi başlatılamadı: ${e.message}")
        }
    }

    private fun updateNotificationError(message: String) {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("J.A.R.V.I.S")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .build()
        getSystemService(NotificationManager::class.java)?.notify(NOTIF_ID, notification)
    }

    private fun onWakeWordDetected() {
        scope.launch {
            try { porcupineManager?.stop() } catch (e: Exception) { /* yoksay */ }
            vibrateShort()
            listenForCommand()
        }
    }

    private fun vibrateShort() {
        try {
            val vibrator = getSystemService(Vibrator::class.java) ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION") vibrator.vibrate(120)
            }
        } catch (e: Exception) { /* yoksay */ }
    }

    private fun listenForCommand() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            resumeWakeWordListening()
            return
        }
        val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer = recognizer
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle) {
                val text = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                cleanupRecognizer()
                if (!text.isNullOrBlank()) processCommand(text) else resumeWakeWordListening()
            }
            override fun onError(error: Int) {
                cleanupRecognizer()
                resumeWakeWordListening()
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer.startListening(intent)
    }

    private fun cleanupRecognizer() {
        try { speechRecognizer?.destroy() } catch (e: Exception) { /* yoksay */ }
        speechRecognizer = null
    }

    private fun processCommand(text: String) {
        scope.launch {
            val apiKey = readGeminiKey()
            if (apiKey.isBlank()) {
                speak("Önce ana ekrandan Gemini anahtarını girmen lazım efendim.")
                return@launch
            }
            val c = client ?: GeminiTextClient(apiKey, DEFAULT_SYSTEM, applicationContext).also { client = it }
            try {
                val deviceContext = DeviceInfo.snapshot(applicationContext, null) +
                    MemoryStore.contextBlock(applicationContext) +
                    ReminderStore.contextBlock(applicationContext)
                val result = c.sendMessage(emptyList(), deviceContext, text, emptyList())
                result.onSuccess { reply -> speak(reply) }
                result.onFailure { speak("Bir sorun oldu efendim, tekrar dener misin?") }
            } catch (e: Exception) {
                Log.w(TAG, "Arka plan komutu işlenemedi", e)
                speak("Bir sorun oldu efendim.")
            }
        }
    }

    /** Gemini anahtarı JarvisViewModel'in yazdığı SharedPreferences aynasından okunur (bkz. mirrorGeminiKey). */
    private fun readGeminiKey(): String = readMirroredGeminiKey(applicationContext)

    private fun speak(text: String) {
        val onDone = { resumeWakeWordListening() }
        val engine = tts
        if (engine != null && ttsReady) {
            speakWith(engine, text, onDone)
            return
        }
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.language = Locale("tr", "TR")
                tts?.let { speakWith(it, text, onDone) }
            } else {
                onDone()
            }
        }
    }

    private fun speakWith(engine: TextToSpeech, text: String, onDone: () -> Unit) {
        val id = UUID.randomUUID().toString()
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId == id) onDone()
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId == id) onDone()
            }
        })
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    private fun resumeWakeWordListening() {
        try { porcupineManager?.start() } catch (e: Exception) { /* yoksay */ }
    }

    override fun onDestroy() {
        try { porcupineManager?.stop() } catch (e: Exception) { /* yoksay */ }
        try { porcupineManager?.delete() } catch (e: Exception) { /* yoksay */ }
        cleanupRecognizer()
        try { tts?.stop(); tts?.shutdown() } catch (e: Exception) { /* yoksay */ }
        scope.cancel()
        super.onDestroy()
    }
}
