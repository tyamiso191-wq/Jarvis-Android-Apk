package com.jarvis.ai.local

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.jarvis.ai.files.FileTool
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException

/** Cihaz üzerinde çalışan, ağ/API anahtarı gerektirmeyen metin istemcisi. */
class LocalTextClient(private val context: Context, private val persona: String) {
    @Volatile var onFileReady: ((FileTool.StagedFile) -> Unit)? = null

    suspend fun sendMessage(
        conversation: List<Pair<String, String>>,
        currentTurnText: String? = null,
        deviceContext: String = ""
    ): Result<String> = withContext(Dispatchers.Default) {
        try {
            LocalModelManager.installFromAssetsIfPresent(context)
            val model = LocalModelManager.modelFile(context)
            if (!LocalModelManager.isReady(context)) {
                return@withContext Result.failure(IOException(
                    "Yerel model bulunamadı. ${model.absolutePath} konumuna uyumlu bir MediaPipe .task veya .litertlm model dosyası ekleyin."
                ))
            }

            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(model.absolutePath)
                .setMaxTokens(2048)
                .setTopK(40)
                .setTemperature(0.7f)
                .build()
            val inference = LlmInference.createFromOptions(context, options)
            try {
                val prompt = buildPrompt(conversation, currentTurnText, deviceContext)
                val generated = inference.generateResponse(prompt)
                Result.success(handleFileTags(generated.trim()))
            } finally {
                inference.close()
            }
        } catch (e: Exception) {
            Log.e("LocalTextClient", "Yerel model çalıştırılamadı", e)
            Result.failure(e)
        }
    }

    private fun buildPrompt(
        conversation: List<Pair<String, String>>,
        currentTurnText: String?,
        deviceContext: String
    ): String = buildString {
        append("<start_of_turn>system\n")
        append(persona)
        append("\nSen tamamen telefon içinde çalışan, API'siz bir asistansın. İnternete erişimin yok.\n")
        append("Kullanıcı dosya istediğinde dosya içeriğini üret ve yalnızca şu biçimi kullan: ")
        append("<jarvis_file name=\"dosya.txt\">DOSYA İÇERİĞİ</jarvis_file>. ")
        append("Kod veya HTML istenirse içeriği bu etiketin içine koy. Etiketi kapat.\n")
        if (deviceContext.isNotBlank()) append(deviceContext).append('\n')
        append("<end_of_turn>\n")
        conversation.takeLast(16).forEach { (role, text) ->
            append("<start_of_turn>").append(if (role == "user") "user" else "model").append('\n')
            append(text).append("\n<end_of_turn>\n")
        }
        if (currentTurnText != null && conversation.lastOrNull()?.second != currentTurnText) {
            append("<start_of_turn>user\n").append(currentTurnText).append("\n<end_of_turn>\n")
        }
        append("<start_of_turn>model\n")
    }

    private fun handleFileTags(text: String): String {
        val regex = Regex("(?s)<jarvis_file\\s+name=\\\"([^\\\"]+)\\\">(.*?)</jarvis_file>")
        var reply = text
        regex.findAll(text).toList().forEach { match ->
            val name = match.groupValues[1].trim().ifBlank { "jarvis_dosya.txt" }
            val content = match.groupValues[2].trimStart('\n', ' ')
            val staged = FileTool.stageTextFile(context, name, content)
            onFileReady?.invoke(staged)
            reply = reply.replace(match.value, "📎 $name dosyasını sohbete ekledim. İndirmek için dosya kartındaki Kaydet düğmesine basabilirsin.")
        }
        return reply.trim()
    }
}
