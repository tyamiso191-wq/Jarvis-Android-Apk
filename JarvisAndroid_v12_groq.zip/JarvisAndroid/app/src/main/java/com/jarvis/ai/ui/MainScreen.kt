package com.jarvis.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.LogLine
import com.jarvis.ai.theme.*
import com.jarvis.ai.weather.WeatherInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MainScreen(
    orbState: OrbState,
    status: String,
    logs: List<LogLine>,
    micOn: Boolean,
    isConnected: Boolean,
    audioLevel: Float,
    weather: WeatherInfo?,
    speedLabel: String,
    onCycleSpeed: () -> Unit,
    onToggleMic: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onSendText: (String) -> Unit,
    onChangeKey: () -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Panel)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "J.A.R.V.I.S",
                    color = Teal,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 3.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "MOBILE",
                    color = Dim,
                    fontSize = 10.sp,
                    letterSpacing = 2.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            StatusBadge(orbState)
            Spacer(Modifier.width(10.dp))
            // API anahtarını değiştirmek için: eskiden bu ekrandan geri dönüşün
            // hiçbir yolu yoktu (anahtar bir kere kaydedilince ApiKeyScreen bir
            // daha hiç gösterilmiyordu). Yeni/yanlış anahtar girildiğinde
            // kullanıcının tekrar giriş ekranına dönebilmesi için eklendi.
            Text(
                "🔑",
                fontSize = 16.sp,
                modifier = Modifier.clickable { onChangeKey() }
            )
        }

        // Body: sol saat paneli | orta orb + kontroller | sağ sohbet paneli
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            ClockPanel(
                weather = weather,
                modifier = Modifier
                    .width(150.dp)
                    .fillMaxHeight()
            )

            CenterPanel(
                orbState = orbState,
                status = status,
                audioLevel = audioLevel,
                micOn = micOn,
                isConnected = isConnected,
                speedLabel = speedLabel,
                onCycleSpeed = onCycleSpeed,
                onToggleMic = onToggleMic,
                onStart = onStart,
                onStop = onStop,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            )

            ChatPanel(
                logs = logs,
                onSendText = onSendText,
                modifier = Modifier
                    .width(260.dp)
                    .fillMaxHeight()
            )
        }
    }
}

@Composable
private fun ClockPanel(weather: WeatherInfo?, modifier: Modifier = Modifier) {
    var time by remember { mutableStateOf(SimpleDateFormat("HH:mm", Locale("tr")).format(Date())) }
    var date by remember { mutableStateOf(SimpleDateFormat("d MMMM", Locale("tr")).format(Date())) }
    var day by remember { mutableStateOf(SimpleDateFormat("EEEE", Locale("tr")).format(Date())) }

    LaunchedEffect(Unit) {
        while (true) {
            val now = Date()
            time = SimpleDateFormat("HH:mm", Locale("tr")).format(now)
            date = SimpleDateFormat("d MMMM", Locale("tr")).format(now)
            day = SimpleDateFormat("EEEE", Locale("tr")).format(now)
            delay(1000)
        }
    }

    Column(
        modifier = modifier
            .border(1.dp, TealDim.copy(alpha = 0.4f))
            .padding(14.dp)
    ) {
        Text(
            "SAAT",
            color = Dim,
            fontSize = 10.sp,
            letterSpacing = 2.sp,
            fontFamily = FontFamily.Monospace
        )
        Spacer(Modifier.height(6.dp))
        Text(
            time,
            color = Teal,
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Spacer(Modifier.height(4.dp))
        Text(
            date.uppercase(Locale("tr")),
            color = Text,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            day.uppercase(Locale("tr")),
            color = Dim,
            fontSize = 11.sp,
            letterSpacing = 1.sp,
            fontFamily = FontFamily.Monospace
        )

        // Saat/tarih ile hava durumu arasındaki boşluğu esnek bırak,
        // hava durumu her zaman panelin en altına yaslansın.
        Spacer(Modifier.weight(1f))

        WeatherRow(weather)
    }
}

@Composable
private fun WeatherRow(weather: WeatherInfo?) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, TealDim.copy(alpha = 0.3f))
            .padding(10.dp)
    ) {
        Text(
            "HAVA DURUMU",
            color = Dim,
            fontSize = 9.sp,
            letterSpacing = 1.5.sp,
            fontFamily = FontFamily.Monospace
        )
        Spacer(Modifier.height(6.dp))
        if (weather == null) {
            Text(
                "…",
                color = Dim,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(weather.emoji, fontSize = 20.sp)
                Spacer(Modifier.width(6.dp))
                Text(
                    "${weather.tempC}°",
                    color = Teal,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(Modifier.height(2.dp))
            Text(
                weather.description,
                color = Text,
                fontSize = 10.sp,
                letterSpacing = 0.5.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                weather.city.uppercase(Locale("tr")),
                color = Dim,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun CenterPanel(
    orbState: OrbState,
    status: String,
    audioLevel: Float,
    micOn: Boolean,
    isConnected: Boolean,
    speedLabel: String,
    onCycleSpeed: () -> Unit,
    onToggleMic: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            JarvisOrb(
                state = orbState,
                audioLevel = audioLevel,
                modifier = Modifier.size(230.dp)
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = status,
                color = Dim,
                fontSize = 12.sp,
                letterSpacing = 2.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(Modifier.height(6.dp))
            // Konuşma hızı: dokununca YAVAŞ -> NORMAL -> HIZLI arasında döngüye girer.
            Text(
                text = "HIZ: $speedLabel  ⟳",
                color = Teal,
                fontSize = 10.sp,
                letterSpacing = 1.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier
                    .clickable(onClick = onCycleSpeed)
                    .background(Teal.copy(alpha = 0.08f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }

        // Durdur | Başlat | Mikrofon
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ModeButton(
                label = "DURDUR",
                active = !isConnected,
                activeColor = Gold,
                onClick = onStop,
                modifier = Modifier.weight(1f)
            )
            ModeButton(
                label = "BAŞLAT",
                active = isConnected && !micOn,
                activeColor = Green,
                onClick = onStart,
                modifier = Modifier.weight(1f)
            )
            ModeButton(
                label = "🎙 MİKROFON",
                active = micOn,
                activeColor = Blue,
                onClick = onToggleMic,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun ModeButton(
    label: String,
    active: Boolean,
    activeColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Eski sürüm düz/mat dolgulu bir Material Button'du ("çok yumuşak" görünüyordu).
    // Bunun yerine ince çerçeveli, camsı/neon dolgulu bir HUD butonu: pasifken bile
    // çerçeve ve yazı rengi belirgin, aktifken çerçeve+dolgu+yazı tam parlaklığa çıkıyor.
    val borderAlpha = if (active) 1f else 0.55f
    val fillAlpha = if (active) 0.24f else 0.08f
    val textAlpha = if (active) 1f else 0.8f

    Box(
        modifier = modifier
            .height(50.dp)
            .background(Bg)
            .border(1.dp, activeColor.copy(alpha = borderAlpha * 0.35f), RoundedCornerShape(4.dp))
            .padding(2.dp)
            .background(activeColor.copy(alpha = fillAlpha), RoundedCornerShape(3.dp))
            .border(1.4.dp, activeColor.copy(alpha = borderAlpha), RoundedCornerShape(3.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = activeColor.copy(alpha = textAlpha),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
            fontSize = 13.sp
        )
    }
}

@Composable
private fun ChatPanel(
    logs: List<LogLine>,
    onSendText: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            scope.launch { listState.animateScrollToItem(logs.lastIndex) }
        }
    }

    Column(
        modifier = modifier
            .border(1.dp, TealDim.copy(alpha = 0.4f))
            .padding(10.dp)
    ) {
        Text(
            "SOHBET",
            color = Dim,
            fontSize = 10.sp,
            letterSpacing = 2.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            items(logs) { line ->
                LogRow(line)
            }
        }

        Spacer(Modifier.height(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = {
                    Text("Yaz…", color = Dim, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        onSendText(input)
                        input = ""
                    }
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Teal,
                    unfocusedBorderColor = TealDim,
                    focusedTextColor = Text,
                    unfocusedTextColor = Text,
                    cursorColor = Teal
                ),
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(6.dp))
            IconButton(
                onClick = {
                    onSendText(input)
                    input = ""
                },
                modifier = Modifier
                    .size(42.dp)
                    .background(Teal, RoundedCornerShape(8.dp))
            ) {
                Text("➤", color = Bg, fontSize = 16.sp)
            }
        }
    }
}

@Composable
private fun StatusBadge(state: OrbState) {
    val (label, color) = when (state) {
        OrbState.LISTENING -> "DİNLİYOR" to Green
        OrbState.SPEAKING -> "KONUŞUYOR" to Blue
        OrbState.THINKING -> "DÜŞÜNÜYOR" to Gold
        OrbState.CONNECTING -> "BAĞLANIYOR" to Orange
        OrbState.ERROR -> "HATA" to Red
        OrbState.MUTED -> "SESSİZ" to Muted
        OrbState.IDLE -> "HAZIR" to Dim
    }
    Text(
        text = label,
        color = color,
        fontSize = 10.sp,
        letterSpacing = 1.sp,
        fontFamily = FontFamily.Monospace,
        modifier = Modifier
            .background(color.copy(alpha = 0.12f), RoundedCornerShape(4.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
private fun LogRow(line: LogLine) {
    val (prefix, color) = when (line.who) {
        "user" -> "SİZ:" to Teal
        "jarvis" -> "JARVIS:" to Green
        else -> "SYS:" to Dim
    }
    Column(modifier = Modifier.padding(vertical = 3.dp)) {
        Text(
            prefix,
            color = color,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Text(
            line.text,
            color = Text.copy(alpha = 0.85f),
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}
