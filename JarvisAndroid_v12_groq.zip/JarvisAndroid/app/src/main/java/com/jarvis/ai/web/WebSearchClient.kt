package com.jarvis.ai.web

import android.util.Base64
import android.util.Log
import okhttp3.FormBody
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Asistanın "önce araştır, sonra cevap ver" yapabilmesi için gerçek web
 * erişimi. API anahtarı gerektirmez, sadece INTERNET izni yeter.
 *
 * Arama zinciri (biri çalışmazsa sıradakine düşer):
 *   1) DuckDuckGo HTML
 *   2) Bing HTML
 *   3) Vikipedi (tr)
 * Haber sorularında Google Haberler RSS kullanılır.
 * Bir sonucun içeriğini okumak için readPage() vardır.
 */
object WebSearchClient {
    private const val TAG = "WebSearchClient"
    private const val UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

    private const val MAX_RESULTS = 5
    private const val MAX_SNIPPET = 260
    private const val MAX_PAGE_CHARS = 3000

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .callTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private data class Hit(val title: String, val url: String, val snippet: String)

    // ------------------------------------------------------------------
    // Genel giriş noktaları
    // ------------------------------------------------------------------

    fun search(query: String, news: Boolean = false): JSONObject {
        val q = query.trim()
        if (q.isEmpty()) return error("Arama sorgusu boş.")

        val hits: List<Hit> = try {
            if (news) {
                googleNews(q).ifEmpty { ddg(q) }.ifEmpty { bing(q) }
            } else {
                ddg(q).ifEmpty { bing(q) }.ifEmpty { wikipedia(q) }
            }
        } catch (e: Exception) {
            Log.w(TAG, "search failed", e)
            emptyList()
        }

        if (hits.isEmpty()) {
            return error("İnternetten sonuç alınamadı (bağlantı ya da kaynak sorunu olabilir).")
        }

        val arr = JSONArray()
        hits.take(MAX_RESULTS).forEach {
            arr.put(
                JSONObject()
                    .put("title", it.title)
                    .put("url", it.url)
                    .put("snippet", it.snippet)
            )
        }
        return JSONObject().put("status", "ok").put("query", q).put("results", arr)
    }

    fun readPage(url: String): JSONObject {
        val u = url.trim()
        val parsed = u.toHttpUrlOrNull()
        if (parsed == null || (parsed.scheme != "http" && parsed.scheme != "https")) {
            return error("Geçersiz adres.")
        }
        return try {
            val req = Request.Builder().url(parsed).header("User-Agent", UA)
                .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.5").build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return error("Sayfa açılamadı: HTTP ${resp.code}")
                val html = resp.peekBody(600_000).string()
                val title = Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                    .find(html)?.groupValues?.get(1)?.let { cleanText(it) }.orEmpty()
                val text = htmlToText(html).take(MAX_PAGE_CHARS)
                if (text.isBlank()) return error("Sayfada okunabilir metin bulunamadı.")
                JSONObject().put("status", "ok").put("url", u).put("title", title).put("text", text)
            }
        } catch (e: Exception) {
            Log.w(TAG, "readPage failed", e)
            error("Sayfa okunamadı: ${e.javaClass.simpleName}")
        }
    }

    // ------------------------------------------------------------------
    // Kaynaklar
    // ------------------------------------------------------------------

    private fun ddg(q: String): List<Hit> {
        val form = FormBody.Builder().add("q", q).add("kl", "tr-tr").build()
        val req = Request.Builder().url("https://html.duckduckgo.com/html/")
            .header("User-Agent", UA)
            .header("Accept-Language", "tr-TR,tr;q=0.9")
            .post(form).build()
        val html = client.newCall(req).execute().use { if (it.isSuccessful) it.body?.string().orEmpty() else "" }
        if (html.isBlank()) return emptyList()

        val opts = setOf(RegexOption.DOT_MATCHES_ALL)
        val linkRe = Regex("""<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>""", opts)
        val snipRe = Regex("""class="result__snippet"[^>]*>(.*?)</a>""", opts)
        val links = linkRe.findAll(html).toList()
        val out = mutableListOf<Hit>()
        for ((i, m) in links.withIndex()) {
            val end = if (i + 1 < links.size) links[i + 1].range.first else html.length
            val block = html.substring(m.range.last, end)
            val url = ddgRealUrl(unescape(m.groupValues[1])) ?: continue
            val title = cleanText(m.groupValues[2])
            val snip = snipRe.find(block)?.groupValues?.get(1)?.let { cleanText(it) }.orEmpty()
            if (title.isNotBlank()) out += Hit(title, url, snip.take(MAX_SNIPPET))
        }
        return out
    }

    private fun ddgRealUrl(href: String): String? {
        var h = href
        if (h.startsWith("//")) h = "https:$h"
        if (h.contains("duckduckgo.com/y.js")) return null // reklam
        val idx = h.indexOf("uddg=")
        if (idx >= 0) {
            val enc = h.substring(idx + 5).substringBefore("&")
            return try { URLDecoder.decode(enc, "UTF-8") } catch (e: Exception) { null }
        }
        return if (h.startsWith("http")) h else null
    }

    private fun bing(q: String): List<Hit> {
        val url = "https://www.bing.com/search?q=" + URLEncoder.encode(q, "UTF-8") +
            "&setlang=tr&cc=TR&mkt=tr-TR"
        val req = Request.Builder().url(url).header("User-Agent", UA)
            .header("Accept-Language", "tr-TR,tr;q=0.9").build()
        val html = client.newCall(req).execute().use { if (it.isSuccessful) it.body?.string().orEmpty() else "" }
        if (html.isBlank()) return emptyList()

        val opts = setOf(RegexOption.DOT_MATCHES_ALL)
        val aRe = Regex("""<h2[^>]*>\s*<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>""", opts)
        val pRe = Regex("""<p[^>]*>(.*?)</p>""", opts)
        val out = mutableListOf<Hit>()
        html.split("""<li class="b_algo"""").drop(1).forEach { block ->
            val am = aRe.find(block) ?: return@forEach
            val url0 = bingRealUrl(unescape(am.groupValues[1])) ?: return@forEach
            val title = cleanText(am.groupValues[2])
            val snip = pRe.find(block)?.groupValues?.get(1)?.let { cleanText(it) }.orEmpty()
            if (title.isNotBlank()) out += Hit(title, url0, snip.take(MAX_SNIPPET))
        }
        return out
    }

    private fun bingRealUrl(href: String): String? {
        if (!href.startsWith("http")) return null
        if (!href.contains("bing.com/ck/a")) return href
        val u = Regex("[?&]u=([^&]+)").find(href)?.groupValues?.get(1) ?: return null
        val enc = URLDecoder.decode(u, "UTF-8")
        if (!enc.startsWith("a1")) return null
        return try {
            String(Base64.decode(enc.substring(2), Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP))
        } catch (e: Exception) { null }
    }

    private fun googleNews(q: String): List<Hit> {
        val url = "https://news.google.com/rss/search?q=" + URLEncoder.encode(q, "UTF-8") +
            "&hl=tr&gl=TR&ceid=TR:tr"
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        val xml = client.newCall(req).execute().use { if (it.isSuccessful) it.body?.string().orEmpty() else "" }
        if (xml.isBlank()) return emptyList()

        val opts = setOf(RegexOption.DOT_MATCHES_ALL)
        val out = mutableListOf<Hit>()
        Regex("<item>(.*?)</item>", opts).findAll(xml).forEach { m ->
            val item = m.groupValues[1]
            val title = tag(item, "title")
            val link = tag(item, "link")
            val date = tag(item, "pubDate")
            if (title.isNotBlank()) out += Hit(title, link, date)
        }
        return out
    }

    private fun wikipedia(q: String): List<Hit> {
        val url = "https://tr.wikipedia.org/w/api.php?action=query&generator=search" +
            "&gsrsearch=" + URLEncoder.encode(q, "UTF-8") +
            "&gsrlimit=3&prop=extracts&exintro=1&explaintext=1&exchars=500&format=json&utf8=1"
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        val body = client.newCall(req).execute().use { if (it.isSuccessful) it.body?.string().orEmpty() else "" }
        if (body.isBlank()) return emptyList()
        val pages = JSONObject(body).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val out = mutableListOf<Hit>()
        val keys = pages.keys()
        while (keys.hasNext()) {
            val p = pages.optJSONObject(keys.next()) ?: continue
            val title = p.optString("title")
            val extract = p.optString("extract").replace("\n", " ")
            if (title.isNotBlank() && extract.isNotBlank()) {
                out += Hit(title, "https://tr.wikipedia.org/wiki/" + URLEncoder.encode(title.replace(' ', '_'), "UTF-8"), extract.take(MAX_SNIPPET * 2))
            }
        }
        return out
    }

    // ------------------------------------------------------------------
    // Yardımcılar
    // ------------------------------------------------------------------

    private fun tag(xml: String, name: String): String {
        val m = Regex("<$name[^>]*>(.*?)</$name>", RegexOption.DOT_MATCHES_ALL).find(xml) ?: return ""
        return cleanText(m.groupValues[1].replace("<![CDATA[", "").replace("]]>", ""))
    }

    private fun error(msg: String) = JSONObject().put("status", "error").put("message", msg)

    private fun unescape(s: String) = s.replace("&amp;", "&")

    private fun cleanText(s: String): String =
        decodeEntities(s.replace(Regex("<[^>]*>"), " ")).replace(Regex("\\s+"), " ").trim()

    private fun htmlToText(html: String): String {
        val o = setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
        var s = html
        for (t in listOf("script", "style", "noscript", "svg", "nav", "header", "footer", "form", "iframe")) {
            s = s.replace(Regex("<$t[\\s>].*?</$t>", o), " ")
        }
        s = s.replace(Regex("<!--.*?-->", RegexOption.DOT_MATCHES_ALL), " ")
        s = s.replace(Regex("</(p|div|li|h[1-6]|tr|br)>", RegexOption.IGNORE_CASE), ". ")
        return cleanText(s).replace(Regex("(\\. ){2,}"), ". ")
    }

    private fun decodeEntities(s: String): String {
        var r = s.replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<")
            .replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'")
        r = Regex("&#(\\d+);").replace(r) {
            it.groupValues[1].toIntOrNull()?.let { c -> String(Character.toChars(c)) } ?: ""
        }
        r = Regex("&#x([0-9a-fA-F]+);").replace(r) {
            it.groupValues[1].toIntOrNull(16)?.let { c -> String(Character.toChars(c)) } ?: ""
        }
        return r
    }
}
