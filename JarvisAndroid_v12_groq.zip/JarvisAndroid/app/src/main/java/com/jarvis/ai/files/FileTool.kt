package com.jarvis.ai.files

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * JARVIS'in kullanıcı için gerçek dosya (txt, herhangi bir düz metin, zip)
 * oluşturabilmesini sağlar.
 *
 * Android 10 (API 29) ve üstünde: MediaStore üzerinden doğrudan paylaşılan
 * "İndirilenler" klasörüne, HİÇBİR ek izin istemeden yazılır (scoped storage).
 * Android 9 ve altında (API 26-28, bu projenin minSdk'sı): scoped storage yok
 * ve genel depolama izni gerekirdi; karmaşıklığı artırmamak için o eski
 * cihazlarda dosya uygulamanın kendi özel alanına (Context.filesDir) yazılır.
 */
object FileTool {

    data class SavedFile(val displayPath: String, val savedToDownloads: Boolean)

    fun createTextFile(
        context: Context,
        filename: String,
        content: String,
        mimeType: String = "text/plain"
    ): SavedFile {
        val safeName = sanitize(filename)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Dosya oluşturulamadı (MediaStore reddetti)")
            resolver.openOutputStream(uri)?.use { it.write(content.toByteArray()) }
                ?: throw IOException("Dosyaya yazılamadı")
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            SavedFile("İndirilenler/$safeName", true)
        } else {
            val file = File(context.filesDir, safeName)
            FileOutputStream(file).use { it.write(content.toByteArray()) }
            SavedFile(file.absolutePath, false)
        }
    }

    fun createZipFile(
        context: Context,
        zipFilename: String,
        entries: List<Pair<String, String>>
    ): SavedFile {
        val safeName = sanitize(zipFilename, forceExt = "zip")
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Zip oluşturulamadı (MediaStore reddetti)")
            resolver.openOutputStream(uri)?.use { out -> writeZip(out, entries) }
                ?: throw IOException("Zip'e yazılamadı")
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            SavedFile("İndirilenler/$safeName", true)
        } else {
            val file = File(context.filesDir, safeName)
            FileOutputStream(file).use { out -> writeZip(out, entries) }
            SavedFile(file.absolutePath, false)
        }
    }

    private fun writeZip(out: java.io.OutputStream, entries: List<Pair<String, String>>) {
        ZipOutputStream(out).use { zos ->
            entries.forEach { (name, text) ->
                zos.putNextEntry(ZipEntry(sanitize(name)))
                zos.write(text.toByteArray())
                zos.closeEntry()
            }
        }
    }

    private fun sanitize(name: String, forceExt: String? = null): String {
        var n = name.trim().ifBlank { "jarvis_dosya" }
        n = n.replace(Regex("[/\\\\:*?\"<>|]"), "_")
        if (forceExt != null && !n.endsWith(".$forceExt", ignoreCase = true)) {
            n = "$n.$forceExt"
        }
        return n
    }
}
