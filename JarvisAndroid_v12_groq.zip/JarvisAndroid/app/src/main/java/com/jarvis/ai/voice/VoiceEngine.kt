package com.jarvis.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale
import java.util.UUID

/**
 * Mikrofon dinleme (STT) ve sesli okuma (TTS) işlerini Android'in kendi
 * yerleşik, ÜCRETSİZ ve API-KEY GEREKTİRMEYEN servisleriyle yapar.
 *
 * Akış: dinle (SpeechRecognizer) → metne çevir → GroqTextClient ile
 * (ücretsiz, normal generateContent API'siyle) cevap al → cevabı sesli oku
 * (TextToSpeech) → mikrofon hâlâ açıksa tekrar dinlemeye başla.
 *
 * ÖNEMLİ (Android kısıtı): SpeechRecognizer.createSpeechRecognizer() ve
 * start/stop/destroy çağrılarının hepsi ANA (UI) thread'den yapılmalı.
 * Bu sınıfın public fonksiyonları bu yüzden içeride mainHandler.post ile
 * her zaman ana thread'e atlıyor — çağıran taraf (ViewModel) hangi thread'de
 * olursa olsun güvenli.
 *
 * TextToSpeech'in ilerleme callback'leri (onStart/onDone/onError) Android'de
 * ana thread olmayan bir thread'den gelebiliyor; onlar da aynı sebeple
 * mainHandler.post ile dışarı aktarılıyor.
 */
class VoiceEngine(context: Context) {

    companion object {
        private const val TAG = "VoiceEngine"
    }

    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    @Volatile private var speechRate = 0.97f

    var onFinalResult: ((String) -> Unit)? = null
    var onRms: ((Float) -> Unit)? = null
    /** recoverable=true: geçici bir durum (sessizlik/anlaşılamadı), otomatik tekrar denenebilir. */
    var onListeningError: ((message: String, recoverable: Boolean) -> Unit)? = null
    var onSpeechStart: (() -> Unit)? = null
    var onSpeechDone: (() -> Unit)? = null

    fun init() {
        mainHandler.post {
            if (tts != null) return@post
            tts = TextToSpeech(appContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val result = tts?.setLanguage(Locale("tr", "TR"))
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.w(TAG, "Türkçe TTS sesi yok, varsayılan dil kullanılacak")
                    }
                    selectMasculineVoice()
                    // Android'in Voice sınıfında cinsiyet bilgisi resmi olarak
                    // yok; isimden tahmin (selectMasculineVoice) ile birlikte
                    // sesi biraz kalınlaştırıp yavaşlatarak filmdeki sakin,
                    // pes tonlu JARVIS hissine yaklaştırıyoruz.
                    tts?.setPitch(0.82f)
                    tts?.setSpeechRate(speechRate)
                    ttsReady = true
                } else {
                    Log.e(TAG, "TTS başlatılamadı: $status")
                }
            }
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    mainHandler.post { onSpeechStart?.invoke() }
                }

                override fun onDone(utteranceId: String?) {
                    mainHandler.post { onSpeechDone?.invoke() }
                }

                @Deprecated("Deprecated in Java", ReplaceWith(""))
                override fun onError(utteranceId: String?) {
                    mainHandler.post { onSpeechDone?.invoke() }
                }
            })
        }
    }

    fun startListening() {
        mainHandler.post {
            try {
                if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
                    onListeningError?.invoke("Bu cihazda konuşma tanıma servisi bulunamadı.", false)
                    return@post
                }
                // Önceki oturumdan kalan bir tanıyıcı varsa temizle — aksi halde
                // "busy" hatası alıp hiç dinlemeye başlamayabiliyor.
                recognizer?.destroy()
                recognizer = SpeechRecognizer.createSpeechRecognizer(appContext).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) = Unit
                        override fun onBeginningOfSpeech() = Unit

                        override fun onRmsChanged(rmsdB: Float) {
                            // rmsdB kabaca 0..10+ arası geliyor; orb animasyonu 0..1 bekliyor.
                            onRms?.invoke((rmsdB / 10f).coerceIn(0f, 1f))
                        }

                        override fun onBufferReceived(buffer: ByteArray?) = Unit

                        override fun onEndOfSpeech() {
                            onRms?.invoke(0f)
                        }

                        override fun onError(error: Int) {
                            val recoverable = error == SpeechRecognizer.ERROR_NO_MATCH ||
                                error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                                error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY
                            onListeningError?.invoke(describeError(error), recoverable)
                        }

                        override fun onResults(results: Bundle?) {
                            val text = results
                                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                                ?.firstOrNull()
                                .orEmpty()
                            if (text.isNotBlank()) onFinalResult?.invoke(text)
                        }

                        override fun onPartialResults(partialResults: Bundle?) = Unit
                        override fun onEvent(eventType: Int, params: Bundle?) = Unit
                    })
                }
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, appContext.packageName)
                }
                recognizer?.startListening(intent)
            } catch (e: Exception) {
                Log.e(TAG, "startListening", e)
                onListeningError?.invoke("Dinleme başlatılamadı: ${e.message}", false)
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            try {
                recognizer?.stopListening()
                recognizer?.destroy()
            } catch (e: Exception) {
                Log.w(TAG, "stopListening", e)
            }
            recognizer = null
            onRms?.invoke(0f)
        }
    }

    /** Konuşma hızını değiştirir (0.5 yavaş … 2.0 hızlı gibi). Hemen uygular. */
    fun setSpeechRate(rate: Float) {
        speechRate = rate
        mainHandler.post {
            if (ttsReady) tts?.setSpeechRate(rate)
        }
    }

    fun speak(text: String) {
        mainHandler.post {
            if (!ttsReady) {
                // TTS motoru henüz hazır olmayabilir (uygulama yeni açıldı);
                // kısa bir bekleme sonrası tekrar dene.
                mainHandler.postDelayed({ speak(text) }, 300)
                return@post
            }
            // Her seferinde uygula: init() sırasında setSpeechRate() henüz
            // TTS hazır olmadan çağrılmış olabilir, burada garantiye alıyoruz.
            tts?.setSpeechRate(speechRate)
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
        }
    }

    fun stopSpeaking() {
        mainHandler.post {
            try { tts?.stop() } catch (e: Exception) { Log.w(TAG, "stopSpeaking", e) }
        }
    }

    fun release() {
        mainHandler.post {
            try { recognizer?.destroy() } catch (e: Exception) { Log.w(TAG, "release/recognizer", e) }
            recognizer = null
            try {
                tts?.stop()
                tts?.shutdown()
            } catch (e: Exception) {
                Log.w(TAG, "release/tts", e)
            }
            tts = null
            ttsReady = false
        }
    }

    /**
     * Android'in TextToSpeech.Voice sınıfı cinsiyeti resmi bir alan olarak
     * vermiyor, o yüzden %100 garanti yok — ama elimizdeki tr-TR seslerinin
     * isimlerine bakıp "female/kadın" geçmeyeni (yani genelde erkek sesi
     * olanı) seçmeye çalışıyoruz. Cihazda/motorda tek ses varsa zaten bir şey
     * değişmez, ama Google TTS motoru gibi birden çok sesi olan motorlarda
     * bu genelde işe yarıyor. Bulunamazsa varsayılan sesle devam edilir
     * (pitch/rate ayarı yine de daha kalın/sakin hissettirir).
     */
    private fun selectMasculineVoice() {
        val engine = tts ?: return
        try {
            val allVoices = engine.voices ?: return
            val trVoices = allVoices.filter { it.locale.language == "tr" }
            if (trVoices.isEmpty()) return

            val male = trVoices.firstOrNull { v ->
                val n = v.name.lowercase()
                !n.contains("female") && !n.contains("kadin") && !n.contains("kadın")
            }

            (male ?: trVoices.firstOrNull())?.let { chosen ->
                engine.voice = chosen
                Log.i(TAG, "TTS sesi seçildi: ${chosen.name}")
            }
        } catch (e: Exception) {
            Log.w(TAG, "selectMasculineVoice", e)
        }
    }

    private fun describeError(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH -> "Anlaşılamadı, tekrar dinleniyor…"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Ses algılanmadı, tekrar dinleniyor…"
        SpeechRecognizer.ERROR_AUDIO -> "Ses kaydı hatası"
        SpeechRecognizer.ERROR_NETWORK -> "Ağ hatası (konuşma tanıma internet gerektirir)"
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Ağ zaman aşımı"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Tanıyıcı meşgul, tekrar deneniyor…"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mikrofon izni eksik"
        SpeechRecognizer.ERROR_CLIENT -> "İstemci hatası"
        else -> "Dinleme hatası (kod $code)"
    }
}
