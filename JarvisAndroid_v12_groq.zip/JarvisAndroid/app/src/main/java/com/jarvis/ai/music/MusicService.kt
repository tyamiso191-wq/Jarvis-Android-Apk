package com.jarvis.ai.music

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.jarvis.ai.MainActivity

/**
 * Yerel bir ses dosyasını ARKA PLANDA (kullanıcı Jarvis ekranından çıksa
 * bile) çalmaya devam eden foreground servis. Bildirim olmadan Android
 * arka plan ses oynatmayı birkaç dakika içinde kapatıyor — bu yüzden
 * foreground + kalıcı bildirim zorunlu (Android'in kendi kısıtı, bizim
 * tercihimiz değil).
 */
class MusicService : Service() {

    companion object {
        private const val TAG = "MusicService"
        private const val CHANNEL_ID = "jarvis_music"
        private const val NOTIF_ID = 42

        const val ACTION_PLAY = "com.jarvis.ai.music.ACTION_PLAY"
        const val ACTION_STOP = "com.jarvis.ai.music.ACTION_STOP"
        const val EXTRA_URI = "uri"
        const val EXTRA_TITLE = "title"
        const val EXTRA_ARTIST = "artist"
        const val EXTRA_HEADERS = "headers"
    }

    private var player: MediaPlayer? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopPlayback()
                stopSelf()
            }
            else -> {
                val uriStr = intent?.getStringExtra(EXTRA_URI)
                val title = intent?.getStringExtra(EXTRA_TITLE) ?: "Şarkı"
                val artist = intent?.getStringExtra(EXTRA_ARTIST) ?: ""
                @Suppress("UNCHECKED_CAST", "DEPRECATION")
                val headers = intent?.getSerializableExtra(EXTRA_HEADERS) as? HashMap<String, String>
                if (uriStr != null) {
                    startForeground(NOTIF_ID, buildNotification(title, artist))
                    play(Uri.parse(uriStr), headers)
                } else {
                    stopSelf()
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun play(uri: Uri, headers: Map<String, String>? = null) {
        stopPlayback()
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                if (headers.isNullOrEmpty()) {
                    setDataSource(applicationContext, uri)
                } else {
                    setDataSource(applicationContext, uri, headers)
                }
                setOnCompletionListener { stopSelf() }
                setOnErrorListener { _, what, extra ->
                    Log.e(TAG, "MediaPlayer hatası: what=$what extra=$extra")
                    stopSelf()
                    true
                }
                // Yerel dosyalarda anında hazır olur; uzak (YouTube ses akışı)
                // kaynaklarda ağdan arabelleğe alma gerektiği için ASENKRON
                // hazırlanır -- prepare() burada servisin ana thread'ini
                // tıkayıp ANR'a yol açardı.
                setOnPreparedListener { it.start() }
                prepareAsync()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Çalma başlatılamadı", e)
            stopSelf()
        }
    }

    private fun stopPlayback() {
        try {
            player?.stop()
            player?.release()
        } catch (e: Exception) {
            Log.w(TAG, "stopPlayback", e)
        }
        player = null
    }

    private fun buildNotification(title: String, artist: String): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "JARVIS Müzik", NotificationManager.IMPORTANCE_LOW)
                )
            }
        }

        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, MusicService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(artist)
            .setContentIntent(openAppIntent)
            .addAction(android.R.drawable.ic_media_pause, "Durdur", stopIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        stopPlayback()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
