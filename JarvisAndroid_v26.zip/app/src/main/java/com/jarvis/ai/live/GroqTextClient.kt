package com.jarvis.ai.live

import android.content.Context
import android.util.Base64
import android.util.Log
import com.jarvis.ai.files.FileTool
import com.jarvis.ai.image.ImageGenClient
import com.jarvis.ai.music.MusicController
import com.jarvis.ai.terminal.TerminalRunner
import com.jarvis.ai.weather.WeatherClient
import com.jarvis.ai.web.WebSearchClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Groq'un OpenAI-uyumlu Chat Completions API'si (https://api.groq.com/openai/v1)
 * ile konuşur. GeminiTextClient'ın yerini alır — aynı public arayüzü
 * (verifyKey / sendMessage) sağladığı için JarvisViewModel'de sadece bu
 * sınıfın kullanılması yeterli.
 *
 * NEDEN GEMINI DEĞİL DE GROQ: Gemini'nin ücretsiz tier kotası çok düşüktü ve
 * bu key'de sürekli 429 (kota aşıldı) hatası alınıyordu — hem "yanlış model
 * seçildi" (nano-banana, customtools gibi sohbete uygun olmayan modellerin
 * sızması) hem de gerçek hesap/proje bazlı kota tükenmesi şeklinde. Groq'un
 * ücretsiz tier'ı (Llama modelleri için günde binlerce istek) çok daha
 * cömert ve model isimleri Gemini'nin aksine sık değişmiyor, bu yüzden
 * Gemini'deki gibi ağır bir "dinamik model keşfi" mekanizmasına gerek yok —
 * sabit, dokümante edilmiş birkaç model arasında basit bir fallback yeterli.
 *
 * WEB ARAMASI: Groq'un "compound" modelleri yerleşik arama yapıyor ama
 * kullanıcı tanımlı fonksiyonları desteklemiyor. Bu yüzden arama, kendi
 * fonksiyonlarımız olarak (web_search / read_webpage / get_weather) uygulamada
 * çalışıyor: model önce bu fonksiyonları çağırıp araştırıyor, sonuçları görüp
 * öyle cevap veriyor. Böylece hem dosya/müzik fonksiyonları hem canlı
 * araştırma bir arada çalışıyor.
 */
class GroqTextClient(
    private val apiKey: String,
    private val persona: String,
    private val appContext: Context
) {
    companion object {
        private const val TAG = "GroqTextClient"
        private const val CHAT_URL = "https://api.groq.com/openai/v1/chat/completions"
        private const val MODELS_URL = "https://api.groq.com/openai/v1/models"

        // Groq'un model isimleri Gemini'nin aksine sık değişmiyor ve
        // dokümante edilmiş durumda, o yüzden dinamik keşif yerine sabit,
        // bilinen bir sıra kullanıyoruz. Sıra: en iyi genel amaçlı/tool-use
        // model önce, sonra hızlı/hafif yedek, en sonda ek bir yedek.
        private val DEFAULT_CANDIDATES = listOf(
            "openai/gpt-oss-120b",
            "llama-3.3-70b-versatile",
            "openai/gpt-oss-20b",
            "qwen/qwen3-32b",
            // Ayrı bir kota havuzu: diğerleri dolunca devreye girer.
            "meta-llama/llama-4-scout-17b-16e-instruct"
        )

        // Fotoğraf/PDF eklenen mesajlarda SADECE görsel destekleyen modeller
        // denenir (metin-only modeller görseli kabul etmez). Groq'un vision
        // sayfasındaki modeller; son sıradaki eski Llama 4 Scout kaldırılmış
        // olabilir, o zaman zaten hata verip atlanır.
        // NOT: qwen3.6/3.8 önizleme modelleri bu hesapta 404 ("does not exist
        // or you do not have access") veriyordu; erişilebilen Llama 4 Scout
        // başa alındı. Erişilemeyen (404) modeller ayrıca kalıcı atlanıyor.
        private val VISION_CANDIDATES = listOf(
            "meta-llama/llama-4-scout-17b-16e-instruct",
            "qwen/qwen3.6-27b",
            "qwen/qwen3.8-27b"
        )

        // HTTP 429 alan bir model bu süre boyunca tekrar denenmez. Groq'un
        // ücretsiz tier'ında dakikalık kota genelde ~1 dakikada yenileniyor.
        private const val COOLDOWN_MS = 60_000L

        // Bir sendMessage() çağrısında en fazla bu kadar farklı model denenir.
        private const val MAX_ATTEMPTS_PER_MESSAGE = 5

        // Art arda bu kadar model 429 döndürürse hesabın genel limiti (o an)
        // dolmuş demektir -- kullanıcıya HATA gösterip vazgeçmek yerine kotanın
        // yenilenmesini SESSİZCE bekleyip otomatik devam ediyoruz.
        private const val MAX_CONSECUTIVE_429 = 5

        // ÖNEMLİ (kullanıcı isteği): kota dolduğunda görev ASLA yarım
        // bırakılıp hata gösterilmesin -- her 1 dakikada bir sessizce
        // kontrol edilip kota açılır açılmaz otomatik devam edilsin. Bu
        // yüzden bekleme turu için bir üst sınır YOK (Int.MAX_VALUE):
        // TPD/RPD (günlük) kota olsa bile uygulama pes etmeden 1 dakikada
        // bir yoklamaya devam eder, ta ki kota yenilenip istek geçene kadar.
        // Kullanıcı isterse "DURDUR" butonuyla bu bekleyişi istediği an
        // kesebilir (chatJob iptal edilir).
        private const val MAX_WAIT_ROUNDS = Int.MAX_VALUE
        private const val DAILY_COOLDOWN_MS = 4 * 60 * 60 * 1000L // 4 saat

        // Başarısız denemeler arasında küçük bir bekleme (rate-limit
        // burst'ünü tetiklememek için).
        private const val ATTEMPT_DELAY_MS = 400L

        // Araştırma (arama + sayfa okuma + cevap) birkaç tur sürebilir.
        private const val MAX_TOOL_TURNS = 7

        // Modele gönderilen en fazla mesaj sayısı (token tasarrufu).
        private const val MAX_HISTORY_SENT = 16

        private const val PREFS_NAME = "groq_text_client_cache"
        private const val PREF_WORKING_MODEL = "working_model"
    }

    /** Araç çalışırken arayüzün durum yazısını güncellemesi için (örn. "ARAŞTIRIYOR"). */
    @Volatile var onToolUse: ((String) -> Unit)? = null

    /**
     * En az bir model 429 (kota dolu) döndürdüğünde tetiklenir; kullanıcıya
     * HATA olarak DEĞİL, ViewModel isterse "BEKLENİYOR" gibi nötr bir durum
     * göstermesi için bilgi amaçlı çağrılır. Hiçbir şey bağlanmazsa (null
     * kalırsa) sessizce beklenir, kullanıcıya hiçbir uyarı gösterilmez.
     * reason: Groq'un döndürdüğü GERÇEK hata metni (hangi model, TPD/RPD mi
     * RPM/TPM mi, limit/used sayıları) -- ViewModel bunu log'a da yazarak
     * kullanıcının "gerçekten dolu mu yoksa yanlış mı algılandı" diye
     * şüphelenmeden kendi gözüyle görebilmesini sağlar.
     */
    @Volatile var onQuotaWait: ((waitMs: Long, reason: String) -> Unit)? = null

    /**
     * Kullanıcı get_weather ile AÇIKÇA bir şehir sorduğunda (city boş değilse)
     * tetiklenir. ViewModel bunu dinleyip sol alttaki hava durumu widget'ını o
     * şehre göre günceller ve bir dahaki açılışta da hatırlansın diye kaydeder.
     */
    @Volatile var onCityQueried: ((String) -> Unit)? = null

    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        // max_tokens 8000'e çıkarıldığı için (bkz. callModel), büyük bir
        // oyun/uygulama kodu üretimi eski 45sn'lik sınırı zorlayabilirdi;
        // burada da pay bırakıldı.
        .readTimeout(90, TimeUnit.SECONDS)
        .callTimeout(100, TimeUnit.SECONDS)
        .build()

    // Süreç boyunca (ve SharedPreferences sayesinde uygulama yeniden
    // başlasa bile) hatırlanan, en son başarılı olan model.
    @Volatile private var workingModel: String? = prefs.getString(PREF_WORKING_MODEL, null)

    // HTTP 429 alınan modeller burada, tekrar denenebilecekleri zaman
    // damgasıyla tutulur.
    private val modelCooldownUntil = ConcurrentHashMap<String, Long>()

    // HTTP 404 / "model_not_found" alan modeller: bu hesapta yok veya erişim
    // yok. Kota değil, kalıcı sorun -- oturum boyunca tekrar denenmez ki 3
    // deneme hakkından biri boşa gitmesin.
    private val unavailableModels = ConcurrentHashMap.newKeySet<String>()

    private fun isModelUnavailableError(message: String?): Boolean {
        if (message.isNullOrBlank()) return false
        val lower = message.lowercase()
        return lower.contains("http 404") || lower.contains("model_not_found") ||
            lower.contains("does not exist or you do not have access")
    }

    private fun isOnCooldown(model: String): Boolean {
        val until = modelCooldownUntil[model] ?: return false
        return System.currentTimeMillis() < until
    }

    private fun markCooldown(model: String, durationMs: Long = COOLDOWN_MS) {
        modelCooldownUntil[model] = System.currentTimeMillis() + durationMs
    }

    /**
     * Groq'un 429 gövdesinde "tokens per day (TPD)" / "requests per day (RPD)"
     * geçiyorsa bu GÜNLÜK bir kota hatasıdır, dakikalık değil. Kullanıcı
     * isteği üzerine bu durumda bile pes edilmiyor -- sadece log/durum
     * mesajında ayırt edebilmek için tutuluyor; bekleme/deneme davranışı
     * ikisinde de aynı: her 1 dakikada bir sessizce yeniden denenir.
     */
    private fun isDailyQuotaError(message: String?): Boolean {
        if (message.isNullOrBlank()) return false
        val lower = message.lowercase()
        return lower.contains("tpd") || lower.contains("rpd") || lower.contains("per day")
    }

    /**
     * Groq'un uzun 429 metninden okunabilir kısa özet çıkarır:
     * "openai/gpt-oss-20b: günlük (TPD) Limit 200000, Used 199800, Requested 4000 — tekrar dene: 12m3s"
     */
    private fun summarizeQuota(err: String): String {
        val model = err.substringBefore(" →").trim()
        val kind = Regex("on ([a-z ]+) \\((TPD|TPM|RPD|RPM)\\)").find(err)?.groupValues?.get(2)
        val kindTr = when (kind) {
            "TPD" -> "günlük token (TPD)"
            "RPD" -> "günlük istek (RPD)"
            "TPM" -> "dakikalık token (TPM)"
            "RPM" -> "dakikalık istek (RPM)"
            else -> "tür bilinmiyor"
        }
        val limit = Regex("Limit (\\d+)").find(err)?.groupValues?.get(1)
        val used = Regex("Used (\\d+)").find(err)?.groupValues?.get(1)
        val req = Regex("Requested (\\d+)").find(err)?.groupValues?.get(1)
        val retry = Regex("try again in ([0-9hms.]+)").find(err)?.groupValues?.get(1)
        val nums = listOfNotNull(
            limit?.let { "Limit $it" }, used?.let { "Used $it" }, req?.let { "Requested $it" }
        ).joinToString(", ")
        return buildString {
            append(model).append(": ").append(kindTr)
            if (nums.isNotEmpty()) append(", ").append(nums)
            if (retry != null) append(" — tekrar dene: ").append(retry)
        }
    }

    private fun persistWorkingModel(model: String) {
        prefs.edit().putString(PREF_WORKING_MODEL, model).apply()
    }

    /** Basit bir GET ile key'in geçerli olup olmadığını hızlıca doğrular. */
    suspend fun verifyKey(): String? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url(MODELS_URL)
                .header("Authorization", "Bearer $apiKey")
                .build()
            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    null
                } else {
                    val body = try { resp.body?.string()?.take(300) } catch (e: Exception) { null }
                    "API anahtarı kontrolü başarısız: HTTP ${resp.code}${if (!body.isNullOrBlank()) " — $body" else ""}"
                }
            }
        } catch (e: Exception) {
            "Ağa ulaşılamıyor (${e.javaClass.simpleName}: ${e.message}). İnternet bağlantını kontrol et."
        }
    }

    /**
     * conversation: sırayla ("user", metin) / ("model", metin) geçmişi
     * (ViewModel Gemini konvansiyonunu koruyor, burada "model" -> "assistant"
     * olarak çevriliyor).
     */
    suspend fun sendMessage(
        conversation: List<Pair<String, String>>,
        deviceContext: String = "",
        // Bu turda kullanıcının mesajının modele giden TAM hali (ek dosya
        // içerikleri dahil). Geçmişe sadece kısa hali yazıldığı için burada ayrı
        // veriliyor. null ise geçmişteki son mesaj olduğu gibi gider.
        currentTurnText: String? = null,
        // Bu turda eklenen fotoğraflar / PDF sayfaları ("data:image/jpeg;base64,...").
        images: List<String> = emptyList()
    ): Result<String> =
        withContext(Dispatchers.IO) {
            // TOKEN TASARRUFU: her istekte ~5.500 token gidiyordu ("selam" bile).
            // Dosya/oyun/zip/görsel/terminal ile ilgili uzun talimatlar ve araç
            // tanımları SADECE son mesajlarda bununla ilgili bir istek varsa
            // gönderilir. Geçmiş de son 16 mesajla sınırlı (kalıcı geçmiş
            // yine 80 mesaj saklanır, sadece modele giden kısım kısaltılır).
            val needsBuilder = needsBuilderTools(conversation, currentTurnText)
            val activePersona = if (needsBuilder) {
                persona.replace("@@B@@", "").replace("@@/B@@", "")
            } else {
                persona.replace(Regex("(?s)@@B@@.*?@@/B@@"), "")
            }
            val fullInstruction = if (deviceContext.isBlank()) activePersona else "$activePersona\n\n$deviceContext"
            val trimmedConversation = conversation.takeLast(MAX_HISTORY_SENT)

            var waitRound = 0
            waitLoop@ while (true) {
                val rawOrder = if (images.isNotEmpty()) {
                    VISION_CANDIDATES
                } else {
                    workingModel?.let { pref ->
                        listOf(pref) + DEFAULT_CANDIDATES.filterNot { it == pref }
                    } ?: DEFAULT_CANDIDATES
                }
                // Erişilemeyen (404) modeller elenir; hepsi elenirse liste sıfırlanır.
                val baseOrder = rawOrder.filterNot { it in unavailableModels }
                    .ifEmpty { unavailableModels.clear(); rawOrder }

                val order = baseOrder
                    .sortedBy { if (isOnCooldown(it)) 1 else 0 }
                    .take(MAX_ATTEMPTS_PER_MESSAGE)

                var lastError: String? = null
                // Ekranda/log'da SADECE gerçek 429 (kota) hatası gösterilir;
                // 404 gibi alakasız hatalar buraya karışmaz.
                var lastQuotaError: String? = null
                val quotaSummaries = mutableListOf<String>()
                val otherErrors = mutableListOf<String>()
                var consecutive429 = 0
                var attempted429Models = 0
                for (model in order) {
                    val result = callModel(model, trimmedConversation, fullInstruction, currentTurnText, images, needsBuilder)
                    if (result.isSuccess) {
                        // Görsel turunda çalışan vision modelini "varsayılan" yapma:
                        // sonraki düz metin sohbetleri yine normal sırayla denensin.
                        if (images.isEmpty()) {
                            workingModel = model
                            persistWorkingModel(model)
                        }
                        return@withContext result
                    }
                    lastError = result.exceptionOrNull()?.message
                    if (isModelUnavailableError(lastError)) {
                        unavailableModels.add(model)
                        if (workingModel == model) {
                            workingModel = null
                            prefs.edit().remove(PREF_WORKING_MODEL).apply()
                        }
                        Log.w(TAG, "$model → bu hesapta erişilemiyor (404), bir daha denenmeyecek.")
                    } else if (lastError?.contains("HTTP 429") == true) {
                        lastQuotaError = lastError
                        quotaSummaries.add(summarizeQuota(lastError!!))
                        // Kullanıcı isteği: kota günlük (TPD/RPD) bile olsa asla
                        // pes edilmesin -- her model 1 dakika (COOLDOWN_MS)
                        // sonra tekrar denenmek üzere işaretlenir, sadece
                        // log'da günlük/dakikalık ayrımı belirtilir.
                        if (isDailyQuotaError(lastError)) {
                            Log.i(TAG, "$model → günlük (TPD/RPD) kota dolu, yine de 1dk sonra tekrar denenecek.")
                        }
                        markCooldown(model, COOLDOWN_MS)
                        consecutive429++
                        attempted429Models++
                        if (consecutive429 >= MAX_CONSECUTIVE_429) {
                            Log.w(TAG, "Art arda $consecutive429 model 429 döndürdü — bu turda deneme durduruldu.")
                            break
                        }
                    } else {
                        consecutive429 = 0
                        otherErrors.add(lastError.orEmpty().take(140))
                    }
                    if (result.isFailure) delay(ATTEMPT_DELAY_MS)
                    Log.w(TAG, "Model başarısız, sıradaki deneniyor: $model → $lastError")
                }

                // Kota (429) durumunda GÖREV ASLA yarım bırakılmıyor: denenen
                // modellerin HEPSİNİN 429 vermesini beklemek yerine (bazen
                // aradaki bir model farklı bir geçici hatayla -- boş yanıt,
                // zaman aşımı vb. -- başarısız olup bu şartı bozabiliyordu ve
                // asıl kota hatası ekrana "Cevap alınamadı" diye düşüyordu),
                // bu turda EN AZ BİR model 429 verdiyse yine de kota meselesi
                // sayılır: kullanıcıya hata GÖSTERİLMEZ, 1 dakika (COOLDOWN_MS)
                // sonra sessizce yeniden denenir, kota açılınca otomatik devam
                // edilir. Sadece hiçbir model 429 vermediyse (401 geçersiz key,
                // gerçek bir ağ/parse hatası vb.) hemen hata ile dönülür.
                if (attempted429Models > 0) {
                    waitRound++
                    if (waitRound > MAX_WAIT_ROUNDS) {
                        // Pratikte asla ulaşılmaz (MAX_WAIT_ROUNDS = Int.MAX_VALUE),
                        // sadece tip güvenliği için bırakıldı.
                        return@withContext Result.failure(IOException(lastError ?: "Bilinmeyen hata"))
                    }
                    val waitMs = order.mapNotNull { modelCooldownUntil[it] }
                        .minOrNull()
                        ?.let { (it - System.currentTimeMillis()).coerceAtLeast(1_000L) }
                        ?: COOLDOWN_MS
                    Log.i(TAG, "Kota dolu, görev yarım bırakılmıyor — ${waitMs}ms sonra sessizce yeniden denenecek (tur $waitRound).")
                    try { onQuotaWait?.invoke(waitMs, (if (quotaSummaries.isNotEmpty()) quotaSummaries.joinToString(" | ") else (lastQuotaError ?: "bilinmeyen sebep")) +
                        (if (otherErrors.isNotEmpty()) " || DİĞER HATALAR: " + otherErrors.joinToString(" | ") else "")) } catch (e: Exception) { Log.w(TAG, "onQuotaWait", e) }
                    delay(waitMs)
                    continue@waitLoop
                }

                return@withContext Result.failure(IOException(lastError ?: "Bilinmeyen hata"))
            }
            @Suppress("UNREACHABLE_CODE")
            Result.failure(IOException("Bilinmeyen hata"))
        }

    // Groq TPM hesabında istenen max_tokens da sayılabildiği için normal
    // sohbette düşük tutulur; sadece kod/oyun/zip üretimi istenince yükseltilir.
    private fun maxTokensFor(conversation: List<Pair<String, String>>, currentTurnText: String?): Int {
        val last = (currentTurnText ?: conversation.lastOrNull { it.first == "user" }?.second ?: "").lowercase()
        val big = listOf("oyun", "zip", "uygulama", "kod", "html", "site", "script", "program", "proje")
        return if (big.any { last.contains(it) }) 8000 else 2000
    }

    private fun callModel(
        model: String,
        conversation: List<Pair<String, String>>,
        systemInstruction: String,
        currentTurnText: String? = null,
        images: List<String> = emptyList(),
        includeBuilderTools: Boolean = true
    ): Result<String> {
      return try {
        // OpenAI-uyumlu "messages" dizisi: sistem mesajı + geçmiş.
        val messages = JSONArray().apply {
            put(JSONObject().apply {
                put("role", "system")
                put("content", systemInstruction)
            })
            conversation.forEachIndexed { index, (role, text) ->
                val isCurrentUserTurn = index == conversation.lastIndex && role == "user" &&
                    (images.isNotEmpty() || currentTurnText != null)
                put(JSONObject().apply {
                    put("role", if (role == "model") "assistant" else "user")
                    if (!isCurrentUserTurn) {
                        put("content", text)
                    } else if (images.isEmpty()) {
                        put("content", currentTurnText ?: text)
                    } else {
                        // OpenAI-uyumlu çok parçalı içerik: metin + görseller.
                        put("content", JSONArray().apply {
                            put(JSONObject().put("type", "text").put("text", currentTurnText ?: text))
                            images.forEach { url ->
                                put(
                                    JSONObject()
                                        .put("type", "image_url")
                                        .put("image_url", JSONObject().put("url", url))
                                )
                            }
                        })
                    }
                })
            }
        }

        var lastText = ""
        for (turn in 0 until MAX_TOOL_TURNS) {
            // Son turda tool_choice=none: model artık elindekiyle cevap vermek zorunda.
            val lastTurn = turn == MAX_TOOL_TURNS - 1
            val body = JSONObject().apply {
                put("model", model)
                put("messages", messages)
                put("temperature", 0.7)
                // gpt-oss gibi muhakeme yapan modellerde düşünme token'ları da
                // bu sınıra dahil; 400 çok azdı ve cevap boş kalabiliyordu.
                // NOT: create_zip ile tam bir oyun/uygulama (index.html içine
                // gömülü CSS+JS) üretilirken bu tool-call çağrısının
                // "arguments" alanı da bu sınıra dahil oluyor -- 1500 gibi
                // düşük bir değer kodu ortasında keserdi ve bozuk/parçalanmış
                // bir zip çıkardı. Sesli, kısa sohbet cevapları modelin
                // kendisi zaten kısa tutuyor (persona'daki "kısa cevap ver"
                // kuralı); bu sadece bir ÜST SINIR, büyütmek kısa cevapları
                // uzatmaz ama uzun bir oyun kodunun tam çıkmasını sağlar.
                put("max_tokens", maxTokensFor(conversation, currentTurnText))
                if (model.startsWith("openai/gpt-oss")) {
                    put("reasoning_effort", "low")
                } else if (model == "qwen/qwen3-32b") {
                    // Sesli asistan için düşünme modu kapalı (hızlı + token yemesin).
                    put("reasoning_effort", "none")
                    put("reasoning_format", "hidden")
                }
                put("tools", buildTools(includeBuilderTools))
                put("tool_choice", if (lastTurn) "none" else "auto")
            }

            val req = Request.Builder()
                .url(CHAT_URL)
                .header("Authorization", "Bearer $apiKey")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val message = client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return Result.failure(IOException("$model → HTTP ${resp.code}: ${raw.take(700)}"))
                }
                JSONObject(raw).optJSONArray("choices")
                    ?.optJSONObject(0)
                    ?.optJSONObject("message")
            } ?: return Result.failure(IOException("$model → boş yanıt döndü"))

            val toolCalls = message.optJSONArray("tool_calls")
            val text = message.optString("content", "")

            if (toolCalls == null || toolCalls.length() == 0) {
                if (text.isBlank()) {
                    return Result.failure(IOException("$model → boş yanıt döndü"))
                }
                return Result.success(stripThinking(text))
            }

            // Modelin fonksiyon çağırma turunu sohbet geçmişine ekle
            // (OpenAI formatı: assistant mesajı tool_calls alanıyla birlikte).
            messages.put(JSONObject().apply {
                put("role", "assistant")
                put("content", if (text.isBlank()) JSONObject.NULL else text)
                put("tool_calls", toolCalls)
            })

            // Her fonksiyon çağrısını GERÇEKTEN çalıştır, sonucu "tool"
            // rolüyle geri besle.
            for (i in 0 until toolCalls.length()) {
                val call = toolCalls.optJSONObject(i) ?: continue
                val fn = call.optJSONObject("function") ?: continue
                val name = fn.optString("name")
                val argsRaw = fn.optString("arguments", "{}")
                val args = try { JSONObject(argsRaw) } catch (e: Exception) { JSONObject() }
                try { onToolUse?.invoke(name) } catch (e: Exception) { Log.w(TAG, "onToolUse", e) }
                val outcome = executeFunction(name, args)
                messages.put(JSONObject().apply {
                    put("role", "tool")
                    put("tool_call_id", call.optString("id"))
                    put("content", outcome.toString())
                })
            }

            lastText = text
        }

        if (lastText.isNotBlank()) Result.success(stripThinking(lastText))
        else Result.failure(IOException("$model → fonksiyon döngüsü tamamlanamadı"))
      } catch (e: Exception) {
        Result.failure(e)
      }
    }

    /** Bazı muhakeme modelleri cevabın başına <think>…</think> ekler; sesli okunmasın. */
    private fun stripThinking(text: String): String {
        val cleaned = text.replace(Regex("(?s)<think>.*?</think>"), "").trim()
        return cleaned.ifBlank { text.trim() }
    }

    private fun buildTools(includeBuilder: Boolean = true): JSONArray = filterTools(includeBuilder, JSONArray()
        .put(functionTool(
            name = "web_search",
            description = "İnternette (Google/DuckDuckGo/Bing benzeri) arama yapar ve sonuç başlıkları + özetleri döndürür. Güncel bilgi, haber, fiyat, skor, okul/sınav/tatil tarihleri, kişiler, ürünler, 'nedir/kimdir/ne zaman' gibi eğitim verinde olmayabilecek ya da emin olmadığın HER konuda ÖNCE bunu çağır, sonra sonuçlara dayanarak cevap ver. Kısa ve net Türkçe sorgu yaz (örn. 'MEB 2026 yaz tatili ne zaman'). Haber/gündem sorusu ise news=true yap.",
            properties = JSONObject().apply {
                put("query", JSONObject().apply {
                    put("type", "string")
                    put("description", "Arama sorgusu")
                })
                put("news", JSONObject().apply {
                    put("type", "boolean")
                    put("description", "Güncel haber araması ise true")
                })
            },
            required = listOf("query")
        ))
        .put(functionTool(
            name = "read_webpage",
            description = "web_search sonucundaki bir sayfanın (url) metnini okur. Arama özetleri cevap için yetersizse en alakalı 1 sonucun sayfasını bununla oku.",
            properties = JSONObject().apply {
                put("url", JSONObject().apply {
                    put("type", "string")
                    put("description", "web_search sonucundan alınan tam adres")
                })
            },
            required = listOf("url")
        ))
        .put(functionTool(
            name = "get_weather",
            description = "Herhangi bir şehir için anlık hava durumu ve günlük tahmin verir (yarın, hafta sonu, yağmur olur mu vb.). Şehir söylenmemişse city'yi boş bırak (kullanıcının bulunduğu yer kullanılır).",
            properties = JSONObject().apply {
                put("city", JSONObject().apply {
                    put("type", "string")
                    put("description", "Şehir adı, örn. Ankara")
                })
                put("days", JSONObject().apply {
                    put("type", "integer")
                    put("description", "Kaç günlük tahmin (1-7), varsayılan 3")
                })
            },
            required = emptyList()
        ))
        .put(functionTool(
            name = "create_file",
            description = "Kullanıcı için bir dosya oluşturup İndirilenler klasörüne kaydeder. Hem düz metin dosyaları (.txt, .md, .json, .csv, .html vb. -- content alanı) HEM DE herhangi bir ikili dosya (content_base64 alanı, örn. bir görselin/ikili verinin base64'ü) desteklenir. Kullanıcı açıkça bir not/liste/metin/dosya kaydetmeni istediğinde çağır.",
            properties = JSONObject().apply {
                put("filename", JSONObject().apply {
                    put("type", "string")
                    put("description", "Uzantılı dosya adı, örn. notlar.txt")
                })
                put("content", JSONObject().apply {
                    put("type", "string")
                    put("description", "Metin dosyası içeriği (ikili dosya için bunun yerine content_base64 kullan)")
                })
                put("content_base64", JSONObject().apply {
                    put("type", "string")
                    put("description", "İkili dosya içeriği, base64 kodlanmış (ör. bir görsel verisi)")
                })
            },
            required = listOf("filename")
        ))
        .put(functionTool(
            name = "create_zip",
            description = "Birden fazla dosyayı (metin VE/VEYA fotoğraf/ikili dosya) tek bir zip arşivinde birleştirip İndirilenler klasörüne kaydeder. Her dosya için ya 'content' (metin) ya da 'content_base64' (ikili/görsel) doldurulur. AYRICA kullanıcı senden bir OYUN veya UYGULAMA yapıp zip olarak vermeni istediğinde de bunu kullan: tam, eksiksiz ve gerçekten çalışan bir HTML5/CSS/JS oyununu tek bir 'index.html' dosyası (CSS ve JS gömülü, internetsiz çalışır) olarak 'content' alanına yaz ve bu şekilde ziple -- kullanıcı bunu kendi tarafında bir WebView aracıyla apk'ya çevirecek.",
            properties = JSONObject().apply {
                put("zip_filename", JSONObject().apply {
                    put("type", "string")
                    put("description", "Arşiv adı, .zip uzantılı ya da uzantısız")
                })
                put("files", JSONObject().apply {
                    put("type", "array")
                    put("items", JSONObject().apply {
                        put("type", "object")
                        put("properties", JSONObject().apply {
                            put("filename", JSONObject().put("type", "string"))
                            put("content", JSONObject().put("type", "string"))
                            put("content_base64", JSONObject().put("type", "string"))
                        })
                        put("required", JSONArray().put("filename"))
                    })
                })
            },
            required = listOf("zip_filename", "files")
        ))
        .put(functionTool(
            name = "create_image",
            description = "Yapay zeka ile, verilen tarif/prompt'tan YENİ bir fotoğraf/görsel/resim üretip galeriye (Resimler) kaydeder. Kullanıcı 'bana ... resmi/fotoğrafı çiz/oluştur/üret' gibi bir şey istediğinde çağır. Tarifi olabildiğince görsel ve betimleyici yaz (renkler, sahne, stil).",
            properties = JSONObject().apply {
                put("prompt", JSONObject().apply {
                    put("type", "string")
                    put("description", "Görselin ne olacağının İngilizce ya da Türkçe betimlemesi, örn. 'gün batımında deniz kenarında oturan kedi, gerçekçi stil'")
                })
                put("filename", JSONObject().apply {
                    put("type", "string")
                    put("description", "Kaydedilecek dosya adı (uzantısız da olur), örn. kedi_gunbatimi")
                })
            },
            required = listOf("prompt")
        ))
        .put(functionTool(
            name = "run_terminal_command",
            description = "Uygulamanın kendi sandbox'ında GERÇEK bir kabuk (shell) komutu çalıştırır (ls, mkdir, cat, echo, grep, find, sh script.sh vb.) ve çıktısını döndürür. Kullanıcı 'terminalde şunu çalıştır/derle/build et' gibi bir şey istediğinde çağır. NOT: cihazda root/gradle/JDK olmadığı için gerçek bir Android derlemesi yapılamaz; ama dosya/klasör işlemleri ve script çalıştırma gerçekten yapılır. Sonucu kullanıcıya kısaca özetle.",
            properties = JSONObject().apply {
                put("command", JSONObject().apply {
                    put("type", "string")
                    put("description", "Çalıştırılacak kabuk komutu, örn. 'ls -la' ya da 'echo merhaba > test.txt && cat test.txt'")
                })
            },
            required = listOf("command")
        ))
        .put(functionTool(
            name = "play_song",
            description = "Kullanıcının istediği şarkıyı çalmaya başlar: önce telefonun yerel müzik kütüphanesinde arar, yoksa YouTube'da arayıp bulduğu ses akışını YİNE arka planda, ekran değiştirmeden çalar. status=playing_local ya da status=playing_stream dönerse şarkı fiilen çalmaya başlamıştır. Sadece status=opened_youtube_search dönerse (nadir, ses akışı çözülemediği durumlar) kullanıcıya YouTube'da açtığını söyle. ÖNEMLİ: kullanıcı belirli bir şarkı adı söylemeden sadece 'çal', 'devam et', 'tekrar çal', 'yine aç' gibi bir şey derse (daha önce çalınmış bir şarkıyı yeniden başlatmak istiyorsa) query'yi BOŞ bırak -- uygulama otomatik olarak en son çalınan şarkıyı hatırlayıp tekrar başlatır, sen tekrar şarkı adı SORMA.",
            properties = JSONObject().apply {
                put("query", JSONObject().apply {
                    put("type", "string")
                    put("description", "Şarkı adı ve varsa sanatçı, örn. 'Tarkan Kuzu Kuzu'. En son çalınan şarkıyı tekrar başlatmak için boş bırakılabilir.")
                })
            },
            required = emptyList()
        ))
        .put(functionTool(
            name = "stop_song",
            description = "Şu anda arka planda çalmakta olan şarkıyı/müziği durdurur. Kullanıcı 'durdur', 'kapat', 'yeter', 'müziği kes' gibi bir şey söylediğinde ve bir şarkı çalıyorsa çağır.",
            properties = JSONObject(),
            required = emptyList()
        )))

    // Her zaman gönderilen hafif araçlar; diğerleri (dosya/zip/oyun/görsel/terminal)
    // yalnızca ilgili bir istek varsa eklenir.
    private val LIGHT_TOOLS = setOf("web_search", "read_webpage", "get_weather", "play_song", "stop_song")

    private fun filterTools(includeBuilder: Boolean, all: JSONArray): JSONArray {
        if (includeBuilder) return all
        val out = JSONArray()
        for (i in 0 until all.length()) {
            val t = all.optJSONObject(i) ?: continue
            val name = t.optJSONObject("function")?.optString("name").orEmpty()
            if (name in LIGHT_TOOLS) out.put(t)
        }
        return out
    }

    private val BUILDER_KEYWORDS = listOf(
        "kaydet", "dosya", "txt", "zip", "oyun", "uygulama", "apk", "html", "kod",
        "site", "script", "proje", "resim", "görsel", "gorsel", "fotoğraf", "çiz",
        "üret", "oluştur", "terminal", "komut", "derle", "build", "indir", "not al", "hazırla"
    )

    /** Son 2 kullanıcı mesajında dosya/oyun/görsel/terminal isteği var mı? */
    private fun needsBuilderTools(conversation: List<Pair<String, String>>, currentTurnText: String?): Boolean {
        val recent = conversation.filter { it.first == "user" }.takeLast(2).joinToString(" ") { it.second }
        val text = ((currentTurnText ?: "") + " " + recent).lowercase()
        return BUILDER_KEYWORDS.any { text.contains(it) }
    }

    private fun functionTool(
        name: String,
        description: String,
        properties: JSONObject,
        required: List<String>
    ): JSONObject = JSONObject().apply {
        put("type", "function")
        put("function", JSONObject().apply {
            put("name", name)
            put("description", description)
            put("parameters", JSONObject().apply {
                put("type", "object")
                put("properties", properties)
                put("required", JSONArray(required))
            })
        })
    }

    private fun executeFunction(name: String, args: JSONObject): JSONObject = try {
        when (name) {
            "create_file" -> {
                val filename = args.optString("filename").ifBlank { "not.txt" }
                val base64 = args.optString("content_base64")
                val saved = if (base64.isNotBlank()) {
                    FileTool.createBinaryFile(appContext, filename, Base64.decode(base64, Base64.DEFAULT))
                } else {
                    FileTool.createTextFile(appContext, filename, args.optString("content"))
                }
                JSONObject().put("status", "ok").put("path", saved.displayPath)
            }
            "create_zip" -> {
                val zipName = args.optString("zip_filename").ifBlank { "arsiv.zip" }
                val filesArr = args.optJSONArray("files") ?: JSONArray()
                val entries = mutableListOf<FileTool.ZipEntryInput>()
                for (i in 0 until filesArr.length()) {
                    val f = filesArr.optJSONObject(i) ?: continue
                    val fname = f.optString("filename", "dosya_$i.txt")
                    val base64 = f.optString("content_base64")
                    val bytes = if (base64.isNotBlank()) {
                        Base64.decode(base64, Base64.DEFAULT)
                    } else {
                        f.optString("content").toByteArray()
                    }
                    entries += FileTool.ZipEntryInput(fname, bytes)
                }
                val saved = FileTool.createZipFile(appContext, zipName, entries)
                JSONObject().put("status", "ok").put("path", saved.displayPath)
            }
            "create_image" -> {
                val prompt = args.optString("prompt")
                if (prompt.isBlank()) {
                    JSONObject().put("status", "error").put("message", "prompt boş olamaz")
                } else {
                    val bytes = runBlocking { ImageGenClient.generate(prompt) }
                    if (bytes == null) {
                        JSONObject().put("status", "error").put("message", "Görsel oluşturulamadı, ağ sorunu olabilir")
                    } else {
                        val filename = args.optString("filename").ifBlank { "jarvis_gorsel_${System.currentTimeMillis()}" }
                        val saved = FileTool.createImageFile(appContext, filename, bytes)
                        JSONObject().put("status", "ok").put("path", saved.displayPath)
                    }
                }
            }
            "run_terminal_command" -> {
                val command = args.optString("command")
                val result = runBlocking { TerminalRunner.run(appContext.filesDir, command) }
                JSONObject()
                    .put("status", "ok")
                    .put("exit_code", result.exitCode)
                    .put("timed_out", result.timedOut)
                    .put("output", result.output)
            }
            "play_song" -> {
                val query = args.optString("query")
                when (val result = MusicController.play(appContext, query)) {
                    is MusicController.PlayResult.PlayingLocal ->
                        JSONObject().put("status", "playing_local")
                            .put("title", result.title).put("artist", result.artist)
                    is MusicController.PlayResult.PlayingStream ->
                        JSONObject().put("status", "playing_stream")
                            .put("title", result.title).put("artist", result.artist)
                    is MusicController.PlayResult.OpenedYoutubeSearch ->
                        JSONObject().put("status", "opened_youtube_search").put("query", result.query)
                    is MusicController.PlayResult.PermissionMissing ->
                        JSONObject().put("status", "error").put("message", result.message)
                    is MusicController.PlayResult.Error ->
                        JSONObject().put("status", "error").put("message", result.message)
                }
            }
            "web_search" -> WebSearchClient.search(
                args.optString("query"),
                args.optBoolean("news", false)
            )
            "read_webpage" -> WebSearchClient.readPage(args.optString("url"))
            "get_weather" -> {
                val city = args.optString("city").takeIf { it.isNotBlank() && it != "null" }
                // Kullanıcı açıkça bir şehir sorduysa, ViewModel'e haber ver ki
                // sol alttaki hava durumu widget'ı o şehre göre güncellensin ve
                // bir dahaki açılışta da hatırlansın.
                if (city != null) {
                    try { onCityQueried?.invoke(city) } catch (e: Exception) { Log.w(TAG, "onCityQueried", e) }
                }
                WeatherClient.forecastFor(city, if (args.has("days")) args.optInt("days", 3) else 3)
            }
            "stop_song" -> {
                MusicController.stop(appContext)
                JSONObject().put("status", "ok")
            }
            else -> JSONObject().put("status", "error").put("message", "Bilinmeyen fonksiyon: $name")
        }
    } catch (e: Exception) {
        JSONObject().put("status", "error").put("message", e.message ?: "bilinmeyen hata")
    }
}
