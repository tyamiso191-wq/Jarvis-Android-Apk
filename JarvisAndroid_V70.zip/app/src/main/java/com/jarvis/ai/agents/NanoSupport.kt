package com.jarvis.ai.agents

import com.google.mlkit.genai.common.FeatureStatus
import com.google.mlkit.genai.prompt.Generation
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Gemini Nano'nun bu cihazdaki durumu. */
enum class NanoState { UNKNOWN, AVAILABLE, DOWNLOADABLE, DOWNLOADING, UNAVAILABLE }

/** Kullanıcıya gösterilecek bildirim metinleri (ML Kit'e bağımlı değil, JVM'de test edilebilir). */
object NanoNotice {
    /** @return AVAILABLE/UNKNOWN için null (bildirim gerekmez). */
    fun messageFor(state: NanoState): String? = when (state) {
        NanoState.UNAVAILABLE ->
            "Bu cihaz Gemini Nano'yu desteklemiyor. Tüm işler OpenRouter üzerinden yapılacak."
        NanoState.DOWNLOADABLE ->
            "Gemini Nano bu cihazda kullanılabilir ama henüz indirilmedi. Şimdilik OpenRouter kullanılıyor."
        NanoState.DOWNLOADING ->
            "Gemini Nano indiriliyor. Hazır olana kadar OpenRouter kullanılıyor."
        NanoState.AVAILABLE, NanoState.UNKNOWN -> null
    }
}

/**
 * Cihaz üstü Gemini Nano'nun kullanılabilirliğini ML Kit Prompt API ile sorgular.
 * Burada metin ÜRETİLMEZ; yalnızca durum kontrolü yapılır. Herhangi bir hata
 * (desteklenmeyen cihaz, AICore yok, Play Hizmetleri eski) UNAVAILABLE sayılır.
 */
object NanoSupport {
    suspend fun check(): NanoState = withContext(Dispatchers.IO) {
        try {
            val model = Generation.getClient()
            try {
                when (model.checkStatus()) {
                    FeatureStatus.AVAILABLE -> NanoState.AVAILABLE
                    FeatureStatus.DOWNLOADABLE -> NanoState.DOWNLOADABLE
                    FeatureStatus.DOWNLOADING -> NanoState.DOWNLOADING
                    else -> NanoState.UNAVAILABLE
                }
            } finally {
                try { model.close() } catch (_: Throwable) {}
            }
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            NanoState.UNAVAILABLE
        }
    }
}
