# J.A.R.V.I.S — Android

Koyu teal / cyan Iron Man tarzı arayüz + Groq destekli sesli sohbet.

---

## Bilgisayar olmadan APK alma (GitHub Actions)

### 1. GitHub hesabı aç
Telefondan: https://github.com → Sign up

### 2. Yeni repo oluştur
1. Sağ üstte **+** → **New repository**
2. Repository name: `JarvisAndroid` (istediğin isim)
3. **Public** seç
4. **Create repository**

### 3. Dosyaları yükle
1. Bu `JarvisAndroid` klasörünün **içindeki tüm dosyaları** GitHub’a yükle.
2. Telefondan:
   - Repoya gir → **uploading an existing file** (veya Add file)
   - Tüm dosya ve klasörleri seç (özellikle **.github** klasörü de gelsin)
   - **Commit changes**

### 4. Otomatik derleme
- **Actions** sekmesine gir
- **Build APK** işinin yeşil tik almasını bekle (3–8 dk)
- İş bitince:
  - İşin üzerine tıkla
  - En altta **Artifacts** → **Jarvis-APK** indir
  - Zip içinden `app-debug.apk` çıkar

### 5. Telefona yükle
- `app-debug.apk` dosyasını aç → Yükle
- İlk açılışta Groq API anahtarını gir (bir kere)
- Sonraki açılışlarda sormaz

---

## Groq API anahtarı (ücretsiz)

https://console.groq.com/keys
→ Create API key → kopyala → uygulamaya yapıştır

---

## Elle tekrar derlemek

GitHub → **Actions** → **Build APK** → **Run workflow**

---

## Notlar

- Model adı değişirse: `GroqTextClient.kt` içindeki `DEFAULT_CANDIDATES` listesini güncelle
- Artifact 14 gün saklanır

---

## Bu sürümde eklenenler (v23)

**Anthropic (Claude) API bağımlılığı kaldırıldı**
- v22'de oyun/uygulama kodu üretimini Groq yerine Claude API'sine yaptıran
  `create_game` fonksiyonu ve `ClaudeGameClient.kt` tamamen kaldırıldı --
  kullanıcının kendi Claude API anahtarı çok hızlı tükeniyordu (ücretli/
  kotalı).
- Claude'a verilen kalite kuralları (jenerik şablona kaçmama, placeholder
  yasağı, tam çalışan tek dosyalık HTML5 oyun, dokunmatik+klavye kontrolü
  vb.) AYNEN korunup doğrudan Groq'un `create_zip` talimatına taşındı --
  yani kalite kuralları kayıp olmadı, sadece hangi modelin uyguladığı
  değişti (artık tamamen ücretsiz Groq).
- Giriş ekranındaki (ApiKeyScreen) ikinci "Anthropic API anahtarı" alanı ve
  buna bağlı tüm saklama/aktarma kodu kaldırıldı; uygulama tekrar tek bir
  (ücretsiz Groq) API anahtarıyla çalışıyor.

---

## Bu sürümde eklenenler (v14)

**1. Fotoğraf / çoklu dosya üretimi**
- `create_file` artık her türlü dosyayı (txt, json, html… ve `content_base64`
  ile herhangi bir ikili dosyayı) İndirilenler'e kaydedebiliyor.
- `create_zip` metin + ikili dosyaları karışık olarak tek arşivde toplayabiliyor.
- Yeni `create_image` aracı: Pollinations.ai (API anahtarı gerekmez) ile
  gerçek bir AI görseli üretip galeriye kaydediyor. "Bana ... resmi çiz"
  dediğinizde çalışır.

**2. Uygulama içi terminal**
- Üst çubuktaki **⌨** ikonuna dokunarak açılan, uygulamanın kendi sandbox'ında
  (`terminal_workspace/`) gerçek bir kabuk (`sh`) çalıştıran terminal ekranı.
- Jarvis da `run_terminal_command` fonksiyonuyla aynı terminali kendisi
  kullanabiliyor ("terminalde şunu çalıştır/derle" dediğinizde).
- ÖNEMLİ SINIRLAMA: telefonda root/Gradle/JDK olmadığı için bu, gerçek bir
  Android/Gradle derlemesi (APK build) YAPAMAZ — sadece dosya/klasör
  işlemleri ve basit script'ler için gerçek bir kabuktur.

**3. Kalıcı hafıza**
- Konuşma geçmişi artık cihazda kalıcı olarak saklanıyor (uygulama kapatılıp
  açılsa bile Jarvis önceki konuşmaları hatırlıyor), tutulan tur sayısı 40'a
  çıkarıldı.
- Müzik: "çal" dedikten sonra "kapat" deyip tekrar sadece "çal" derseniz
  (şarkı adı vermeden), en son çalınan şarkı otomatik olarak hatırlanıp
  yeniden başlatılıyor — tekrar şarkı adı sormuyor.

**4. Hava durumu widget'ı**
- Sohbette açıkça bir şehrin hava durumunu sorduğunuzda (örn. "İstanbul'da
  hava nasıl"), sol alttaki widget artık IP'den tahmin edilen konum yerine
  o şehri gösteriyor ve bunu kalıcı olarak hatırlıyor.

---

## Bu sürümde eklenenler (v16)

**1. Oyun / uygulama projesi üretme (zip → apk)**
- "Bana şöyle bir korku oyunu yap, zip olarak ver" dediğinizde, Jarvis artık
  `create_zip` fonksiyonuyla **gerçekten çalışan, tek dosyalık
  (`index.html` içine gömülü CSS+JS) bir HTML5 oyunu** üretip İndirilenler'e
  zip olarak kaydediyor. Bu index.html tamamen internetsiz çalışacak şekilde
  yazılıyor (harici bağlantı yok), dokunmatik ve klavye kontrolleri birlikte
  geliyor.
- Zip'i indirdikten sonra `index.html`'i bir **WebView sarmalayıcı** aracıyla
  (Android Studio'nun boş WebView şablonu, ya da bir "web sitesini apk'ya
  çevir" aracı) kendi tarafınızda apk'ya çeviriyorsunuz — Jarvis'in kendisi
  hâlâ gerçek bir Gradle/Android derlemesi yapmıyor (telefonda buna gerek
  yok, tarayıcıda/WebView'da oynanabilir tam bir oyun üretiyor).
- Kota (429) anlarında istek düşürülmüyor: model çıktı üretirken (uzun oyun
  kodu dahil) kesilmesin diye yanıt token sınırı ve ağ zaman aşımı süreleri
  büyütüldü.

---

## Bu sürümde eklenenler (v15)

**1. Sohbete fotoğraf / dosya ekleme**
- Sohbet yazı çubuğunun solundaki **📎** tuşu: **Fotoğraf** (sistem foto
  seçicisi) ya da **Dosya** (sistem dosya seçicisi) seçtirir. Ek izni gerekmez.
- Seçilenler yazı çubuğunun üstünde küçük etiketler olarak durur (dokununca
  kaldırılır), gönder tuşuna basınca mesajla birlikte gider. Sadece ek göndermek
  de mümkün ("Bunu incele ve kısaca anlat" varsayılan istemi kullanılır).
- Fotoğraflar (ve PDF'in ilk 2 sayfası) küçültülüp Groq'un görsel destekli
  modeline (`meta-llama/llama-4-scout-17b-16e-instruct`, yedek `qwen/qwen3.6-27b`, `qwen/qwen3.8-27b`; 404 veren model otomatik atlanır) gönderilir. Bir
  mesajda en fazla 3 görsel/sayfa.
- Metin ve kod dosyaları (txt, md, json, csv, kt, py, html…) mesajın içine
  yazılır (ilk ~8000 karakter). Word/Excel gibi biçimler henüz okunamıyor.
- Geçmişe ve DataStore'a sadece kısa not yazılır ("[Ekler: kedi.jpg]");
  fotoğraf/dosya içeriği kalıcı olarak saklanmaz.

**2. Klavyeyle birlikte hareket eden yazı çubuğu**
- Klavye açılınca yazı çubuğu ekranın altına, klavyenin hemen üstüne, tam
  genişlikte çıkar; klavye kapanınca sağ sohbet panelinin altındaki küçük
  yerine geri döner. (Eskiden klavye çubuğun üstünü kapatıyordu.)
