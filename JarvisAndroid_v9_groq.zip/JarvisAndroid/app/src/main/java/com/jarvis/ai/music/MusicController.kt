package com.jarvis.ai.music

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.ContextCompat

/**
 * "Bohemian Rhapsody aç" gibi bir istek geldiğinde:
 *  1) Önce cihazın yerel müzik kütüphanesinde (MediaStore.Audio) başlık/
 *     sanatçı adına göre arar. Bulursa MusicService'i başlatıp gerçekten
 *     ARKA PLANDA çalmaya başlar — sohbet ekranından çıksa bile devam eder.
 *  2) Yerelde yoksa (dosya telefonda değilse), YouTube'da o aramayı açan
 *     bir intent'e düşer. Bu, API key/ücret gerektirmeyen tek dürüst
 *     seçenek — ama gerçek "otomatik arka plan oynatma" DEĞİL, YouTube
 *     uygulaması/tarayıcı açılır, kullanıcının ilk sonuca dokunması
 *     gerekebilir. Bunu olduğu gibi söylüyoruz, abartmıyoruz.
 */
object MusicController {

    sealed class PlayResult {
        data class PlayingLocal(val title: String, val artist: String) : PlayResult()
        data class OpenedYoutubeSearch(val query: String) : PlayResult()
        data class PermissionMissing(val message: String) : PlayResult()
        data class Error(val message: String) : PlayResult()
    }

    private fun readAudioPermission(): String =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, readAudioPermission()) == PackageManager.PERMISSION_GRANTED

    fun play(context: Context, query: String): PlayResult {
        val q = query.trim()
        if (q.isBlank()) return PlayResult.Error("Hangi şarkıyı çalacağım belirtilmedi.")

        if (hasPermission(context)) {
            val local = findLocalTrack(context, q)
            if (local != null) {
                val intent = Intent(context, MusicService::class.java).apply {
                    action = MusicService.ACTION_PLAY
                    putExtra(MusicService.EXTRA_URI, local.uri.toString())
                    putExtra(MusicService.EXTRA_TITLE, local.title)
                    putExtra(MusicService.EXTRA_ARTIST, local.artist)
                }
                ContextCompat.startForegroundService(context, intent)
                return PlayResult.PlayingLocal(local.title, local.artist)
            }
        }

        return try {
            val searchUrl = "https://www.youtube.com/results?search_query=" +
                Uri.encode(q)
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(searchUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            PlayResult.OpenedYoutubeSearch(q)
        } catch (e: Exception) {
            PlayResult.Error("Açılamadı: ${e.message}")
        }
    }

    fun stop(context: Context) {
        val intent = Intent(context, MusicService::class.java).apply {
            action = MusicService.ACTION_STOP
        }
        context.startService(intent)
    }

    private data class LocalTrack(val uri: Uri, val title: String, val artist: String)

    private fun findLocalTrack(context: Context, query: String): LocalTrack? {
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND (" +
            "${MediaStore.Audio.Media.TITLE} LIKE ? OR ${MediaStore.Audio.Media.ARTIST} LIKE ?)"
        val like = "%$query%"
        val args = arrayOf(like, like)

        context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            args,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID))
                val title = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE))
                val artist = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST))
                val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                return LocalTrack(uri, title ?: query, artist ?: "")
            }
        }
        return null
    }
}
