package com.jarvis.ai.files

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * JARVIS'in kullanıcı için gerçek dosya (txt, herhangi bir düz metin, zip,
 * fotoğraf/görsel dahil herhangi bir ikili dosya) oluşturabilmesini sağlar.
 *
 * DAVRANIŞ (kullanıcı isteğiyle değiştirildi): oluşturulan dosyalar artık
 * doğrudan telefonun İndirilenler/Resimler klasörüne YAZILMIYOR -- Claude'un
 * kendi arayüzündeki gibi önce SOHBETE bir ek olarak düşüyor (stageXxx
 * fonksiyonları, uygulamanın kendi önbellek klasörüne yazıp bir
 * content:// Uri döner), kullanıcı beğenirse "Kaydet" düğmesine basıp
 * GERÇEKTEN cihaza indiriyor (persistStagedFile, o zaman MediaStore'a yazar).
 * Eski createXxx fonksiyonları (doğrudan MediaStore'a yazan) persistStagedFile
 * tarafından İÇTEN kullanılıyor, dışarıdan artık çağrılmıyor.
 */
object FileTool {

    data class SavedFile(val displayPath: String, val savedToDownloads: Boolean)

    /** Sohbete eklenen, henüz cihaza KAYDEDİLMEMİŞ bir dosya. */
    data class StagedFile(val uri: Uri, val filename: String, val mimeType: String, val isImage: Boolean)

    /** Zip içine eklenecek tek bir girdi: metin ya da ikili (fotoğraf vb.) veri. */
    data class ZipEntryInput(val filename: String, val bytes: ByteArray)

    private fun cacheDir(context: Context): File =
        File(context.cacheDir, "chat_attachments").apply { mkdirs() }

    private fun uriFor(context: Context, file: File): Uri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

    /** Herhangi bir metin/ikili dosyayı sohbete EK olarak hazırlar (henüz cihaza kaydetmez). */
    fun stageFile(context: Context, filename: String, bytes: ByteArray, mimeType: String = guessMimeType(filename)): StagedFile {
        val safeName = sanitize(filename)
        val file = File(cacheDir(context), "${System.currentTimeMillis()}_$safeName")
        FileOutputStream(file).use { it.write(bytes) }
        return StagedFile(uriFor(context, file), safeName, mimeType, isImage = mimeType.startsWith("image/"))
    }

    fun stageTextFile(context: Context, filename: String, content: String, mimeType: String = "text/plain"): StagedFile =
        stageFile(context, filename, content.toByteArray(), mimeType)

    fun stageImageFile(context: Context, filename: String, bytes: ByteArray, mimeType: String = "image/png"): StagedFile {
        val safeName = sanitize(filename, forceExt = if (mimeType.contains("jpeg")) "jpg" else "png")
        return stageFile(context, safeName, bytes, mimeType)
    }

    fun stageZipFile(context: Context, zipFilename: String, entries: List<ZipEntryInput>): StagedFile {
        val safeName = sanitize(zipFilename, forceExt = "zip")
        val file = File(cacheDir(context), "${System.currentTimeMillis()}_$safeName")
        FileOutputStream(file).use { out -> writeZip(out, entries) }
        return StagedFile(uriFor(context, file), safeName, "application/zip", isImage = false)
    }

    /**
     * Kullanıcı sohbetteki "Kaydet" düğmesine bastığında çağrılır: önbellekteki
     * ek dosyayı okuyup GERÇEKTEN cihaza (İndirilenler ya da görselse
     * Resimler) yazar.
     */
    fun persistStagedFile(context: Context, staged: StagedFile): SavedFile {
        val bytes = context.contentResolver.openInputStream(staged.uri)?.use { it.readBytes() }
            ?: throw IOException("Ek dosya artık okunamıyor")
        return if (staged.isImage) {
            createImageFile(context, staged.filename, bytes, staged.mimeType)
        } else {
            createBinaryFile(context, staged.filename, bytes, staged.mimeType)
        }
    }

    fun createTextFile(
        context: Context,
        filename: String,
        content: String,
        mimeType: String = "text/plain"
    ): SavedFile = createBinaryFile(context, filename, content.toByteArray(), mimeType)

    /**
     * Herhangi bir ikili dosyayı (görsel, ses, arşiv, doküman -- her türlü
     * uzantı) İndirilenler klasörüne kaydeder. AI'nin "birçok dosya türü"
     * oluşturabilmesinin temel yapı taşı; create_file, create_zip ve
     * create_image bunun üzerine kurulu.
     */
    fun createBinaryFile(
        context: Context,
        filename: String,
        bytes: ByteArray,
        mimeType: String = guessMimeType(filename)
    ): SavedFile {
        val safeName = sanitize(filename)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Dosya oluşturulamadı (MediaStore reddetti)")
            resolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: throw IOException("Dosyaya yazılamadı")
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            SavedFile("İndirilenler/$safeName", true)
        } else {
            val file = File(context.filesDir, safeName)
            FileOutputStream(file).use { it.write(bytes) }
            SavedFile(file.absolutePath, false)
        }
    }

    /**
     * AI tarafından üretilen (ya da indirilen) bir fotoğrafı/görseli, galeride
     * görünecek şekilde MediaStore.Images (Pictures) koleksiyonuna kaydeder.
     */
    fun createImageFile(
        context: Context,
        filename: String,
        bytes: ByteArray,
        mimeType: String = "image/png"
    ): SavedFile {
        val safeName = sanitize(filename, forceExt = if (mimeType.contains("jpeg")) "jpg" else "png")
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, safeName)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Görsel oluşturulamadı (MediaStore reddetti)")
            resolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: throw IOException("Görsele yazılamadı")
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            SavedFile("Resimler/$safeName", true)
        } else {
            val file = File(context.filesDir, safeName)
            FileOutputStream(file).use { it.write(bytes) }
            SavedFile(file.absolutePath, false)
        }
    }

    fun createZipFile(
        context: Context,
        zipFilename: String,
        entries: List<ZipEntryInput>
    ): SavedFile {
        val safeName = sanitize(zipFilename, forceExt = "zip")
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Zip oluşturulamadı (MediaStore reddetti)")
            resolver.openOutputStream(uri)?.use { out -> writeZip(out, entries) }
                ?: throw IOException("Zip'e yazılamadı")
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            SavedFile("İndirilenler/$safeName", true)
        } else {
            val file = File(context.filesDir, safeName)
            FileOutputStream(file).use { out -> writeZip(out, entries) }
            SavedFile(file.absolutePath, false)
        }
    }

    private fun writeZip(out: java.io.OutputStream, entries: List<ZipEntryInput>) {
        ZipOutputStream(out).use { zos ->
            entries.forEach { entry ->
                zos.putNextEntry(ZipEntry(sanitize(entry.filename)))
                zos.write(entry.bytes)
                zos.closeEntry()
            }
        }
    }

    private fun guessMimeType(filename: String): String {
        val ext = filename.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "json" -> "application/json"
            "csv" -> "text/csv"
            "md" -> "text/markdown"
            "pdf" -> "application/pdf"
            "zip" -> "application/zip"
            "xml" -> "text/xml"
            "html", "htm" -> "text/html"
            else -> "text/plain"
        }
    }

    private fun sanitize(name: String, forceExt: String? = null): String {
        var n = name.trim().ifBlank { "jarvis_dosya" }
        n = n.replace(Regex("[/\\\\:*?\"<>|]"), "_")
        if (forceExt != null && !n.endsWith(".$forceExt", ignoreCase = true)) {
            n = "$n.$forceExt"
        }
        return n
    }
}
