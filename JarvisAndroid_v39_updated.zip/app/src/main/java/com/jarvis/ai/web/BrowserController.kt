package com.jarvis.ai.web

import android.webkit.WebView
import java.lang.ref.WeakReference

/**
 * Windows Jarvis V3'teki browser_control aracının "open_url"/"search"
 * kısmı Android'de zaten open_website/watch_video ile karşılanıyor (üstelik
 * Android'de site UYGULAMA İÇİNDE, gezinilebilir bir mini pencerede açılıyor
 * -- Windows'ta sadece harici tarayıcı açılıyordu, bu yüzden Android
 * tarafı zaten daha güçlü). Burada eklenen, GERÇEKTEN eksik olan kısım:
 * o AÇIK OLAN mini tarayıcıyı sesli komutla geri/ileri götürme ve
 * yenileme -- Windows'un browser_control'ünde bile olmayan bir yetenek.
 *
 * WeakReference kullanılıyor ki Compose bu WebView'i attach/detach ettikçe
 * (mini pencere kapanıp açıldıkça) bellek sızıntısı olmasın.
 */
object BrowserController {
    @Volatile private var webViewRef: WeakReference<WebView>? = null

    /** MainScreen'deki SiteWebView composable'ı, WebView oluşturulduğunda çağırır. */
    fun attach(webView: WebView) {
        webViewRef = WeakReference(webView)
    }

    /** Mini pencere kapandığında (SiteWebView Compose'dan kaldırıldığında) çağrılır. */
    fun detach(webView: WebView) {
        if (webViewRef?.get() === webView) webViewRef = null
    }

    enum class Result { OK, NO_ACTIVE_BROWSER, NOT_POSSIBLE }

    fun goBack(): Result {
        val wv = webViewRef?.get() ?: return Result.NO_ACTIVE_BROWSER
        if (!wv.canGoBack()) return Result.NOT_POSSIBLE
        wv.post { wv.goBack() }
        return Result.OK
    }

    fun goForward(): Result {
        val wv = webViewRef?.get() ?: return Result.NO_ACTIVE_BROWSER
        if (!wv.canGoForward()) return Result.NOT_POSSIBLE
        wv.post { wv.goForward() }
        return Result.OK
    }

    fun reload(): Result {
        val wv = webViewRef?.get() ?: return Result.NO_ACTIVE_BROWSER
        wv.post { wv.reload() }
        return Result.OK
    }
}
