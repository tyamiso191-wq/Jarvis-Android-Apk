package com.jarvis.ai.live

import android.content.Context
import android.util.Base64
import android.util.Log
import com.jarvis.ai.calendar.CalendarTool
import com.jarvis.ai.files.FileTool
import com.jarvis.ai.image.ImageGenClient
import com.jarvis.ai.memory.MemoryStore
import com.jarvis.ai.music.MusicController
import com.jarvis.ai.reminders.ReminderStore
import com.jarvis.ai.terminal.TerminalRunner
import com.jarvis.ai.video.VideoSearchController
import com.jarvis.ai.vision.VisionAnalyzer
import com.jarvis.ai.phonecontrol.PhoneControlTool
import com.jarvis.ai.social.SocialMessagingTool
import com.jarvis.ai.web.BrowserController
import com.jarvis.ai.youtube.YouTubeStatsTool
import com.jarvis.ai.sysinfo.SysInfoTool
import com.jarvis.ai.wakeword.WakeWordService
import com.jarvis.ai.weather.WeatherClient
import com.jarvis.ai.web.WebSearchClient
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Google Gemini'nin OpenAI-uyumlu Chat Completions katmanı
 * (https://generativelanguage.googleapis.com/v1beta/openai/) ile konuşur.
 * Tek bir Gemini API anahtarı kullanılır (Google AI Studio'dan alınan
 * "AIza..." ile başlayan anahtar) -- ayrı bir Groq anahtarına veya yedek
 * mekanizmasına gerek yok.
 *
 * NEDEN OpenAI-UYUMLU KATMAN: Gemini'nin kendi native REST formatı
 * (generateContent, functionDeclarations vb.) yerine bu katman kullanılıyor
 * çünkü mesaj geçmişi, fonksiyon/araç tanımları ve tool-call döngüsü
 * standart OpenAI "messages" + "tools" şemasıyla yazıldı; Gemini bu şemayı
 * BİREBİR aynı şekilde kabul ediyor, sadece url + model adı + anahtar
 * değişiyor. Böylece callModel()'in mesaj/araç mantığı hiç değişmeden çalışır.
 *
 * KOTA: Gemini'nin ücretsiz tier'ında dakikalık/günlük istek sınırı var.
 * 429 alındığında görev YARIM BIRAKILMAZ -- model 1 dakika sonra sessizce
 * tekrar denenir, kota açılınca otomatik devam edilir (bkz. sendMessage).
 *
 * WEB ARAMASI: Gemini'nin bu katmanı kullanıcı tanımlı fonksiyonları
 * desteklediği için arama kendi fonksiyonlarımız olarak (web_search /
 * read_webpage / get_weather) uygulamada çalışıyor: model önce bu
 * fonksiyonları çağırıp araştırıyor, sonuçları görüp öyle cevap veriyor.
 * Böylece hem dosya/müzik fonksiyonları hem canlı araştırma bir arada
 * çalışıyor.
 */
class GeminiTextClient(
    private val apiKey: String,
    private val persona: String,
    private val appContext: Context
) {
    companion object {
        private const val TAG = "GeminiTextClient"

        // Gemini'nin OpenAI-uyumlu chat completions uç noktası. Sohbet,
        // fonksiyon çağırma VE fotoğraf/PDF ekli mesajların HEPSİ buradan
        // geçer (Flash modelleri görsel girişi de destekler, ayrı bir
        // "vision" endpoint'i yok).
        private const val CHAT_URL = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"

        // Anahtarın geçerliliğini doğrulamak için Gemini'nin NATIVE model
        // listesi uç noktası kullanılıyor (OpenAI-uyumlu /openai/models ucu
        // Google tarafında zaman zaman 501/401 dönebiliyor, native uç daha
        // güvenilir). Bu uç Authorization header değil ?key= query param'ı
        // bekliyor.
        private const val MODELS_URL = "https://generativelanguage.googleapis.com/v1beta/models"

        // NOT: model adı değişirse (Google yeni bir sürüm çıkarırsa) burayı
        // güncelle -- ai.google.dev/gemini-api/docs/models içinde güncel
        // liste var. Flash modelleri hem metin hem görsel destekler, bu
        // yüzden hem normal sohbet hem fotoğraflı mesajlarda aynı liste
        // kullanılıyor.
        // NOT (2026-09 güncellemesi): gemini-2.0-flash zaten kapatıldı,
        // gemini-2.5-flash-lite yeni kullanıcılara HTTP 404 dönmeye başladı
        // ("no longer available to new users"). Google modelleri sık
        // değiştiriyor -- burada hata alırsan ai.google.dev/gemini-api/docs/models
        // sayfasından GÜNCEL model adını buradaki listeye ekle/değiştir.
        private val CANDIDATES = listOf(
            "gemini-3.5-flash",
            "gemini-3.5-flash-lite"
        )

        // HTTP 429 alan bir model bu süre boyunca tekrar denenmez. Gemini'nin
        // ücretsiz tier'ında dakikalık kota genelde ~1 dakikada yenileniyor.
        private const val COOLDOWN_MS = 60_000L

        // Bir sendMessage() çağrısında en fazla bu kadar farklı model denenir.
        private const val MAX_ATTEMPTS_PER_MESSAGE = 5

        // Art arda bu kadar model 429 döndürürse hesabın genel limiti (o an)
        // dolmuş demektir -- kullanıcıya HATA gösterip vazgeçmek yerine kotanın
        // yenilenmesini SESSİZCE bekleyip otomatik devam ediyoruz.
        private const val MAX_CONSECUTIVE_429 = 5

        // ÖNEMLİ (kullanıcı isteği): kota dolduğunda görev ASLA yarım
        // bırakılıp hata gösterilmesin -- her 1 dakikada bir sessizce
        // kontrol edilip kota açılır açılmaz otomatik devam edilsin. Bu
        // yüzden bekleme turu için bir üst sınır YOK (Int.MAX_VALUE):
        // TPD/RPD (günlük) kota olsa bile uygulama pes etmeden 1 dakikada
        // bir yoklamaya devam eder, ta ki kota yenilenip istek geçene kadar.
        // Kullanıcı isterse "DURDUR" butonuyla bu bekleyişi istediği an
        // kesebilir (chatJob iptal edilir).
        private const val MAX_WAIT_ROUNDS = Int.MAX_VALUE
        private const val DAILY_COOLDOWN_MS = 4 * 60 * 60 * 1000L // 4 saat

        // Başarısız denemeler arasında küçük bir bekleme (rate-limit
        // burst'ünü tetiklememek için).
        private const val ATTEMPT_DELAY_MS = 400L

        // Araştırma (arama + sayfa okuma + cevap) birkaç tur sürebilir.
        private const val MAX_TOOL_TURNS = 7

        // Modele gönderilen en fazla mesaj sayısı (token tasarrufu).
        private const val MAX_HISTORY_SENT = 16

        private const val PREFS_NAME = "gemini_text_client_cache"
        private const val PREF_WORKING_MODEL = "working_model"
    }

    /** Araç çalışırken arayüzün durum yazısını güncellemesi için (örn. "ARAŞTIRIYOR"). */
    @Volatile var onToolUse: ((String) -> Unit)? = null

    /**
     * En az bir model 429 (kota dolu) döndürdüğünde tetiklenir; kullanıcıya
     * HATA olarak DEĞİL, ViewModel isterse "BEKLENİYOR" gibi nötr bir durum
     * göstermesi için bilgi amaçlı çağrılır. Hiçbir şey bağlanmazsa (null
     * kalırsa) sessizce beklenir, kullanıcıya hiçbir uyarı gösterilmez.
     * reason: Gemini'nin döndürdüğü GERÇEK hata metni (hangi model, hangi
     * kota türü, varsa limit/kalan sayıları) -- ViewModel bunu log'a da
     * yazarak kullanıcının "gerçekten dolu mu yoksa yanlış mı algılandı"
     * diye şüphelenmeden kendi gözüyle görebilmesini sağlar.
     */
    @Volatile var onQuotaWait: ((waitMs: Long, reason: String) -> Unit)? = null

    /**
     * Kullanıcı get_weather ile AÇIKÇA bir şehir sorduğunda (city boş değilse)
     * tetiklenir. ViewModel bunu dinleyip sol alttaki hava durumu widget'ını o
     * şehre göre günceller ve bir dahaki açılışta da hatırlansın diye kaydeder.
     */
    @Volatile var onCityQueried: ((String) -> Unit)? = null

    /**
     * Kullanıcı watch_video ile bir film/dizi/video istediğinde ve YouTube'da
     * bir sonuç bulunduğunda tetiklenir (videoId, başlık). ViewModel bunu
     * dinleyip sol üstte küçük bir oynatıcı açar; kullanıcı ona dokunup
     * büyütme tuşuyla tam ekran izleyebilir.
     */
    @Volatile var onWatchVideo: ((videoId: String, title: String) -> Unit)? = null

    /**
     * Kullanıcı open_website ile herhangi bir site açmanı istediğinde ve bir
     * url verildiğinde tetiklenir (url, başlık). ViewModel bunu dinleyip sol
     * üstte aynı mini pencerede (video ile aynı yerde) o siteyi açar.
     */
    @Volatile var onOpenSite: ((url: String, title: String) -> Unit)? = null

    /** Kullanıcı stop_video/close_website ile açık mini pencereyi kapatmak istediğinde tetiklenir. */
    @Volatile var onCloseWindow: (() -> Unit)? = null

    /**
     * analyze_webcam çağrıldığında tetiklenir: Activity/UI tarafında
     * kameradan (varsayılan ön kamera) tek bir JPEG kare yakalayıp döner.
     * İzin yoksa/başarısızsa null döner, fonksiyon kullanıcıya uygun bir
     * hata mesajı üretir.
     */
    @Volatile var onCaptureWebcam: (suspend () -> ByteArray?)? = null

    /**
     * analyze_screen çağrıldığında tetiklenir: MediaProjection izni
     * uygulama açılışında zaten alınmışsa mevcut ekranın bir JPEG kaydını
     * döner. İzin yoksa/başarısızsa null döner.
     */
    @Volatile var onCaptureScreen: (suspend () -> ByteArray?)? = null

    /**
     * YouTube kanal raporu (get_youtube_channel_report) için AYRI bir
     * anahtar -- Gemini anahtarıyla otomatik gelmez, kullanıcının Google
     * Cloud Console'dan "YouTube Data API v3"ü etkinleştirip girmesi
     * gerekir. Kullanıcı sohbet içinde "youtube api anahtarım şu: ..."
     * derse save_youtube_api_key aracıyla kaydedilir.
     */
    @Volatile var youtubeApiKey: String = ""
    @Volatile var onSaveYoutubeApiKey: ((String) -> Unit)? = null

    /**
     * create_file/create_zip/create_image artık dosyayı doğrudan cihaza
     * kaydetmiyor -- önce sohbete bir EK olarak düşüyor (Claude'daki gibi),
     * kullanıcı "Kaydet"e basınca gerçekten indiriliyor. Bu callback, yeni
     * bir ek hazır olduğunda (dosya cache'e yazıldığında) tetiklenir; UI
     * tarafı (JarvisViewModel) bunu dinleyip sohbete bir ek balonu ekler.
     */
    @Volatile var onFileReady: ((FileTool.StagedFile) -> Unit)? = null

    /** set_wakeword_listening aracı çağrıldığında UI'daki 🎙 simgesini senkron tutmak için. */
    @Volatile var onWakeWordChanged: ((Boolean) -> Unit)? = null

    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        // max_tokens 8000'e çıkarıldığı için (bkz. callModel), büyük bir
        // oyun/uygulama kodu üretimi eski 45sn'lik sınırı zorlayabilirdi;
        // burada da pay bırakıldı.
        .readTimeout(90, TimeUnit.SECONDS)
        .callTimeout(100, TimeUnit.SECONDS)
        .build()

    // Süreç boyunca (ve SharedPreferences sayesinde uygulama yeniden
    // başlasa bile) hatırlanan, en son başarılı olan model.
    @Volatile private var workingModel: String? = prefs.getString(PREF_WORKING_MODEL, null)

    // HTTP 429 alınan modeller burada, tekrar denenebilecekleri zaman
    // damgasıyla tutulur.
    private val modelCooldownUntil = ConcurrentHashMap<String, Long>()

    // HTTP 404 / "model_not_found" alan modeller: bu hesapta yok veya erişim
    // yok. Kota değil, kalıcı sorun -- oturum boyunca tekrar denenmez ki 3
    // deneme hakkından biri boşa gitmesin.
    private val unavailableModels = ConcurrentHashMap.newKeySet<String>()

    private fun isModelUnavailableError(message: String?): Boolean {
        if (message.isNullOrBlank()) return false
        val lower = message.lowercase()
        return lower.contains("http 404") || lower.contains("model_not_found") ||
            lower.contains("does not exist or you do not have access")
    }

    private fun isOnCooldown(model: String): Boolean {
        val until = modelCooldownUntil[model] ?: return false
        return System.currentTimeMillis() < until
    }

    private fun markCooldown(model: String, durationMs: Long = COOLDOWN_MS) {
        modelCooldownUntil[model] = System.currentTimeMillis() + durationMs
    }

    /**
     * Gemini'nin 429 gövdesinde "PerDay" / "per day" geçiyorsa bu GÜNLÜK bir
     * kota hatasıdır, dakikalık değil. Kullanıcı isteği üzerine bu durumda
     * bile pes edilmiyor -- sadece log/durum mesajında ayırt edebilmek için
     * tutuluyor; bekleme/deneme davranışı ikisinde de aynı: her 1 dakikada
     * bir sessizce yeniden denenir.
     */
    private fun isDailyQuotaError(message: String?): Boolean {
        if (message.isNullOrBlank()) return false
        val lower = message.lowercase()
        return lower.contains("perday") || lower.contains("per day") || lower.contains("daily")
    }

    /**
     * Gemini'nin 429 gövdesinden okunabilir kısa bir özet çıkarır. Google'ın
     * kota hata metni Groq'unkinden farklı biçimlerde gelebildiği (bazen
     * düz "RESOURCE_EXHAUSTED", bazen retryDelay saniyesiyle) için burada
     * TAHMİN YÜRÜTÜLMEZ -- ham hata gövdesi (kısaltılmış) doğrudan gösterilir,
     * varsa "retryDelay" saniyesi ayrıca çıkarılır.
     */
    private fun summarizeQuota(err: String): String {
        val model = err.substringBefore(" →").trim()
        val retry = Regex("retryDelay\"?\\s*:\\s*\"?([0-9]+)s").find(err)?.groupValues?.get(1)
        return buildString {
            append(model).append(": kota/limit hatası")
            if (retry != null) append(" — tekrar dene: ${retry}sn")
        }
    }

    private fun persistWorkingModel(model: String) {
        prefs.edit().putString(PREF_WORKING_MODEL, model).apply()
    }

    /** Basit bir GET ile key'in geçerli olup olmadığını hızlıca doğrular. */
    suspend fun verifyKey(): String? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("$MODELS_URL?key=$apiKey")
                .build()
            client.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    null
                } else {
                    val body = try { resp.body?.string()?.take(300) } catch (e: Exception) { null }
                    "API anahtarı kontrolü başarısız: HTTP ${resp.code}${if (!body.isNullOrBlank()) " — $body" else ""}"
                }
            }
        } catch (e: Exception) {
            "Ağa ulaşılamıyor (${e.javaClass.simpleName}: ${e.message}). İnternet bağlantını kontrol et."
        }
    }

    /**
     * conversation: sırayla ("user", metin) / ("model", metin) geçmişi
     * (ViewModel Gemini konvansiyonunu koruyor, burada "model" -> "assistant"
     * olarak çevriliyor).
     */
    suspend fun sendMessage(
        conversation: List<Pair<String, String>>,
        deviceContext: String = "",
        // Bu turda kullanıcının mesajının modele giden TAM hali (ek dosya
        // içerikleri dahil). Geçmişe sadece kısa hali yazıldığı için burada ayrı
        // veriliyor. null ise geçmişteki son mesaj olduğu gibi gider.
        currentTurnText: String? = null,
        // Bu turda eklenen fotoğraflar / PDF sayfaları ("data:image/jpeg;base64,...").
        images: List<String> = emptyList()
    ): Result<String> =
        withContext(Dispatchers.IO) {
            // TOKEN TASARRUFU: her istekte ~5.500 token gidiyordu ("selam" bile).
            // Dosya/oyun/zip/görsel/terminal ile ilgili uzun talimatlar ve araç
            // tanımları SADECE son mesajlarda bununla ilgili bir istek varsa
            // gönderilir. Geçmiş de son 16 mesajla sınırlı (kalıcı geçmiş
            // yine 80 mesaj saklanır, sadece modele giden kısım kısaltılır).
            val needsBuilder = needsBuilderTools(conversation, currentTurnText)
            val activePersona = if (needsBuilder) {
                persona.replace("@@B@@", "").replace("@@/B@@", "")
            } else {
                persona.replace(Regex("(?s)@@B@@.*?@@/B@@"), "")
            }
            val fullInstruction = if (deviceContext.isBlank()) activePersona else "$activePersona\n\n$deviceContext"
            val trimmedConversation = conversation.takeLast(MAX_HISTORY_SENT)

            var waitRound = 0
            waitLoop@ while (true) {
                val rawOrder = workingModel?.let { pref ->
                    listOf(pref) + CANDIDATES.filterNot { it == pref }
                } ?: CANDIDATES
                // Erişilemeyen (404) modeller elenir; hepsi elenirse liste sıfırlanır.
                val baseOrder = rawOrder.filterNot { it in unavailableModels }
                    .ifEmpty { unavailableModels.clear(); rawOrder }

                val order = baseOrder
                    .sortedBy { if (isOnCooldown(it)) 1 else 0 }
                    .take(MAX_ATTEMPTS_PER_MESSAGE)

                var lastError: String? = null
                // Ekranda/log'da SADECE gerçek 429 (kota) hatası gösterilir;
                // 404 gibi alakasız hatalar buraya karışmaz.
                var lastQuotaError: String? = null
                val quotaSummaries = mutableListOf<String>()
                val otherErrors = mutableListOf<String>()
                var consecutive429 = 0
                var attempted429Models = 0
                for (model in order) {
                    val result = callModel(model, trimmedConversation, fullInstruction, currentTurnText, images, needsBuilder)
                    if (result.isSuccess) {
                        // Görsel turunda çalışan vision modelini "varsayılan" yapma:
                        // sonraki düz metin sohbetleri yine normal sırayla denensin.
                        if (images.isEmpty()) {
                            workingModel = model
                            persistWorkingModel(model)
                        }
                        return@withContext result
                    }
                    lastError = result.exceptionOrNull()?.message
                    if (isModelUnavailableError(lastError)) {
                        unavailableModels.add(model)
                        if (workingModel == model) {
                            workingModel = null
                            prefs.edit().remove(PREF_WORKING_MODEL).apply()
                        }
                        Log.w(TAG, "$model → bu hesapta erişilemiyor (404), bir daha denenmeyecek.")
                    } else if (lastError?.contains("HTTP 429") == true) {
                        lastQuotaError = lastError
                        quotaSummaries.add(summarizeQuota(lastError!!))
                        // Kullanıcı isteği: kota günlük (TPD/RPD) bile olsa asla
                        // pes edilmesin -- her model 1 dakika (COOLDOWN_MS)
                        // sonra tekrar denenmek üzere işaretlenir, sadece
                        // log'da günlük/dakikalık ayrımı belirtilir.
                        if (isDailyQuotaError(lastError)) {
                            Log.i(TAG, "$model → günlük (TPD/RPD) kota dolu, yine de 1dk sonra tekrar denenecek.")
                        }
                        markCooldown(model, COOLDOWN_MS)
                        consecutive429++
                        attempted429Models++
                        if (consecutive429 >= MAX_CONSECUTIVE_429) {
                            Log.w(TAG, "Art arda $consecutive429 model 429 döndürdü — bu turda deneme durduruldu.")
                            break
                        }
                    } else {
                        consecutive429 = 0
                        otherErrors.add(lastError.orEmpty().take(140))
                    }
                    if (result.isFailure) delay(ATTEMPT_DELAY_MS)
                    Log.w(TAG, "Model başarısız, sıradaki deneniyor: $model → $lastError")
                }

                // Kota (429) durumunda GÖREV ASLA yarım bırakılmıyor: denenen
                // modellerin HEPSİNİN 429 vermesini beklemek yerine (bazen
                // aradaki bir model farklı bir geçici hatayla -- boş yanıt,
                // zaman aşımı vb. -- başarısız olup bu şartı bozabiliyordu ve
                // asıl kota hatası ekrana "Cevap alınamadı" diye düşüyordu),
                // bu turda EN AZ BİR model 429 verdiyse yine de kota meselesi
                // sayılır: kullanıcıya hata GÖSTERİLMEZ, 1 dakika (COOLDOWN_MS)
                // sonra sessizce yeniden denenir, kota açılınca otomatik devam
                // edilir. Sadece hiçbir model 429 vermediyse (401 geçersiz key,
                // gerçek bir ağ/parse hatası vb.) hemen hata ile dönülür.
                if (attempted429Models > 0) {
                    waitRound++
                    if (waitRound > MAX_WAIT_ROUNDS) {
                        // Pratikte asla ulaşılmaz (MAX_WAIT_ROUNDS = Int.MAX_VALUE),
                        // sadece tip güvenliği için bırakıldı.
                        return@withContext Result.failure(IOException(lastError ?: "Bilinmeyen hata"))
                    }
                    val waitMs = order.mapNotNull { modelCooldownUntil[it] }
                        .minOrNull()
                        ?.let { (it - System.currentTimeMillis()).coerceAtLeast(1_000L) }
                        ?: COOLDOWN_MS
                    Log.i(TAG, "Kota dolu, görev yarım bırakılmıyor — ${waitMs}ms sonra sessizce yeniden denenecek (tur $waitRound).")
                    try { onQuotaWait?.invoke(waitMs, (if (quotaSummaries.isNotEmpty()) quotaSummaries.joinToString(" | ") else (lastQuotaError ?: "bilinmeyen sebep")) +
                        (if (otherErrors.isNotEmpty()) " || DİĞER HATALAR: " + otherErrors.joinToString(" | ") else "")) } catch (e: Exception) { Log.w(TAG, "onQuotaWait", e) }
                    delay(waitMs)
                    continue@waitLoop
                }

                return@withContext Result.failure(IOException(lastError ?: "Bilinmeyen hata"))
            }
            @Suppress("UNREACHABLE_CODE")
            Result.failure(IOException("Bilinmeyen hata"))
        }

    // Gemini'nin TPM (dakikalık token) hesabında istenen max_tokens de
    // sayıldığı için normal sohbette düşük tutulur; sadece kod/oyun/zip
    // üretimi istenince yükseltilir.
    private fun maxTokensFor(conversation: List<Pair<String, String>>, currentTurnText: String?): Int {
        val last = (currentTurnText ?: conversation.lastOrNull { it.first == "user" }?.second ?: "").lowercase()
        val big = listOf("oyun", "zip", "uygulama", "kod", "html", "site", "script", "program", "proje")
        return if (big.any { last.contains(it) }) 8000 else 2000
    }

    private fun callModel(
        model: String,
        conversation: List<Pair<String, String>>,
        systemInstruction: String,
        currentTurnText: String? = null,
        images: List<String> = emptyList(),
        includeBuilderTools: Boolean = true
    ): Result<String> {
      return try {
        // OpenAI-uyumlu "messages" dizisi: sistem mesajı + geçmiş.
        val messages = JSONArray().apply {
            put(JSONObject().apply {
                put("role", "system")
                put("content", systemInstruction)
            })
            conversation.forEachIndexed { index, (role, text) ->
                val isCurrentUserTurn = index == conversation.lastIndex && role == "user" &&
                    (images.isNotEmpty() || currentTurnText != null)
                put(JSONObject().apply {
                    put("role", if (role == "model") "assistant" else "user")
                    if (!isCurrentUserTurn) {
                        put("content", text)
                    } else if (images.isEmpty()) {
                        put("content", currentTurnText ?: text)
                    } else {
                        // OpenAI-uyumlu çok parçalı içerik: metin + görseller.
                        put("content", JSONArray().apply {
                            put(JSONObject().put("type", "text").put("text", currentTurnText ?: text))
                            images.forEach { url ->
                                put(
                                    JSONObject()
                                        .put("type", "image_url")
                                        .put("image_url", JSONObject().put("url", url))
                                )
                            }
                        })
                    }
                })
            }
        }

        var lastText = ""
        for (turn in 0 until MAX_TOOL_TURNS) {
            // Son turda tool_choice=none: model artık elindekiyle cevap vermek zorunda.
            val lastTurn = turn == MAX_TOOL_TURNS - 1
            val body = JSONObject().apply {
                put("model", model)
                put("messages", messages)
                put("temperature", 0.7)
                // gpt-oss gibi muhakeme yapan modellerde düşünme token'ları da
                // bu sınıra dahil; 400 çok azdı ve cevap boş kalabiliyordu.
                // NOT: create_zip ile tam bir oyun/uygulama (index.html içine
                // gömülü CSS+JS) üretilirken bu tool-call çağrısının
                // "arguments" alanı da bu sınıra dahil oluyor -- 1500 gibi
                // düşük bir değer kodu ortasında keserdi ve bozuk/parçalanmış
                // bir zip çıkardı. Sesli, kısa sohbet cevapları modelin
                // kendisi zaten kısa tutuyor (persona'daki "kısa cevap ver"
                // kuralı); bu sadece bir ÜST SINIR, büyütmek kısa cevapları
                // uzatmaz ama uzun bir oyun kodunun tam çıkmasını sağlar.
                put("max_tokens", maxTokensFor(conversation, currentTurnText))
                put("tools", buildTools(includeBuilderTools))
                put("tool_choice", if (lastTurn) "none" else "auto")
            }

            val req = Request.Builder()
                .url(CHAT_URL)
                .header("Authorization", "Bearer $apiKey")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val message = client.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return Result.failure(IOException("$model → HTTP ${resp.code}: ${raw.take(700)}"))
                }
                JSONObject(raw).optJSONArray("choices")
                    ?.optJSONObject(0)
                    ?.optJSONObject("message")
            } ?: return Result.failure(IOException("$model → boş yanıt döndü"))

            val toolCalls = message.optJSONArray("tool_calls")
            val text = message.optString("content", "")

            if (toolCalls == null || toolCalls.length() == 0) {
                if (text.isBlank()) {
                    return Result.failure(IOException("$model → boş yanıt döndü"))
                }
                return Result.success(stripThinking(text))
            }

            // Modelin fonksiyon çağırma turunu sohbet geçmişine ekle
            // (OpenAI formatı: assistant mesajı tool_calls alanıyla birlikte).
            messages.put(JSONObject().apply {
                put("role", "assistant")
                put("content", if (text.isBlank()) JSONObject.NULL else text)
                put("tool_calls", toolCalls)
            })

            // Her fonksiyon çağrısını GERÇEKTEN çalıştır, sonucu "tool"
            // rolüyle geri besle.
            for (i in 0 until toolCalls.length()) {
                val call = toolCalls.optJSONObject(i) ?: continue
                val fn = call.optJSONObject("function") ?: continue
                val name = fn.optString("name")
                val argsRaw = fn.optString("arguments", "{}")
                val args = try { JSONObject(argsRaw) } catch (e: Exception) { JSONObject() }
                try { onToolUse?.invoke(name) } catch (e: Exception) { Log.w(TAG, "onToolUse", e) }
                val outcome = executeFunction(name, args)
                messages.put(JSONObject().apply {
                    put("role", "tool")
                    put("tool_call_id", call.optString("id"))
                    put("content", outcome.toString())
                })
            }

            lastText = text
        }

        if (lastText.isNotBlank()) Result.success(stripThinking(lastText))
        else Result.failure(IOException("$model → fonksiyon döngüsü tamamlanamadı"))
      } catch (e: Exception) {
        Result.failure(e)
      }
    }

    /** Bazı muhakeme modelleri cevabın başına <think>…</think> ekler; sesli okunmasın. */
    private fun stripThinking(text: String): String {
        val cleaned = text.replace(Regex("(?s)<think>.*?</think>"), "").trim()
        return cleaned.ifBlank { text.trim() }
    }

    private fun buildTools(includeBuilder: Boolean = true): JSONArray = filterTools(includeBuilder, JSONArray()
        .put(functionTool(
            name = "web_search",
            description = "İnternette (Google/DuckDuckGo/Bing benzeri) arama yapar ve sonuç başlıkları + özetleri döndürür. Güncel bilgi, haber, fiyat, skor, okul/sınav/tatil tarihleri, kişiler, ürünler, 'nedir/kimdir/ne zaman' gibi eğitim verinde olmayabilecek ya da emin olmadığın HER konuda ÖNCE bunu çağır, sonra sonuçlara dayanarak cevap ver. Kısa ve net Türkçe sorgu yaz (örn. 'MEB 2026 yaz tatili ne zaman'). Haber/gündem sorusu ise news=true yap.",
            properties = JSONObject().apply {
                put("query", JSONObject().apply {
                    put("type", "string")
                    put("description", "Arama sorgusu")
                })
                put("news", JSONObject().apply {
                    put("type", "boolean")
                    put("description", "Güncel haber araması ise true")
                })
            },
            required = listOf("query")
        ))
        .put(functionTool(
            name = "read_webpage",
            description = "web_search sonucundaki bir sayfanın (url) metnini okur. Arama özetleri cevap için yetersizse en alakalı 1 sonucun sayfasını bununla oku.",
            properties = JSONObject().apply {
                put("url", JSONObject().apply {
                    put("type", "string")
                    put("description", "web_search sonucundan alınan tam adres")
                })
            },
            required = listOf("url")
        ))
        .put(functionTool(
            name = "get_weather",
            description = "Herhangi bir şehir için anlık hava durumu ve günlük tahmin verir (yarın, hafta sonu, yağmur olur mu vb.). Şehir söylenmemişse city'yi boş bırak (kullanıcının bulunduğu yer kullanılır).",
            properties = JSONObject().apply {
                put("city", JSONObject().apply {
                    put("type", "string")
                    put("description", "Şehir adı, örn. Ankara")
                })
                put("days", JSONObject().apply {
                    put("type", "integer")
                    put("description", "Kaç günlük tahmin (1-7), varsayılan 3")
                })
            },
            required = emptyList()
        ))
        .put(functionTool(
            name = "create_file",
            description = "Kullanıcı için bir dosya oluşturup İndirilenler klasörüne kaydeder. Hem düz metin dosyaları (.txt, .md, .json, .csv, .html vb. -- content alanı) HEM DE herhangi bir ikili dosya (content_base64 alanı, örn. bir görselin/ikili verinin base64'ü) desteklenir. Kullanıcı açıkça bir not/liste/metin/dosya kaydetmeni istediğinde çağır.",
            properties = JSONObject().apply {
                put("filename", JSONObject().apply {
                    put("type", "string")
                    put("description", "Uzantılı dosya adı, örn. notlar.txt")
                })
                put("content", JSONObject().apply {
                    put("type", "string")
                    put("description", "Metin dosyası içeriği (ikili dosya için bunun yerine content_base64 kullan)")
                })
                put("content_base64", JSONObject().apply {
                    put("type", "string")
                    put("description", "İkili dosya içeriği, base64 kodlanmış (ör. bir görsel verisi)")
                })
            },
            required = listOf("filename")
        ))
        .put(functionTool(
            name = "create_zip",
            description = "Birden fazla dosyayı (metin VE/VEYA fotoğraf/ikili dosya) tek bir zip arşivinde birleştirip İndirilenler klasörüne kaydeder. Her dosya için ya 'content' (metin) ya da 'content_base64' (ikili/görsel) doldurulur. AYRICA kullanıcı senden bir OYUN veya UYGULAMA yapıp zip olarak vermeni istediğinde de bunu kullan: tam, eksiksiz ve gerçekten çalışan bir HTML5/CSS/JS oyununu tek bir 'index.html' dosyası (CSS ve JS gömülü, internetsiz çalışır) olarak 'content' alanına yaz ve bu şekilde ziple -- kullanıcı bunu kendi tarafında bir WebView aracıyla apk'ya çevirecek.",
            properties = JSONObject().apply {
                put("zip_filename", JSONObject().apply {
                    put("type", "string")
                    put("description", "Arşiv adı, .zip uzantılı ya da uzantısız")
                })
                put("files", JSONObject().apply {
                    put("type", "array")
                    put("items", JSONObject().apply {
                        put("type", "object")
                        put("properties", JSONObject().apply {
                            put("filename", JSONObject().put("type", "string"))
                            put("content", JSONObject().put("type", "string"))
                            put("content_base64", JSONObject().put("type", "string"))
                        })
                        put("required", JSONArray().put("filename"))
                    })
                })
            },
            required = listOf("zip_filename", "files")
        ))
        .put(functionTool(
            name = "create_image",
            description = "Yapay zeka ile, verilen tarif/prompt'tan YENİ bir fotoğraf/görsel/resim üretip galeriye (Resimler) kaydeder. Kullanıcı 'bana ... resmi/fotoğrafı çiz/oluştur/üret' gibi bir şey istediğinde çağır. Tarifi olabildiğince görsel ve betimleyici yaz (renkler, sahne, stil).",
            properties = JSONObject().apply {
                put("prompt", JSONObject().apply {
                    put("type", "string")
                    put("description", "Görselin ne olacağının İngilizce ya da Türkçe betimlemesi, örn. 'gün batımında deniz kenarında oturan kedi, gerçekçi stil'")
                })
                put("filename", JSONObject().apply {
                    put("type", "string")
                    put("description", "Kaydedilecek dosya adı (uzantısız da olur), örn. kedi_gunbatimi")
                })
            },
            required = listOf("prompt")
        ))
        .put(functionTool(
            name = "run_terminal_command",
            description = "Uygulamanın kendi sandbox'ında GERÇEK bir kabuk (shell) komutu çalıştırır (ls, mkdir, cat, echo, grep, find, sh script.sh vb.) ve çıktısını döndürür. Kullanıcı 'terminalde şunu çalıştır/derle/build et' gibi bir şey istediğinde çağır. NOT: cihazda root/gradle/JDK olmadığı için gerçek bir Android derlemesi yapılamaz; ama dosya/klasör işlemleri ve script çalıştırma gerçekten yapılır. Sonucu kullanıcıya kısaca özetle.",
            properties = JSONObject().apply {
                put("command", JSONObject().apply {
                    put("type", "string")
                    put("description", "Çalıştırılacak kabuk komutu, örn. 'ls -la' ya da 'echo merhaba > test.txt && cat test.txt'")
                })
            },
            required = listOf("command")
        ))
        .put(functionTool(
            name = "play_song",
            description = "Kullanıcının istediği şarkıyı çalmaya başlar: önce telefonun yerel müzik kütüphanesinde arar, yoksa YouTube'da arayıp bulduğu ses akışını YİNE arka planda, ekran değiştirmeden çalar. status=playing_local ya da status=playing_stream dönerse şarkı fiilen çalmaya başlamıştır. Sadece status=opened_youtube_search dönerse (nadir, ses akışı çözülemediği durumlar) kullanıcıya YouTube'da açtığını söyle. ÖNEMLİ: kullanıcı belirli bir şarkı adı söylemeden sadece 'çal', 'devam et', 'tekrar çal', 'yine aç' gibi bir şey derse (daha önce çalınmış bir şarkıyı yeniden başlatmak istiyorsa) query'yi BOŞ bırak -- uygulama otomatik olarak en son çalınan şarkıyı hatırlayıp tekrar başlatır, sen tekrar şarkı adı SORMA.",
            properties = JSONObject().apply {
                put("query", JSONObject().apply {
                    put("type", "string")
                    put("description", "Şarkı adı ve varsa sanatçı, örn. 'Tarkan Kuzu Kuzu'. En son çalınan şarkıyı tekrar başlatmak için boş bırakılabilir.")
                })
            },
            required = emptyList()
        ))
        .put(functionTool(
            name = "stop_song",
            description = "Şu anda arka planda çalmakta olan şarkıyı/müziği durdurur. Kullanıcı 'durdur', 'kapat', 'yeter', 'müziği kes' gibi bir şey söylediğinde ve bir şarkı çalıyorsa çağır.",
            properties = JSONObject(),
            required = emptyList()
        ))
        .put(functionTool(
            name = "watch_video",
            description = "Kullanıcının izlemek istediği bir film, dizi (bölümü) ya da herhangi bir videoyu YouTube'da arayıp bulur ve ekranın sol üst köşesinde küçük bir oynatıcıda açar; kullanıcı ona dokunup büyütme tuşuna basarak tam ekran izleyebilir. Kullanıcı '... izle', '... filmini/dizisini aç', '... videosunu göster' gibi bir şey dediğinde çağır. Sadece arama yapıp oynatıcıyı açar, sesli cevapta filmin/dizinin adını söylersin, video için ekranı tarif etmene gerek yok.",
            properties = JSONObject().apply {
                put("query", JSONObject().apply {
                    put("type", "string")
                    put("description", "İzlenecek film/dizi/video adı, varsa sezon/bölüm bilgisiyle birlikte, örn. 'Inception filmi' ya da 'Breaking Bad 1. sezon 1. bölüm'")
                })
            },
            required = listOf("query")
        ))
        .put(functionTool(
            name = "stop_video",
            description = "Açık olan video oynatıcıyı kapatır. Kullanıcı 'videoyu kapat', 'izlemeyi durdur', 'filmi kapat' gibi bir şey söylediğinde ve bir video açıksa çağır.",
            properties = JSONObject(),
            required = emptyList()
        ))
        .put(functionTool(
            name = "open_website",
            description = "Kullanıcının istediği bir siteyi/sayfayı ekranın sol üst köşesinde küçük bir pencerede açar (video oynatıcıyla aynı yerde) -- kullanıcı ona dokunup büyütme tuşuna basarak tam ekran kullanabilir, sayfada gezinebilir, teste/forma girebilir. Ders konusu, test/soru, haber, ürün, tarif, TAMAMEN HERHANGİ BİR konuda kullanılabilir -- sadece derslerle sınırlı değil. ÖNCE web_search ile ara, sonuçlardan konuya en uygun olanının url'sini seç, SONRA bu fonksiyona ver -- sadece bulduğunu anlatıp geçme, siteyi GERÇEKTEN aç.",
            properties = JSONObject().apply {
                put("url", JSONObject().apply {
                    put("type", "string")
                    put("description", "Açılacak sayfanın tam adresi (http:// veya https:// ile), web_search sonuçlarındaki 'url' alanından alınmış olmalı")
                })
                put("title", JSONObject().apply {
                    put("type", "string")
                    put("description", "Sayfanın/sitenin kısa başlığı, kullanıcıya ne açtığını söylemek için")
                })
            },
            required = listOf("url")
        ))
        .put(functionTool(
            name = "close_website",
            description = "Açık olan mini site penceresini kapatır. Kullanıcı 'siteyi kapat', 'pencereyi kapat' gibi bir şey söylediğinde ve bir site açıksa çağır.",
            properties = JSONObject(),
            required = emptyList()
        ))
        .put(functionTool(
            name = "save_memory",
            description = "Kullanıcı hakkında kalıcı olarak hatırlaman gereken bir bilgiyi (isim, tercih, önemli tarih, alışkanlık, kişi/evcil hayvan adı vb.) hafızana kaydeder -- bu bilgi uygulama kapatılıp açılsa bile HER sohbette sana hatırlatılır. Kullanıcı 'bunu hatırla/unutma/aklında tut' derse ya da kendiliğinden önemli, tekrar işine yarayacak bir bilgi paylaşırsa çağır. Geçici/anlık şeyleri (örn. şu anki ruh hali) KAYDETME, sadece kalıcı, tekrar lazım olacak bilgileri kaydet.",
            properties = JSONObject().apply {
                put("text", JSONObject().apply {
                    put("type", "string")
                    put("description", "Kaydedilecek not, kısa ve net bir cümle, örn. 'kedisinin adı Pamuk' ya da 'her sabah 07:00 alarmı istiyor'")
                })
            },
            required = listOf("text")
        ))
        .put(functionTool(
            name = "delete_memory",
            description = "Daha önce save_memory ile kaydedilmiş bir notu hafızadan siler. Kullanıcı 'bunu unut/sil/artık geçerli değil' derse çağır.",
            properties = JSONObject().apply {
                put("query", JSONObject().apply {
                    put("type", "string")
                    put("description", "Silinecek notun id'si (cihaz bağlamındaki [KALICI HAFIZA] listesinden) ya da notun içeriğinden bir parça")
                })
            },
            required = listOf("query")
        ))
        .put(functionTool(
            name = "add_reminder",
            description = "Belirli bir zaman için anımsatıcı/hatırlatıcı kurar; zamanı gelince telefon bir bildirim gösterir. Kullanıcı 'bana ... hatırlat', '... saatinde uyar', 'alarm kur' gibi bir şey dediğinde çağır. when_iso'yu MUTLAKA cihaz bağlamındaki güncel tarih/saate göre, ISO 8601 formatında (YYYY-MM-DDTHH:MM:SS) hesapla -- 'yarın', 'bir saat sonra', 'akşam 8'de' gibi göreli ifadeleri kendin kesin bir tarihe/saate çevir.",
            properties = JSONObject().apply {
                put("text", JSONObject().apply {
                    put("type", "string")
                    put("description", "Hatırlatıcının metni, örn. 'ilaç saati' ya da 'toplantı var'")
                })
                put("when_iso", JSONObject().apply {
                    put("type", "string")
                    put("description", "Hatırlatma zamanı, ISO 8601 (örn. 2026-09-21T20:00:00)")
                })
            },
            required = listOf("text", "when_iso")
        ))
        .put(functionTool(
            name = "get_reminders",
            description = "Kullanıcının kurulu olan, henüz gelmemiş tüm anımsatıcılarını listeler. Kullanıcı 'hatırlatıcılarım ne', 'bana ne hatırlatacaktın' gibi bir şey sorduğunda çağır (cihaz bağlamındaki [BEKLEYEN ANIMSATICILAR] bloğu zaten güncel olsa da, kullanıcı açıkça sorarsa yine de bu fonksiyonu çağırıp teyit et).",
            properties = JSONObject(),
            required = emptyList()
        ))
        .put(functionTool(
            name = "delete_reminder",
            description = "Kurulu bir anımsatıcıyı iptal eder. Kullanıcı 'o hatırlatıcıyı iptal et/sil' derse çağır.",
            properties = JSONObject().apply {
                put("query", JSONObject().apply {
                    put("type", "string")
                    put("description", "İptal edilecek hatırlatıcının id'si ya da metninden bir parça")
                })
            },
            required = listOf("query")
        ))
        .put(functionTool(
            name = "get_calendar_events",
            description = "Kullanıcının telefon takviminden (Google/Samsung takvimi, telefonda zaten senkronize) etkinlikleri okur. Kullanıcı 'takvimimde ne var', 'bugün/yarın/bu hafta ne var', 'programım nasıl' gibi bir şey sorduğunda çağır.",
            properties = JSONObject().apply {
                put("query", JSONObject().apply {
                    put("type", "string")
                    put("description", "'today', 'tomorrow', 'week' ya da 'month' -- hangi aralığın sorulduğu, varsayılan today")
                })
                put("limit", JSONObject().apply {
                    put("type", "integer")
                    put("description", "En fazla kaç etkinlik döndürülsün, varsayılan 8")
                })
            },
            required = emptyList()
        ))
        .put(functionTool(
            name = "add_calendar_event",
            description = "Kullanıcının telefon takvimine yeni bir etkinlik/randevu ekler. Kullanıcı 'takvime ekle', '... için randevu/etkinlik oluştur' gibi bir şey dediğinde çağır. start_iso/end_iso'yu cihaz bağlamındaki güncel tarihe göre kesin bir ISO 8601 tarihe çevir (göreli ifadeleri -- 'yarın', 'salı' vb. -- kendin hesapla).",
            properties = JSONObject().apply {
                put("title", JSONObject().apply {
                    put("type", "string")
                    put("description", "Etkinlik başlığı")
                })
                put("start_iso", JSONObject().apply {
                    put("type", "string")
                    put("description", "Başlangıç, ISO 8601 (örn. 2026-09-22T14:00:00)")
                })
                put("end_iso", JSONObject().apply {
                    put("type", "string")
                    put("description", "Bitiş, ISO 8601. Verilmezse başlangıçtan 1 saat sonrası alınır.")
                })
                put("location", JSONObject().apply {
                    put("type", "string")
                    put("description", "Konum (opsiyonel)")
                })
                put("notes", JSONObject().apply {
                    put("type", "string")
                    put("description", "Ek not/açıklama (opsiyonel)")
                })
                put("all_day", JSONObject().apply {
                    put("type", "boolean")
                    put("description", "Tüm gün süren bir etkinlikse true")
                })
            },
            required = listOf("title", "start_iso")
        ))
        .put(functionTool(
            name = "delete_calendar_event",
            description = "Başlığa göre eşleşen takvim etkinliğini/etkinliklerini siler. Kullanıcı 'takvimden ... sil/iptal et' derse çağır.",
            properties = JSONObject().apply {
                put("title", JSONObject().apply {
                    put("type", "string")
                    put("description", "Silinecek etkinliğin başlığı ya da başlığından bir parça")
                })
                put("delete_all_matches", JSONObject().apply {
                    put("type", "boolean")
                    put("description", "true ise başlığa uyan TÜM etkinlikleri siler, false ise (varsayılan) sadece en yakın olanı siler")
                })
            },
            required = listOf("title")
        ))
        .put(functionTool(
            name = "analyze_webcam",
            description = "Windows Jarvis V3'ten taşındı: telefonun ön kamerasından ANLIK olarak tek bir fotoğraf çeker (önizleme göstermeden) ve ne gördüğünü yorumlar. Kullanıcı 'bana bak', 'üzerimde ne var', 'neye benziyorum', 'şunu göster/tanı' gibi kameradan bir şey görmeni isteyen bir şey dediğinde çağır. question alanına kullanıcının tam olarak ne öğrenmek istediğini yaz.",
            properties = JSONObject().apply {
                put("question", JSONObject().apply {
                    put("type", "string")
                    put("description", "Görüntüde ne aranacağı/sorulacağı, örn. 'üzerimdeki kıyafetin rengi ne'. Boş bırakılırsa genel bir açıklama istenir.")
                })
            },
            required = emptyList()
        ))
        .put(functionTool(
            name = "analyze_screen",
            description = "Windows Jarvis V3'ten taşındı: telefonun O ANKİ ekran görüntüsünü yakalayıp içeriğini yorumlar (yazı okuma, hata mesajı anlama, bir uygulamanın ekranını açıklama vb.). Kullanıcı 'ekranda ne yazıyor', 'şu hatayı oku', 'ekranımı analiz et' gibi bir şey dediğinde çağır. NOT: ekran yakalama izni uygulama açılışında istenir; kullanıcı reddettiyse status=error döner, o zaman uygulamayı kapatıp tekrar açıp izni onaylaması gerektiğini söyle.",
            properties = JSONObject().apply {
                put("question", JSONObject().apply {
                    put("type", "string")
                    put("description", "Ekranda ne aranacağı/sorulacağı, örn. 'bu hata mesajı ne anlama geliyor'. Boş bırakılırsa genel bir açıklama istenir.")
                })
            },
            required = emptyList()
        ))
        .put(functionTool(
            name = "set_alarm",
            description = "Windows Jarvis V3'ten taşındı: telefonun Saat uygulamasında GERÇEKTEN bir alarm kurar (onay ekranı açmadan, direkt kurulur). Kullanıcı 'şu saate alarm kur', 'yarın 7'de uyandır' gibi bir şey dediğinde çağır.",
            properties = JSONObject().apply {
                put("hour", JSONObject().put("type", "integer").put("description", "24 saat formatında saat (0-23)"))
                put("minute", JSONObject().put("type", "integer").put("description", "dakika (0-59)"))
                put("label", JSONObject().put("type", "string").put("description", "alarmın etiketi/nedeni, opsiyonel"))
            },
            required = listOf("hour", "minute")
        ))
        .put(functionTool(
            name = "open_app",
            description = "Windows Jarvis V3'ten taşındı: telefonda YÜKLÜ bir uygulamayı gerçekten açar (örn. 'Instagram'ı aç', 'YouTube'u aç'). Uygulama YÜKLÜ DEĞİLSE, Android güvenlik mimarisi 3. parti uygulamaların onay olmadan sessizce apk kurmasına izin vermediği için (bu Google Asistan için de aynı), bunun yerine Play Store'da o uygulamanın/oyunun sayfasını açar -- kullanıcı tek dokunuşla yükleyebilir. Kullanıcı 'X uygulamasını/oyununu indir' dediğinde de bunu çağır, sonucu status alanına göre kullanıcıya doğru anlat (yüklüyse 'açtım', değilse 'Play Store'da açtım, Yükle'ye basman yeterli').",
            properties = JSONObject().apply {
                put("app_name", JSONObject().put("type", "string").put("description", "açılacak/indirilecek uygulama ya da oyunun adı"))
            },
            required = listOf("app_name")
        ))
        .put(functionTool(
            name = "set_volume",
            description = "Windows Jarvis V3'ten taşındı: telefonun medya (müzik/video) ses seviyesini GERÇEKTEN ayarlar. Kullanıcı 'sesi %70 yap', 'sesi kıs/aç' gibi bir şey dediğinde çağır.",
            properties = JSONObject().apply {
                put("percent", JSONObject().put("type", "integer").put("description", "0-100 arası hedef ses yüzdesi"))
            },
            required = listOf("percent")
        ))
        .put(functionTool(
            name = "toggle_flashlight",
            description = "Windows Jarvis V3'ten taşındı: telefonun el fenerini GERÇEKTEN açar/kapatır. Kullanıcı 'el fenerini aç/kapat' dediğinde çağır. Tüm cihazlarda çalışmayabilir (donanım/izin), status=error dönerse kullanıcıya söyle.",
            properties = JSONObject().apply {
                put("on", JSONObject().put("type", "boolean").put("description", "true=aç, false=kapat"))
            },
            required = listOf("on")
        ))
        .put(functionTool(
            name = "open_wifi_settings",
            description = "Wi-Fi ayar panelini açar. Android 10+ itibarıyla üçüncü parti uygulamalar Wi-Fi'ı kullanıcı onayı olmadan sessizce açıp kapatamadığı için (işletim sistemi kısıtı), en iyi ihtimal bu paneli açıp kullanıcının tek dokunuşla değiştirmesini sağlamak. Kullanıcı 'wifi'yi aç/kapat' dediğinde çağır, sonrasında kullanıcıya panelde dokunmasının yeterli olduğunu söyle.",
            properties = JSONObject(),
            required = emptyList()
        ))
        .put(functionTool(
            name = "open_bluetooth_settings",
            description = "Bluetooth ayarlarını açar. Aynı Android kısıtı (bkz. open_wifi_settings) burada da geçerli -- sessizce açılıp kapatılamaz, kullanıcı ekranda dokunur. Kullanıcı 'bluetooth'u aç/kapat' dediğinde çağır.",
            properties = JSONObject(),
            required = emptyList()
        ))
        .put(functionTool(
            name = "send_whatsapp_message",
            description = "Windows Jarvis V3'ten taşındı: WhatsApp'ı, verilen kişiye/numaraya YAZILMIŞ mesajla açar. Android güvenliği gereği (WhatsApp/Instagram/TikTok'un kendi arayüzüne sahte dokunuş yaptırmak Play Store politikalarına ve bu uygulamaların kullanım şartlarına aykırı olur) mesaj OTOMATİK gönderilmez -- kullanıcı WhatsApp açıldığında SADECE Gönder'e basar. Bunu kullanıcıya net söyle: 'WhatsApp'ı X için hazır mesajla açtım, göndermen için sadece dokunman yeterli'. recipient bir isim (daha önce save_social_contact ile kaydedilmiş) ya da doğrudan telefon numarası olabilir.",
            properties = JSONObject().apply {
                put("recipient", JSONObject().put("type", "string").put("description", "kayıtlı kişi adı ya da telefon numarası"))
                put("message", JSONObject().put("type", "string").put("description", "gönderilecek mesaj metni"))
            },
            required = listOf("recipient", "message")
        ))
        .put(functionTool(
            name = "open_instagram_dm",
            description = "Windows Jarvis V3'ten genişletildi: Instagram'ı, verilen kullanıcıyla DM (direkt mesaj) ekranı AÇIK olarak açar. Instagram'ın genel/resmi bir mesaj METNİ önceden doldurma yolu YOK -- sadece doğru sohbet ekranı açılır, mesajı kullanıcı kendi yazar. Bunu kullanıcıya söyle. recipient bir isim (save_social_contact ile kaydedilmiş) ya da doğrudan kullanıcı adı olabilir.",
            properties = JSONObject().apply {
                put("recipient", JSONObject().put("type", "string").put("description", "kayıtlı kişi adı ya da Instagram kullanıcı adı"))
            },
            required = listOf("recipient")
        ))
        .put(functionTool(
            name = "open_tiktok_profile",
            description = "Windows Jarvis V3'ten genişletildi: TikTok'ta verilen kullanıcının PROFİLİNİ açar. TikTok'ta belirli bir kullanıcıyla DM ekranını doğrudan açacak genel bir bağlantı YOK (Instagram/WhatsApp'tan farklı olarak) -- kullanıcı profile gidip mesaj düğmesine kendisi basmalı (karşılıklı takip gerekebilir). Bunu kullanıcıya söyle. recipient bir isim (save_social_contact ile kaydedilmiş) ya da doğrudan kullanıcı adı olabilir.",
            properties = JSONObject().apply {
                put("recipient", JSONObject().put("type", "string").put("description", "kayıtlı kişi adı ya da TikTok kullanıcı adı"))
            },
            required = listOf("recipient")
        ))
        .put(functionTool(
            name = "save_social_contact",
            description = "Kullanıcı bir kişinin WhatsApp numarasını ya da Instagram/TikTok kullanıcı adını isimle ilişkilendirip kaydetmeni istediğinde çağır (örn. 'Ahmet'in WhatsApp'ı 0555...', 'Ayşe'nin Instagram'ı @ayse123'). Sonra o isim, send_whatsapp_message/open_instagram_dm/open_tiktok_profile'da recipient olarak kullanılabilir.",
            properties = JSONObject().apply {
                put("platform", JSONObject().apply {
                    put("type", "string")
                    put("enum", JSONArray().put("whatsapp").put("instagram").put("tiktok"))
                })
                put("name", JSONObject().put("type", "string").put("description", "kişinin adı"))
                put("handle", JSONObject().put("type", "string").put("description", "whatsapp için telefon numarası, instagram/tiktok için kullanıcı adı"))
            },
            required = listOf("platform", "name", "handle")
        ))
        .put(functionTool(
            name = "browser_control",
            description = "Windows Jarvis V3'ten taşındı ve GENİŞLETİLDİ: AÇIK OLAN mini tarayıcı penceresini (open_website ile açılmış) sesli komutla yönetir -- geri git, ileri git, sayfayı yenile. Kullanıcı 'geri git', 'önceki sayfaya dön', 'sayfayı yenile' gibi bir şey dediğinde ve bir site açıksa çağır. 'search' eylemi Google arama SONUÇLARI sayfasını mini pencerede açar (kullanıcı 'google'da ara ve sonuçları göster' gibi spesifik isterse kullan; normalde bir konuyu araştırmak için önce web_search, sonra en uygun sonucu open_website ile açmak DAHA İYİDİR, search eylemini SADECE kullanıcı özellikle arama sonuçlarını görmek isterse kullan).",
            properties = JSONObject().apply {
                put("action", JSONObject().apply {
                    put("type", "string")
                    put("enum", JSONArray().put("go_back").put("go_forward").put("reload").put("search"))
                })
                put("query", JSONObject().put("type", "string").put("description", "SADECE action=search ise: aranacak metin"))
            },
            required = listOf("action")
        ))
        .put(functionTool(
            name = "get_youtube_channel_report",
            description = "Windows Jarvis V3'ten taşındı: herkese açık YouTube verilerine göre bir kanalın abone/izlenme/video sayısını, son videolarının ortalama performansını, en güçlü videosunu ve yayın temposunu özetler. Kullanıcı 'kanalım nasıl gidiyor', 'X kanalının istatistiklerini ver' gibi bir şey dediğinde çağır. Studio'ya özel veriler (CTR, gösterim, gelir vb.) YOKTUR, bunu kullanıcıya söyle. status=error ve message='NEEDS_KEY' dönerse kullanıcıdan YouTube API anahtarı iste ve save_youtube_api_key ile kaydet.",
            properties = JSONObject().apply {
                put("channel", JSONObject().put("type", "string").put("description", "@handle, kanal URL'si ya da kanal ID'si"))
                put("query", JSONObject().put("type", "string").put("description", "kullanıcının tam isteği, örn. 'detaylı analiz' -- 'detay/analiz/rapor' geçerse son videoların dökümü de eklenir"))
                put("video_limit", JSONObject().put("type", "integer").put("description", "kaç son video incelensin, varsayılan 6"))
            },
            required = listOf("channel")
        ))
        .put(functionTool(
            name = "save_youtube_api_key",
            description = "Kullanıcı sana bir Google Cloud / YouTube Data API v3 anahtarı verdiğinde çağır (örn. 'youtube api anahtarım: AIza...'). Bu, get_youtube_channel_report için GEREKLİ ayrı bir anahtardır, Gemini anahtarıyla aynı değildir.",
            properties = JSONObject().apply {
                put("key", JSONObject().put("type", "string"))
            },
            required = listOf("key")
        ))
        .put(functionTool(
            name = "sys_info",
            description = "Windows Jarvis V3'ten taşındı: telefonun pil, RAM, depolama, ağ, saat/tarih bilgisini verir. Kullanıcı 'pil yüzde kaç', 'ne kadar RAM var', 'depolama durumu' gibi bir şey sorduğunda çağır.",
            properties = JSONObject().apply {
                put("query", JSONObject().apply {
                    put("type", "string")
                    put("enum", JSONArray().put("battery").put("cpu").put("ram").put("disk").put("time").put("date").put("network").put("all"))
                })
            },
            required = listOf("query")
        ))
        .put(functionTool(
            name = "set_wakeword_listening",
            description = "Kullanıcı 'Jarvis dinlemeyi aç/kapat', 'arka planda dinle', 'uyandırma kelimesini kapat' gibi bir şey dediğinde çağır. Hiçbir ek anahtar/hesap gerekmez (Android'in kendi ses tanımasını kullanır). AÇILDIĞINDA kullanıcıya şunu MUTLAKA söyle: bildirimden hep görünür kalır (Android kuralı, gizlenemez), normal dinlemeden daha çok pil tüketir, bazen yanlış algılayabilir/kaçırabilir, ve ŞU AN çalan bir alarmı SESLE KAPATAMAZ (alarmlar Saat uygulamasında, Jarvis'in erişimi yok) -- ama saat/hava durumu gibi bilgi sorularına cevap verir.",
            properties = JSONObject().apply {
                put("enabled", JSONObject().put("type", "boolean"))
            },
            required = listOf("enabled")
        )))

    // Her zaman gönderilen hafif araçlar; diğerleri (dosya/zip/oyun/görsel/terminal)
    // yalnızca ilgili bir istek varsa eklenir.
    private val LIGHT_TOOLS = setOf(
        "web_search", "read_webpage", "get_weather", "play_song", "stop_song",
        "watch_video", "stop_video", "open_website", "close_website",
        "save_memory", "delete_memory", "add_reminder", "get_reminders", "delete_reminder",
        "get_calendar_events", "add_calendar_event", "delete_calendar_event",
        "analyze_webcam", "analyze_screen",
        "set_alarm", "open_app", "set_volume", "toggle_flashlight",
        "open_wifi_settings", "open_bluetooth_settings",
        "send_whatsapp_message", "open_instagram_dm", "open_tiktok_profile", "save_social_contact",
        "browser_control", "get_youtube_channel_report", "save_youtube_api_key", "sys_info",
        "set_wakeword_listening"
    )

    private fun filterTools(includeBuilder: Boolean, all: JSONArray): JSONArray {
        if (includeBuilder) return all
        val out = JSONArray()
        for (i in 0 until all.length()) {
            val t = all.optJSONObject(i) ?: continue
            val name = t.optJSONObject("function")?.optString("name").orEmpty()
            if (name in LIGHT_TOOLS) out.put(t)
        }
        return out
    }

    private val BUILDER_KEYWORDS = listOf(
        "kaydet", "dosya", "txt", "zip", "oyun", "uygulama", "apk", "html", "kod",
        "site", "script", "proje", "resim", "görsel", "gorsel", "fotoğraf", "çiz",
        "üret", "oluştur", "terminal", "komut", "derle", "build", "indir", "not al", "hazırla"
    )

    /** Son 2 kullanıcı mesajında dosya/oyun/görsel/terminal isteği var mı? */
    private fun needsBuilderTools(conversation: List<Pair<String, String>>, currentTurnText: String?): Boolean {
        val recent = conversation.filter { it.first == "user" }.takeLast(2).joinToString(" ") { it.second }
        val text = ((currentTurnText ?: "") + " " + recent).lowercase()
        return BUILDER_KEYWORDS.any { text.contains(it) }
    }

    private fun functionTool(
        name: String,
        description: String,
        properties: JSONObject,
        required: List<String>
    ): JSONObject = JSONObject().apply {
        put("type", "function")
        put("function", JSONObject().apply {
            put("name", name)
            put("description", description)
            put("parameters", JSONObject().apply {
                put("type", "object")
                put("properties", properties)
                put("required", JSONArray(required))
            })
        })
    }

    // Model bazen saat dilimsiz ("2026-09-21T20:00:00"), bazen "Z"/offset'li
    // ISO 8601 gönderebiliyor; ikisini de dener, saat dilimsiz olanı cihazın
    // yerel saat dilimi kabul eder.
    private fun parseIsoToMillis(iso: String): Long? {
        val s = iso.trim()
        if (s.isBlank()) return null
        return try {
            java.time.Instant.parse(s).toEpochMilli()
        } catch (e: Exception) {
            try {
                java.time.OffsetDateTime.parse(s).toInstant().toEpochMilli()
            } catch (e2: Exception) {
                try {
                    LocalDateTime.parse(s, DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                        .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                } catch (e3: Exception) {
                    null
                }
            }
        }
    }

    private fun executeFunction(name: String, args: JSONObject): JSONObject = try {
        when (name) {
            "create_file" -> {
                val filename = args.optString("filename").ifBlank { "not.txt" }
                val base64 = args.optString("content_base64")
                val staged = if (base64.isNotBlank()) {
                    FileTool.stageFile(appContext, filename, Base64.decode(base64, Base64.DEFAULT))
                } else {
                    FileTool.stageTextFile(appContext, filename, args.optString("content"))
                }
                onFileReady?.invoke(staged)
                JSONObject().put("status", "ok").put("filename", staged.filename)
                    .put("note", "Dosya sohbete eklendi, kullanıcı oradan indirebilir. 'indirdim/kaydettim' DEME, 'sohbete ekledim, indirmek istersen Kaydet'e basman yeterli' gibi bir şey söyle.")
            }
            "create_zip" -> {
                val zipName = args.optString("zip_filename").ifBlank { "arsiv.zip" }
                val filesArr = args.optJSONArray("files") ?: JSONArray()
                val entries = mutableListOf<FileTool.ZipEntryInput>()
                for (i in 0 until filesArr.length()) {
                    val f = filesArr.optJSONObject(i) ?: continue
                    val fname = f.optString("filename", "dosya_$i.txt")
                    val base64 = f.optString("content_base64")
                    val bytes = if (base64.isNotBlank()) {
                        Base64.decode(base64, Base64.DEFAULT)
                    } else {
                        f.optString("content").toByteArray()
                    }
                    entries += FileTool.ZipEntryInput(fname, bytes)
                }
                val staged = FileTool.stageZipFile(appContext, zipName, entries)
                onFileReady?.invoke(staged)
                JSONObject().put("status", "ok").put("filename", staged.filename)
                    .put("note", "Zip sohbete eklendi, kullanıcı oradan indirebilir. 'indirdim/kaydettim' DEME, 'sohbete ekledim, indirmek istersen Kaydet'e basman yeterli' gibi bir şey söyle.")
            }
            "create_image" -> {
                val prompt = args.optString("prompt")
                if (prompt.isBlank()) {
                    JSONObject().put("status", "error").put("message", "prompt boş olamaz")
                } else {
                    val bytes = runBlocking { ImageGenClient.generate(apiKey, prompt) }
                    if (bytes == null) {
                        JSONObject().put("status", "error").put("message", "Görsel oluşturulamadı, ağ sorunu olabilir")
                    } else {
                        val filename = args.optString("filename").ifBlank { "jarvis_gorsel_${System.currentTimeMillis()}" }
                        val staged = FileTool.stageImageFile(appContext, filename, bytes)
                        onFileReady?.invoke(staged)
                        JSONObject().put("status", "ok").put("filename", staged.filename)
                            .put("note", "Görsel sohbete eklendi, kullanıcı oradan indirebilir/paylaşabilir. 'indirdim/kaydettim' DEME, 'sohbete ekledim, indirmek istersen Kaydet'e basman yeterli' gibi bir şey söyle.")
                    }
                }
            }
            "run_terminal_command" -> {
                val command = args.optString("command")
                val result = runBlocking { TerminalRunner.run(appContext.filesDir, command) }
                JSONObject()
                    .put("status", "ok")
                    .put("exit_code", result.exitCode)
                    .put("timed_out", result.timedOut)
                    .put("output", result.output)
            }
            "play_song" -> {
                val query = args.optString("query")
                when (val result = MusicController.play(appContext, query)) {
                    is MusicController.PlayResult.PlayingLocal ->
                        JSONObject().put("status", "playing_local")
                            .put("title", result.title).put("artist", result.artist)
                    is MusicController.PlayResult.PlayingStream ->
                        JSONObject().put("status", "playing_stream")
                            .put("title", result.title).put("artist", result.artist)
                    is MusicController.PlayResult.OpenedYoutubeSearch ->
                        JSONObject().put("status", "opened_youtube_search").put("query", result.query)
                    is MusicController.PlayResult.PermissionMissing ->
                        JSONObject().put("status", "error").put("message", result.message)
                    is MusicController.PlayResult.Error ->
                        JSONObject().put("status", "error").put("message", result.message)
                }
            }
            "web_search" -> WebSearchClient.search(
                args.optString("query"),
                args.optBoolean("news", false)
            )
            "read_webpage" -> WebSearchClient.readPage(args.optString("url"))
            "get_weather" -> {
                val city = args.optString("city").takeIf { it.isNotBlank() && it != "null" }
                // Kullanıcı açıkça bir şehir sorduysa, ViewModel'e haber ver ki
                // sol alttaki hava durumu widget'ı o şehre göre güncellensin ve
                // bir dahaki açılışta da hatırlansın.
                if (city != null) {
                    try { onCityQueried?.invoke(city) } catch (e: Exception) { Log.w(TAG, "onCityQueried", e) }
                }
                WeatherClient.forecastFor(city, if (args.has("days")) args.optInt("days", 3) else 3)
            }
            "stop_song" -> {
                MusicController.stop(appContext)
                JSONObject().put("status", "ok")
            }
            "watch_video" -> {
                val query = args.optString("query")
                when (val result = VideoSearchController.search(query)) {
                    is VideoSearchController.Result.Found -> {
                        try {
                            onWatchVideo?.invoke(result.videoId, result.title)
                        } catch (e: Exception) {
                            Log.w(TAG, "onWatchVideo", e)
                        }
                        JSONObject().put("status", "opened")
                            .put("title", result.title)
                            .put("channel", result.channel)
                    }
                    VideoSearchController.Result.NotFound ->
                        JSONObject().put("status", "error").put("message", "YouTube'da uygun bir video bulunamadı.")
                    is VideoSearchController.Result.Error ->
                        JSONObject().put("status", "error").put("message", result.message)
                }
            }
            "stop_video" -> {
                try { onCloseWindow?.invoke() } catch (e: Exception) { Log.w(TAG, "onCloseWindow", e) }
                JSONObject().put("status", "ok")
            }
            "open_website" -> {
                val url = args.optString("url").trim()
                val title = args.optString("title").ifBlank { url }
                if (!(url.startsWith("http://") || url.startsWith("https://"))) {
                    JSONObject().put("status", "error").put("message", "Geçersiz url -- http:// ya da https:// ile başlamalı.")
                } else {
                    try {
                        onOpenSite?.invoke(url, title)
                    } catch (e: Exception) {
                        Log.w(TAG, "onOpenSite", e)
                    }
                    JSONObject().put("status", "opened").put("url", url).put("title", title)
                }
            }
            "close_website" -> {
                try { onCloseWindow?.invoke() } catch (e: Exception) { Log.w(TAG, "onCloseWindow", e) }
                JSONObject().put("status", "ok")
            }
            "save_memory" -> {
                val text = args.optString("text").trim()
                if (text.isBlank()) {
                    JSONObject().put("status", "error").put("message", "text boş olamaz")
                } else {
                    val id = MemoryStore.add(appContext, text)
                    JSONObject().put("status", "ok").put("id", id)
                }
            }
            "delete_memory" -> {
                val n = MemoryStore.delete(appContext, args.optString("query"))
                if (n > 0) JSONObject().put("status", "ok").put("deleted", n)
                else JSONObject().put("status", "error").put("message", "Eşleşen not bulunamadı")
            }
            "add_reminder" -> {
                val text = args.optString("text").trim()
                val whenMillis = parseIsoToMillis(args.optString("when_iso"))
                when {
                    text.isBlank() -> JSONObject().put("status", "error").put("message", "text boş olamaz")
                    whenMillis == null -> JSONObject().put("status", "error").put("message", "when_iso geçersiz, ISO 8601 formatında olmalı")
                    else -> {
                        val r = ReminderStore.add(appContext, text, whenMillis)
                        JSONObject().put("status", "ok").put("id", r.id).put("when_iso", args.optString("when_iso"))
                    }
                }
            }
            "get_reminders" -> {
                val items = ReminderStore.upcoming(appContext)
                val arr = JSONArray()
                items.forEach { arr.put(JSONObject().put("id", it.id).put("text", it.text).put("when_millis", it.timeMillis)) }
                JSONObject().put("status", "ok").put("reminders", arr)
            }
            "delete_reminder" -> {
                val n = ReminderStore.delete(appContext, args.optString("query"))
                if (n > 0) JSONObject().put("status", "ok").put("deleted", n)
                else JSONObject().put("status", "error").put("message", "Eşleşen anımsatıcı bulunamadı")
            }
            "get_calendar_events" -> {
                val (from, to) = CalendarTool.rangeForQuery(args.optString("query", "today"))
                val limit = if (args.has("limit")) args.optInt("limit", 8) else 8
                CalendarTool.getEvents(appContext, from, to, limit).fold(
                    onSuccess = { events ->
                        val arr = JSONArray()
                        events.forEach { arr.put(CalendarTool.formatEvent(it)) }
                        JSONObject().put("status", "ok").put("events", arr).put("count", events.size)
                    },
                    onFailure = {
                        JSONObject().put("status", "error").put("message", "Takvim izni verilmemiş, kullanıcıya uygulama izinlerinden Takvim iznini açmasını söyle.")
                    }
                )
            }
            "add_calendar_event" -> {
                val title = args.optString("title").trim()
                val start = parseIsoToMillis(args.optString("start_iso"))
                val end = args.optString("end_iso").takeIf { it.isNotBlank() }?.let { parseIsoToMillis(it) }
                    ?: start?.plus(60 * 60 * 1000L)
                when {
                    title.isBlank() -> JSONObject().put("status", "error").put("message", "title boş olamaz")
                    start == null -> JSONObject().put("status", "error").put("message", "start_iso geçersiz, ISO 8601 formatında olmalı")
                    else -> CalendarTool.addEvent(
                        appContext, title, start, end!!,
                        args.optString("notes"), args.optString("location"),
                        args.optBoolean("all_day", false)
                    ).fold(
                        onSuccess = { id -> JSONObject().put("status", "ok").put("event_id", id) },
                        onFailure = { e ->
                            val msg = if (e is SecurityException) "Takvim izni verilmemiş, kullanıcıya uygulama izinlerinden Takvim iznini açmasını söyle."
                                else "Takvim etkinliği eklenemedi: ${e.message}"
                            JSONObject().put("status", "error").put("message", msg)
                        }
                    )
                }
            }
            "delete_calendar_event" -> {
                val title = args.optString("title").trim()
                if (title.isBlank()) {
                    JSONObject().put("status", "error").put("message", "title boş olamaz")
                } else {
                    CalendarTool.deleteEventsByTitle(appContext, title, args.optBoolean("delete_all_matches", false)).fold(
                        onSuccess = { n ->
                            if (n > 0) JSONObject().put("status", "ok").put("deleted", n)
                            else JSONObject().put("status", "error").put("message", "Eşleşen etkinlik bulunamadı")
                        },
                        onFailure = {
                            JSONObject().put("status", "error").put("message", "Takvim izni verilmemiş, kullanıcıya uygulama izinlerinden Takvim iznini açmasını söyle.")
                        }
                    )
                }
            }
            "analyze_webcam" -> {
                val question = args.optString("question")
                val bytes = runBlocking { onCaptureWebcam?.invoke() }
                if (bytes == null) {
                    JSONObject().put("status", "error").put("message", "Kamera açılamadı -- kamera izni verilmemiş olabilir, kullanıcıya uygulama izinlerinden Kamera iznini açmasını söyle.")
                } else {
                    val result = runBlocking { VisionAnalyzer.analyze(apiKey, bytes, question) }
                    result.fold(
                        onSuccess = { desc -> JSONObject().put("status", "ok").put("description", desc) },
                        onFailure = { e -> JSONObject().put("status", "error").put("message", "Görüntü analiz edilemedi: ${e.message}") }
                    )
                }
            }
            "analyze_screen" -> {
                val question = args.optString("question")
                val bytes = runBlocking { onCaptureScreen?.invoke() }
                if (bytes == null) {
                    JSONObject().put("status", "error").put("message", "Ekran yakalanamadı -- ekran kaydı izni verilmemiş olabilir, kullanıcıya uygulamayı kapatıp tekrar açtığında çıkan ekran kaydı izni penceresini onaylaması gerektiğini söyle.")
                } else {
                    val result = runBlocking { VisionAnalyzer.analyze(apiKey, bytes, question) }
                    result.fold(
                        onSuccess = { desc -> JSONObject().put("status", "ok").put("description", desc) },
                        onFailure = { e -> JSONObject().put("status", "error").put("message", "Ekran analiz edilemedi: ${e.message}") }
                    )
                }
            }
            "set_alarm" -> {
                val hour = args.optInt("hour", -1)
                val minute = args.optInt("minute", -1)
                if (hour !in 0..23 || minute !in 0..59) {
                    JSONObject().put("status", "error").put("message", "hour (0-23) ve minute (0-59) geçerli olmalı")
                } else {
                    val ok = PhoneControlTool.setAlarm(appContext, hour, minute, args.optString("label"))
                    if (ok) JSONObject().put("status", "ok")
                    else JSONObject().put("status", "error").put("message", "Alarm kurulamadı, cihazda bir Saat uygulaması olmayabilir")
                }
            }
            "open_app" -> {
                val appName = args.optString("app_name").trim()
                if (appName.isBlank()) {
                    JSONObject().put("status", "error").put("message", "app_name boş olamaz")
                } else {
                    when (val result = PhoneControlTool.openOrOfferInstall(appContext, appName)) {
                        is PhoneControlTool.OpenAppResult.Opened ->
                            JSONObject().put("status", "ok").put("action", "opened").put("app", result.appLabel)
                        is PhoneControlTool.OpenAppResult.OpenedStorePage ->
                            JSONObject().put("status", "ok").put("action", "store_page_opened").put("query", result.query)
                        PhoneControlTool.OpenAppResult.Failed ->
                            JSONObject().put("status", "error").put("message", "Uygulama açılamadı/Play Store bulunamadı")
                    }
                }
            }
            "set_volume" -> {
                val percent = args.optInt("percent", -1)
                if (percent !in 0..100) {
                    JSONObject().put("status", "error").put("message", "percent 0-100 arası olmalı")
                } else {
                    val ok = PhoneControlTool.setMediaVolume(appContext, percent)
                    if (ok) JSONObject().put("status", "ok")
                    else JSONObject().put("status", "error").put("message", "Ses ayarlanamadı")
                }
            }
            "toggle_flashlight" -> {
                val on = args.optBoolean("on", true)
                val ok = PhoneControlTool.setFlashlight(appContext, on)
                if (ok) JSONObject().put("status", "ok")
                else JSONObject().put("status", "error").put("message", "El feneri değiştirilemedi, cihazda flaş olmayabilir")
            }
            "open_wifi_settings" -> {
                val ok = PhoneControlTool.openWifiSettings(appContext)
                if (ok) JSONObject().put("status", "ok")
                else JSONObject().put("status", "error").put("message", "Wi-Fi ayarları açılamadı")
            }
            "open_bluetooth_settings" -> {
                val ok = PhoneControlTool.openBluetoothSettings(appContext)
                if (ok) JSONObject().put("status", "ok")
                else JSONObject().put("status", "error").put("message", "Bluetooth ayarları açılamadı")
            }
            "send_whatsapp_message" -> {
                val recipient = args.optString("recipient").trim()
                val message = args.optString("message").trim()
                if (recipient.isBlank() || message.isBlank()) {
                    JSONObject().put("status", "error").put("message", "recipient ve message boş olamaz")
                } else {
                    when (val result = SocialMessagingTool.sendWhatsAppMessage(appContext, recipient, message)) {
                        is SocialMessagingTool.SendResult.Opened ->
                            JSONObject().put("status", "ok").put("opened_for", result.label)
                        is SocialMessagingTool.SendResult.NoContact ->
                            JSONObject().put("status", "error").put("message", "'${result.name}' kayıtlı değil ve numaraya benzemiyor, önce save_social_contact ile kaydet ya da doğrudan numara ver")
                        SocialMessagingTool.SendResult.InvalidPhone ->
                            JSONObject().put("status", "error").put("message", "Telefon numarası geçersiz")
                        SocialMessagingTool.SendResult.Failed ->
                            JSONObject().put("status", "error").put("message", "WhatsApp açılamadı")
                    }
                }
            }
            "open_instagram_dm" -> {
                val recipient = args.optString("recipient").trim()
                when (val result = SocialMessagingTool.openInstagramDm(appContext, recipient)) {
                    is SocialMessagingTool.DmResult.Opened ->
                        JSONObject().put("status", "ok").put("opened_for", result.username)
                    SocialMessagingTool.DmResult.NoContact ->
                        JSONObject().put("status", "error").put("message", "recipient boş olamaz")
                    SocialMessagingTool.DmResult.Failed ->
                        JSONObject().put("status", "error").put("message", "Instagram açılamadı")
                }
            }
            "open_tiktok_profile" -> {
                val recipient = args.optString("recipient").trim()
                when (val result = SocialMessagingTool.openTikTokProfile(appContext, recipient)) {
                    is SocialMessagingTool.DmResult.Opened ->
                        JSONObject().put("status", "ok").put("opened_for", result.username)
                    SocialMessagingTool.DmResult.NoContact ->
                        JSONObject().put("status", "error").put("message", "recipient boş olamaz")
                    SocialMessagingTool.DmResult.Failed ->
                        JSONObject().put("status", "error").put("message", "TikTok açılamadı")
                }
            }
            "save_social_contact" -> {
                val platformStr = args.optString("platform").trim().lowercase()
                val platform = SocialMessagingTool.Platform.values().firstOrNull { it.key == platformStr }
                val savedName = args.optString("name").trim()
                val handle = args.optString("handle").trim()
                if (platform == null) {
                    JSONObject().put("status", "error").put("message", "platform whatsapp/instagram/tiktok olmalı")
                } else {
                    val ok = SocialMessagingTool.saveContact(appContext, platform, savedName, handle)
                    if (ok) JSONObject().put("status", "ok")
                    else JSONObject().put("status", "error").put("message", "name ve handle boş olamaz")
                }
            }
            "browser_control" -> {
                when (args.optString("action")) {
                    "go_back" -> when (BrowserController.goBack()) {
                        BrowserController.Result.OK -> JSONObject().put("status", "ok")
                        BrowserController.Result.NO_ACTIVE_BROWSER -> JSONObject().put("status", "error").put("message", "Açık bir tarayıcı penceresi yok")
                        BrowserController.Result.NOT_POSSIBLE -> JSONObject().put("status", "error").put("message", "Gidilecek önceki bir sayfa yok")
                    }
                    "go_forward" -> when (BrowserController.goForward()) {
                        BrowserController.Result.OK -> JSONObject().put("status", "ok")
                        BrowserController.Result.NO_ACTIVE_BROWSER -> JSONObject().put("status", "error").put("message", "Açık bir tarayıcı penceresi yok")
                        BrowserController.Result.NOT_POSSIBLE -> JSONObject().put("status", "error").put("message", "Gidilecek sonraki bir sayfa yok")
                    }
                    "reload" -> when (BrowserController.reload()) {
                        BrowserController.Result.OK -> JSONObject().put("status", "ok")
                        else -> JSONObject().put("status", "error").put("message", "Açık bir tarayıcı penceresi yok")
                    }
                    "search" -> {
                        val q = args.optString("query").trim()
                        if (q.isBlank()) {
                            JSONObject().put("status", "error").put("message", "query boş olamaz")
                        } else {
                            val searchUrl = "https://www.google.com/search?q=${java.net.URLEncoder.encode(q, "UTF-8")}"
                            onOpenSite?.invoke(searchUrl, "Google: $q")
                            JSONObject().put("status", "ok")
                        }
                    }
                    else -> JSONObject().put("status", "error").put("message", "action go_back/go_forward/reload/search olmalı")
                }
            }
            "get_youtube_channel_report" -> {
                val channel = args.optString("channel").trim()
                if (channel.isBlank()) {
                    JSONObject().put("status", "error").put("message", "channel boş olamaz")
                } else if (youtubeApiKey.isBlank()) {
                    JSONObject().put("status", "error").put("message", "NEEDS_KEY: YouTube API anahtarı girilmemiş, kullanıcıdan iste ve save_youtube_api_key ile kaydet")
                } else {
                    val result = runBlocking {
                        YouTubeStatsTool.getChannelReport(
                            youtubeApiKey, channel, args.optString("query"), args.optInt("video_limit", 6)
                        )
                    }
                    result.fold(
                        onSuccess = { report -> JSONObject().put("status", "ok").put("report", report) },
                        onFailure = { e -> JSONObject().put("status", "error").put("message", e.message ?: "YouTube raporu alınamadı") }
                    )
                }
            }
            "save_youtube_api_key" -> {
                val newKey = args.optString("key").trim()
                if (newKey.isBlank()) {
                    JSONObject().put("status", "error").put("message", "key boş olamaz")
                } else {
                    youtubeApiKey = newKey
                    try { onSaveYoutubeApiKey?.invoke(newKey) } catch (e: Exception) { Log.w(TAG, "onSaveYoutubeApiKey", e) }
                    JSONObject().put("status", "ok")
                }
            }
            "sys_info" -> {
                val q = args.optString("query", "all")
                JSONObject().put("status", "ok").put("info", SysInfoTool.query(appContext, q))
            }
            "set_wakeword_listening" -> {
                val enabled = args.optBoolean("enabled", true)
                WakeWordService.setEnabled(appContext, enabled)
                try { onWakeWordChanged?.invoke(enabled) } catch (e: Exception) { Log.w(TAG, "onWakeWordChanged", e) }
                JSONObject().put("status", "ok").put("enabled", enabled)
            }
            else -> JSONObject().put("status", "error").put("message", "Bilinmeyen fonksiyon: $name")
        }
    } catch (e: Exception) {
        JSONObject().put("status", "error").put("message", e.message ?: "bilinmeyen hata")
    }
}
