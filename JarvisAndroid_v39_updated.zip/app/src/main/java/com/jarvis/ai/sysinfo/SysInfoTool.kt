package com.jarvis.ai.sysinfo

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.StatFs
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Windows Jarvis V3'teki actions/sys_info.py'nin Android karşılığı. Aynı
 * query sözlüğü kullanılıyor: battery/pil, cpu/işlemci, ram/bellek/memory,
 * disk/depolama, time/saat/zaman, date/tarih, network/ağ/wifi, all.
 *
 * NOT: Android 8+ itibarıyla üçüncü parti bir uygulama sistem GENELİNDEKİ
 * CPU kullanım yüzdesini (Windows'taki psutil.cpu_percent gibi) GÜVENİLİR
 * bir şekilde okuyamıyor -- /proc/stat erişimi çoğu cihazda/ROM'da
 * kısıtlanmış. Bu yüzden cpu sorgusu sadece çekirdek sayısını (her zaman
 * doğru, izin gerektirmez) döner; okunabiliyorsa ek olarak kaba bir
 * kullanım yüzdesi de eklenir.
 */
object SysInfoTool {
    private const val TAG = "SysInfoTool"

    fun query(context: Context, rawQuery: String): String {
        val q = rawQuery.trim().lowercase()
        val results = mutableListOf<String>()

        if (q in setOf("battery", "pil", "all")) results += battery(context)
        if (q in setOf("cpu", "işlemci", "all")) results += cpu()
        if (q in setOf("ram", "bellek", "memory", "all")) results += ram(context)
        if (q in setOf("disk", "depolama", "all")) results += disk()
        if (q in setOf("time", "saat", "zaman", "all")) results += "Saat: ${timeNow()}"
        if (q in setOf("date", "tarih", "all")) results += "Tarih: ${dateNow()}"
        if (q in setOf("network", "ağ", "ag", "wifi", "all")) results += network(context)

        if (results.isEmpty()) {
            return "Bilinmeyen sorgu: $rawQuery. battery/cpu/ram/disk/time/date/network/all kullan."
        }
        return results.filter { it.isNotBlank() }.joinToString("\n")
    }

    private fun battery(context: Context): String {
        return try {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus = context.registerReceiver(null, filter) ?: return "Pil bilgisi alınamadı."
            val level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            if (level < 0 || scale <= 0) return "Pil bilgisi alınamadı."
            val pct = (level * 100 / scale.toFloat())
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            "Pil: %${pct.toInt()} — ${if (charging) "Şarj oluyor" else "Pilde"}"
        } catch (e: Exception) {
            Log.w(TAG, "battery", e)
            "Pil bilgisi alınamadı."
        }
    }

    private fun cpu(): String {
        val cores = Runtime.getRuntime().availableProcessors()
        val usage = try { readOverallCpuUsagePercent() } catch (e: Exception) { null }
        return if (usage != null) {
            "CPU: %${"%.1f".format(Locale("tr", "TR"), usage)} kullanım — $cores çekirdek"
        } else {
            "CPU: $cores çekirdek (anlık kullanım yüzdesi bu cihazda okunamıyor)"
        }
    }

    /**
     * /proc/stat çoğu cihazda 3. parti uygulamalara kapalı (Android 8+),
     * ama bazı üreticilerde hâlâ okunabiliyor -- iki anlık örnek arasındaki
     * farktan kaba bir kullanım yüzdesi hesaplanır. Okunamazsa null döner,
     * uygulama kırılmaz.
     */
    private fun readOverallCpuUsagePercent(): Float? {
        fun readTicks(): LongArray? {
            val line = java.io.RandomAccessFile("/proc/stat", "r").use { it.readLine() } ?: return null
            val parts = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (parts.size < 4) return null
            val idle = parts[3]
            val total = parts.sum()
            return longArrayOf(idle, total)
        }
        val first = readTicks() ?: return null
        Thread.sleep(200)
        val second = readTicks() ?: return null
        val idleDelta = (second[0] - first[0]).toFloat()
        val totalDelta = (second[1] - first[1]).toFloat()
        if (totalDelta <= 0) return null
        return (1f - idleDelta / totalDelta) * 100f
    }

    private fun ram(context: Context): String {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val info = ActivityManager.MemoryInfo()
            am.getMemoryInfo(info)
            val totalGb = info.totalMem / (1024.0 * 1024 * 1024)
            val usedGb = (info.totalMem - info.availMem) / (1024.0 * 1024 * 1024)
            val pct = ((info.totalMem - info.availMem) * 100.0 / info.totalMem)
            "RAM: %.1fGB / %.1fGB kullanımda (%%%.0f)".format(Locale("tr", "TR"), usedGb, totalGb, pct)
        } catch (e: Exception) {
            Log.w(TAG, "ram", e)
            "RAM bilgisi alınamadı."
        }
    }

    private fun disk(): String {
        return try {
            val stat = StatFs(android.os.Environment.getDataDirectory().path)
            val total = stat.totalBytes / (1024.0 * 1024 * 1024)
            val free = stat.availableBytes / (1024.0 * 1024 * 1024)
            val used = total - free
            "Depolama: %.1fGB kullanıldı, %.1fGB boş (toplam %.1fGB)".format(Locale("tr", "TR"), used, free, total)
        } catch (e: Exception) {
            Log.w(TAG, "disk", e)
            "Depolama bilgisi alınamadı."
        }
    }

    private fun timeNow(): String =
        SimpleDateFormat("HH:mm:ss", Locale("tr", "TR")).format(Date())

    private fun dateNow(): String =
        SimpleDateFormat("d MMMM yyyy, EEEE", Locale("tr", "TR")).format(Date())

    private fun network(context: Context): String {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val active = cm.activeNetwork ?: return "Ağ bağlantısı bulunamadı."
            val caps = cm.getNetworkCapabilities(active) ?: return "Ağ bağlantısı bulunamadı."
            val type = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WiFi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobil veri"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                else -> "Bilinmeyen ağ"
            }
            val ip = localIp()
            "Ağ: $type bağlı" + (if (ip.isNotBlank()) " — IP $ip" else "")
        } catch (e: Exception) {
            Log.w(TAG, "network", e)
            "Ağ bilgisi alınamadı."
        }
    }

    private fun localIp(): String {
        return try {
            java.net.NetworkInterface.getNetworkInterfaces().asSequence()
                .flatMap { it.inetAddresses.asSequence() }
                .firstOrNull { !it.isLoopbackAddress && it.hostAddress?.contains(":") == false }
                ?.hostAddress.orEmpty()
        } catch (e: Exception) {
            ""
        }
    }
}
