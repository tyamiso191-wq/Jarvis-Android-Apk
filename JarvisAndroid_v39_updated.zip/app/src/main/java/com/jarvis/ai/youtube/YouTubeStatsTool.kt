package com.jarvis.ai.youtube

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.NumberFormat
import java.time.Duration
import java.time.Instant
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Windows Jarvis V3'teki actions/youtube_stats.py -> get_youtube_channel_report
 * fonksiyonunun Android/Kotlin karşılığı. AYNI mantık: YouTube Data API v3
 * (herkese açık istatistikler -- abone/izlenme/video sayısı, son videoların
 * ortalama performansı, en güçlü video, yayın temposu, kaba bir trend
 * cümlesi). Studio'ya özel veriler (izlenme süresi, CTR, gelir vb.)
 * herkese açık API ile alınamıyor -- Windows'taki gibi burada da bu net
 * bir şekilde belirtiliyor.
 *
 * API ANAHTARI: Gemini anahtarıyla AYNI Google Cloud projesinde "YouTube
 * Data API v3" servisi ayrıca ETKİNLEŞTİRİLMİŞSE aynı anahtar burada da
 * çalışır (Gemini anahtarı otomatik olarak bunu içermez, kullanıcı Google
 * Cloud Console'dan bir kere açmalı). Etkin değilse net bir hata mesajı
 * döner, uygulama kırılmaz.
 */
object YouTubeStatsTool {
    private const val TAG = "YouTubeStatsTool"
    private const val API_ROOT = "https://www.googleapis.com/youtube/v3"
    private val CHANNEL_ID_RE = Regex("^UC[a-zA-Z0-9_-]{22}$")
    private val ISO_DURATION_RE = Regex("PT(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?")

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val nf = NumberFormat.getInstance(Locale("tr", "TR"))
    private fun fmt(n: Long): String = nf.format(n)

    private fun parseDurationSeconds(raw: String?): Long {
        val m = ISO_DURATION_RE.find(raw.orEmpty()) ?: return 0
        val h = m.groupValues[1].toLongOrNull() ?: 0
        val min = m.groupValues[2].toLongOrNull() ?: 0
        val s = m.groupValues[3].toLongOrNull() ?: 0
        return h * 3600 + min * 60 + s
    }

    private fun formatDuration(raw: String?): String {
        val total = parseDurationSeconds(raw)
        if (total <= 0) return ""
        val h = total / 3600
        val min = (total % 3600) / 60
        val s = total % 60
        return when {
            h > 0 -> "${h}s ${min}dk"
            min > 0 -> "${min}dk ${s.toString().padStart(2, '0')}sn"
            else -> "${s}sn"
        }
    }

    private fun daysAgoText(publishedAt: String?): String {
        if (publishedAt.isNullOrBlank()) return ""
        return try {
            val published = Instant.parse(publishedAt)
            val days = ChronoUnit.DAYS.between(published, Instant.now())
            when {
                days <= 0 -> "bugün"
                days == 1L -> "dün"
                else -> "$days gün önce"
            }
        } catch (e: Exception) {
            ""
        }
    }

    /** @return Pair(filterName, filterValue) -- filterName "forHandle" ya da "id". */
    private fun normalizeChannelRef(raw: String): Pair<String, String>? {
        val value = raw.trim()
        if (value.isBlank()) return null
        if (value.startsWith("@")) return "forHandle" to value
        if (CHANNEL_ID_RE.matches(value)) return "id" to value
        if (value.startsWith("http://") || value.startsWith("https://")) {
            try {
                val uri = java.net.URI(value)
                val host = uri.host?.lowercase().orEmpty()
                if (host in setOf("youtube.com", "www.youtube.com", "m.youtube.com")) {
                    val path = uri.path.trim('/')
                    if (path.startsWith("@")) return "forHandle" to path
                    if (path.startsWith("channel/")) {
                        val id = path.substringAfter("channel/").trim()
                        if (id.isNotBlank()) return "id" to id
                    }
                }
            } catch (e: Exception) { /* düşer, aşağıda handle gibi denenir */ }
        }
        return "forHandle" to (if (value.startsWith("@")) value else "@$value")
    }

    private fun apiGet(endpoint: String, params: Map<String, String>, apiKey: String): JSONObject {
        val urlBuilder = "$API_ROOT/$endpoint".toHttpUrlOrNull()!!.newBuilder()
        params.forEach { (k, v) -> urlBuilder.addQueryParameter(k, v) }
        urlBuilder.addQueryParameter("key", apiKey)
        val req = Request.Builder().url(urlBuilder.build()).build()
        client.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            val json = try { JSONObject(raw) } catch (e: Exception) { JSONObject() }
            if (resp.isSuccessful) return json
            val error = json.optJSONObject("error")
            val reason = error?.optJSONArray("errors")?.optJSONObject(0)?.optString("reason").orEmpty()
            val message = error?.optString("message").orEmpty()
            throw when {
                reason == "keyInvalid" -> IllegalStateException("YouTube API anahtarı geçersiz görünüyor.")
                reason == "quotaExceeded" -> IllegalStateException("YouTube API kotası şu anda dolu görünüyor.")
                reason == "accessNotConfigured" || reason == "forbidden" ->
                    IllegalStateException("YouTube Data API bu anahtar için aktif değil -- Google Cloud Console'dan 'YouTube Data API v3'ü etkinleştir.")
                resp.code == 404 -> IllegalStateException("YouTube verisi bulunamadı.")
                else -> IllegalStateException(message.ifBlank { "YouTube API hatası (${resp.code})." })
            }
        }
    }

    private data class VideoInfo(
        val id: String, val title: String, val publishedAt: String,
        val views: Long = 0, val likes: Long = 0, val comments: Long = 0, val duration: String = ""
    )

    private fun fetchRecentVideos(uploadsPlaylistId: String, apiKey: String, limit: Int): List<VideoInfo> {
        val playlistPayload = apiGet(
            "playlistItems",
            mapOf(
                "part" to "snippet,contentDetails",
                "playlistId" to uploadsPlaylistId,
                "maxResults" to limit.coerceIn(1, 10).toString()
            ),
            apiKey
        )
        val items = playlistPayload.optJSONArray("items") ?: return emptyList()
        val orderedIds = mutableListOf<String>()
        val byId = mutableMapOf<String, VideoInfo>()
        for (i in 0 until items.length()) {
            val item = items.optJSONObject(i) ?: continue
            val snippet = item.optJSONObject("snippet") ?: JSONObject()
            val details = item.optJSONObject("contentDetails") ?: JSONObject()
            val videoId = details.optString("videoId").ifBlank {
                snippet.optJSONObject("resourceId")?.optString("videoId").orEmpty()
            }
            if (videoId.isBlank()) continue
            orderedIds += videoId
            byId[videoId] = VideoInfo(videoId, snippet.optString("title"), snippet.optString("publishedAt"))
        }
        if (orderedIds.isEmpty()) return emptyList()

        val videosPayload = apiGet(
            "videos",
            mapOf("part" to "snippet,statistics,contentDetails", "id" to orderedIds.joinToString(",")),
            apiKey
        )
        val vItems = videosPayload.optJSONArray("items")
        if (vItems != null) {
            for (i in 0 until vItems.length()) {
                val item = vItems.optJSONObject(i) ?: continue
                val vid = item.optString("id")
                if (!byId.containsKey(vid)) continue
                val snippet = item.optJSONObject("snippet") ?: JSONObject()
                val stats = item.optJSONObject("statistics") ?: JSONObject()
                val details = item.optJSONObject("contentDetails") ?: JSONObject()
                byId[vid] = byId[vid]!!.copy(
                    title = snippet.optString("title").ifBlank { byId[vid]!!.title },
                    publishedAt = snippet.optString("publishedAt").ifBlank { byId[vid]!!.publishedAt },
                    views = stats.optString("viewCount", "0").toLongOrNull() ?: 0,
                    likes = stats.optString("likeCount", "0").toLongOrNull() ?: 0,
                    comments = stats.optString("commentCount", "0").toLongOrNull() ?: 0,
                    duration = details.optString("duration")
                )
            }
        }
        return orderedIds.mapNotNull { byId[it] }
    }

    private fun trendSentence(videos: List<VideoInfo>): String {
        if (videos.size < 4) return ""
        val split = (videos.size / 2).coerceAtLeast(2)
        val recent = videos.take(split)
        val older = videos.drop(split)
        val recentAvg = recent.map { it.views }.average()
        val olderAvg = older.map { it.views }.average()
        if (olderAvg <= 0) return ""
        val ratio = recentAvg / olderAvg
        return when {
            ratio >= 1.18 -> "Son videolar önceki gruba göre daha güçlü performans gösteriyor."
            ratio <= 0.82 -> "Son videolar önceki gruba göre biraz daha yavaş gidiyor."
            else -> "Son videoların performansı genel olarak dengeli."
        }
    }

    /**
     * @param apiKey Google Cloud API anahtarı (YouTube Data API v3 etkin olmalı).
     * @param channelRef @handle, kanal URL'si ya da UC... kanal ID'si.
     * @param query "detay"/"analiz"/"rapor" gibi kelimeler geçerse son videoların
     * satır satır dökümü de eklenir.
     */
    suspend fun getChannelReport(
        apiKey: String, channelRef: String, query: String = "", videoLimit: Int = 6
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException(
                "YouTube istatistikleri için bir YouTube API anahtarı gerekli. Google Cloud Console'dan 'YouTube Data API v3'ü etkinleştirip anahtarı gir."
            ))
        }
        try {
            val (filterName, filterValue) = normalizeChannelRef(channelRef)
                ?: return@withContext Result.failure(IllegalStateException("Kanal adı/handle'i belirtilmedi."))

            val channelPayload = apiGet(
                "channels",
                mapOf("part" to "snippet,statistics,contentDetails", filterName to filterValue, "maxResults" to "1"),
                apiKey
            )
            val channel = channelPayload.optJSONArray("items")?.optJSONObject(0)
                ?: return@withContext Result.failure(IllegalStateException("YouTube kanalını bulamadım: '$filterValue'."))

            val snippet = channel.optJSONObject("snippet") ?: JSONObject()
            val statistics = channel.optJSONObject("statistics") ?: JSONObject()
            val uploadsId = channel.optJSONObject("contentDetails")
                ?.optJSONObject("relatedPlaylists")?.optString("uploads").orEmpty()

            val channelTitle = snippet.optString("title", "YouTube kanalın")
            val customUrl = snippet.optString("customUrl")
            val displayHandle = customUrl.ifBlank { filterValue }.let { if (it.startsWith("@")) it else filterValue }
            val subscribers = statistics.optString("subscriberCount", "0").toLongOrNull() ?: 0
            val totalViews = statistics.optString("viewCount", "0").toLongOrNull() ?: 0
            val videoCount = statistics.optString("videoCount", "0").toLongOrNull() ?: 0

            val videos = if (uploadsId.isNotBlank()) fetchRecentVideos(uploadsId, apiKey, videoLimit) else emptyList()
            val validVideos = videos.filter { it.title.isNotBlank() && it.title != "Private video" }

            val parts = mutableListOf(
                "Herkese açık YouTube verine göre $channelTitle kanalında ${fmt(subscribers)} abone, " +
                    "${fmt(totalViews)} toplam görüntülenme ve ${fmt(videoCount)} video var."
            )
            if (displayHandle.isNotBlank()) parts += "Kanal referansı: $displayHandle."

            if (validVideos.isNotEmpty()) {
                val avgViews = validVideos.map { it.views }.average().let { Math.round(it) }
                val avgLikes = validVideos.map { it.likes }.average().let { Math.round(it) }
                val avgComments = validVideos.map { it.comments }.average().let { Math.round(it) }
                parts += "Son ${validVideos.size} videonun ortalaması ${fmt(avgViews)} izlenme, " +
                    "${fmt(avgLikes)} beğeni ve ${fmt(avgComments)} yorum."

                val best = validVideos.maxByOrNull { it.views }!!
                val bestTail = listOfNotNull(
                    daysAgoText(best.publishedAt).ifBlank { null },
                    formatDuration(best.duration).ifBlank { null }
                )
                parts += "En güçlü son video '${best.title}' - ${fmt(best.views)} izlenme" +
                    (if (bestTail.isNotEmpty()) " (${bestTail.joinToString(", ")})" else "") + "."

                val publishInstants = validVideos.mapNotNull {
                    try { Instant.parse(it.publishedAt) } catch (e: Exception) { null }
                }
                if (publishInstants.size >= 2) {
                    val gaps = publishInstants.zipWithNext { later, earlier ->
                        Duration.between(earlier, later).toMillis() / 86_400_000.0
                    }.map { Math.abs(it) }
                    if (gaps.isNotEmpty()) {
                        val avgGap = gaps.average()
                        parts += "Yayın temposu son videolarda ortalama %.1f günde bir.".format(Locale("tr", "TR"), avgGap)
                    }
                }

                trendSentence(validVideos).ifBlank { null }?.let { parts += it }

                val queryL = query.lowercase()
                if (listOf("detay", "analiz", "rapor", "son video", "son videolar").any { it in queryL }) {
                    val lines = validVideos.take(3).mapIndexed { idx, v ->
                        val tail = daysAgoText(v.publishedAt)
                        "${idx + 1}. ${v.title} - ${fmt(v.views)} izlenme, ${fmt(v.likes)} beğeni, ${fmt(v.comments)} yorum" +
                            (if (tail.isNotBlank()) " ($tail)" else "")
                    }
                    if (lines.isNotEmpty()) parts += "Son video detayı: " + lines.joinToString(" | ") + "."
                }
            }

            parts += "Not: Studio erişimi olmadan izlenme süresi, CTR, gösterim, gelir ve trafik kaynağı verilerini göremem."
            Result.success(parts.joinToString(" "))
        } catch (e: Exception) {
            Log.w(TAG, "YouTube raporu alınamadı", e)
            Result.failure(e)
        }
    }
}
