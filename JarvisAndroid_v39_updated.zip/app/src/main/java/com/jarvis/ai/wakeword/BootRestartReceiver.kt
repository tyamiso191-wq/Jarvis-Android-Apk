package com.jarvis.ai.wakeword

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Telefon yeniden başlatılınca (kullanıcı "Jarvis dinlesin" özelliğini AÇIK
 * bıraktıysa) uyandırma kelimesi dinlemesini otomatik geri başlatır.
 * Kullanıcı özelliği kapalı bıraktıysa hiçbir şey yapmaz.
 */
class BootRestartReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (WakeWordService.isEnabled(context)) {
            WakeWordService.start(context)
        }
    }
}
