package com.jarvis.ai.claude

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Groq'tan TAMAMEN AYRI, bağımsız bir istemci. SADECE GroqTextClient'ın
 * "create_game" fonksiyonu bunu kullanır: kullanıcının KENDİ Anthropic API
 * anahtarıyla gerçek bir Claude modelini çağırıp tam, çalışan bir HTML5
 * oyun/uygulama kodu ürettirir. Groq'un ücretsiz modelleri de create_zip ile
 * oyun kodu yazabiliyordu ama uzun/karmaşık oyunlarda tutarlılığı düşüktü;
 * Claude burada sadece bu tek işi (kod üretimi) yapan bir ARAÇ olarak
 * kullanılıyor -- asıl sohbeti/sesli asistanı hâlâ Groq yürütüyor.
 *
 * NOT: anahtar YOKSA ya da istek başarısız olursa GroqTextClient bunu
 * status=error olarak modele geri bildiriyor ve persona'daki talimat
 * gereği model sessizce create_zip'e (kendi ürettiği kodla) düşüyor --
 * kullanıcı bu istemcinin var olduğunu bile fark etmeyebilir.
 */
object ClaudeGameClient {
    private const val TAG = "ClaudeGameClient"
    private const val URL = "https://api.anthropic.com/v1/messages"

    // Kodlama/ajan görevleri için hız-zeka dengesi en iyi güncel model.
    private const val MODEL = "claude-sonnet-5"
    private const val API_VERSION = "2023-06-01"

    // Tam bir oyunun (CSS+JS gömülü tek HTML dosyası) kesilmeden çıkabilmesi
    // için yüksek bir üst sınır; Groq tarafındaki 8000'den daha geniş çünkü
    // burada tek seferde SADECE kod üretiliyor, sohbet/persona metni yok.
    private const val MAX_TOKENS = 16000

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        // Büyük bir oyun kodunun üretimi uzun sürebilir; Groq'un aksine
        // burada kısa sesli-sohbet gecikmesi kaygısı yok.
        .readTimeout(180, TimeUnit.SECONDS)
        .callTimeout(190, TimeUnit.SECONDS)
        .build()

    private val SYSTEM_PROMPT = """
        Sen bir HTML5 oyun/uygulama geliştiricisisin. Kullanıcının tarif
        ettiği oyunu/uygulamayı TEK bir index.html dosyası olarak, CSS
        (<style>) ve JavaScript (<script>) TAMAMEN dosyanın İÇİNE gömülü
        şekilde üret. Kesin kurallar:
        - Kod TAM ve GERÇEKTEN ÇALIŞIR olmalı; "// buraya kod gelecek" gibi
          hiçbir placeholder, eksik ya da yarım kısım OLMAMALI.
        - Kullanıcının anlattığı HER unsuru (karakterler, tema, hikaye,
          kurallar, hedef, bölüm sayısı vb.) koda gerçekten yansıt -- bilinen
          kalıp bir şablona (Snake, Flappy Bird, Pong, Breakout vb.) kaçma,
          kullanıcı özellikle bunu istemediyse.
        - Hiçbir harici bağlantı/CDN/font/görsel/ses dosyası kullanma --
          internet olmadan da tam çalışmalı. Görsel gerekiyorsa emoji, CSS
          şekilleri ya da <canvas> ile çizim kullan.
        - Dokunmatik (touch) VE klavye/tıklama kontrollerinin ikisi de
          çalışsın ki telefonda da oynanabilsin.
        - Emin olmadığın bir ayrıntı varsa (ör. tam bölüm sayısı) en mantıklı
          varsayımı kendin seç, ama konuyu değiştirip alakasız bir oyuna
          KAYMA.
        - Yanıtında SADECE ham HTML kodu olsun: açıklama, markdown kod bloğu
          (```), önsöz ya da sonsöz YAZMA. Yanıt doğrudan <!DOCTYPE html> ile
          başlayıp </html> ile bitsin.
    """.trimIndent()

    /**
     * @param apiKey kullanıcının kendi Anthropic API anahtarı (sk-ant-...)
     * @param description kullanıcının istediği oyun/uygulamanın ayrıntılı tarifi
     * @return başarılıysa tam index.html kaynak kodu
     */
    suspend fun generateGame(apiKey: String, description: String): Result<String> =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) {
                return@withContext Result.failure(IOException("Anthropic API anahtarı ayarlanmamış"))
            }
            if (description.isBlank()) {
                return@withContext Result.failure(IOException("description boş olamaz"))
            }
            try {
                val body = JSONObject().apply {
                    put("model", MODEL)
                    put("max_tokens", MAX_TOKENS)
                    put("system", SYSTEM_PROMPT)
                    put(
                        "messages",
                        JSONArray().put(
                            JSONObject().put("role", "user").put("content", description)
                        )
                    )
                }

                val req = Request.Builder()
                    .url(URL)
                    .header("x-api-key", apiKey)
                    .header("anthropic-version", API_VERSION)
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                client.newCall(req).execute().use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        return@withContext Result.failure(
                            IOException("Claude API hatası: HTTP ${resp.code}: ${raw.take(300)}")
                        )
                    }
                    val contentArr = JSONObject(raw).optJSONArray("content") ?: JSONArray()
                    val text = buildString {
                        for (i in 0 until contentArr.length()) {
                            val block = contentArr.optJSONObject(i) ?: continue
                            if (block.optString("type") == "text") {
                                append(block.optString("text"))
                            }
                        }
                    }
                    val html = extractHtml(text)
                    if (html.isBlank()) {
                        Result.failure(IOException("Claude boş/geçersiz yanıt döndürdü"))
                    } else {
                        Result.success(html)
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Oyun üretilemedi", e)
                Result.failure(e)
            }
        }

    /** Model yine de markdown kod bloğuna sarmışsa (``` ya da ```html) temizler. */
    private fun extractHtml(raw: String): String {
        var text = raw.trim()
        if (text.startsWith("```")) {
            text = text.substringAfter("\n", "").trim()
        }
        if (text.endsWith("```")) {
            text = text.substringBeforeLast("```").trim()
        }
        return text
    }
}
