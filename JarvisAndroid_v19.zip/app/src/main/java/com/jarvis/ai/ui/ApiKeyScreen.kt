package com.jarvis.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.theme.*

@Composable
fun ApiKeyScreen(
    initialAnthropicKey: String = "",
    onSave: (groqKey: String, anthropicKey: String) -> Unit
) {
    var key by remember { mutableStateOf("") }
    var anthropicKey by remember { mutableStateOf(initialAnthropicKey) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(12.dp))
                .padding(28.dp)
        ) {
            Text(
                text = "◈ J.A.R.V.I.S",
                color = Teal,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 4.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = "Başlamak için ücretsiz Groq API anahtarını gir.",
                color = Dim,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                fontFamily = FontFamily.Monospace
            )
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(
                value = key,
                onValueChange = { key = it },
                placeholder = {
                    Text("Groq API anahtarı (gsk_...)", color = Dim, fontFamily = FontFamily.Monospace)
                },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Teal,
                    unfocusedBorderColor = TealDim,
                    focusedTextColor = Text,
                    unfocusedTextColor = Text,
                    cursorColor = Teal
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(20.dp))
            Text(
                text = "İsteğe bağlı: Anthropic (Claude) API anahtarı",
                color = Dim,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = "Girilirse Jarvis senin için oyun/uygulama isteğinde gerçek Claude ile kod üretir.",
                color = Dim.copy(alpha = 0.7f),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = anthropicKey,
                onValueChange = { anthropicKey = it },
                placeholder = {
                    Text("Anthropic API anahtarı (sk-ant-...)", color = Dim, fontFamily = FontFamily.Monospace)
                },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Teal,
                    unfocusedBorderColor = TealDim,
                    focusedTextColor = Text,
                    unfocusedTextColor = Text,
                    cursorColor = Teal
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { if (key.isNotBlank()) onSave(key.trim(), anthropicKey.trim()) },
                colors = ButtonDefaults.buttonColors(containerColor = Teal, contentColor = Bg),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text(
                    "BAŞLAT",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            }
            Spacer(Modifier.height(16.dp))
            Text(
                text = "Ücretsiz anahtar: console.groq.com/keys",
                color = Dim,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Anahtarın yalnızca bu telefonda saklanır.",
                color = Dim.copy(alpha = 0.7f),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center
            )
        }
    }
}
