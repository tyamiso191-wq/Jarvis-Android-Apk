package com.jarvis.ai.image

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * AI ile görsel/fotoğraf oluşturma. API anahtarı GEREKTİRMEYEN, ücretsiz
 * Pollinations.ai text-to-image servisini kullanır: prompt URL'ye kodlanıp
 * GET ile istenince doğrudan görsel (PNG) bayt dizisi döner. Groq'un kendi
 * modellerinde görsel üretimi olmadığı için bu ayrı, bağımsız bir servis.
 */
object ImageGenClient {
    private const val TAG = "ImageGenClient"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .callTimeout(65, TimeUnit.SECONDS)
        .build()

    /**
     * @return üretilen görselin bayt dizisi, başarısız olursa null.
     */
    suspend fun generate(prompt: String, width: Int = 1024, height: Int = 1024): ByteArray? =
        withContext(Dispatchers.IO) {
            try {
                val cleanPrompt = prompt.trim().ifBlank { "abstract colorful art" }
                val encoded = URLEncoder.encode(cleanPrompt, "UTF-8").replace("+", "%20")
                // seed: her istekte farklı bir görsel üretilsin diye (aksi halde
                // aynı prompt için servis önbellekten aynı görseli döndürebiliyor).
                val seed = System.currentTimeMillis() % 1_000_000L
                val url = "https://image.pollinations.ai/prompt/$encoded" +
                    "?width=$width&height=$height&seed=$seed&nologo=true"
                val req = Request.Builder().url(url).build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        Log.w(TAG, "Görsel isteği başarısız: HTTP ${resp.code}")
                        return@withContext null
                    }
                    val bytes = resp.body?.bytes()
                    if (bytes == null || bytes.size < 500) {
                        Log.w(TAG, "Görsel çok küçük/boş döndü")
                        return@withContext null
                    }
                    bytes
                }
            } catch (e: Exception) {
                Log.w(TAG, "Görsel oluşturulamadı", e)
                null
            }
        }
}
