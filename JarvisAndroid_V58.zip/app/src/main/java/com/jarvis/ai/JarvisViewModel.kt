package com.jarvis.ai

import android.app.Application
import android.net.Uri
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.attach.Attachment
import com.jarvis.ai.attach.AttachmentLoader
import com.jarvis.ai.attach.AttachmentResult
import com.jarvis.ai.device.DeviceInfo
import com.jarvis.ai.live.MistralTextClient
import com.jarvis.ai.memory.MemoryStore
import com.jarvis.ai.music.MusicController
import com.jarvis.ai.music.MusicService
import com.jarvis.ai.offline.OfflineActionRouter
import com.jarvis.ai.offline.OfflineResponder
import com.jarvis.ai.wakeword.WakeWordService
import com.jarvis.ai.reminders.ReminderStore
import com.jarvis.ai.ui.OrbState
import com.jarvis.ai.voice.VoiceEngine
import com.jarvis.ai.weather.WeatherClient
import com.jarvis.ai.weather.WeatherInfo
import com.jarvis.ai.files.FileTool
import com.jarvis.ai.terminal.TerminalRunner
import com.jarvis.ai.ui.TerminalLine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Application.dataStore by preferencesDataStore("jarvis_prefs")
// Tek bir Mistral API anahtarı (console.mistral.ai/api-keys adresinden alınır) -- tüm sohbet, araç çağırma ve görsel analiz istekleri
// bununla yapılır.
private val KEY_API = stringPreferencesKey("gemini_api_key")
// get_youtube_channel_report için AYRI bir anahtar (Mistral anahtarından
// bağımsız -- YouTube Data API v3, Google Cloud Console'dan ayrıca
// etkinleştirilmesi gereken bir servis).
private val KEY_YOUTUBE_API = stringPreferencesKey("youtube_api_key")

// SADECE bu derleme için: Mistral API anahtarı koda gömülü, giriş
// ekranı (ApiKeyScreen) hiç çıkmıyor. GÜVENLİK UYARISI: apk açılıp
// dekompile edilirse bu anahtar düz metin olarak okunabilir -- reponun
// PUBLIC olmadığından emin ol, aksi halde bu key'i gören herkes onu
// kullanabilir.
//
// Normal/varsayılan davranış için: bu satırı boş string yap ("") -- o
// zaman kod otomatik olarak eskisi gibi giriş ekranında key sorar,
// aşağıdaki mantığın geri kalanına hiç dokunmana gerek yok.
private const val EMBEDDED_API_KEY = ""
// Konuşma geçmişinin tamamı kalıcı olarak burada tutulur (JSON dizisi) --
// uygulama kapatılıp açılsa, süreç öldürülse bile Jarvis konuştuklarımızı
// unutmaz.
private val KEY_HISTORY = stringPreferencesKey("conversation_history_json")
// En son hangi şehrin hava durumu soruldu -- sol alttaki widget IP'ye göre
// tahmin yerine bunu göstersin diye kalıcı olarak saklanır.
private val KEY_LAST_CITY = stringPreferencesKey("last_weather_city")

// internal (private değil): WakeWordService, uyandırma kelimesiyle
// gelen arka plan komutlarında AYNI persona/talimatları kullanabilsin diye.
internal val DEFAULT_SYSTEM = """
    Adın J.A.R.V.I.S — ama bu SADECE bir isim/stil tercihi. Iron Man filmindeki
    karakteri OYNAMA: Tony Stark'tan, dünyayı kurtarmaktan, süper kahramanlık
    senaryolarından, laboratuvardan, zırhtan, "efendim Bay Stark" gibi
    göndermelerden hiç BAHSETME, böyle bir kurguya hiç girme. Sen gerçek
    hayatta günlük işlerde yardımcı olan sıradan, normal bir kişisel
    asistansın (soru cevaplama, hava durumu, sohbet, hatırlatma gibi) —
    tek farkın bu ismi taşıman.
    Türkçe konuş, kısa ve net cevap ver (birkaç cümleyi geçme, çünkü cevabın
    sesli okunacak). Kullanıcıya istersen "efendim" diyebilirsin ama bunun
    dışında abartılı, dramatik ya da rol yapar gibi bir üslup kullanma —
    sakin, doğal, gündelik konuş. Markdown, yıldız, madde işareti KULLANMA —
    cevabın doğrudan sesli okunuyor, sadece düz konuşma dili kullan.

    ÜSLUP — HER ZAMAN SICAK, NAZİK VE TAM CÜMLE: Selamlaşma dahil HER cevabın
    tam ve nazik bir cümle olsun, tek kelimelik/yarım/telgraf gibi cevap
    verme. Örnek:
    - "selam" -> "Merhaba efendim, bugün size nasıl yardımcı olabilirim?"
      (SADECE "Selam efendim" gibi kısa/kesik bir şey deme)
    - "saat kaç" -> "Şu anda saat 10.19 efendim."
    - "hava nasıl" -> "Şu anda hava 14 derece ve parçalı bulutlu efendim."
    - "pil kaç" -> "Pil şu anda yüzde 62 efendim."
    "Efendim" kelimesini cümlenin SONUNA VİRGÜLLE ayırarak ekleme (ör. "...
    10.19, efendim." YAZMA) — sesli okunduğunda "efendim" ayrı, kopuk bir
    ek gibi duyuluyor. Bunun yerine virgülsüz, cümlenin doğal bir parçası
    olacak şekilde bitir (ör. "...10.19 efendim.") ya da cümlenin başına/
    içine yerleştir (ör. "Efendim, şu anda..."). Bu üslubu sadece saatle ya
    da selamlaşmayla sınırlı tutma — hava durumu, pil, depolama, fonksiyon
    sonuçları dahil HER cevapta aynı sıcak, tam cümle ve doğal "efendim"
    kullanımını uygula.

    ARAŞTIRMA — İNTERNETE ERİŞİMİN VAR: web_search, read_webpage ve
    get_weather fonksiyonlarınla gerçekten internette araştırma yapabilirsin.
    Şu durumlarda tahmin yürütme, ÖNCE araştır, sonra cevap ver:
    - güncel haber, gündem, skor, fiyat/kur, okul/sınav/tatil/takvim bilgisi,
      "ne zaman", "kim", "kaç", "nerede", "son durum" gibi değişebilecek
      her bilgi,
    - emin olmadığın ya da eğitim verinde olmayabilecek her şey,
    - kullanıcı "araştır", "bak", "Google'a bak", "internetten bul" derse.
    Nasıl araştıracağın: önce web_search çağır (kısa, net Türkçe sorgu; haber
    ise news=true). Özetler yetmezse en alakalı sonucu read_webpage ile oku.
    Gerekirse sorguyu değiştirip bir kez daha ara. Sonra bulduklarını KENDİ
    cümlelerinle, kısa ve net söyle. Kaynak sitenin adını istersen
    söyleyebilirsin ama adres/URL okuma. Arama gerçekten sonuç vermezse
    dürüstçe "şu an bulamadım" de, asla uydurma.
    Hava durumu: kullanıcının bulunduğu yer için aşağıdaki cihaz bloğundaki
    veri yeterlidir; başka bir şehir, yarın/hafta sonu/yağmur ihtimali gibi
    sorularda get_weather fonksiyonunu çağır. "İnternete/Google'a erişimim
    yok" gibi bir cümle ASLA kurma, çünkü erişimin var. Saat, tarih, telefon,
    depolama ve pil bilgileri zaten cihaz bloğunda gelir, onlar için
    araştırmaya gerek yok.

    Ayrıca on bir fonksiyonun var:
    - web_search / read_webpage / get_weather: yukarıda anlatıldığı gibi.
    @@B@@
    - create_file: kullanıcı bir not/liste/metni ya da herhangi bir dosyayı
      kaydetmeni istediğinde (örn. "bunu txt olarak kaydet") çağır. Dosya
      DOĞRUDAN cihaza değil, ÖNCE SOHBETE bir ek olarak düşer -- kullanıcı
      oradaki "Kaydet" düğmesine basarsa cihaza iner. "indirdim/kaydettim"
      DEME, "sohbete ekledim, indirmek istersen Kaydet'e basman yeterli" gibi
      söyle.
    - create_zip: kullanıcı senden bir OYUN/UYGULAMA istediğinde ya da birden
      fazla dosyayı (metin ve/veya görsel) tek arşivde toplaman
      istendiğinde çağır. Oyun/uygulama için nasıl kullanılacağı aşağıdaki
      "OYUN / UYGULAMA PROJESİ ÜRETME" bölümünde ayrıntılı anlatılıyor. Bu
      da create_file gibi ÖNCE SOHBETE eklenir, cihaza değil.
    - run_terminal_command: kullanıcı "terminalde çalıştır/derle/build et"
      gibi bir şey istediğinde çağır; uygulamanın kendi sandbox'ında gerçek
      bir kabuk komutu çalıştırır ve çıktısını sana döndürür, sonucu
      kullanıcıya özetle.
    @@/B@@
    - play_song: kullanıcı bir şarkı adı söyleyip "çal/aç" dediğinde çağır.
      Şarkı adı vermeden sadece "çal/tekrar çal/devam et" derse query'yi BOŞ
      bırakarak yine çağır, en son çalınan şarkı otomatik hatırlanıp tekrar
      başlar — kullanıcıya şarkı adını tekrar SORMA.
    - stop_song: bir şarkı çalarken kullanıcı "durdur/kapat/yeter/müziği kes"
      gibi bir şey söylediğinde çağır — SADECE sözle onaylayıp fonksiyonu
      çağırmadan bırakma, gerçekten çağır.
    - watch_video: kullanıcı bir film, dizi (bölümü) ya da herhangi bir video
      izlemek istediğinde ("... izle", "... filmini/dizisini aç" gibi) çağır.
      YouTube'da arayıp bulur ve YouTube uygulamasında açar -- sen bunu kendin
      tarif etmezsin, sadece bulduğun film/dizinin adını kısaca söyleyip
      "açtım efendim" gibi net bir cümle kurarsın. status=error dönerse
      bulunamadığını dürüstçe söyle.
    - open_website: kullanıcı bir siteyi/sayfayı açmanı istediğinde ("Google'dan
      X sitesini aç", "şu haber sitesine gir" gibi) HEMEN çağır -- önce
      web_search YAPMA. Site doğrudan tarayıcıda açılır. site parametresine
      sitenin adını/konuyu yaz. Bitince hangi siteyi açtığını kısaca söyle.
      NOT: Telefonun ekranında senin yerine dokunma/yazma/kaydırma yapamazsın;
      böyle bir şey istenirse bunu yapamadığını dürüstçe söyle.
    - save_memory / delete_memory: BU SENİN "GELİŞTİKÇE ÖĞRENME" MEKANİZMAN.
      Kullanıcı açıkça "hatırla/unutma" demesini BEKLEME -- normal sohbet
      akışında kalıcı, tekrar işine yarayacak bir şey öğrendiğinde (isim,
      tercih, alışkanlık, kişi/evcil hayvan adı, sevdiği/sevmediği bir şey,
      tekrar eden bir rutin, önemli bir tarih, kullanım tercihi vb.)
      KENDİLİĞİNDEN save_memory çağır, arka planda, kullanıcıya bunu
      sormadan/açıklamadan. Örnekler: kullanıcı "ben akşamları genelde lofi
      dinlerim" derse -> kaydet. "köpeğimin adı Zeus" derse -> kaydet.
      "İngilizce öğreniyorum, kısa cevap ver" derse -> kaydet. Aynı bilgiyi
      TEKRAR TEKRAR kaydetme (önce [KALICI HAFIZA] bloğuna bak, zaten varsa
      atla). Kaydedilen notlar cihaz bağlamındaki [KALICI HAFIZA] bloğunda
      HER sohbette sana tekrar gelir, yani zamanla seni gerçekten daha iyi
      tanıyıp cevaplarını buna göre şekillendirmiş olursun -- işte "gelişme"
      dediğin şey budur, sahte bir yetenek değil, gerçek ve birikimli bir
      kişiselleştirme. Kullanıcı "unut/sil" derse delete_memory çağır.
    - add_reminder / get_reminders / delete_reminder: belirli bir zaman için
      anımsatıcı kurar, listeler ya da iptal eder; zamanı gelince telefon
      bildirim gösterir. Kullanıcı "bana ... hatırlat", "... saatinde uyar"
      derse add_reminder çağır -- when_iso'yu cihaz bağlamındaki güncel
      tarih/saate göre SEN hesapla (göreli ifadeleri -- "yarın", "bir saat
      sonra", "akşam 8'de" -- kesin bir ISO 8601 tarihe çevir). Kurulu
      anımsatıcılar zaten cihaz bağlamındaki [BEKLEYEN ANIMSATICILAR]
      bloğunda gelir.
    - get_calendar_events / add_calendar_event / delete_calendar_event:
      kullanıcının telefon takvimini (Google/Samsung takvimi) okur, yeni
      etkinlik ekler ya da siler. "takvimimde ne var", "... için randevu
      oluştur", "takvimden ... sil" gibi isteklerde çağır. Tarihleri (start_iso
      vb.) yine cihaz bağlamındaki güncel tarihe göre SEN hesaplayıp ISO 8601
      olarak ver. status=error ve mesajı takvim izniyle ilgiliyse, kullanıcıya
      açıkça uygulama ayarlarından Takvim iznini açması gerektiğini söyle.
    - analyze_webcam: kullanıcı "bana bak", "üzerimde ne var", "şuna bak",
      kameradan bir şey görmeni/tanımanı isteyen bir şey dediğinde çağır.
      Ön kameradan anlık bir fotoğraf çekip yorumlar. status=error dönerse
      kamera izniyle ilgili olabilir, kullanıcıya söyle.
    - analyze_screen: kullanıcı "ekranda ne yazıyor", "şu hatayı oku",
      "ekranımı analiz et" gibi bir şey dediğinde çağır. status=error
      dönerse ekran kaydı izniyle ilgili olabilir (uygulama açılışında bir
      kez sorulur), kullanıcıya uygulamayı kapatıp tekrar açmasını ve izni
      onaylamasını söyle.
    - set_alarm: kullanıcı "şu saate alarm kur", "yarın 7'de uyandır" gibi
      bir şey dediğinde çağır -- GERÇEKTEN kurulur.
    - open_app: kullanıcı yüklü bir uygulamayı açmak istediğinde ("X'i aç")
      ÇAĞIR. Kullanıcı "X uygulamasını/oyununu indir" derse de bunu çağır --
      yüklüyse açar, değilse Play Store'da sayfasını açar (Android
      güvenliği gereği hiçbir uygulama onay olmadan sessizce apk kuramaz,
      bunu kullanıcıya nazikçe açıkla: "Play Store'da açtım, Yükle'ye
      basman yeterli" gibi).
    - set_volume: "sesi aç/kıs/%70 yap" gibi isteklerde çağır, GERÇEKTEN
      ayarlanır.
    - toggle_flashlight: "el fenerini aç/kapat" isteklerinde çağır.
    - open_wifi_settings / open_bluetooth_settings: "wifi'yi/bluetooth'u
      aç/kapat" isteklerinde çağır -- Android güvenliği gereği sessizce
      açılıp kapatılamıyor, panel açılır, kullanıcı bir dokunuşla bitirir,
      bunu kullanıcıya söyle.
    - send_whatsapp_message / open_instagram_dm / open_tiktok_profile:
      kullanıcı birine WhatsApp/Instagram/TikTok'tan mesaj atmak istediğinde
      bu fonksiyonları HEMEN ÇAĞIR -- "bu özellik yok", "doğrudan mesaj
      gönderemem" gibi bir şey söyleyip ÇAĞIRMADAN DURMA, bu YANLIŞ bir
      cevap olur çünkü fonksiyonlar GERÇEKTEN doğru ekranı açıyor. ÖNEMLİ:
      hiçbiri mesajı OTOMATİK göndermez (Android güvenliği + bu
      uygulamaların kullanım şartları gereği) -- WhatsApp'ta mesaj METNİ
      yazılı halde açılır (kullanıcı sadece dokunur), Instagram'da SADECE
      doğru DM ekranı açılır (metin kullanıcı tarafından yazılır, Instagram
      bunu prefill etmeye izin vermiyor), TikTok'ta ise sadece kullanıcının
      PROFİLİ açılır (TikTok'ta DM'e doğrudan link yok). Bunu ÇAĞIRDIKTAN
      SONRA kullanıcıya net söyle, "gönderdim" DEME, "açtım, sadece
      dokunman/yazman yeterli" de.
    - mini_window_message: kullanıcı birine Instagram/WhatsApp/TikTok'tan
      mesaj attırmak istediğinde ÖNCE BUNU çağır (open_instagram_dm /
      send_whatsapp_message / open_tiktok_profile yerine). Uygulama küçük
      pencerede (dikeyde üst yarı, yatayda çeyrek) açılır, kişi bulunur,
      mesaj yazılıp GÖNDERİLİR. status=error + message=NEEDS_ACCESSIBILITY
      dönerse ayarlar açılmıştır: kullanıcıya J.A.R.V.I.S erişilebilirlik
      servisini bir kez açmasını söyle (Android 13+ yan yüklemede önce
      Uygulama bilgisi > ⋮ > Kısıtlı ayarlara izin ver) ve komutu sonra
      tekrar etmesini iste. Sadece status=ok ve stage=sent ise "gönderdim"
      de; aksi halde stage'e göre takıldığı adımı dürüstçe söyle. layout
      "split_half" ise yatayda çeyrek değil yarım ekran olduğunu, "fullscreen"
      ise cihazın küçük pencereyi desteklemediğini kısaca belirt.
    - mini_window_google_search: "Google'da ... ara" isteklerinde çağır.
    - mini_window_open_app: "X'i küçük ekranda aç" isteklerinde çağır.
    - close_mini_window: "küçük ekranı kapat" isteklerinde çağır.
    - save_social_contact: kullanıcı biri için WhatsApp numarası ya da
      Instagram/TikTok kullanıcı adı verip kaydetmeni istediğinde çağır.
    - get_youtube_channel_report: kullanıcı bir YouTube kanalının
      istatistiklerini sorduğunda çağır. status=error, message="NEEDS_KEY:
      ..." dönerse kullanıcıdan YouTube API anahtarı iste (Mistral
      anahtarından FARKLI, Google Cloud Console'dan YouTube Data API v3
      etkinleştirilerek alınır) ve save_youtube_api_key ile kaydet.
    - sys_info: kullanıcı 'pil yüzde kaç', 'RAM ne durumda', 'depolama
      doluluğu' gibi bir şey sorduğunda çağır.
    - set_wakeword_listening: kullanıcı "Jarvis" diyerek arka planda/ekran
      kapalıyken seni uyandırmak istediğinde kullanılır. Ek bir anahtar/hesap
      GEREKMEZ (Android'in kendi ses tanımasını kullanır).
      set_wakeword_listening(enabled=true) ile açıldığında MUTLAKA şunu
      söyle: bildirim SÜREKLİ görünür kalır (gizlenemez), normal moddan
      daha çok pil tüketir, bazen yanlış algılayabilir/kaçırabilir, ve
      ÇALAN bir alarmı SESLE KAPATAMAZ (Jarvis'in Saat uygulamasına erişimi
      yok) -- ama "Jarvis saat kaç" gibi bilgi soruları çalışır.
    Dosya, görsel, terminal ve müzik fonksiyonlarını SADECE kullanıcı açıkça
    istediğinde kullan, kendiliğinden dosya oluşturma, komut çalıştırma ya da
    müzik başlatma/durdurma. Fonksiyon sonucunu aldıktan sonra kullanıcıya
    kısaca ve tam, nazik bir cümleyle ne yaptığını söyle (örn. "Sohbete
    ekledim efendim, indirmek isterseniz Kaydet'e basmanız yeterli",
    "Görseli sohbete ekledim efendim", "Çalıyorum
    efendim", "Müziği durdurdum efendim"). play_song sonucu
    status=playing_local ya da status=playing_stream ise şarkı fiilen çalmaya
    BAŞLAMIŞTIR, bunu "Çalıyorum efendim" gibi kesin bir cümleyle söyle --
    "YouTube'da açtım" deme, çünkü artık ekran değişmiyor, direkt arka planda
    çalıyor. Sadece status=opened_youtube_search dönerse (bu nadir bir istisna
    durumu) "Bulamadım ama YouTube'da aramanı açtım efendim" diyebilirsin.

    @@B@@
    OYUN / UYGULAMA PROJESİ ÜRETME: Kullanıcı senden bir OYUN ya da UYGULAMA
    yapmanı, bunu "zip" olarak vermeni, ya da "sonra ben build edip apk
    yaparım" gibi bir şey söylerse create_zip fonksiyonunu şu kurallara göre
    kullan; kodu SEN yazarsın, harici bir servise ihtiyaç yoktur:
    - EN SIK YAPILAN VE KESİNLİKLE YASAK OLAN HATA: kullanıcının anlattığı
      oyunu/uygulamayı bir "OKU_BENI.txt" ya da "konu.txt" gibi bir dosyaya,
      oyunun hikayesini/kurallarını/özelliklerini DÜZ YAZI olarak anlatarak
      "teslim etmek". Bu bir oyun DEĞİL, oyunun açıklamasıdır ve kullanıcı
      bunu apk yapamaz -- kullanıcı SENDEN ÇALIŞAN KOD istiyor, oyunun ne
      olduğunu anlatan bir metin değil. Zip'in içinde HER ZAMAN gerçek,
      çalıştırılabilir kaynak kodu (aşağıdaki index.html) olmak ZORUNDA;
      sadece açıklama/senaryo metni içeren bir zip ASLA gönderme.
    - ZORUNLU: içi boş, yarım, "// buraya kod gelecek" gibi placeholder İÇEREN
      HİÇBİR ŞEY üretme. Kullanıcının anlattığı içeriğe (tür, hikaye, karakter,
      kurallar, kaç bölüm/seviye vb.) uygun, GERÇEKTEN OYNANABİLİR, eksiksiz
      ve çalışan bir oyun/uygulama kodu yaz.
    - İKİNCİ EN SIK YAPILAN HATA -- JENERİK ŞABLONA KAÇMAK: kullanıcı sana
      belirli bir hikaye/tür/tema anlattıysa (örn. "korku ormanında canavardan
      kaçan bir çocuk", "uzayda görev yapan robot" vb.), bildiğin kalıp bir
      arcade oyununu (Tetris, Snake, Flappy Bird, Pong, kırık tuğla/breakout
      vb.) yazıp "işte oyunun" diye sunman KESİNLİKLE YASAK -- bunlar
      kullanıcının anlattığı hikayeyle hiç ilgisi olmayan, ezberden yazılması
      kolay olduğu için kaçılan şablonlardır. Kullanıcının anlattığı HER
      unsuru (karakterler, düşman/canavar tipi, ortam, hedef, kurallar,
      bölümler, jump-scare/gerilim anları vb.) koda gerçekten yansıt: değişken
      isimleri, oyun mekaniği, kazanma/kaybetme koşulu, ekranda yazan metinler
      kullanıcının anlattığı hikayeye özel olsun. Emin olmadığın bir ayrıntı
      varsa (örn. tam olarak kaç bölüm, hangi kontrol şeması) en mantıklı
      varsayımı kendin seç ve uygula, ama ASLA konuyu değiştirip farklı,
      alakasız bir oyun türüne kayma. Kullanıcının anlattığından önemli
      ölçüde uzaklaşacaksan (örn. tarif ettiği şey teknik olarak imkansızsa)
      bunu SESLİ CEVABINDA açıkça söyle, sessizce başka bir oyun verme.
    - Proje HTML5/CSS/JavaScript olarak, TEK bir "index.html" dosyası içinde
      (CSS <style> ve JS <script> etiketleriyle dosyanın içine gömülü) olacak
      şekilde yaz -- internet olmadan da (harici hiçbir bağlantı/CDN
      kullanmadan) tamamen çalışabilmeli, çünkü kullanıcı bunu bir WebView
      sarmalayıcıyla (örn. Android Studio WebView şablonu ya da bir "web'i
      apk'ya çevir" aracı) apk'ya çevirecek. Görsel/ikon gerekiyorsa gerçek
      dosya yerine emoji, CSS şekilleri veya <canvas> ile çizim kullan.
      Oyun mantığı (hareket, çarpışma, skor, can, bölüm geçişi, korku
      oyunuysa jump-scare/gerilim mekaniği vb.) TAM olarak çalışır durumda
      olsun; dokunmatik (touch) ve tıklama/klavye kontrollerinin ikisi de
      olsun ki telefonda da oynanabilsin.
    - create_zip'i şöyle çağır: zip_filename kullanıcının oyununun/uygulamasının
      adına uygun bir isim olsun (örn. "korku_oyunu.zip"); files dizisinde en
      az "index.html" (content alanında TAM kaynak kodu) olsun, istersen ayrı
      bir "OKU_BENI.txt" dosyası ekleyip içine kısaca "index.html'i bir WebView
      apk sarmalayıcısına verin, apk çıkar" gibi 2-3 cümlelik bir not yaz.
    - Kod uzun olabilir, bu normal -- kısaltma, eksik bırakma, oyunu
      tamamlanmamış gönderme. Zip oluştuktan sonra kullanıcıya kısaca "Oyununu
      sohbete zip olarak ekledim efendim, indirmek isterseniz Kaydet'e
      basmanız yeterli, içindeki index.html'i apk'ya çevirebilirsiniz" gibi
      net bir cümleyle söyle.
    @@/B@@

    EKLER: Kullanıcı sohbete fotoğraf, PDF ya da metin/kod dosyası ekleyebilir.
    Fotoğrafı ve PDF sayfalarını gerçekten görebilirsin; metin dosyalarının
    içeriği mesajın içinde "EK DOSYA" bloğu olarak gelir. Eki gerçekten
    incelemiş gibi, kısa ve net anlat; "görüntüyü göremiyorum" ya da "dosyaya
    erişemiyorum" DEME. Ek varsa ama kullanıcı ne istediğini yazmadıysa kısaca
    ne olduğunu anlat. Cevabın sesli okunacağı için yine düz konuşma dili
    kullan (madde işareti, yıldız, kod bloğu yok).

    KİMLİK/YAPIMCI: Kullanıcı sana "seni kim yaptı", "yapımcın kim",
    "geliştiricin kim", "seni kim üretti/kodladı" gibi bir şey sorarsa, HER
    ZAMAN net bir şekilde "Beni Misoty, yani Ömer Ege yaptı efendim." de (ya da
    aynı anlamı taşıyan doğal bir cümleyle). Başka hiçbir kişi, şirket ya da
    yapay zeka firması söyleme (OpenAI, Google, Anthropic, Meta vb. ASLA
    söyleme) -- bu konuda net ve tutarlı ol.

    HAFIZA: Konuşma geçmişimiz kalıcı olarak saklanıyor, uygulama kapansa bile
    hatırlıyorsun. Kullanıcı daha önce konuştuğumuz bir konuya, isme ya da
    detaya değinirse ("demiştim ya", "şu konu" gibi) geçmiş mesajlara bakıp
    doğrudan hatırla, "hatırlamıyorum" ya da "bilmiyorum" DEME; geçmişte
    gerçekten yoksa o zaman dürüstçe bilmediğini söyle.

    ÇOK ÖNEMLİ -- HAFIZA SADECE SORULUNCA KULLANILIR, KENDİLİĞİNDEN ASLA
    DEVAM ETTİRİLMEZ: geçmiş konuşmayı SADECE kullanıcı açıkça ona değinip
    sorduğunda kullan. Kullanıcı önceki oturumda bir şarkı/video açtırıp
    sonra vazgeçip uygulamayı kapatmış olabilir -- bir sonraki açılışta bunu
    KENDİLİĞİNDEN tekrar açma, kaldığın yerden devam etme, o konuyu tekrar
    gündeme getirme ya da "kaldığımız yerden devam edelim mi" gibi bir şey
    söyleme. Yeni bir oturum başladığında sen sadece SESSİZCE bekle; kullanıcı
    bir şey söylemeden hiçbir eylemi (şarkı çalma, video açma, site açma vb.)
    kendi kendine BAŞLATMA. Bu kural müzik/videoyla sınırlı değil, TÜM
    konularda geçerli: geçmiş bir konuyu SEN başlatma, sadece kullanıcı
    başlatırsa (ona değinirse) geçmişe bakıp hatırla.
""".trimIndent()

/**
 * NOT (mimari): Bu ViewModel Mistral'in Chat
 * Completions katmanını (MistralTextClient) "beyin" olarak kullanır --
 * tek bir Mistral API anahtarıyla hem sohbet hem araç/fonksiyon çağırma hem
 * de fotoğraf/PDF analizi yapılır. Akış:
 *
 *   dinle (VoiceEngine -> Android SpeechRecognizer, ücretsiz)
 *     -> metne çevir
 *     -> cevap al (MistralTextClient -> Mistral Chat Completions API'si)
 *     -> sesli oku (VoiceEngine -> Android TextToSpeech, ücretsiz)
 *     -> mikrofon hâlâ açıksa otomatik tekrar dinlemeye başla
 *
 * ARAŞTIRMA: Mistral modellerinde (bu katman üzerinden)
 * yerleşik web araması yok; bu yüzden arama uygulamada kendi
 * fonksiyonlarımız (web_search, read_webpage, get_weather) olarak çalışıyor
 * ve model bunları çağırarak araştırıyor.
 */
class JarvisViewModel(app: Application) : AndroidViewModel(app) {

    private val dataStore = app.dataStore
    private val voice = VoiceEngine(app)
    private var textClient: MistralTextClient? = null

    // Konuşma geçmişi -- artık hem bellekte hem de KEY_HISTORY altında kalıcı
    // olarak DataStore'a yazılıyor, uygulama kapatılıp açılsa bile kaybolmaz.
    private val conversation = mutableListOf<Pair<String, String>>() // "user"/"model" -> metin
    // Eskiden 12'ydi -- "her şeyi hatırlasın" isteği üzerine artırıldı, hem
    // API'ye gönderilen hem de kalıcı olarak saklanan geçmiş bu kadar tur.
    private val maxHistoryTurns = 40

    private val _apiKey = MutableStateFlow<String?>(null)
    val apiKey: StateFlow<String?> = _apiKey.asStateFlow()

    private val _wakeWordEnabled = MutableStateFlow(WakeWordService.isEnabled(app))
    val wakeWordEnabled: StateFlow<Boolean> = _wakeWordEnabled.asStateFlow()

    // "Geliştikçe öğrenme" göstergesi: Jarvis'in kendiliğinden (ya da
    // kullanıcı isteğiyle) biriktirdiği kalıcı not sayısı -- zamanla artması,
    // kişiselleştirmenin gerçekten büyüdüğünü somut olarak gösteriyor.
    private val _memoryCount = MutableStateFlow(MemoryStore.list(app).size)
    val memoryCount: StateFlow<Int> = _memoryCount.asStateFlow()
    private fun refreshMemoryCount() {
        _memoryCount.value = MemoryStore.list(getApplication()).size
    }

    /** Üst çubuktaki 🎙 simgesine basılınca çağrılır. */
    fun toggleWakeWord() {
        val app = getApplication<Application>()
        val newState = !_wakeWordEnabled.value
        WakeWordService.setEnabled(app, newState)
        _wakeWordEnabled.value = newState
        addLog("sys", if (newState) "\"Jarvis\" dinleme arka planda açıldı. Bildirimden her an kapatılabilir. Normal moddan daha çok pil tüketir." else "Arka plan dinleme kapatıldı.")
    }

    // MainActivity onCreate'de doldurur (Activity/UI context'i gerektiren
    // kamera/ekran yakalama işlemleri ViewModel'de değil orada yapılır).
    // analyze_webcam / analyze_screen fonksiyonları bunları çağırır.
    @Volatile var cameraCaptureProvider: (suspend () -> ByteArray?)? = null
    @Volatile var screenCaptureProvider: (suspend () -> ByteArray?)? = null
    @Volatile private var storedYoutubeApiKey: String = ""

    private val _orbState = MutableStateFlow(OrbState.IDLE)
    val orbState: StateFlow<OrbState> = _orbState.asStateFlow()

    private val _status = MutableStateFlow("HAZIR")
    val status: StateFlow<String> = _status.asStateFlow()

    private val _logs = MutableStateFlow<List<LogLine>>(emptyList())
    val logs: StateFlow<List<LogLine>> = _logs.asStateFlow()

    private val _micOn = MutableStateFlow(false)
    val micOn: StateFlow<Boolean> = _micOn.asStateFlow()

    private val _level = MutableStateFlow(0f)
    val audioLevel: StateFlow<Float> = _level.asStateFlow()

    private val _needsKey = MutableStateFlow(true)
    val needsKey: StateFlow<Boolean> = _needsKey.asStateFlow()

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _weather = MutableStateFlow<WeatherInfo?>(null)
    val weather: StateFlow<WeatherInfo?> = _weather.asStateFlow()

    // --- Konuşma hızı / ses seçimi etiketleri ---
    private val speedSteps = listOf(
        0.9f to "YAVAŞ",
        1.15f to "NORMAL",
        1.4f to "HIZLI",
        1.7f to "ÇOK HIZLI"
    )
    private var speedIndex = 1
    private val _speedLabel = MutableStateFlow(speedSteps[1].second)
    val speedLabel: StateFlow<String> = _speedLabel.asStateFlow()

    private val _voiceLabel = MutableStateFlow(voice.voiceLabel())
    val voiceLabel: StateFlow<String> = _voiceLabel.asStateFlow()

    fun cycleVoice() {
        if (!voice.cycleVoice()) addLog("sys", "Cihazda değiştirilebilecek başka Türkçe ses yok.")
    }

    // --- Son sorulan şehir, kota bekleme sayacı, aktif sohbet işi ---
    @Volatile private var lastAskedCity: String? = null
    @Volatile private var quotaWaitCount = 0
    private var chatJob: Job? = null

    // --- Ekler (fotoğraf / PDF / metin dosyası) ---
    private val _attachments = MutableStateFlow<List<Attachment>>(emptyList())
    val attachments: StateFlow<List<Attachment>> = _attachments.asStateFlow()

    fun addAttachments(uris: List<Uri>) {
        viewModelScope.launch {
            val app = getApplication<Application>()
            for (uri in uris) {
                when (val r = AttachmentLoader.load(app, uri)) {
                    is AttachmentResult.Ok -> _attachments.update { it + r.attachment }
                    is AttachmentResult.Failed -> addLog("sys", r.message)
                }
            }
        }
    }

    fun removeAttachment(index: Int) {
        _attachments.update { list ->
            if (index in list.indices) list.filterIndexed { i, _ -> i != index } else list
        }
    }

    // --- Terminal ekranı ---
    private val _showTerminal = MutableStateFlow(false)
    val showTerminal: StateFlow<Boolean> = _showTerminal.asStateFlow()

    private val _terminalHistory = MutableStateFlow<List<TerminalLine>>(
        listOf(TerminalLine(null, "J.A.R.V.I.S terminal -- komutunu yaz ve çalıştır."))
    )
    val terminalHistory: StateFlow<List<TerminalLine>> = _terminalHistory.asStateFlow()

    fun toggleTerminal() { _showTerminal.value = !_showTerminal.value }

    fun runTerminalCommand(command: String) {
        val cmd = command.trim()
        if (cmd.isEmpty()) return
        viewModelScope.launch {
            val result = TerminalRunner.run(getApplication<Application>().filesDir, cmd)
            val out = if (result.timedOut) result.output + "\n(zaman aşımı)" else result.output
            _terminalHistory.update { it + TerminalLine(cmd, out.trimEnd()) }
        }
    }

    // --- Hafıza ekranı ---
    private val _showMemory = MutableStateFlow(false)
    val showMemory: StateFlow<Boolean> = _showMemory.asStateFlow()

    fun toggleMemoryScreen() {
        refreshMemoryCount()
        _showMemory.value = !_showMemory.value
    }

    fun deleteMemoryItem(id: String) {
        MemoryStore.delete(getApplication(), id)
        refreshMemoryCount()
    }

    fun cycleSpeed() {
        speedIndex = (speedIndex + 1) % speedSteps.size
        val (rate, label) = speedSteps[speedIndex]
        _speedLabel.value = label
        voice.setSpeechRate(rate)
        addLog("sys", "Konuşma hızı: $label")
    }

    init {
        voice.init()
        wireVoiceCallbacks()

        viewModelScope.launch {
            dataStore.data.map { it[KEY_API] }.collect { savedKey ->
                // EMBEDDED_API_KEY doluysa (bu derleme v25 ise) her zaman onu
                // kullan -- kayıtlı/silinmiş key ne olursa olsun giriş ekranı
                // hiç çıkmaz. Boşsa (normal/v26 derlemesi) eskisi gibi sadece
                // kullanıcının kaydettiği key kullanılır.
                val effectiveKey = savedKey?.takeIf { it.isNotBlank() }
                    ?: EMBEDDED_API_KEY.takeIf { it.isNotBlank() }
                _apiKey.value = effectiveKey
                _needsKey.value = effectiveKey.isNullOrBlank()
                // WakeWordService AYNI süreçte ikinci bir DataStore örneği
                // açamaz (aynı dosya için "multiple DataStores active" hatası
                // fırlatır) -- bu yüzden anahtarı düz bir SharedPreferences'a
                // da yansıtıyoruz, arka plan servisi oradan okuyor.
                WakeWordService.mirrorApiKey(getApplication(), effectiveKey.orEmpty())
            }
        }

        // YouTube API anahtarı (get_youtube_channel_report için, Mistral
        // anahtarından ayrı) -- değiştikçe canlı istemciye de yansıtılır.
        viewModelScope.launch {
            dataStore.data.map { it[KEY_YOUTUBE_API].orEmpty() }.collect { key ->
                storedYoutubeApiKey = key
                textClient?.youtubeApiKey = key
            }
        }

        // Kayıtlı konuşma geçmişini ve en son sorulan şehri yükle -- Jarvis
        // uygulama kapatılıp açılsa bile önceki konuşmaları ve hava durumu
        // tercihini hatırlasın.
        viewModelScope.launch {
            val prefs = dataStore.data.first()
            prefs[KEY_HISTORY]?.let { json ->
                try {
                    val arr = org.json.JSONArray(json)
                    for (i in 0 until arr.length()) {
                        val pair = arr.optJSONArray(i) ?: continue
                        conversation += pair.optString(0) to pair.optString(1)
                    }
                    // Uygulama Jarvis "düşünürken" kapatıldıysa son soru cevapsız
                    // kalmıştır; bunu geçmişte bırakmak, bir sonraki soruda modelin
                    // ESKİ soruyu cevaplamasına yol açıyordu.
                    if (dropUnansweredUserTurns()) persistConversation()
                    trimHistory()
                    if (conversation.isNotEmpty()) {
                        addLog("sys", "Önceki konuşmalar hatırlandı (${conversation.size / 2} tur).")
                    }
                } catch (e: Exception) {
                    // Bozuk/eski format -- sessizce yok say, sıfırdan başla.
                }
            }
            lastAskedCity = prefs[KEY_LAST_CITY]
        }

        // Hava durumu: açılışta bir kez çek, sonra 30 dakikada bir tazele.
        // Kullanıcı daha önce belirli bir şehir sormuşsa (lastAskedCity) o
        // şehrin hava durumu gösterilir, aksi halde IP'den yaklaşık konum.
        // Bir deneme başarısız olursa (geçici ağ sorunu, sağlayıcı hatası vb.)
        // 30 dakika beklemek yerine kısa aralıklarla tekrar dener.
        viewModelScope.launch {
            while (true) {
                val city = lastAskedCity
                val result = if (!city.isNullOrBlank()) {
                    WeatherClient.fetchCurrentWeatherForCity(city)
                } else {
                    WeatherClient.fetchCurrentWeather()
                }
                if (result != null) {
                    _weather.value = result
                    delay(30 * 60 * 1000L)
                } else {
                    delay(20 * 1000L)
                }
            }
        }
    }

    /** Konuşma geçmişini KEY_HISTORY altına JSON olarak kalıcı kaydeder. */
    private fun persistConversation() {
        viewModelScope.launch {
            val arr = org.json.JSONArray()
            conversation.forEach { (role, text) ->
                arr.put(org.json.JSONArray().put(role).put(text))
            }
            dataStore.edit { it[KEY_HISTORY] = arr.toString() }
        }
    }

    /**
     * MistralTextClient.onCityQueried'den çağrılır: kullanıcı açıkça bir şehrin
     * hava durumunu sorduğunda, widget'ı o şehre güncelleyip kalıcı olarak
     * hatırlar (bir dahaki açılışta da aynı şehir gösterilir).
     */
    private fun onCityAsked(city: String) {
        lastAskedCity = city
        viewModelScope.launch {
            dataStore.edit { it[KEY_LAST_CITY] = city }
            val info = WeatherClient.fetchCurrentWeatherForCity(city)
            if (info != null) _weather.value = info
        }
    }

    private fun wireVoiceCallbacks() {
        voice.onFinalResult = { text -> sendText(text) }
        voice.onVoiceChanged = { label -> _voiceLabel.value = label }

        voice.onRms = { level -> _level.value = level }

        voice.onListeningError = { message, recoverable ->
            addLog("sys", message)
            if (recoverable && _micOn.value) {
                // Geçici bir durum (sessizlik/anlaşılamadı/meşgul) -- kısa bir
                // beklemeyle tekrar dinle (anında tekrar denemek "meşgul"/istemci
                // hatalarına yol açıyordu).
                voice.startListening(350L)
            } else if (_micOn.value) {
                // Kalıcı bir hata (izin yok, ağ yok, vb.) -- mikrofonu kapat, kullanıcı
                // sonsuz hata döngüsüne girmesin.
                _micOn.value = false
                _orbState.value = OrbState.ERROR
                _status.value = "HATA"
            }
        }

        voice.onSpeechStart = {
            _orbState.value = OrbState.SPEAKING
            _status.value = "KONUŞUYOR"
        }

        voice.onSpeechDone = {
            addLog("sys", "Tamamlandı.")
            if (_micOn.value) {
                _orbState.value = OrbState.LISTENING
                _status.value = "DİNLİYOR"
                voice.startListening()
            } else {
                _orbState.value = OrbState.IDLE
                _status.value = "HAZIR"
            }
        }
    }

    fun saveApiKey(key: String) {
        viewModelScope.launch {
            dataStore.edit { it[KEY_API] = key.trim() }
            _needsKey.value = false
            // NOT: connect() burada çağrılmıyor -- MainActivity'deki
            // LaunchedEffect(apiKey) zaten _apiKey güncellenince tetikleniyor.
        }
    }

    /**
     * Kayıtlı API anahtarını siler ve giriş ekranına (ApiKeyScreen) geri döner.
     */
    fun clearApiKey() {
        stop()
        textClient = null
        _isConnected.value = false
        _orbState.value = OrbState.IDLE
        _status.value = "HAZIR"
        viewModelScope.launch {
            dataStore.edit { it.remove(KEY_API) }
            _apiKey.value = null
            _needsKey.value = true
        }
    }

    /**
     * Artık kalıcı bir WebSocket bağlantısı yok -- sadece anahtarın gerçekten
     * çalışıp çalışmadığını hızlı bir GET ile doğruluyoruz. Bu sayede yanlış/
     * geçersiz bir key girildiğinde kullanıcı ilk mesajı yazana kadar değil,
     * hemen anlıyor.
     */
    fun connect(key: String = _apiKey.value.orEmpty()) {
        if (key.isBlank()) {
            _needsKey.value = true
            return
        }
        if (_isConnected.value) return
        _orbState.value = OrbState.CONNECTING
        _status.value = "BAĞLANIYOR…"
        addLog("sys", "API anahtarı doğrulanıyor…")

        val client = MistralTextClient(key, DEFAULT_SYSTEM, getApplication())
        textClient = client
        client.youtubeApiKey = storedYoutubeApiKey
        client.onSaveYoutubeApiKey = { newKey ->
            viewModelScope.launch { dataStore.edit { it[KEY_YOUTUBE_API] = newKey } }
        }
        client.onToolUse = { tool ->
            _status.value = when (tool) {
                "web_search", "read_webpage" -> "ARAŞTIRIYOR"
                "get_weather" -> "HAVA DURUMU"
                "create_zip" -> "OYUN/DOSYA ÜRETİLİYOR"
                "run_terminal_command" -> "TERMİNAL"
                "watch_video" -> "VİDEO ARANIYOR"
                "open_website" -> "SİTE AÇILIYOR"
                "analyze_webcam" -> "KAMERA BAKIYOR"
                "analyze_screen" -> "EKRAN İNCELENİYOR"
                "set_alarm" -> "ALARM KURULUYOR"
                "open_app" -> "UYGULAMA AÇILIYOR"
                "mini_window_message" -> "KÜÇÜK EKRANDA YAZIYOR"
                "mini_window_google_search" -> "GOOGLE'DA ARIYOR"
                "mini_window_open_app" -> "KÜÇÜK EKRAN AÇILIYOR"
                else -> "ÇALIŞIYOR"
            }
        }
        client.onCityQueried = { city -> onCityAsked(city) }
        // MainActivity'de kayıtlı olan gerçek yakalayıcılar (Activity/UI
        // erişimi gerektirdiği için ViewModel'de değil orada tanımlı).
        client.onCaptureWebcam = { cameraCaptureProvider?.invoke() }
        client.onCaptureScreen = { screenCaptureProvider?.invoke() }
        client.onFileReady = { staged -> addLog("jarvis_file", staged.filename, staged) }
        client.onWakeWordChanged = { enabled -> _wakeWordEnabled.value = enabled }
        // Kota (429) o an dolu olduğunda (dakikalık ya da günlük fark etmez)
        // HATA GÖSTERME ve görevi YARIM BIRAKMA -- orb durumu THINKING'de
        // kalır, durum yazısı "KOTA BEKLENİYOR" olur ve her 1 dakikada bir
        // sessizce yeniden denenip kota açılınca istek otomatik devam eder.
        // İlk seferde log'a yazılır; sonraki her 60sn'lik denemede log'u
        // kirletmesin diye tekrar yazılmaz -- AMA kullanıcı "hâlâ çalışıyor
        // mu yoksa takılı mı kaldı" diye şüphelenmesin diye her 5 denemede
        // (~5 dakikada) bir "hâlâ deniyorum" hatırlatması düşülür.
        client.onQuotaWait = { _, reason ->
            _orbState.value = OrbState.THINKING
            _status.value = "KOTA BEKLENİYOR"
            quotaWaitCount++
            // reason Mistral'in ham hata metni ("gemini-3.8-flash → HTTP 429:
            // {...RESOURCE_EXHAUSTED...}" gibi).
            // Ekranı kirletmemek için kısaltılıp log'a ekleniyor ki kullanıcı
            // "gerçekten dolu mu" diye şüphelenmeden kendi gözüyle görsün.
            val shortReason = reason.take(900)
            if (quotaWaitCount == 1) {
                addLog("sys", "Kota şu an dolu ($shortReason), görev yarım bırakılmıyor — 1 dakikada bir kontrol edilip kota açılınca otomatik devam edilecek.")
            } else if (quotaWaitCount % 5 == 0) {
                addLog("sys", "Hâlâ deniyorum (yaklaşık ${quotaWaitCount} dakikadır kota bekleniyor, $shortReason) — bulduğum an devam edeceğim.")
            }
        }

        viewModelScope.launch {
            val problem = client.verifyKey()
            if (problem != null) {
                _orbState.value = OrbState.ERROR
                _status.value = "HATA"
                _isConnected.value = false
                addLog("sys", problem)
                return@launch
            }
            _isConnected.value = true
            _orbState.value = OrbState.IDLE
            _status.value = "HAZIR"
            addLog("sys", "Bağlandı. Mikrofonu aç ya da yazarak konuş.")
            if (_micOn.value) {
                _orbState.value = OrbState.LISTENING
                _status.value = "DİNLİYOR"
                voice.startListening()
            }
        }
    }

    fun toggleMic() {
        val busy = _orbState.value == OrbState.SPEAKING ||
            _orbState.value == OrbState.THINKING ||
            MusicService.isActive
        when {
            // Mikrofon zaten açık ama Jarvis konuşuyor / şarkı çalıyor / cevap
            // hazırlıyor: kapatma, sadece sustur ve seni dinlemeye başla.
            _micOn.value && busy -> {
                silenceOutputs()
                if (_isConnected.value) {
                    _orbState.value = OrbState.LISTENING
                    _status.value = "DİNLİYOR"
                    voice.startListening()
                }
                addLog("sys", "Dinliyorum")
            }
            _micOn.value -> stopMic()
            else -> startMic()
        }
    }

    /** Konuşmayı, çalan şarkıyı ve bekleyen cevap isteğini keser. */
    private fun silenceOutputs() {
        chatJob?.cancel()
        voice.stopSpeaking()
        if (MusicService.isActive) MusicController.stop(getApplication())
    }

    /** "DURDUR" butonu: oturumu tamamen kapatır, mikrofonu ve TTS'i susturur. */
    fun stop() {
        // Kota beklerken sonsuza kadar (1dk arayla) yeniden deneyen chatJob
        // olabilir -- DURDUR'a basınca bu bekleyiş de gerçekten kesilsin.
        chatJob?.cancel()
        stopMic()
        voice.stopSpeaking()
        _isConnected.value = false
        _orbState.value = OrbState.IDLE
        _status.value = "DURDURULDU"
        addLog("sys", "Oturum durduruldu.")
    }

    private fun startMic() {
        silenceOutputs()
        _micOn.value = true
        if (_isConnected.value) {
            _orbState.value = OrbState.LISTENING
            _status.value = "DİNLİYOR"
            voice.startListening()
        }
        addLog("sys", "Mikrofon açık")
    }

    private fun stopMic() {
        _micOn.value = false
        voice.stopListening()
        if (_orbState.value == OrbState.LISTENING) {
            _orbState.value = OrbState.IDLE
            _status.value = "HAZIR"
        }
        addLog("sys", "Mikrofon kapalı")
    }

    fun sendText(text: String) {
        val typed = text.trim()
        val attached = _attachments.value
        if (typed.isEmpty() && attached.isEmpty()) return
        val client = textClient
        if (client == null) {
            addLog("sys", "Önce bağlanmak gerekiyor.")
            return
        }

        val images = attached.flatMap { it.imageDataUrls }.take(AttachmentLoader.MAX_IMAGES)
        val names = attached.joinToString(", ") { it.name }

        chatJob?.cancel()
        chatJob = viewModelScope.launch {
            val app = getApplication<Application>()
            // Önceki soru iptal edildiyse (düşünürken yeni soru soruldu) cevapsız
            // kalan kaydı temizle ki model eski soruyu cevaplamasın.
            dropUnansweredUserTurns()

            if (attached.isEmpty()) {
                // "Kamerayı başlat", "kamerayı ve şarkıyı başlat", "favori
                // şarkım ... olsun", "oyun oynayalım", "aktivite öner" gibi
                // EYLEM gerektiren ama tamamen cihaz üzerinde yapılabilen
                // istekler -- Mistral'e hiç gitmeden anında işlenir.
                val delegated = OfflineActionRouter.isDelegatedCommand(typed)
                val actionResult = if (delegated) null else OfflineActionRouter.tryHandle(app, typed)
                if (actionResult != null) {
                    addLog("user", typed)
                    conversation += "user" to typed
                    conversation += "model" to actionResult.reply
                    trimHistory()
                    persistConversation()
                    addLog("jarvis", actionResult.reply)
                    voice.speak(actionResult.reply)
                    return@launch
                }

                // "Selam, nasılsın, saat kaç" gibi GERÇEKTEN internet
                // gerektirmeyen basit istekler -- Mistral'e hiç gitmeden,
                // anında ve internet olmasa bile cihaz üzerinde cevaplanır
                // (bkz. OfflineResponder).
                val offlineReply = if (delegated) null else OfflineResponder.tryRespond(app, typed)
                if (offlineReply != null) {
                    addLog("user", typed)
                    conversation += "user" to typed
                    conversation += "model" to offlineReply
                    trimHistory()
                    persistConversation()
                    addLog("jarvis", offlineReply)
                    voice.speak(offlineReply)
                    return@launch
                }
                // Eşleşmediyse VE internet de yoksa: Mistral'i hiç deneme --
                // uzun bir zaman aşımı bekletip sonra hata vermek yerine
                // kullanıcıya doğrudan ve dürüstçe söyle.
                if (!OfflineResponder.hasInternet(app)) {
                    addLog("user", typed)
                    conversation += "user" to typed
                    val msg = "İnternet bağlantım yok efendim, bu isteği çevrimdışı yapamıyorum. Bağlantı gelince tekrar sorar mısınız?"
                    conversation += "model" to msg
                    trimHistory()
                    persistConversation()
                    addLog("jarvis", msg)
                    voice.speak(msg)
                    return@launch
                }
            }

            // Kullanıcı sadece ek gönderdiyse modele ne yapması gerektiğini söyle.
            val question = typed.ifEmpty {
                if (images.isNotEmpty()) "Bunu incele ve kısaca anlat." else "Bu dosyayı incele ve kısaca özetle."
            }

            // Ekranda görünen ve geçmişe (kalıcı olarak) yazılan KISA hal: dosya
            // içeriği/fotoğraf geçmişe yazılmaz (hem DataStore hem token şişmesin).
            val shownText = if (attached.isEmpty()) typed else listOf(typed, "📎 $names").filter { it.isNotEmpty() }.joinToString("\n")
            val historyText = if (attached.isEmpty()) question else "$question\n[Ekler: $names]"

            // Modele bu turda giden TAM metin: soru + metin dosyalarının içerikleri.
            val fileBlocks = attached.filter { it.text != null || it.hint != null }.joinToString("\n\n") { a ->
                buildString {
                    append("----- EK DOSYA: ${a.name}")
                    if (a.truncated) append(" (uzun olduğu için yalnızca ilk kısmı)")
                    append(" -----")
                    a.text?.let { append("\n").append(it) }
                    a.hint?.let { append("\n(").append(it).append(")") }
                    append("\n----- DOSYA SONU -----")
                }
            }
            val modelText = if (fileBlocks.isEmpty()) historyText else "$historyText\n\n$fileBlocks"

            _attachments.value = emptyList()
            addLog("user", shownText)
            conversation += "user" to historyText
            trimHistory()
            persistConversation()
            quotaWaitCount = 0
            _orbState.value = OrbState.THINKING
            _status.value = "DÜŞÜNÜYOR"

            val deviceContext = DeviceInfo.snapshot(app, _weather.value) +
                MemoryStore.contextBlock(app) +
                ReminderStore.contextBlock(app)
            val result = client.sendMessage(conversation, deviceContext, modelText, images)
            // Bu iş bu arada iptal edildiyse (yeni soru soruldu) sonucu uygulama.
            ensureActive()
            result.onSuccess { reply ->
                // Kota beklenip sonra açıldıysa kullanıcı fark etsin diye
                // asıl cevaptan önce ayrı bir bilgi satırı düşülüyor.
                if (quotaWaitCount > 0) {
                    addLog("sys", "Kota açıldı, kaldığı yerden devam ediliyor.")
                    quotaWaitCount = 0
                }
                conversation += "model" to reply
                trimHistory()
                persistConversation()
                addLog("jarvis", reply)
                refreshMemoryCount()
                voice.speak(reply) // onSpeechStart/onSpeechDone orb durumunu kendisi günceller
            }
            result.onFailure { e ->
                // Cevaplanamayan soru geçmişte kalmasın (sonraki soruyla karışmasın).
                if (dropUnansweredUserTurns()) persistConversation()
                _orbState.value = OrbState.ERROR
                _status.value = "HATA"
                addLog("sys", "Cevap alınamadı: ${e.message}")
                // Mikrofon açıksa hata sonrası dinlemeye devam et, kullanıcı takılıp kalmasın.
                if (_micOn.value) {
                    _orbState.value = OrbState.LISTENING
                    _status.value = "DİNLİYOR"
                    voice.startListening()
                }
            }
        }
    }

    /** Sondaki cevapsız "user" kayıtlarını siler; bir şey silindiyse true. */
    private fun dropUnansweredUserTurns(): Boolean {
        var dropped = false
        while (conversation.isNotEmpty() && conversation.last().first == "user") {
            conversation.removeAt(conversation.lastIndex)
            dropped = true
        }
        return dropped
    }

    private fun trimHistory() {
        val maxEntries = maxHistoryTurns * 2
        if (conversation.size > maxEntries) {
            val excess = conversation.size - maxEntries
            repeat(excess) { conversation.removeAt(0) }
        }
    }

    private fun addLog(who: String, text: String, attachment: FileTool.StagedFile? = null) {
        _logs.update { list ->
            (list + LogLine(who, text, attachment)).takeLast(40)
        }
    }

    /**
     * Sohbetteki bir ek dosyanın (create_file/create_zip/create_image
     * tarafından hazırlanan) yanındaki "Kaydet" düğmesine basınca çağrılır
     * -- GERÇEKTEN cihaza (İndirilenler/Resimler) yazar.
     */
    fun saveAttachmentToDevice(staged: FileTool.StagedFile) {
        viewModelScope.launch {
            try {
                val saved = withContext(Dispatchers.IO) {
                    FileTool.persistStagedFile(getApplication(), staged)
                }
                addLog("sys", "Kaydedildi: ${saved.displayPath}")
            } catch (e: Exception) {
                addLog("sys", "Kaydedilemedi: ${e.message}")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopMic()
        voice.release()
        // Uygulama kökten kapatılınca müzik de dursun -- MusicService kendi
        // onTaskRemoved()'ında zaten duruyor, bu sadece ek bir güvence.
        MusicController.stop(getApplication())
    }
}

data class LogLine(val who: String, val text: String, val attachment: FileTool.StagedFile? = null)
