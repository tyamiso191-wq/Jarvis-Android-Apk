package com.jarvis.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.jarvis.ai.theme.JarvisTheme
import com.jarvis.ai.ui.ApiKeyScreen
import com.jarvis.ai.ui.MainScreen

class MainActivity : ComponentActivity() {

    private val vm: JarvisViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            // Mic permission granted – user can toggle mic
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        setContent {
            JarvisTheme {
                val needsKey by vm.needsKey.collectAsState()
                val orbState by vm.orbState.collectAsState()
                val status by vm.status.collectAsState()
                val logs by vm.logs.collectAsState()
                val micOn by vm.micOn.collectAsState()
                val level by vm.audioLevel.collectAsState()
                val apiKey by vm.apiKey.collectAsState()

                LaunchedEffect(apiKey) {
                    if (!apiKey.isNullOrBlank()) {
                        vm.connect(apiKey!!)
                    }
                }

                if (needsKey) {
                    ApiKeyScreen(onSave = { key ->
                        vm.saveApiKey(key)
                    })
                } else {
                    MainScreen(
                        orbState = orbState,
                        status = status,
                        logs = logs,
                        micOn = micOn,
                        audioLevel = level,
                        onToggleMic = {
                            ensureMicPermission {
                                vm.toggleMic()
                            }
                        },
                        onSendText = { vm.sendText(it) }
                    )
                }
            }
        }
    }

    private fun ensureMicPermission(onGranted: () -> Unit) {
        when {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED -> onGranted()
            else -> permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
}
