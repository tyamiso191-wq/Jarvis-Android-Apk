package com.jarvis.ai.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.jarvis.ai.theme.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun JarvisOrb(
    state: OrbState,
    audioLevel: Float = 0f,
    modifier: Modifier = Modifier
) {
    val infinite = rememberInfiniteTransition(label = "orb")

    val rotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rot"
    )

    val pulse by infinite.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val color = when (state) {
        OrbState.LISTENING -> Green
        OrbState.SPEAKING -> Blue
        OrbState.THINKING -> Gold
        OrbState.MUTED -> Muted
        OrbState.ERROR -> Red
        OrbState.CONNECTING -> Orange
        OrbState.IDLE -> Teal
    }

    val level = audioLevel.coerceIn(0f, 1f)
    val scale = pulse + level * 0.25f

    Canvas(modifier = modifier.size(280.dp)) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val baseR = size.minDimension / 2f * 0.38f * scale

        // Outer glow rings
        for (i in 3 downTo 1) {
            val r = baseR + i * 28f + level * 12f
            drawCircle(
                color = color.copy(alpha = 0.06f + (3 - i) * 0.03f),
                radius = r,
                center = Offset(cx, cy),
                style = Stroke(width = 1.5f)
            )
        }

        // Rotating segmented arcs
        rotate(rotation, Offset(cx, cy)) {
            val arcR = baseR + 42f
            val stroke = Stroke(width = 3f, cap = StrokeCap.Round)
            listOf(0f, 90f, 180f, 270f).forEach { start ->
                drawArc(
                    color = color.copy(alpha = 0.55f),
                    startAngle = start,
                    sweepAngle = 42f,
                    useCenter = false,
                    topLeft = Offset(cx - arcR, cy - arcR),
                    size = Size(arcR * 2, arcR * 2),
                    style = stroke
                )
            }
        }

        // Counter-rotating thin ring
        rotate(-rotation * 1.4f, Offset(cx, cy)) {
            val r2 = baseR + 22f
            drawArc(
                color = color.copy(alpha = 0.35f),
                startAngle = 20f,
                sweepAngle = 140f,
                useCenter = false,
                topLeft = Offset(cx - r2, cy - r2),
                size = Size(r2 * 2, r2 * 2),
                style = Stroke(width = 1.5f)
            )
            drawArc(
                color = color.copy(alpha = 0.35f),
                startAngle = 200f,
                sweepAngle = 140f,
                useCenter = false,
                topLeft = Offset(cx - r2, cy - r2),
                size = Size(r2 * 2, r2 * 2),
                style = Stroke(width = 1.5f)
            )
        }

        // Core filled circle
        drawCircle(
            color = color.copy(alpha = 0.18f),
            radius = baseR,
            center = Offset(cx, cy)
        )
        drawCircle(
            color = color.copy(alpha = 0.9f),
            radius = baseR * 0.22f,
            center = Offset(cx, cy)
        )

        // Inner dashed ring
        val dashR = baseR * 0.72f
        val dashes = 24
        for (i in 0 until dashes) {
            val a = Math.toRadians((i * 360.0 / dashes) + rotation * 0.3)
            val x1 = cx + cos(a).toFloat() * (dashR - 4)
            val y1 = cy + sin(a).toFloat() * (dashR - 4)
            val x2 = cx + cos(a).toFloat() * (dashR + 4)
            val y2 = cy + sin(a).toFloat() * (dashR + 4)
            drawLine(
                color = color.copy(alpha = 0.45f),
                start = Offset(x1, y1),
                end = Offset(x2, y2),
                strokeWidth = 2f,
                cap = StrokeCap.Round
            )
        }
    }
}
