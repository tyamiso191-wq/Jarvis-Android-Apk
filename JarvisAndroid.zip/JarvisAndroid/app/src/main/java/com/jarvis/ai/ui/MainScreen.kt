package com.jarvis.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.LogLine
import com.jarvis.ai.theme.*
import kotlinx.coroutines.launch

@Composable
fun MainScreen(
    orbState: OrbState,
    status: String,
    logs: List<LogLine>,
    micOn: Boolean,
    audioLevel: Float,
    onToggleMic: () -> Unit,
    onSendText: (String) -> Unit
) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            scope.launch { listState.animateScrollToItem(logs.lastIndex) }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Panel)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "J.A.R.V.I.S",
                    color = Teal,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 3.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "MOBILE",
                    color = Dim,
                    fontSize = 10.sp,
                    letterSpacing = 2.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            StatusBadge(orbState)
        }

        // Orb + status
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            JarvisOrb(
                state = orbState,
                audioLevel = audioLevel,
                modifier = Modifier.size(260.dp)
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = status,
                color = Dim,
                fontSize = 12.sp,
                letterSpacing = 2.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        // Log
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 160.dp)
                .padding(horizontal = 14.dp),
            reverseLayout = false
        ) {
            items(logs) { line ->
                LogRow(line)
            }
        }

        // Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            Button(
                onClick = onToggleMic,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (micOn) Teal else TealMid,
                    contentColor = if (micOn) Bg else Teal
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .height(48.dp)
                    .widthIn(min = 140.dp)
            ) {
                Text(
                    if (micOn) "🎙️  MIC AÇIK" else "🎙️  MIC",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }

        // Text input
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .padding(bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = {
                    Text("Yazılı komut gönder…", color = Dim, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        onSendText(input)
                        input = ""
                    }
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Teal,
                    unfocusedBorderColor = TealDim,
                    focusedTextColor = Text,
                    unfocusedTextColor = Text,
                    cursorColor = Teal
                ),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            IconButton(
                onClick = {
                    onSendText(input)
                    input = ""
                },
                modifier = Modifier
                    .size(48.dp)
                    .background(Teal, RoundedCornerShape(8.dp))
            ) {
                Text("➤", color = Bg, fontSize = 18.sp)
            }
        }
    }
}

@Composable
private fun StatusBadge(state: OrbState) {
    val (label, color) = when (state) {
        OrbState.LISTENING -> "DİNLİYOR" to Green
        OrbState.SPEAKING -> "KONUŞUYOR" to Blue
        OrbState.THINKING -> "DÜŞÜNÜYOR" to Gold
        OrbState.CONNECTING -> "BAĞLANIYOR" to Orange
        OrbState.ERROR -> "HATA" to Red
        OrbState.MUTED -> "SESSİZ" to Muted
        OrbState.IDLE -> "HAZIR" to Dim
    }
    Text(
        text = label,
        color = color,
        fontSize = 10.sp,
        letterSpacing = 1.sp,
        fontFamily = FontFamily.Monospace,
        modifier = Modifier
            .background(color.copy(alpha = 0.12f), RoundedCornerShape(4.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
private fun LogRow(line: LogLine) {
    val (prefix, color) = when (line.who) {
        "user" -> "SİZ:" to Teal
        "jarvis" -> "JARVIS:" to Green
        else -> "SYS:" to Dim
    }
    Row(modifier = Modifier.padding(vertical = 2.dp)) {
        Text(
            prefix,
            color = color,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.width(6.dp))
        Text(
            line.text,
            color = Text.copy(alpha = 0.85f),
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}
