package com.jarvis.ai

import android.app.Application
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.audio.AudioEngine
import com.jarvis.ai.live.GeminiLiveClient
import com.jarvis.ai.live.LiveEvent
import com.jarvis.ai.ui.OrbState
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

private val Application.dataStore by preferencesDataStore("jarvis_prefs")
private val KEY_API = stringPreferencesKey("gemini_api_key")

class JarvisViewModel(app: Application) : AndroidViewModel(app) {

    private val dataStore = app.dataStore
    private val audio = AudioEngine()
    private var client: GeminiLiveClient? = null

    private val _apiKey = MutableStateFlow<String?>(null)
    val apiKey: StateFlow<String?> = _apiKey.asStateFlow()

    private val _orbState = MutableStateFlow(OrbState.IDLE)
    val orbState: StateFlow<OrbState> = _orbState.asStateFlow()

    private val _status = MutableStateFlow("HAZIR")
    val status: StateFlow<String> = _status.asStateFlow()

    private val _logs = MutableStateFlow<List<LogLine>>(emptyList())
    val logs: StateFlow<List<LogLine>> = _logs.asStateFlow()

    private val _micOn = MutableStateFlow(false)
    val micOn: StateFlow<Boolean> = _micOn.asStateFlow()

    private val _level = audio.level
    val audioLevel: StateFlow<Float> = _level

    private val _needsKey = MutableStateFlow(true)
    val needsKey: StateFlow<Boolean> = _needsKey.asStateFlow()

    init {
        viewModelScope.launch {
            dataStore.data.map { it[KEY_API] }.collect { key ->
                _apiKey.value = key
                _needsKey.value = key.isNullOrBlank()
            }
        }
    }

    fun saveApiKey(key: String) {
        viewModelScope.launch {
            dataStore.edit { it[KEY_API] = key.trim() }
            _needsKey.value = false
            connect(key.trim())
        }
    }

    fun connect(key: String = _apiKey.value.orEmpty()) {
        if (key.isBlank()) {
            _needsKey.value = true
            return
        }
        client?.close()
        _orbState.value = OrbState.CONNECTING
        _status.value = "BAĞLANIYOR…"
        addLog("sys", "Gemini Live'a bağlanılıyor…")

        client = GeminiLiveClient(key).also { c ->
            viewModelScope.launch {
                c.events.collect { event ->
                    when (event) {
                        is LiveEvent.Ready -> {
                            _orbState.value = OrbState.LISTENING
                            _status.value = "DİNLİYOR"
                            addLog("sys", "Bağlandı. Konuşabilirsin.")
                            if (_micOn.value) startMic()
                        }
                        is LiveEvent.Audio -> {
                            _orbState.value = OrbState.SPEAKING
                            _status.value = "KONUŞUYOR"
                            audio.playPcm(event.pcm)
                        }
                        is LiveEvent.Text -> {
                            addLog("jarvis", event.text)
                        }
                        is LiveEvent.TurnComplete -> {
                            if (_micOn.value) {
                                _orbState.value = OrbState.LISTENING
                                _status.value = "DİNLİYOR"
                            } else {
                                _orbState.value = OrbState.IDLE
                                _status.value = "HAZIR"
                            }
                        }
                        is LiveEvent.Interrupted -> {
                            audio.stopPlayback()
                        }
                        is LiveEvent.Error -> {
                            _orbState.value = OrbState.ERROR
                            _status.value = "HATA"
                            addLog("sys", event.message)
                        }
                        is LiveEvent.Disconnected -> {
                            _orbState.value = OrbState.IDLE
                            _status.value = "BAĞLANTI KESİLDİ"
                            addLog("sys", "Bağlantı koptu: ${event.reason}")
                        }
                    }
                }
            }
            c.connect()
        }
    }

    fun toggleMic() {
        if (_micOn.value) {
            stopMic()
        } else {
            startMic()
        }
    }

    private fun startMic() {
        _micOn.value = true
        audio.onPcmChunk = { pcm ->
            client?.sendAudio(pcm)
        }
        audio.startRecording()
        if (client?.isReady() == true) {
            _orbState.value = OrbState.LISTENING
            _status.value = "DİNLİYOR"
        }
        addLog("sys", "Mikrofon açık")
    }

    private fun stopMic() {
        _micOn.value = false
        audio.stopRecording()
        audio.onPcmChunk = null
        if (_orbState.value == OrbState.LISTENING) {
            _orbState.value = OrbState.IDLE
            _status.value = "HAZIR"
        }
        addLog("sys", "Mikrofon kapalı")
    }

    fun sendText(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        addLog("user", t)
        _orbState.value = OrbState.THINKING
        _status.value = "DÜŞÜNÜYOR"
        client?.sendText(t)
    }

    private fun addLog(who: String, text: String) {
        _logs.update { list ->
            (list + LogLine(who, text)).takeLast(40)
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopMic()
        client?.close()
        audio.release()
    }
}

data class LogLine(val who: String, val text: String)
