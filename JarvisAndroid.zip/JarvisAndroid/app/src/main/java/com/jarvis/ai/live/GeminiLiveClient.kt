package com.jarvis.ai.live

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Gemini Live API client using WebSocket.
 * Model: gemini-2.5-flash-native-audio-preview (or latest live model).
 * Sends 16 kHz PCM16 audio, receives audio + text.
 */
class GeminiLiveClient(
    private val apiKey: String,
    private val systemInstruction: String = DEFAULT_SYSTEM,
    private val voiceName: String = "Charon"
) {
    companion object {
        private const val TAG = "GeminiLive"
        // Official Live endpoint (Google AI Studio key)
        private const val WS_URL =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent"

        // Prefer current live models; fall back gracefully
        private const val MODEL = "models/gemini-2.5-flash-preview-native-audio-dialog"

        val DEFAULT_SYSTEM = """
            Sen J.A.R.V.I.S'sin. Türkçe konuşan, zeki, yardımcı ve hafif esprili bir kişisel asistansın.
            Kısa ve net cevap ver. Kullanıcıya "efendim" diye hitap edebilirsin.
            Gereksiz uzun açıklama yapma. Sesli sohbet için uygunsun.
        """.trimIndent()
    }

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private var webSocket: WebSocket? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val connected = AtomicBoolean(false)
    private val setupDone = AtomicBoolean(false)

    private val _events = MutableSharedFlow<LiveEvent>(extraBufferCapacity = 64)
    val events: SharedFlow<LiveEvent> = _events

    fun connect() {
        if (connected.get()) return
        val url = "$WS_URL?key=$apiKey"
        val request = Request.Builder().url(url).build()
        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.i(TAG, "WebSocket open")
                connected.set(true)
                sendSetup()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleMessage(text)
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                Log.w(TAG, "Closing: $code $reason")
                connected.set(false)
                setupDone.set(false)
                scope.launch { _events.emit(LiveEvent.Disconnected(reason)) }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.e(TAG, "Failure", t)
                connected.set(false)
                setupDone.set(false)
                scope.launch {
                    _events.emit(LiveEvent.Error(t.message ?: "Bağlantı hatası"))
                }
            }
        })
    }

    private fun sendSetup() {
        val setup = JSONObject().apply {
            put("setup", JSONObject().apply {
                put("model", MODEL)
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().put("AUDIO"))
                    put("speechConfig", JSONObject().apply {
                        put("voiceConfig", JSONObject().apply {
                            put("prebuiltVoiceConfig", JSONObject().apply {
                                put("voiceName", voiceName)
                            })
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
                })
            })
        }
        webSocket?.send(setup.toString())
        Log.i(TAG, "Setup sent")
    }

    private fun handleMessage(text: String) {
        try {
            val json = JSONObject(text)

            if (json.has("setupComplete")) {
                setupDone.set(true)
                scope.launch { _events.emit(LiveEvent.Ready) }
                Log.i(TAG, "Setup complete")
                return
            }

            val serverContent = json.optJSONObject("serverContent") ?: return

            // Interrupted
            if (serverContent.optBoolean("interrupted", false)) {
                scope.launch { _events.emit(LiveEvent.Interrupted) }
            }

            // Model turn parts
            val modelTurn = serverContent.optJSONObject("modelTurn")
            modelTurn?.optJSONArray("parts")?.let { parts ->
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    // Inline audio
                    part.optJSONObject("inlineData")?.let { inline ->
                        val mime = inline.optString("mimeType", "")
                        val data = inline.optString("data", "")
                        if (data.isNotEmpty() && mime.contains("audio")) {
                            val bytes = Base64.decode(data, Base64.DEFAULT)
                            scope.launch { _events.emit(LiveEvent.Audio(bytes)) }
                        }
                    }
                    // Text
                    part.optString("text", "").takeIf { it.isNotBlank() }?.let { t ->
                        scope.launch { _events.emit(LiveEvent.Text(t)) }
                    }
                }
            }

            if (serverContent.optBoolean("turnComplete", false)) {
                scope.launch { _events.emit(LiveEvent.TurnComplete) }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Parse error", e)
        }
    }

    /** Send 16-bit PCM audio chunk (16 kHz mono recommended). */
    fun sendAudio(pcm16: ByteArray) {
        if (!setupDone.get()) return
        val b64 = Base64.encodeToString(pcm16, Base64.NO_WRAP)
        val msg = JSONObject().apply {
            put("realtimeInput", JSONObject().apply {
                put("mediaChunks", JSONArray().put(JSONObject().apply {
                    put("mimeType", "audio/pcm;rate=16000")
                    put("data", b64)
                }))
            })
        }
        webSocket?.send(msg.toString())
    }

    fun sendText(text: String) {
        if (!setupDone.get() || text.isBlank()) return
        val msg = JSONObject().apply {
            put("clientContent", JSONObject().apply {
                put("turns", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", text)))
                }))
                put("turnComplete", true)
            })
        }
        webSocket?.send(msg.toString())
    }

    fun close() {
        webSocket?.close(1000, "bye")
        webSocket = null
        connected.set(false)
        setupDone.set(false)
        scope.cancel()
    }

    fun isReady(): Boolean = setupDone.get()
}

sealed class LiveEvent {
    data object Ready : LiveEvent()
    data class Audio(val pcm: ByteArray) : LiveEvent()
    data class Text(val text: String) : LiveEvent()
    data object TurnComplete : LiveEvent()
    data object Interrupted : LiveEvent()
    data class Disconnected(val reason: String) : LiveEvent()
    data class Error(val message: String) : LiveEvent()
}
