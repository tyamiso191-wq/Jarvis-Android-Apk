package com.jarvis.ai.automation

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import com.jarvis.ai.social.SocialMessagingTool

/**
 * "Ahmet'e Instagram'dan 'selam' yaz" gibi komutları, uygulamayı küçük
 * pencerede açıp senin yerine yazıp göndererek yapar.
 *
 * NOT: Düğme/alan eşleştirmesi ekrandaki yazı/açıklamaya (TR + EN) ve bilinen
 * görünüm kimliklerine dayanır. Instagram/TikTok/WhatsApp arayüzlerini
 * güncelledikçe bir adım tutmayabilir -- o durumda sonuç "stage" alanıyla
 * hangi adımda takıldığını söyler ve pencere açık bırakılır (kalan adımı sen
 * tamamlayabilirsin).
 */
object AppAutomation {
    private const val TAG = "AppAutomation"

    const val PKG_INSTAGRAM = "com.instagram.android"
    const val PKG_TIKTOK = "com.zhiliaoapp.musically"
    const val PKG_TIKTOK_ALT = "com.ss.android.ugc.trill"
    const val PKG_WHATSAPP = "com.whatsapp"
    const val PKG_WHATSAPP_BIZ = "com.whatsapp.w4b"
    const val PKG_GOOGLE = "com.google.android.googlequicksearchbox"

    private val SEND_LABELS = listOf("send", "gönder", "gonder")
    private val MESSAGE_BUTTON_LABELS = listOf("message", "mesaj", "mesaj gönder", "send message")

    data class Outcome(
        val ok: Boolean,
        val stage: String,
        val message: String,
        val layout: MiniWindow.Layout? = null
    )

    fun accessibilityEnabled() = JarvisAccessibilityService.isEnabled()

    /** Erişilebilirlik ayarlarını açar (kullanıcı servisi bir kez etkinleştirir). */
    fun openAccessibilitySettings(context: Context) {
        try {
            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Log.w(TAG, "Erişilebilirlik ayarları açılamadı", e)
        }
    }

    // ─── Genel mesaj akışı ────────────────────────────────────────────────
    fun sendMessage(
        context: Context,
        platform: SocialMessagingTool.Platform,
        recipient: String,
        message: String
    ): Outcome {
        val svc = JarvisAccessibilityService.instance
            ?: return Outcome(false, "needs_accessibility", "Erişilebilirlik servisi kapalı")
        JarvisAccessibilityService.cancelRequested = false
        return try {
            svc.showOverlay("JARVIS ${platform.key} üzerinde yazıyor…")
            when (platform) {
                SocialMessagingTool.Platform.WHATSAPP -> whatsapp(context, svc, recipient, message)
                SocialMessagingTool.Platform.INSTAGRAM -> instagram(context, svc, recipient, message)
                SocialMessagingTool.Platform.TIKTOK -> tiktok(context, svc, recipient, message)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Akış hatası", e)
            Outcome(false, "exception", e.message ?: "Beklenmeyen hata")
        } finally {
            svc.hideOverlay()
        }
    }

    // ─── WhatsApp ─────────────────────────────────────────────────────────
    private fun whatsapp(ctx: Context, svc: JarvisAccessibilityService, recipient: String, message: String): Outcome {
        val pkg = when {
            MiniWindow.isInstalled(ctx, PKG_WHATSAPP) -> PKG_WHATSAPP
            MiniWindow.isInstalled(ctx, PKG_WHATSAPP_BIZ) -> PKG_WHATSAPP_BIZ
            else -> return Outcome(false, "not_installed", "WhatsApp yüklü değil")
        }
        val phone = SocialMessagingTool.resolvePhone(ctx, recipient)
            ?: return Outcome(false, "no_contact", "'$recipient' için kayıtlı numara yok")
        // Metin zaten dolu açılır; geriye sadece Gönder'e basmak kalır.
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://api.whatsapp.com/send?phone=$phone&text=${Uri.encode(message)}")
        ).setPackage(pkg)
        val layout = MiniWindow.launch(ctx, intent, pkg)
        if (!waitForPackage(svc, pkg, 8000)) return Outcome(false, "open", "WhatsApp ekranı açılmadı", layout)

        val sent = UiWait.until(10000) { clickSend(svc, pkg, listOf("$pkg:id/send")) }
        return if (sent) Outcome(true, "sent", "Mesaj gönderildi", layout)
        else Outcome(false, "send_button", "Gönder düğmesi bulunamadı", layout)
    }

    // ─── Instagram ────────────────────────────────────────────────────────
    private fun instagram(ctx: Context, svc: JarvisAccessibilityService, recipient: String, message: String): Outcome {
        if (!MiniWindow.isInstalled(ctx, PKG_INSTAGRAM)) return Outcome(false, "not_installed", "Instagram yüklü değil")
        val username = SocialMessagingTool.resolveUsername(ctx, SocialMessagingTool.Platform.INSTAGRAM, recipient)
        val directDeepLink = username != null
        var intent = if (directDeepLink) {
            Intent(Intent.ACTION_VIEW, Uri.parse("https://ig.me/m/$username")).setPackage(PKG_INSTAGRAM)
        } else {
            // Kullanıcı adı bilinmiyor: DM kutusunu aç, oradan ara.
            Intent(Intent.ACTION_VIEW, Uri.parse("instagram://direct_inbox")).setPackage(PKG_INSTAGRAM)
        }
        if (intent.resolveActivity(ctx.packageManager) == null) {
            // ig.me bağlantısını Instagram karşılamıyorsa profil bağlantısı + "Mesaj" düğmesi.
            intent = if (directDeepLink) Intent(Intent.ACTION_VIEW, Uri.parse("instagram://user?username=$username")).setPackage(PKG_INSTAGRAM)
            else MiniWindow.launcherIntentFor(ctx, PKG_INSTAGRAM) ?: intent
        }
        val layout = MiniWindow.launch(ctx, intent, PKG_INSTAGRAM)
        if (!waitForPackage(svc, PKG_INSTAGRAM, 8000)) return Outcome(false, "open", "Instagram açılmadı", layout)

        if (!directDeepLink) {
            if (!searchAndOpenChat(svc, PKG_INSTAGRAM, recipient)) {
                return Outcome(false, "search", "'$recipient' DM aramasında bulunamadı", layout)
            }
        }
        return typeAndSend(svc, PKG_INSTAGRAM, message, layout, tapMessageButtonFirst = true,
            sendIds = listOf("$PKG_INSTAGRAM:id/row_thread_composer_button_send"),
            inputIds = listOf("$PKG_INSTAGRAM:id/row_thread_composer_edittext"))
    }

    // ─── TikTok ───────────────────────────────────────────────────────────
    private fun tiktok(ctx: Context, svc: JarvisAccessibilityService, recipient: String, message: String): Outcome {
        val pkg = when {
            MiniWindow.isInstalled(ctx, PKG_TIKTOK) -> PKG_TIKTOK
            MiniWindow.isInstalled(ctx, PKG_TIKTOK_ALT) -> PKG_TIKTOK_ALT
            else -> return Outcome(false, "not_installed", "TikTok yüklü değil")
        }
        val username = SocialMessagingTool.resolveUsername(ctx, SocialMessagingTool.Platform.TIKTOK, recipient)
            ?: return Outcome(false, "no_contact", "'$recipient' için TikTok kullanıcı adı kayıtlı değil")
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/@$username")).setPackage(pkg)
        val layout = MiniWindow.launch(ctx, intent, pkg)
        if (!waitForPackage(svc, pkg, 8000)) return Outcome(false, "open", "TikTok açılmadı", layout)
        return typeAndSend(svc, pkg, message, layout, tapMessageButtonFirst = true,
            sendIds = emptyList(), inputIds = emptyList())
    }

    // ─── Google ───────────────────────────────────────────────────────────
    fun googleSearch(context: Context, query: String): Outcome {
        val svc = JarvisAccessibilityService.instance
            ?: return Outcome(false, "needs_accessibility", "Erişilebilirlik servisi kapalı")
        JarvisAccessibilityService.cancelRequested = false
        return try {
            svc.showOverlay("JARVIS Google'da arıyor…")
            val pkg = if (MiniWindow.isInstalled(context, PKG_GOOGLE)) PKG_GOOGLE else "com.android.chrome"
            var intent = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, query).setPackage(PKG_GOOGLE)
            if (intent.resolveActivity(context.packageManager) == null) {
                intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}"))
                if (MiniWindow.isInstalled(context, pkg)) intent.setPackage(pkg)
            }
            val layout = MiniWindow.launch(context, intent, pkg)
            Outcome(true, "opened", "Google araması küçük pencerede açıldı", layout)
        } catch (e: Exception) {
            Outcome(false, "exception", e.message ?: "Beklenmeyen hata")
        } finally {
            svc.hideOverlay()
        }
    }

    // ─── Herhangi bir uygulamayı küçük pencerede aç ───────────────────────
    fun openInMiniWindow(context: Context, pkg: String): Outcome {
        val intent = MiniWindow.launcherIntentFor(context, pkg)
            ?: return Outcome(false, "not_installed", "Uygulama yüklü değil")
        val layout = MiniWindow.launch(context, intent, pkg)
        return Outcome(true, "opened", "Uygulama küçük pencerede açıldı", layout)
    }

    // ─── Ortak adımlar ────────────────────────────────────────────────────
    private fun waitForPackage(svc: JarvisAccessibilityService, pkg: String, timeoutMs: Long): Boolean =
        UiWait.until(timeoutMs) { svc.rootFor(pkg) != null }

    /** "Mesaj" düğmesine (varsa) bas, yazı alanını bul, yaz, gönder. */
    private fun typeAndSend(
        svc: JarvisAccessibilityService, pkg: String, message: String, layout: MiniWindow.Layout,
        tapMessageButtonFirst: Boolean, sendIds: List<String>, inputIds: List<String>
    ): Outcome {
        var input: AccessibilityNodeInfo? = null
        var triedMessageButton = false
        val foundInput = UiWait.until(15000, 400) {
            val root = svc.rootFor(pkg) ?: return@until false
            input = findInput(svc, root, inputIds)
            if (input == null && tapMessageButtonFirst && !triedMessageButton) {
                val btn = svc.findAll(root) { n ->
                    (n.isClickable || n.parent?.isClickable == true) &&
                        svc.labelOf(n).trim().lowercase() in MESSAGE_BUTTON_LABELS
                }.firstOrNull()
                if (btn != null && svc.click(btn)) triedMessageButton = true
            }
            input != null
        }
        val field = input
        if (!foundInput || field == null) return Outcome(false, "input", "Mesaj yazma alanı bulunamadı", layout)

        // İnsan gibi: önce alana dokun, sonra yaz.
        if (!svc.setText(field, message)) return Outcome(false, "typing", "Metin yazılamadı", layout)
        UiWait.sleep(500)

        val sent = UiWait.until(8000, 400) { clickSend(svc, pkg, sendIds) }
        return if (sent) Outcome(true, "sent", "Mesaj gönderildi", layout)
        else Outcome(false, "send_button", "Gönder düğmesi bulunamadı (mesaj yazıldı, sen gönderebilirsin)", layout)
    }

    private fun findInput(svc: JarvisAccessibilityService, root: AccessibilityNodeInfo, ids: List<String>): AccessibilityNodeInfo? {
        for (id in ids) {
            root.findAccessibilityNodeInfosByViewId(id).firstOrNull { it.isEditable }?.let { return it }
        }
        return svc.findAll(root) { it.isEditable && it.isEnabled }.lastOrNull()
    }

    private fun clickSend(svc: JarvisAccessibilityService, pkg: String, ids: List<String>): Boolean {
        val root = svc.rootFor(pkg) ?: return false
        for (id in ids) {
            val n = root.findAccessibilityNodeInfosByViewId(id).firstOrNull()
            if (n != null && svc.click(n)) return true
        }
        val byLabel = svc.findAll(root) { n ->
            !n.isEditable && svc.labelOf(n).trim().lowercase() in SEND_LABELS
        }.firstOrNull() ?: return false
        return svc.click(byLabel)
    }

    /** Kullanıcı adı bilinmeyen kişi için DM kutusundaki arama alanını kullan. */
    private fun searchAndOpenChat(svc: JarvisAccessibilityService, pkg: String, name: String): Boolean {
        var searched = false
        val found = UiWait.until(15000, 500) {
            val root = svc.rootFor(pkg) ?: return@until false
            if (!searched) {
                val box = svc.findAll(root) { it.isEditable }.firstOrNull()
                    ?: svc.findAll(root) { n ->
                        val l = svc.labelOf(n).lowercase()
                        l == "search" || l == "ara" || l.startsWith("search") || l.startsWith("ara ")
                    }.firstOrNull()?.also { svc.click(it) }
                if (box != null && box.isEditable && svc.setText(box, name)) searched = true
                return@until false
            }
            // Sonuç: kişinin adını taşıyan ilk tıklanabilir satır.
            val row = svc.findAll(root) { n ->
                !n.isEditable && svc.labelOf(n).contains(name, ignoreCase = true)
            }.firstOrNull()
            row != null && svc.click(row)
        }
        return found
    }
}
